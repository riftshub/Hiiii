// Night Owl Market: shared settings

/** Co-op relay on the same Render server as the Minecraft world (path /market) */
export const COOP_SERVER = 'wss://gl-1-ku5b.onrender.com/market'

export const coopServerUrl = () => {
  const { hostname, protocol, host } = window.location
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    const port = new URLSearchParams(location.search).get('relayPort') || '8080'
    return `${protocol === 'https:' ? 'wss' : 'ws'}://${hostname}:${port}/market`
  }
  if (hostname.endsWith('.onrender.com')) return `wss://${host}/market`
  return COOP_SERVER
}
