// Creeps: game loop, floors, co-op glue, rendering.
import * as THREE from 'three'
import { buildFloor, floorParams, DOOR_W } from './level.js'
import { ROOM, WALL_H } from './rooms.js'
import { Entities, peekerModel, mannequinModel, mimicModel, stalkerModel, tokenMesh, catModel } from './entities.js'
import { input, initInput, initTouchControls, consumePressed, consumeLook } from './input.js'
import { initGamepad, BTN } from '../../gamekit/gamepad.js'
import { net, on, connect, disconnect, sendAll, sendHost, sendTo } from '../../gamekit/net.js'
import { createAvatar } from '../../gamekit/avatar.js'
import { bindFullscreenButtons } from '../../gamekit/fullscreen.js'
import * as A from './audio.js'
import { DEFAULT_SETTINGS, isTouchDevice, coopServerUrl, WALK, SPRINT, CROUCH, RADIUS, EYE, CROUCH_EYE, STAMINA_DRAIN, STAMINA_REGEN, RESPAWN_SECONDS, CAT_UNLOCK_FLOOR } from './config.js'

const $ = s => document.querySelector(s)
const store = {
  get (k, fallback) { try { return { ...fallback, ...JSON.parse(localStorage.getItem(k) || '{}') } } catch { return { ...fallback } } },
  set (k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} },
}
const settings = store.get('creeps.settings', DEFAULT_SETTINGS)
const progress = store.get('creeps.progress', { maxFloor: 1, xp: 0, catUnlocked: false, deaths: 0, floorsCleared: 0 })
const saveSettings = () => store.set('creeps.settings', settings)
const saveProgress = () => store.set('creeps.progress', progress)
const playerLevel = () => 1 + Math.floor(Math.sqrt(progress.xp / 40))
let myName = (() => { try { return localStorage.getItem('creeps.name') || '' } catch { return '' } })() || `Kid ${Math.floor(100 + Math.random() * 900)}`
const touch = isTouchDevice()
const quality = settings.quality === 'auto' ? (touch ? 'low' : 'high') : settings.quality
const HIGH = quality === 'high'
document.body.classList.toggle('touch-ui', touch)

// ═════════════ renderer ═════════════
const canvas = $('#view')
const renderer = new THREE.WebGLRenderer({ canvas, antialias: HIGH, powerPreference: 'high-performance' })
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, HIGH ? 1.5 : 1))
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 1.1
renderer.shadowMap.enabled = HIGH
const scene = new THREE.Scene()
scene.background = new THREE.Color(0x0b080d)
scene.fog = new THREE.FogExp2(0x0b080d, 0.07)
const camera = new THREE.PerspectiveCamera(74, 1, 0.05, 200)
camera.rotation.order = 'YXZ'
scene.add(camera)
const resize = () => { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix() }
addEventListener('resize', resize)
resize()

const hemi = new THREE.HemisphereLight(0x3a3046, 0x0c0a0e, 0.35)
scene.add(hemi)
const torch = new THREE.SpotLight(0xfff0d6, 0, 24, 0.55, 0.75, 1.5)
torch.position.set(0.12, -0.1, 0)
torch.castShadow = HIGH
torch.shadow.mapSize.set(1024, 1024)
torch.shadow.bias = -0.0008
camera.add(torch, torch.target)
torch.target.position.set(0.04, -0.06, -1)
const roomLights = Array.from({ length: HIGH ? 5 : 3 }, () => { const l = new THREE.PointLight(0xfff4dc, 0, 13, 1.5); scene.add(l); return l })
const glowLights = Array.from({ length: 2 }, () => { const l = new THREE.PointLight(0x7dff9a, 0, 8, 1.6); scene.add(l); return l })

// ═════════════ state ═════════════
const G = {
  mode: 'title', // title | playing | dead | loading
  floor: 1, entitiesOn: true, F: null, ents: null,
  tokens: new Set(), items: new Set(), glows: [], toys: [], exitOpen: false, liftAt: 0, liftCountdown: 0,
  visuals: { tokens: new Map(), items: new Map(), ents: new Map(), lamps: [], glowMeshes: new Map(), toyMeshes: new Map() },
  entState: new Map(), registry: new Map(), avatars: new Map(), coop: false,
  fear: 0, heartbeatAt: 0, lastWorld: 0, lastState: 0, paused: false, jumpscare: null, hiddenSpot: null, breath: null,
  cat: null, catState: { x: 0, z: 0, yaw: 0, alertAt: 0, alert: false, adopted: false, stray: null }, xpFloor: 0,
  selectedFloor: 1, deathsThisFloor: 0, lastAmbient: 0,
}
const P = {
  x: 0, z: 0, yaw: 0, pitch: 0, crouch: false, crouchT: 0, moving: false, sprinting: false, speed: 0, stamina: 100, boostUntil: 0,
  flashlight: true, inv: { soda: 0, glowstick: 0, windup: 0 }, hidden: null, hiddenSeen: false,
  breath: 1, holdingBreath: false, dead: false, bob: 0, stepDist: 0, shake: 0,
}
const myId = () => net.id ?? 'local'
const isHost = () => net.isHost
const now = () => performance.now()

// ═════════════ floors ═════════════
function loadFloor (n, entitiesOn) {
  $('#loading').style.display = 'block'
  if (G.F) {
    G.F.dispose()
    for (const m of [...G.visuals.tokens.values(), ...G.visuals.items.values(), ...G.visuals.glowMeshes.values(), ...G.visuals.toyMeshes.values()]) scene.remove(m)
    for (const v of G.visuals.ents.values()) scene.remove(v.root)
    for (const l of G.visuals.lamps) scene.remove(l.mesh)
    if (G.catState.stray) { scene.remove(G.catState.stray.root); G.catState.stray = null }
  }
  G.visuals = { tokens: new Map(), items: new Map(), ents: new Map(), lamps: [], glowMeshes: new Map(), toyMeshes: new Map() }
  G.floor = n
  G.entitiesOn = entitiesOn
  G.F = buildFloor(scene, n, { entities: entitiesOn, quality })
  const F = G.F
  G.tokens = new Set(); G.items = new Set(); G.glows = []; G.toys = []; G.exitOpen = false; G.liftAt = 0
  G.deathsThisFloor = 0
  // tokens + items
  for (const t of F.tokens) { const m = tokenMesh(); m.position.set(t.x, t.y + 0.18, t.z); scene.add(m); G.visuals.tokens.set(t.id, m) }
  for (const it of F.items) { const m = itemMesh(it.kind); m.position.set(it.x, it.y + 0.02, it.z); scene.add(m); G.visuals.items.set(it.id, m) }
  // lamp panels (each its own material so it can flicker)
  for (const l of F.lights) {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.5), new THREE.MeshStandardMaterial({ color: 0x222222, emissive: l.color, emissiveIntensity: 0 }))
    mesh.rotation.x = Math.PI / 2
    mesh.position.set(l.x, WALL_H - 0.06, l.z)
    scene.add(mesh)
    // some rooms just have their lights off
    l.off = !l.broken && F.rng() < 0.18
    G.visuals.lamps.push({ l, mesh })
  }
  // entities (everyone builds the same set from the floor data)
  const add = (id, type, model) => { scene.add(model.root); G.visuals.ents.set(id, { type, ...model }) }
  F.mannequins.forEach((m, i) => { const v = mannequinModel(i + n * 7); v.root.position.set(m.x, 0, m.z); v.root.rotation.y = m.yaw; add(m.id, 'mannequin', v) })
  F.mimics.forEach(m => { const v = mimicModel(); v.root.position.set(m.x, m.y, m.z); add(m.id, 'mimic', v) })
  for (let k = 0; k < F.params.peekers; k++) { const v = peekerModel(); v.root.visible = false; add(`p${k}`, 'peeker', v) }
  if (F.params.stalker) add('s0', 'stalker', stalkerModel())
  G.entState = new Map()
  G.ents = isHost() ? new Entities(F, entHooks, F.params) : null
  if (G.ents) for (const e of G.ents.list) G.entState.set(e.id, { ...e })
  // the stray cat waits in the lobby on floor 5
  if (!progress.catUnlocked && n >= CAT_UNLOCK_FLOOR) {
    const stray = catModel(0xd08a3a)
    const s = F.layout.start.center
    stray.root.position.set(s.x + 2.5, 0, s.z + 2.5)
    scene.add(stray.root)
    G.catState.stray = stray
  }
  progress.maxFloor = Math.max(progress.maxFloor, n)
  saveProgress()
  $('#loading').style.display = 'none'
}

function spawnInElevator () {
  const e = G.F.elevators.start
  const idx = respawnIndex()
  const side = e.along === 'x' ? [1, 0] : [0, 1]
  // side by side, all inside the doorway's width
  P.x = e.inside.x + side[0] * (idx - 1.5) * 0.3
  P.z = e.inside.z + side[1] * (idx - 1.5) * 0.3
  P.yaw = e.yawOut // look out into the room
  P.pitch = 0
}

const respawnIndex = () => { const ids = [...new Set([...net.players.keys(), myId()])].sort(); return Math.max(0, ids.indexOf(myId())) % 4 }

function respawnRandom () {
  const F = G.F
  const threats = [...G.entState.values()].filter(e => e.visible)
  const rooms = F.spawnRooms.slice().sort(() => Math.random() - 0.5)
  let pick = rooms[0]
  for (const r of rooms) {
    if (threats.every(t => Math.hypot(t.x - r.center.x, t.z - r.center.z) > 13)) { pick = r; break }
  }
  for (let k = 0; k < 30; k++) {
    const x = pick.center.x + (Math.random() - 0.5) * 4, z = pick.center.z + (Math.random() - 0.5) * 4
    if (F.free(x, z, 0.4)) { P.x = x; P.z = z; break }
  }
  P.yaw = Math.random() * Math.PI * 2
  P.pitch = 0
}

// ═════════════ effects ═════════════
const entHooks = {
  kill: (pid, type, eid) => hostKill(pid, type, eid),
  fx: (kind, d) => fx(kind, d),
  isHidden: spotId => { for (const p of G.registry.values()) if (p.hidden === spotId) return { playerId: p.id, holdingBreath: p.holdingBreath, seen: p.hiddenSeen }; return null },
  glowAt: (x, z, r) => G.glows.some(g => Math.hypot(g.x - x, g.z - z) < r),
  roomLit: (x, z) => {
    const lamps = G.visuals.lamps.filter(v => Math.abs(v.l.x - x) < 6 && Math.abs(v.l.z - z) < 6)
    return lamps.length ? Math.max(...lamps.map(v => v.l.level ?? 0)) : 0
  },
}

function fx (kind, d = {}) {
  playFx(kind, d)
  if (net.online && isHost()) sendAll('fx', { kind, data: d }) // wrapped: d may have its own 'type'/'kind'
}

function playFx (kind, d) {
  const pos = d.x != null ? A.at(d.x, d.z) : undefined
  switch (kind) {
    case 'scrape': A.play('mannequin', { pos, vol: 0.8, ref: 2.5 }); break
    case 'giggle': A.play('giggle', { pos, vol: 1, ref: 3, max: 50 }); bumpFear(0.35); break
    case 'peekerFlee': A.play('giggle', { pos, vol: 0.6, rate: 0.7, ref: 3 }); break
    case 'peekerLunge': A.play('scream_child', { pos, vol: 0.9, ref: 4 }); bumpFear(0.8); break
    case 'mimic': A.play('mimic', { pos, vol: 1.1, ref: 3 }); bumpFear(0.8); break
    case 'dread': bumpFear(d.v ?? 0.1); break
    case 'mimicLure': A.play('chest_open', { pos, vol: 0.35, rate: 0.6, ref: 2, max: 24 }); break
    case 'mimicGone': A.play('chest_close', { pos, vol: 0.5 }); break
    case 'roar': A.play('stalker_roar', { pos, vol: 1.2, ref: 4, max: 90 }); A.play('stinger', { vol: 0.5, music: true }); bumpFear(0.6); break
    case 'stalkerSound': A.play(Math.random() < 0.5 ? 'stalker_growl' : 'stalker_breath', { pos, vol: 0.9, ref: 3, max: 70 }); break
    case 'rattle': {
      A.play('chest_open', { pos, vol: 0.9 })
      A.play('stalker_breath', { pos, vol: 1, ref: 2 })
      if (G.hiddenSpot === d.spot) { bumpFear(1); toast(touch ? 'It\'s right outside. Hold your breath!' : 'It\'s right outside. Hold Space!', 2600) }
      break
    }
    case 'killed': onKilled(d); break
    case 'token': {
      const m = G.visuals.tokens.get(d.id)
      if (m) m.visible = false
      A.play('token', { vol: 0.6, rateJitter: 0 })
      if (d.by !== myId()) toast(`${playerName(d.by)} found a token (${d.count}/${G.F.params.tokens}).`)
      else toast(`Token ${d.count} of ${G.F.params.tokens}.`)
      break
    }
    case 'exitOpen': {
      A.play('elevator', { pos: A.at(G.F.elevators.exit.inside.x, G.F.elevators.exit.inside.z), vol: 1, ref: 4, max: 80 })
      A.play('unlock', { vol: 0.5, music: true })
      big('All tokens found', 'The lift is open. Find it.')
      break
    }
    case 'lift': A.play('elevator', { pos: A.at(G.F.elevators.exit.inside.x, G.F.elevators.exit.inside.z), vol: 0.8 }); break
    case 'place': placeVisual(d); break
    case 'toast': if (!d.to || d.to === myId()) toast(d.text, d.ms); break
  }
}

function bumpFear (v) { G.fear = Math.min(1, G.fear + v) }

// ═════════════ host logic ═════════════
function hostKill (pid, type, eid) {
  const p = G.registry.get(pid)
  if (!p || p.dead) return
  p.dead = true
  p.hidden = null
  fx('killed', { id: pid, type, eid })
}

function hostRequest (pid, d) {
  const F = G.F
  const tell = text => fx('toast', { to: pid, text })
  if (d.kind === 'token') {
    const mimic = G.ents?.list.find(e => e.id === d.id && e.type === 'mimic')
    if (mimic) { if (mimic.state === 'disguised') { mimic.state = 'reveal'; mimic.timer = 0.45; mimic.targetId = pid; fx('mimic', { x: mimic.x, z: mimic.z }) } return }
    if (G.tokens.has(d.id) || !F.tokens.some(t => t.id === d.id)) return
    G.tokens.add(d.id)
    fx('token', { id: d.id, by: pid, count: G.tokens.size })
    grant(pid, 'xp', 10)
    if (G.tokens.size >= F.params.tokens && !G.exitOpen) { G.exitOpen = true; fx('exitOpen') }
  } else if (d.kind === 'item') {
    if (G.items.has(d.id)) return
    const it = F.items.find(i => i.id === d.id)
    if (!it) return
    G.items.add(d.id)
    grant(pid, it.kind, 1)
  } else if (d.kind === 'hide') {
    const taken = [...G.registry.values()].some(p => p.hidden === d.spot && p.id !== pid)
    if (taken) { tell('Someone is already hiding there.'); return }
    const st = G.ents?.list.find(e => e.type === 'stalker')
    const rp = G.registry.get(pid)
    const seen = !!(st && st.state === 'chase' && st.chaseId === pid && rp && G.ents.stalkerCanSee(st, { ...rp, hidden: null }))
    if (rp) { rp.hidden = d.spot; rp.hiddenSeen = seen }
    if (pid === myId()) enterHide(d.spot, seen); else sendTo(pid, 'hideOk', { spot: d.spot, seen })
  } else if (d.kind === 'lift') {
    if (!G.exitOpen || G.liftAt) return
    G.liftAt = now() + 6000
    fx('lift')
  } else if (d.kind === 'place') {
    const item = { id: `${pid}-${Math.random().toString(36).slice(2, 7)}`, kind: d.item, x: d.x, z: d.z, until: now() + (d.item === 'glowstick' ? 90000 : 10000) }
    if (d.item === 'glowstick') G.glows.push(item); else G.toys.push(item)
    fx('place', item)
  }
}

function grant (pid, kind, amount) {
  if (pid === myId()) applyGrant(kind, amount); else sendTo(pid, 'grant', { kind, amount })
}

function applyGrant (kind, amount) {
  if (kind === 'xp') { progress.xp += amount; saveProgress(); return }
  P.inv[kind] = (P.inv[kind] ?? 0) + amount
  A.play('pickup', { vol: 0.6 })
  const names = { battery: 'A torch battery.', soda: touch ? 'A fizzy drink. Tap Drink to run for longer.' : 'A fizzy drink. Press 1 to run for longer.', glowstick: touch ? 'A glow stick. Tap Glow to drop a light that keeps the Peeker away.' : 'A glow stick. Press 2 to drop a light that keeps the Peeker away.', windup: touch ? 'A wind-up toy. Tap Toy to make a noise somewhere else.' : 'A wind-up toy. Press 3: it plays a tune that draws the Big Friend to it.' }
  toast(names[kind] ?? '')
}

function nextFloor () {
  const n = G.floor + 1
  sendAll('floor', { n, entities: G.entitiesOn })
  goToFloor(n, G.entitiesOn)
}

function goToFloor (n, entitiesOn) {
  const cleared = G.floor
  progress.xp += 20 * cleared
  progress.floorsCleared = (progress.floorsCleared ?? 0) + 1
  saveProgress()
  fade(1, 600)
  A.play('level_done', { vol: 0.5, music: true })
  setTimeout(() => {
    loadFloor(n, entitiesOn)
    spawnInElevator()
    P.dead = false
    fade(0, 1400)
    big(`Floor ${n}`, floorBlurb(n))
  }, 700)
}

const floorBlurb = n => {
  const p = floorParams(n, G.entitiesOn)
  if (!G.entitiesOn) return 'Creatures off. Take your time.'
  if (n === 1) return 'Something giggles in the dark.'
  if (n === 2) return 'Something big lives on this floor.'
  if (n === 3) return 'Not every token is a token.'
  if (n === CAT_UNLOCK_FLOOR && !progress.catUnlocked) return 'You hear a small meow from the lobby.'
  return `${p.tokens} tokens. ${p.mannequins} mannequins. It's getting bigger.`
}

// ═════════════ networking ═════════════
on('state', (d, from) => {
  const p = G.registry.get(from) ?? { id: from }
  Object.assign(p, d, { id: from })
  G.registry.set(from, p)
  let av = G.avatars.get(from)
  if (!av) {
    const model = createAvatar(from, { outfit: 'explorer', name: playerName(from), shadows: HIGH })
    scene.add(model.group)
    av = { model, target: d, x: d.x, z: d.z, yaw: d.yaw, speed: 0, cat: null }
    G.avatars.set(from, av)
  }
  av.target = d
})
on('req', (d, from) => { if (isHost()) hostRequest(from, d) })
on('noise', d => { if (isHost()) G.ents?.hear(d.x, d.z, d.r) })
on('fx', d => { if (!isHost()) playFx(d.kind, d.data ?? {}) })
on('grant', d => applyGrant(d.kind, d.amount))
on('hideOk', d => enterHide(d.spot, d.seen))
on('floor', d => { if (!isHost()) goToFloor(d.n, d.entities) })
on('start', d => { if (!isHost()) startGame({ floor: d.floor, entities: d.entities, coop: true }) })
on('world', d => {
  if (isHost() || !G.F || d.floor !== G.floor) return
  for (const [id, x, z, yaw, state, vis, speed, alert, y, type] of d.e) G.entState.set(id, { id, x, z, yaw, state, visible: !!vis, speed, alert, y, type })
  G.tokens = new Set(d.tk); G.items = new Set(d.it)
  G.glows = d.gl; G.toys = d.toys
  for (const g of [...d.gl, ...d.toys]) if (!G.visuals.glowMeshes.has(g.id) && !G.visuals.toyMeshes.has(g.id)) placeVisual(g)
  G.exitOpen = d.exit
  G.liftCountdown = d.lift
  G.deadIds = new Set(d.dead)
})
on('peerJoin', d => {
  toast(`${d.name} joined.`)
  if (isHost() && G.mode !== 'title') sendTo(d.id, 'start', { floor: G.floor, entities: G.entitiesOn, late: true })
  refreshLobby()
})
on('peerLeave', d => {
  toast(`${playerName(d.id)} left.`)
  G.registry.delete(d.id)
  const av = G.avatars.get(d.id)
  if (av) { av.model.dispose(); if (av.cat) scene.remove(av.cat.root); G.avatars.delete(d.id) }
  refreshLobby()
})
on('hostChange', ({ isHost: me }) => {
  if (me && G.F && G.mode !== 'title') {
    // take over the creatures from where they were
    G.ents = new Entities(G.F, entHooks, G.F.params)
    for (const e of G.ents.list) { const s = G.entState.get(e.id); if (s) Object.assign(e, { x: s.x, z: s.z, yaw: s.yaw, visible: s.visible, state: e.type === 'stalker' ? 'patrol' : e.state }) }
    toast('You are now the host.')
  }
  refreshLobby()
})
on('disconnected', () => {
  if (G.mode === 'title') { setStatus('#lobby-status', 'Disconnected from the co-op server.', true); return }
  toast('Lost the connection. Carrying on alone.', 4000)
  for (const av of G.avatars.values()) { av.model.dispose(); if (av.cat) scene.remove(av.cat.root) }
  G.avatars.clear()
  for (const id of [...G.registry.keys()]) if (id !== 'local') G.registry.delete(id)
  if (!G.ents && G.F) G.ents = new Entities(G.F, entHooks, G.F.params)
})
on('roster', () => refreshLobby())
on('name', (d, from) => { const p = net.players.get(from); if (p) p.name = d.name; refreshLobby() })

const playerName = id => (id === myId() ? myName : net.players.get(id)?.name ?? 'Someone')

const request = (kind, data = {}) => { if (isHost()) hostRequest(myId(), { kind, ...data }); else sendHost('req', { kind, ...data }) }
const noise = (x, z, r) => { if (isHost()) G.ents?.hear(x, z, r); else sendHost('noise', { x: +x.toFixed(1), z: +z.toFixed(1), r }) }

// ═════════════ death + respawn ═════════════
const DEATH_LINES = {
  peeker: ['It was smiling the whole time.', 'You looked away.'],
  mannequin: ['You turned your back on it.', 'It was closer than it looked.'],
  mimic: ['That wasn\'t a token.', 'Some prizes bite.'],
  stalker: ['The Big Friend wanted a hug.', 'It found you.'],
}

function onKilled (d) {
  if (d.id !== myId()) {
    A.play('scream', { pos: (() => { const p = G.registry.get(d.id); return p ? A.at(p.x, p.z) : undefined })(), vol: 0.8 })
    toast(`${playerName(d.id)} was caught. They'll wake up somewhere else.`)
    return
  }
  if (P.hidden) leaveHide()
  P.dead = true
  G.mode = 'dead'
  progress.deaths = (progress.deaths ?? 0) + 1
  G.deathsThisFloor++
  saveProgress()
  input.enabled = false
  G.jumpscare = { t: 0, type: d.type, eid: d.eid }
  A.play(d.type === 'peeker' ? 'scream_child' : 'scream', { vol: 1.3 })
  flashRed()
  P.shake = 1
  setTimeout(() => {
    G.jumpscare = null
    fade(1, 300)
    setTimeout(() => {
      setHud(false)
      $('#dead-title').textContent = 'Caught'
      const lines = DEATH_LINES[d.type] ?? ['Caught.']
      $('#dead-text').textContent = `${lines[Math.floor(Math.random() * lines.length)]} You'll wake up somewhere else on this floor.`
      showScreen('dead')
      let left = Math.ceil(RESPAWN_SECONDS)
      $('#dead-count').textContent = left
      const iv = setInterval(() => {
        left--
        $('#dead-count').textContent = Math.max(0, left)
        if (left <= 0) { clearInterval(iv); respawn() }
      }, 1000)
    }, 350)
  }, 1150)
}

function respawn () {
  respawnRandom()
  P.dead = false
  P.stamina = 100
  G.mode = 'playing'
  input.enabled = true
  showScreen(null)
  setHud(true)
  fade(0, 900)
  A.play('respawn', { vol: 0.6 })
  if (!touch) void canvas.requestPointerLock?.()
  const rp = G.registry.get(myId())
  if (rp) rp.dead = false
  sendAll('respawned', {})
}
on('respawned', (d, from) => { const p = G.registry.get(from); if (p) p.dead = false })

// ═════════════ hiding ═════════════
function enterHide (spotId, seen) {
  const spot = G.F.hideSpots.find(h => h.id === spotId)
  if (!spot) return
  P.hidden = spotId; P.hiddenSeen = !!seen; G.hiddenSpot = spotId
  P.yaw = spot.yaw + Math.PI // look out of the opening
  P.pitch = 0
  const enclosed = ['cubby', 'cupboard', 'locker', 'booth', 'chest', 'bin', 'stall'].includes(spot.type)
  $('#slits').style.display = enclosed ? 'block' : 'none'
  A.play(spot.type === 'ballpit' ? 'ballpit' : 'chest_open', { pos: A.at(spot.inside.x, spot.inside.z), vol: 0.8 })
  G.breath = A.S.bed('breath_loop', { vol: 0 })
}

function leaveHide () {
  const spot = G.F?.hideSpots.find(h => h.id === P.hidden)
  P.hidden = null; G.hiddenSpot = null
  if (spot) { P.x = spot.exit.x; P.z = spot.exit.z; A.play(spot.type === 'ballpit' ? 'ballpit' : 'chest_close', { pos: A.at(spot.inside.x, spot.inside.z), vol: 0.7 }) }
  $('#slits').style.display = 'none'
  G.breath?.stop(0.3); G.breath = null
  const rp = G.registry.get(myId())
  if (rp) rp.hidden = null
}

// ═════════════ items in the world (glow sticks, toys) ═════════════
function placeVisual (d) {
  if (d.kind === 'glowstick') {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.22, 8), new THREE.MeshBasicMaterial({ color: 0x8dff9e }))
    m.rotation.z = Math.PI / 2
    m.position.set(d.x, 0.03, d.z)
    scene.add(m)
    G.visuals.glowMeshes.set(d.id, m)
    A.play('glowstick', { pos: A.at(d.x, d.z, 0.2), vol: 0.7 })
  } else {
    const m = itemMesh('windup')
    m.position.set(d.x, 0, d.z)
    scene.add(m)
    G.visuals.toyMeshes.set(d.id, m)
    const h = A.play('windup', { pos: A.at(d.x, d.z, 0.3), vol: 1, ref: 4, max: 70 })
    setTimeout(() => A.play('windup', { pos: A.at(d.x, d.z, 0.3), vol: 1, ref: 4, max: 70 }), 3000)
    setTimeout(() => A.play('windup', { pos: A.at(d.x, d.z, 0.3), vol: 1, ref: 4, max: 70 }), 6000)
    void h
  }
}

function itemMesh (kind) {
  const g = new THREE.Group()
  const std = (c, extra = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.45, ...extra })
  if (kind === 'battery') {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.12, 12), std(0x2f6fd1, { metalness: 0.3 }))
    b.rotation.z = Math.PI / 2; b.position.y = 0.035
    g.add(b)
  } else if (kind === 'soda') {
    const c = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.12, 14), std(0xd94141, { metalness: 0.6, roughness: 0.3 }))
    c.position.y = 0.06
    g.add(c)
  } else if (kind === 'glowstick') {
    const s = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.2, 8), std(0x7dff9a, { emissive: 0x2a8a3a, emissiveIntensity: 0.6 }))
    s.rotation.z = Math.PI / 2; s.position.y = 0.02
    g.add(s)
  } else if (kind === 'windup') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.12, 0.1), std(0xe8c23a))
    body.position.y = 0.08
    const key = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.008, 6, 12), std(0x888888, { metalness: 0.8 }))
    key.position.set(0, 0.1, -0.07)
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.018, 8, 6), std(0x111111))
    eye.position.set(0.03, 0.11, 0.05)
    const eye2 = eye.clone(); eye2.position.x = -0.03
    g.add(body, key, eye, eye2)
  }
  const glint = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 }))
  glint.position.y = 0.16
  glint.name = 'glint'
  g.add(glint)
  return g
}

// ═════════════ session ═════════════
function startGame ({ floor = 1, entities = true, coop = false } = {}) {
  A.S.init()
  A.S.setVolume(settings.volume)
  void A.startBeds()
  G.coop = coop
  G.registry.clear()
  Object.assign(P, { dead: false, hidden: null, stamina: 100, flashlight: true, inv: { soda: 1, glowstick: 1, windup: 0 }, crouch: false })
  loadFloor(floor, entities)
  spawnInElevator()
  G.mode = 'playing'
  input.enabled = true
  clearStack(); showScreen(null); setHud(true)
  fade(1, 0)
  setTimeout(() => fade(0, 1500), 100)
  big(`Floor ${floor}`, floorBlurb(floor))
  if (!touch) void canvas.requestPointerLock?.()
  setupCat()
}

function quitToTitle () {
  disconnect()
  G.mode = 'title'
  input.enabled = false
  document.exitPointerLock?.()
  for (const av of G.avatars.values()) { av.model.dispose(); if (av.cat) scene.remove(av.cat.root) }
  G.avatars.clear()
  if (P.hidden) leaveHide()
  setHud(false)
  clearStack(); showScreen('title')
  G.paused = false
  updateProfile()
}

// ═════════════ the cat ═════════════
function setupCat () {
  if (G.cat) { scene.remove(G.cat.root); G.cat = null }
  if (progress.catUnlocked && settings.cat) {
    G.cat = catModel(0xd08a3a)
    G.catState.x = P.x + 0.6; G.catState.z = P.z + 0.6
    scene.add(G.cat.root)
  }
  $('#cat').style.display = G.cat ? 'flex' : 'none'
}

function updateCat (dt, t) {
  if (!G.cat) return
  const c = G.catState
  // trot after the player, staying a step behind
  const bx = P.x + Math.sin(P.yaw) * 1.0 + Math.cos(P.yaw) * 0.5, bz = P.z + Math.cos(P.yaw) * 1.0 - Math.sin(P.yaw) * 0.5
  const dx = bx - c.x, dz = bz - c.z, d = Math.hypot(dx, dz)
  let speed = 0
  if (d > 0.4) { speed = Math.min(5, d * 2.2); c.x += dx / d * speed * dt; c.z += dz / d * speed * dt; c.yaw = Math.atan2(dx, dz) }
  if (d > 9) { c.x = bx; c.z = bz }
  // anything nasty nearby? (mimics count: the cat always knows)
  let threat = null
  for (const e of G.entState.values()) {
    if (!e.visible) continue
    const dd = Math.hypot(e.x - P.x, e.z - P.z)
    if (dd < 12 && (!threat || dd < threat.d)) threat = { e, d: dd }
  }
  const alert = !!threat
  if (alert) {
    c.yaw = Math.atan2(threat.e.x - c.x, threat.e.z - c.z)
    if (t - c.alertAt > 4500) { c.alertAt = t; A.play('meow', { pos: A.at(c.x, c.z, 0.3), vol: 1.1, rate: 0.82, ref: 2 }) }
  } else if (Math.random() < dt * 0.01) A.play('meow', { pos: A.at(c.x, c.z, 0.3), vol: 0.5, rate: 1.1 })
  c.alert = alert
  G.cat.root.position.set(c.x, 0, c.z)
  G.cat.root.rotation.y = c.yaw
  G.cat.animate(dt, { speed, alert })
  const el = $('#cat')
  el.classList.toggle('alert', alert)
  setText($('#cat-text'), alert ? (threat.d < 6 ? 'The cat is hissing!' : 'The cat is growling') : 'The cat is calm')
}

// ═════════════ interaction ═════════════
const tmpV = new THREE.Vector3()
function findInteraction () {
  if (P.dead || G.mode !== 'playing') return null
  if (P.hidden) return { kind: 'unhide', label: 'Get out' }
  const eye = new THREE.Vector3(P.x, eyeHeight(), P.z)
  const fwd = new THREE.Vector3(-Math.sin(P.yaw) * Math.cos(P.pitch), Math.sin(P.pitch), -Math.cos(P.yaw) * Math.cos(P.pitch))
  let best = null
  const consider = (x, y, z, reach, label, data, lim = 0.6) => {
    tmpV.set(x, y, z).sub(eye)
    const d = tmpV.length()
    if (d > reach) return
    const ang = tmpV.normalize().angleTo(fwd)
    if (ang > lim + (d < 0.9 ? 0.5 : 0)) return
    const score = d + ang * 2
    if (!best || score < best.score) best = { ...data, label, score }
  }
  const F = G.F
  for (const t of F.tokens) if (!G.tokens.has(t.id)) consider(t.x, t.y + 0.18, t.z, 2.0, 'Take the token', { kind: 'token', id: t.id })
  for (const e of G.entState.values()) if (e.type === 'mimic' && e.state === 'disguised' && e.visible) consider(e.x, (e.y ?? 0) + 0.18, e.z, 2.0, 'Take the token', { kind: 'token', id: e.id })
  for (const it of F.items) if (!G.items.has(it.id)) consider(it.x, it.y + 0.05, it.z, 2.0, { battery: 'Take the battery', soda: 'Take the fizzy drink', glowstick: 'Take the glow stick', windup: 'Take the wind-up toy' }[it.kind], { kind: 'item', id: it.id })
  for (const h of F.hideSpots) {
    if (Math.hypot(P.x - h.exit.x, P.z - h.exit.z) > 1.5 && Math.hypot(P.x - h.inside.x, P.z - h.inside.z) > 1.6) continue
    consider(h.inside.x, 0.8, h.inside.z, 2.4, h.label, { kind: 'hide', id: h.id }, 0.9)
  }
  const ex = F.elevators.exit
  if (ex.contains(P.x, P.z)) best = G.exitOpen ? (G.liftCountdown || G.liftAt ? null : { kind: 'lift', label: 'Press the button: go down', score: 0 }) : null
  if (G.catState.stray && !progress.catUnlocked) {
    const s = G.catState.stray.root.position
    consider(s.x, 0.3, s.z, 2.2, 'Pet the cat', { kind: 'cat' }, 1.0)
  }
  return best
}

function useInteraction (t) {
  if (!t) return
  switch (t.kind) {
    case 'unhide': leaveHide(); break
    case 'token': request('token', { id: t.id }); break
    case 'item': request('item', { id: t.id }); break
    case 'hide': request('hide', { spot: t.id }); break
    case 'lift': request('lift'); break
    case 'cat':
      progress.catUnlocked = true
      saveProgress()
      settings.cat = true
      saveSettings()
      scene.remove(G.catState.stray.root)
      G.catState.stray = null
      A.play('meow', { vol: 0.9 })
      big('A new friend', 'The cat follows you now. It yowls when something is near.')
      setupCat()
      break
  }
}

// ═════════════ player ═════════════
const eyeHeight = () => EYE + (CROUCH_EYE - EYE) * P.crouchT

function collide () {
  const F = G.F
  for (let it = 0; it < 3; it++) {
    let pushed = false
    for (const c of F.colliders) {
      if (c.elevator === 'exit' && F.elevators.exit.open > 0.7) continue
      if (c.elevator === 'start' && F.elevators.start.open > 0.7) continue
      const cx = Math.max(c.minX, Math.min(P.x, c.maxX)), cz = Math.max(c.minZ, Math.min(P.z, c.maxZ))
      const dx = P.x - cx, dz = P.z - cz, d2 = dx * dx + dz * dz
      if (d2 >= RADIUS * RADIUS) continue
      if (d2 > 1e-8) { const d = Math.sqrt(d2); P.x += dx / d * (RADIUS - d); P.z += dz / d * (RADIUS - d) } else {
        const opts = [[c.minX - RADIUS - P.x, 0], [c.maxX + RADIUS - P.x, 0], [0, c.minZ - RADIUS - P.z], [0, c.maxZ + RADIUS - P.z]]
        opts.sort((a, b) => Math.abs(a[0] + a[1]) - Math.abs(b[0] + b[1]))
        P.x += opts[0][0]; P.z += opts[0][1]
      }
      pushed = true
    }
    if (!pushed) break
  }
}

function updatePlayer (dt, look, canAct) {
  const sens = 0.0022 * (settings.sensitivity ?? 1)
  P.yaw -= look.x * sens
  P.pitch -= look.y * sens * (settings.invertY ? -1 : 1)
  P.pitch = Math.max(-1.35, Math.min(1.35, P.pitch))
  if (P.dead) return []
  const events = []
  if (P.hidden) {
    const spot = G.F.hideSpots.find(h => h.id === P.hidden)
    if (spot) {
      let dy = P.yaw - (spot.yaw + Math.PI)
      while (dy > Math.PI) dy -= Math.PI * 2
      while (dy < -Math.PI) dy += Math.PI * 2
      P.yaw = spot.yaw + Math.PI + Math.max(-0.8, Math.min(0.8, dy))
      P.pitch = Math.max(-0.5, Math.min(0.4, P.pitch))
    }
    P.holdingBreath = input.held.breath && P.breath > 0
    P.breath = P.holdingBreath ? Math.max(0, P.breath - dt / 7) : Math.min(1, P.breath + dt / 4)
    if (P.breath <= 0 && input.held.breath) { P.holdingBreath = false; events.push({ type: 'gasp' }) }
    return events
  }
  P.holdingBreath = false
  if (canAct && consumePressed('crouch')) P.crouch = !P.crouch
  P.crouchT += ((P.crouch ? 1 : 0) - P.crouchT) * Math.min(1, dt * 9)
  let mx = canAct ? input.move.x : 0, my = canAct ? input.move.y : 0
  const len = Math.hypot(mx, my)
  if (len > 1) { mx /= len; my /= len }
  const boosted = now() < P.boostUntil
  const maxStamina = 100 * (1 + Math.min(0.4, (playerLevel() - 1) * 0.02))
  const wantSprint = canAct && input.held.sprint && !P.crouch && my > 0.3 && (P.stamina > 4 || boosted)
  let speed = P.crouch ? CROUCH : wantSprint ? SPRINT * (boosted ? 1.1 : 1) : WALK
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw), rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw)
  const ox = P.x, oz = P.z
  P.x += (fx * my + rx * mx) * speed * dt
  P.z += (fz * my + rz * mx) * speed * dt
  collide()
  const moved = Math.hypot(P.x - ox, P.z - oz)
  P.speed = moved / Math.max(dt, 1e-4)
  P.moving = len > 0.15 && P.speed > 0.2
  P.sprinting = wantSprint && P.moving
  if (P.sprinting && !boosted) P.stamina = Math.max(0, P.stamina - STAMINA_DRAIN * dt)
  else if (!P.sprinting) P.stamina = Math.min(maxStamina, P.stamina + STAMINA_REGEN * dt * (P.moving ? 0.6 : 1))
  P.maxStamina = maxStamina
  if (P.moving) {
    P.stepDist += moved
    P.bob += moved * (P.sprinting ? 2.6 : 3.2)
    const stride = P.sprinting ? 0.8 : P.crouch ? 0.55 : 0.68
    if (P.stepDist >= stride) {
      P.stepDist = 0
      events.push({ type: 'step', radius: P.sprinting ? 14 : P.crouch ? 1.5 : 6, loud: P.sprinting ? 0.9 : P.crouch ? 0.25 : 0.55 })
    }
  }
  return events
}

const surfaceAt = (x, z) => {
  const c = G.F.cellAt(x, z)
  const f = c?.template.floor ?? 'carpet'
  return f === 'foam' ? 'foam' : f === 'carpet' ? 'carpet' : 'tile'
}

// ═════════════ visuals ═════════════
function updateLamps (dt, t) {
  const st = [...G.entState.values()].find(e => e.type === 'stalker' && e.visible)
  for (const v of G.visuals.lamps) {
    const l = v.l
    let level = l.off ? 0 : 1
    if (l.broken) level = (Math.sin(t * 0.011 + l.phase) * Math.sin(t * 0.0037 + l.phase * 2) > 0.1 ? 1 : 0.08) * (Math.random() < 0.03 ? 0 : 1)
    // lights stutter when the Big Friend is close (your warning)
    if (st && level > 0 && Math.hypot(st.x - l.x, st.z - l.z) < 10 && Math.random() < 0.4) level *= Math.random() * 0.4
    l.level = (l.level ?? 0) + (level - (l.level ?? 0)) * Math.min(1, dt * 20)
    v.mesh.material.emissiveIntensity = l.level * 1.6
  }
  const cands = G.visuals.lamps.filter(v => v.l.level > 0.05).map(v => ({ v, d: Math.hypot(v.l.x - camera.position.x, v.l.z - camera.position.z) })).filter(c => c.d < 26).sort((a, b) => a.d - b.d)
  roomLights.forEach((light, i) => {
    const c = cands[i]
    if (!c) { light.intensity = 0; return }
    light.position.set(c.v.l.x, c.v.l.y - 0.15, c.v.l.z)
    light.color.setHex(c.v.l.color)
    light.intensity = c.v.l.level * 9
  })
  const gl = G.glows.filter(g => g.until > (isHost() ? now() : 0) || !isHost()).map(g => ({ g, d: Math.hypot(g.x - camera.position.x, g.z - camera.position.z) })).sort((a, b) => a.d - b.d)
  glowLights.forEach((light, i) => {
    const c = gl[i]
    if (!c) { light.intensity = 0; return }
    light.position.set(c.g.x, 0.3, c.g.z)
    light.intensity = 3.2 + Math.sin(t * 0.003 + i) * 0.3
  })
}

function updateWorldVisuals (dt, t) {
  const F = G.F
  for (const [id, m] of G.visuals.tokens) { m.visible = !G.tokens.has(id); m.rotation.y += dt * 1.6; m.position.y = F.tokens.find(k => k.id === id).y + 0.18 + Math.sin(t / 600 + m.position.x) * 0.03 }
  for (const [id, m] of G.visuals.items) {
    m.visible = !G.items.has(id)
    const glint = m.getObjectByName('glint')
    if (glint) glint.material.opacity = 0.2 + Math.sin(t / 300 + m.position.x * 3) * 0.15
  }
  for (const s of F.spinners) s.obj.rotation.y += s.speed * dt
  for (const s of F.screens) s.mesh.material.color.setHSL((s.phase + t / 9000) % 1, 0.4, Math.random() < 0.02 ? 0.05 : 0.28)
  // expired glow sticks and toys
  for (const [id, m] of G.visuals.glowMeshes) if (!G.glows.some(g => g.id === id)) { scene.remove(m); G.visuals.glowMeshes.delete(id) }
  for (const [id, m] of G.visuals.toyMeshes) if (!G.toys.some(g => g.id === id)) { scene.remove(m); G.visuals.toyMeshes.delete(id) } else m.rotation.y += dt * 3
  // elevator doors
  for (const [name, e] of Object.entries(F.elevators)) {
    const target = name === 'start' ? 1 : (G.exitOpen && !(G.liftCountdown > 0 && G.liftCountdown < 1.5) ? 1 : 0)
    e.open += (target - e.open) * Math.min(1, dt * 2.5)
    for (const leaf of e.doors) {
      const off = leaf.userData.s * e.open * 0.85
      if (e.along === 'x') leaf.position.x = leaf.userData.bx + off; else leaf.position.z = leaf.userData.bz + off
    }
    if (name === 'exit') e.lamp.material.color.setHex(G.exitOpen ? 0x6aff8a : 0xff3b30)
  }
  // creatures
  for (const [id, v] of G.visuals.ents) {
    const s = G.entState.get(id)
    if (!s) continue
    if (!isHost()) {
      // smooth toward the host's numbers
      v.sx = v.sx ?? s.x; v.sz = v.sz ?? s.z
      const jump = Math.hypot(s.x - v.sx, s.z - v.sz)
      const k = jump > 5 ? 1 : Math.min(1, dt * 10)
      v.sx += (s.x - v.sx) * k; v.sz += (s.z - v.sz) * k
    } else { v.sx = s.x; v.sz = s.z }
    v.root.visible = s.visible
    if (!s.visible) continue
    v.root.position.set(v.sx, s.type === 'mimic' && s.state === 'disguised' ? (s.y ?? 0) : 0, v.sz)
    v.root.rotation.y = s.yaw
    if (v.type === 'mannequin') {
      // new pose every time it was moved while you weren't looking
      if (s.state === 'moving') v.wasMoving = true
      else if (v.wasMoving) { v.wasMoving = false; v.newPose() }
    }
    v.animate(dt, s)
    if (v.type === 'stalker' && s.speed > 0.1) {
      v.stepPhase = (v.stepPhase ?? 0) + dt * (s.speed > 2.8 ? 3.6 : 2.2)
      if (v.stepPhase > 1) { v.stepPhase = 0; A.play('stalker_step', { pos: A.at(v.sx, v.sz, 0.2), vol: s.speed > 2.8 ? 1.2 : 0.8, ref: 3, max: 60 }) }
    }
  }
}

function updateAvatars (dt) {
  for (const [id, av] of G.avatars) {
    const t = av.target
    const jump = Math.hypot(t.x - av.x, t.z - av.z)
    const k = jump > 4 ? 1 : Math.min(1, dt * 12)
    const ox = av.x, oz = av.z
    av.x += (t.x - av.x) * k; av.z += (t.z - av.z) * k
    let dy = t.yaw - av.yaw
    while (dy > Math.PI) dy -= Math.PI * 2
    while (dy < -Math.PI) dy += Math.PI * 2
    av.yaw += dy * Math.min(1, dt * 12)
    const v = jump > 4 ? 0 : Math.hypot(av.x - ox, av.z - oz) / Math.max(dt, 1e-3)
    av.speed += (v - av.speed) * Math.min(1, dt * 8)
    av.model.setName(playerName(id))
    av.model.update(dt, { x: av.x, z: av.z, yaw: av.yaw, pitch: t.pitch, speed: av.speed, crouch: t.crouch, hidden: !!t.hidden, gone: !!t.dead, flashlight: t.flashlight })
    // their cat, if they brought one
    if (t.cat && !av.cat) { av.cat = catModel(0xd08a3a); scene.add(av.cat.root); av.cx = av.x; av.cz = av.z }
    if (av.cat) {
      const bx = av.x + Math.sin(av.yaw) * 1.0, bz = av.z + Math.cos(av.yaw) * 1.0
      const ddx = bx - av.cx, ddz = bz - av.cz, d = Math.hypot(ddx, ddz)
      let sp = 0
      if (d > 0.4) { sp = Math.min(5, d * 2.2); av.cx += ddx / d * sp * dt; av.cz += ddz / d * sp * dt }
      if (d > 9) { av.cx = bx; av.cz = bz }
      av.cat.root.position.set(av.cx, 0, av.cz)
      av.cat.root.rotation.y = Math.atan2(ddx, ddz)
      av.cat.root.visible = !t.dead
      av.cat.animate(dt, { speed: sp, alert: false })
    }
  }
}

function updateCamera (dt, t) {
  if (G.mode === 'title') {
    // a slow drift through the first room of floor 1
    const s = t / 1000
    const c = G.F?.layout.cells[1]?.center ?? { x: 0, z: 0 }
    camera.position.set(c.x + Math.sin(s * 0.12) * 3, 1.5, c.z + Math.cos(s * 0.12) * 3)
    camera.rotation.set(-0.08, s * 0.12 + Math.PI, 0)
    return
  }
  let x = P.x, z = P.z, y = eyeHeight()
  if (P.hidden) {
    const spot = G.F.hideSpots.find(h => h.id === P.hidden)
    if (spot) { x = spot.inside.x; z = spot.inside.z; y = spot.type === 'ballpit' ? 0.45 : ['chest', 'bin', 'table', 'tube', 'frame'].includes(spot.type) ? 0.55 : 1.4 }
  }
  const bob = P.moving ? Math.sin(P.bob * Math.PI) * (P.sprinting ? 0.05 : 0.028) : 0
  const sh = P.shake * 0.05
  camera.position.set(x + (Math.random() - 0.5) * sh, y + bob + (Math.random() - 0.5) * sh, z + (Math.random() - 0.5) * sh)
  camera.rotation.set(P.pitch, P.yaw, Math.sin(t / 1000) * 0.004 + (P.moving ? Math.sin(P.bob * Math.PI * 0.5) * 0.006 : 0))
  camera.fov = 74 + (P.sprinting ? 6 : 0) + G.fear * 3
  camera.updateProjectionMatrix()
  P.shake = Math.max(0, P.shake - dt * 1.6)
}

function updateJumpscare (dt) {
  const js = G.jumpscare
  if (!js) return
  js.t += dt
  const v = G.visuals.ents.get(js.eid) ?? [...G.visuals.ents.values()].find(e => e.type === js.type)
  if (!v) return
  const fwd = new THREE.Vector3(-Math.sin(P.yaw), 0, -Math.cos(P.yaw))
  P.pitch += (0 - P.pitch) * Math.min(1, dt * 12) // look it in the face
  const dist = Math.max(js.type === 'stalker' ? 1.15 : 0.6, 1.8 - js.t * 5)
  const headY = { stalker: 2.75, peeker: 2.3, mannequin: 1.75, mimic: 0.7 }[js.type] ?? 1.7
  v.root.visible = true
  v.root.position.set(camera.position.x + fwd.x * dist, camera.position.y - headY + 0.15 + Math.sin(js.t * 45) * 0.025, camera.position.z + fwd.z * dist)
  v.root.rotation.y = Math.atan2(-fwd.x, -fwd.z)
  v.animate(dt, { state: js.type === 'mimic' ? 'reveal' : js.type === 'peeker' ? 'scare' : 'lunge', speed: 0, alert: 1 })
  if (v.head) v.head.rotation.z = (Math.random() - 0.5) * 0.4
}

// ═════════════ the torch ═════════════
const torchOn = () => P.flashlight && now() > (G.torchOutUntil ?? 0)
function updateTorchFlicker (dt, t) {
  G.torchStutter = Math.max(0, (G.torchStutter ?? 0) - dt)
  if (!P.flashlight || P.hidden || t < (G.torchOutUntil ?? 0)) return
  let near = 99
  for (const e of G.entState.values()) if (e.visible && !(e.type === 'mimic' && e.state === 'disguised')) near = Math.min(near, Math.hypot(e.x - P.x, e.z - P.z))
  const rate = near < 8 ? 1 / 5 : near < 16 ? 1 / 14 : 1 / 45 // cut-outs per second
  if (Math.random() < rate * dt) {
    G.torchStutter = 0.5 // a little stutter first, as a warning
    const dur = 0.7 + Math.random() * (near < 16 ? 2.2 : 1.2)
    G.torchOutUntil = t + 500 + dur * 1000
    setTimeout(() => A.play('click', { vol: 0.35, rate: 0.7 }), 500)
    setTimeout(() => { if (P.flashlight) A.play('click', { vol: 0.35 }) }, 500 + dur * 1000)
  }
}

// ═════════════ main loop ═════════════
let last = now()
function frame () {
  requestAnimationFrame(frame)
  const t = now()
  const dt = Math.min(0.05, (t - last) / 1000)
  last = t
  window.__frames = (window.__frames ?? 0) + 1
  if (G.F && (G.mode === 'playing' || G.mode === 'dead') && !G.paused) step(dt, t)
  if (G.F) {
    updateWorldVisuals(dt, t)
    updateLamps(dt, t)
    updateAvatars(dt)
    updateCat(dt, t)
  }
  updateCamera(dt, t)
  updateJumpscare(dt)
  const stutter = G.torchStutter > 0 ? (Math.random() < 0.5 ? 0.15 : 1) : 1
  torch.intensity = torchOn() && !P.hidden && !P.dead && G.mode !== 'title' ? 17 * stutter : 0
  if (G.jumpscare) $('#flash').style.opacity = 0.15 + Math.random() * 0.2
  renderer.render(scene, camera)
}

function step (dt, t) {
  const look = consumeLook()
  const canAct = G.mode === 'playing' && input.enabled
  if (consumePressed('pause') && G.mode === 'playing') pause()
  if (canAct) {
    if (consumePressed('flashlight') && !P.hidden) {
      P.flashlight = !P.flashlight
      A.play('click', { vol: 0.5 })
    }
    if (consumePressed('soda') && !P.hidden) {
      if (P.inv.soda > 0) { P.inv.soda--; P.boostUntil = now() + 20000; P.stamina = P.maxStamina ?? 100; A.play('soda', { vol: 0.8 }); toast('Sugar rush! Run all you like for 20 seconds.') } else toast('No fizzy drinks.')
    }
    if (consumePressed('glowstick') && !P.hidden) {
      if (P.inv.glowstick > 0) { P.inv.glowstick--; request('place', { item: 'glowstick', x: P.x - Math.sin(P.yaw) * 0.8, z: P.z - Math.cos(P.yaw) * 0.8 }) } else toast('No glow sticks.')
    }
    if (consumePressed('windup') && !P.hidden) {
      if (P.inv.windup > 0) {
        // toss it a few metres ahead
        let tx = P.x, tz = P.z
        for (let d = 0.5; d < 5; d += 0.25) { const x = P.x - Math.sin(P.yaw) * d, z = P.z - Math.cos(P.yaw) * d; if (!G.F.free(x, z, 0.15)) break; tx = x; tz = z }
        P.inv.windup--; request('place', { item: 'windup', x: tx, z: tz })
      } else toast('No wind-up toys.')
    }
  } else for (const k of ['flashlight', 'soda', 'glowstick', 'windup']) input.pressed.delete(k)

  const events = updatePlayer(dt, canAct || P.hidden ? look : { x: 0, y: 0 }, canAct)
  for (const ev of events) {
    if (ev.type === 'step') { A.play(`step_${surfaceAt(P.x, P.z)}`, { pos: A.at(P.x, P.z, 0.1), vol: 0.25 + ev.loud * 0.7, ref: 1.5 }); noise(P.x, P.z, ev.radius) }
    if (ev.type === 'gasp') { A.play('gasp', { vol: 0.7 }); noise(P.x, P.z, 6) }
  }
  // the torch never runs out, but it cuts out now and then (much more when something is close)
  updateTorchFlicker(dt, t)

  // interaction
  const target = canAct ? findInteraction() : null
  setPrompt(target?.label ?? '')
  if (canAct && consumePressed('interact')) useInteraction(target)
  input.pressed.delete('interact')

  // host simulation
  if (isHost()) hostStep(dt, t)

  // send our state
  if (net.online && t - G.lastState > 66) {
    G.lastState = t
    sendAll('state', { x: +P.x.toFixed(2), z: +P.z.toFixed(2), yaw: +P.yaw.toFixed(2), pitch: +P.pitch.toFixed(2), crouch: P.crouch, flashlight: torchOn(), hidden: P.hidden, hiddenSeen: P.hiddenSeen, holdingBreath: P.holdingBreath, dead: P.dead, cat: !!G.cat })
  }

  // fear + heartbeat + music
  let near = 99
  let chasing = false
  for (const e of G.entState.values()) {
    if (!e.visible) continue
    const d = Math.hypot(e.x - P.x, e.z - P.z)
    if (e.type === 'mimic' && e.state === 'disguised') continue
    near = Math.min(near, d)
    if ((e.type === 'stalker' && e.state === 'chase') || (e.type === 'peeker' && e.state === 'lunge') || (e.type === 'mimic' && e.state === 'scuttle')) chasing = chasing || d < 25
  }
  const fearTarget = Math.max(0, 1 - near / 14) * 0.9 + (chasing ? 0.4 : 0)
  G.fear += (Math.min(1, fearTarget) - G.fear) * Math.min(1, dt * (fearTarget > G.fear ? 3 : 0.4))
  if (G.fear > 0.3 && t > G.heartbeatAt) { A.play('heartbeat', { vol: 0.4 + G.fear * 0.6, rateJitter: 0 }); G.heartbeatAt = t + 1100 - G.fear * 550 }
  G.breath?.setVol?.(P.holdingBreath ? 0 : 0.35 + G.fear * 0.5, 0.1)
  // random ambience: whispers, distant giggles
  if (t - G.lastAmbient > 25000 + Math.random() * 20000) {
    G.lastAmbient = t
    const a = Math.random() * Math.PI * 2
    A.play(Math.random() < 0.5 ? 'whisper' : 'squeak', { pos: A.at(P.x + Math.cos(a) * 9, P.z + Math.sin(a) * 9), vol: 0.5, ref: 3 })
  }
  const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
  A.S.listener(camera.position, fwd)
  A.updateBeds(dt, { fear: G.fear, chasing, elevator: G.F.elevators.exit.contains(P.x, P.z) && G.exitOpen })
  updateHud()
}

function hostStep (dt, t) {
  const F = G.F
  G.registry.set(myId(), { id: myId(), x: P.x, z: P.z, yaw: P.yaw, pitch: P.pitch, crouch: P.crouch, flashlight: torchOn(), hidden: P.hidden, hiddenSeen: P.hiddenSeen, holdingBreath: P.holdingBreath, dead: P.dead })
  const players = [...G.registry.values()]
  if (G.ents) {
    G.ents.update(dt, players, t)
    for (const e of G.ents.list) G.entState.set(e.id, { ...e })
  }
  // wind-up toys keep calling the Big Friend while they play
  for (const toy of G.toys) if (t < toy.until && (!toy.lastCall || t - toy.lastCall > 1500)) { toy.lastCall = t; G.ents?.hear(toy.x, toy.z, 30) }
  G.glows = G.glows.filter(g => g.until > t)
  G.toys = G.toys.filter(g => g.until > t)
  // the lift
  if (G.liftAt) {
    G.liftCountdown = Math.max(0, (G.liftAt - t) / 1000)
    if (t >= G.liftAt) { G.liftAt = 0; G.liftCountdown = 0; nextFloor(); return }
  } else G.liftCountdown = 0
  if (net.online && t - G.lastWorld > 100) {
    G.lastWorld = t
    sendAll('world', {
      floor: G.floor, e: G.ents ? G.ents.snapshot() : [], tk: [...G.tokens], it: [...G.items],
      gl: G.glows.map(g => ({ ...g, until: 1 })), toys: G.toys.map(g => ({ ...g, until: 1 })), exit: G.exitOpen, lift: +G.liftCountdown.toFixed(1),
      dead: players.filter(p => p.dead).map(p => p.id),
    })
  }
  void F
}

// ═════════════ UI ═════════════
const screens = ['title', 'floors', 'join', 'lobby', 'howto', 'settings', 'pause', 'dead']
let current = 'title'
const stack = []
function showScreen (name, { push = false } = {}) {
  if (push && current) stack.push(current)
  for (const s of screens) $(`#screen-${s}`)?.classList.toggle('is-open', s === name)
  current = name
  const first = name && $(`#screen-${name}`)?.querySelector('input, button')
  if (first && !touch) setTimeout(() => first.focus({ preventScroll: true }), 30)
}
const backScreen = () => showScreen(stack.pop() ?? 'title')
const clearStack = () => { stack.length = 0 }
const setHud = on => { $('#hud').classList.toggle('is-on', on); $('#touch').classList.toggle('is-on', on && touch) }
const fade = (to, ms) => { const el = $('#fade'); el.style.transition = `opacity ${ms}ms`; el.style.opacity = String(to) }
let flashTimer
const flashRed = () => { const el = $('#flash'); el.style.transition = 'none'; el.style.opacity = '1'; clearTimeout(flashTimer); flashTimer = setTimeout(() => { el.style.transition = 'opacity 1.4s'; el.style.opacity = '0' }, 1300) }
const textCache = new WeakMap()
const setText = (el, text, html = false) => { if (textCache.get(el) === text) return; textCache.set(el, text); if (html) el.innerHTML = text; else el.textContent = text }
let toastTimer
const toast = (text, ms = 3200) => { const el = $('#toast'); el.textContent = text; el.style.opacity = '1'; clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.style.opacity = '0' }, ms) }
let bigTimer
const big = (title, sub) => { const el = $('#big'); el.innerHTML = `${esc(title)}<small>${esc(sub)}</small>`; el.classList.add('is-on'); clearTimeout(bigTimer); bigTimer = setTimeout(() => el.classList.remove('is-on'), 3800) }
const setPrompt = label => setText($('#prompt'), label ? (touch ? esc(label) : `<kbd>E</kbd>${esc(label)}`) : '', true)
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
const setStatus = (sel, text, bad = false) => { const el = $(sel); el.textContent = text; el.classList.toggle('bad', bad) }

function updateHud () {
  const F = G.F
  setText($('#hud-floor'), `Floor ${G.floor}${G.entitiesOn ? '' : ' (creatures off)'}`)
  setText($('#hud-tokens'), `${G.tokens.size}/${F.params.tokens}`)
  setText($('#hud-goal'), G.exitOpen ? 'The lift is open. Get in and press the button.' : 'Find the star tokens. Then take the lift down.')
  const items = [
    ['Torch', !P.flashlight ? 'Off' : torchOn() ? 'On' : 'Out!', 'F', torchOn()],
    ['Drink', P.inv.soda, '1', P.inv.soda > 0],
    ['Glow', P.inv.glowstick, '2', P.inv.glowstick > 0],
    ['Toy', P.inv.windup, '3', P.inv.windup > 0],
  ]
  setText($('#items'), items.map(([n, v, k, on, bar]) => `<div class="item ${on ? '' : 'off'}">${k ? `<kbd>${k}</kbd>` : ''}<span>${n}</span><b>${v}</b>${bar != null ? `<div class="bar"><i style="width:${Math.round(bar)}%"></i></div>` : ''}</div>`).join(''), true)
  const boosted = now() < P.boostUntil
  $('#stamina-bar').style.width = `${boosted ? 100 : Math.round(P.stamina / (P.maxStamina ?? 100) * 100)}%`
  $('#stamina').classList.toggle('boost', boosted)
  setText($('#stamina-label'), boosted ? 'Sugar rush' : 'Stamina')
  const breath = $('#breath')
  breath.style.display = P.hidden ? 'block' : 'none'
  if (P.hidden) { $('#breath-bar').style.width = `${P.breath * 100}%`; setText($('#breath-text'), touch ? 'Hidden. Hold breath when it comes close' : 'Hidden. Hold Space to hold your breath, E to get out') }
  const cd = $('#countdown')
  const c = G.liftCountdown
  cd.style.display = c > 0 ? 'block' : 'none'
  if (c > 0) setText(cd, `Going down in ${Math.ceil(c)}…`)
  if (G.coop && net.online) setText($('#team'), [...net.players.values()].map(p => { const r = p.id === myId() ? P : G.registry.get(p.id); return `<span class="${r?.dead ? 'dead' : ''}">${esc(p.name)}${p.id === myId() ? ' (you)' : ''}${r?.dead ? ', caught' : ''}</span>` }).join(''), true)
  else setText($('#team'), '')
}

function updateProfile () {
  setText($('#profile'), `Deepest floor <b>${progress.maxFloor}</b> &nbsp; Level <b>${playerLevel()}</b> &nbsp; ${progress.catUnlocked ? 'Cat <b>adopted</b>' : `A stray cat waits on floor ${CAT_UNLOCK_FLOOR}`}`, true)
  $('#cat-row').style.display = progress.catUnlocked ? '' : 'none'
}

function renderFloors () {
  const list = $('#floor-list')
  list.innerHTML = ''
  for (let n = 1; n <= progress.maxFloor; n++) {
    const b = document.createElement('button')
    b.innerHTML = `${n}${n === progress.maxFloor ? '<small>deepest</small>' : ''}`
    b.setAttribute('aria-pressed', String(n === G.selectedFloor))
    b.setAttribute('aria-label', `Floor ${n}`)
    b.addEventListener('click', () => { G.selectedFloor = n; G.pickedFloor = true; renderFloors() })
    list.appendChild(b)
  }
  for (const b of document.querySelectorAll('#set-entities button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(G.entitiesOn)))
  setText($('#floor-play'), net.online ? `Use floor ${G.selectedFloor}` : `Play floor ${G.selectedFloor}`)
  setText($('#lobby-start'), `Start on floor ${G.selectedFloor}${G.entitiesOn ? '' : ' (creatures off)'}`)
}

function refreshLobby () {
  if (!net.online) return
  setText($('#lobby-code'), net.code || '- - - -')
  setText($('#lobby-roster'), [...net.players.values()].map(p => `<li>${esc(p.name)}${p.id === net.hostId ? '<small>host</small>' : ''}${p.id === net.id ? '<small>you</small>' : ''}</li>`).join(''), true)
  $('#lobby-start-li').style.display = isHost() ? '' : 'none'
  setText($('#lobby-hint'), isHost() ? 'Share this code with up to three friends, then start.' : 'Waiting for the host to start.')
  renderFloors()
}

function pause () {
  if (G.mode !== 'playing' || current === 'pause') return
  G.paused = !net.online
  input.pressed.clear()
  setText($('#pause-note'), net.online ? 'The play centre keeps going. In co-op, so does everything in it.' : 'Everything waits for you.')
  showScreen('pause')
}
function resume () { G.paused = false; input.pressed.clear(); showScreen(null); if (!touch) void canvas.requestPointerLock?.() }

async function openRoom () {
  showScreen('lobby', { push: true })
  $('#host-name-field').style.display = ''
  $('#host-name').value = myName
  setStatus('#lobby-status', 'Opening a room… (the server can take up to a minute to wake up)')
  try { await connect({ url: coopServerUrl(), mode: 'create', name: myName }); setStatus('#lobby-status', ''); refreshLobby() } catch (err) { setStatus('#lobby-status', err.message, true) }
}
async function joinRoom () {
  const name = $('#join-name').value.trim() || myName
  const code = $('#join-code').value.trim().toUpperCase()
  if (code.length !== 4) { setStatus('#join-status', 'Room codes are four letters.', true); return }
  setName(name)
  setStatus('#join-status', 'Joining… (the server can take up to a minute to wake up)')
  try {
    await connect({ url: coopServerUrl(), mode: 'join', code, name: myName })
    setStatus('#join-status', '')
    showScreen('lobby', { push: true })
    $('#host-name-field').style.display = 'none'
    refreshLobby()
  } catch (err) { setStatus('#join-status', err.message, true) }
}
const setName = n => { myName = n.slice(0, 14); try { localStorage.setItem('creeps.name', myName) } catch {} }

document.addEventListener('click', e => {
  const btn = e.target.closest('[data-go]')
  if (!btn) return
  A.S.init()
  switch (btn.dataset.go) {
    case 'play': disconnect(); startGame({ floor: progress.maxFloor > 1 ? progress.maxFloor : 1, entities: true }); break
    case 'host': void openRoom(); break
    case 'join': showScreen('join', { push: true }); $('#join-name').value = myName; break
    case 'join-go': void joinRoom(); break
    case 'floors': G.selectedFloor = G.pickedFloor ? Math.min(G.selectedFloor, progress.maxFloor) : progress.maxFloor; renderFloors(); showScreen('floors', { push: true }); break
    case 'floor-play':
      if (net.online) { backScreen(); renderFloors(); break }
      disconnect(); startGame({ floor: G.selectedFloor, entities: G.entitiesOn }); break
    case 'howto': showScreen('howto', { push: true }); break
    case 'settings': syncSettings(); showScreen('settings', { push: true }); break
    case 'back': backScreen(); break
    case 'leave': disconnect(); clearStack(); showScreen('title'); break
    case 'lobby-start':
      if (!isHost()) return
      sendAll('start', { floor: G.selectedFloor, entities: G.entitiesOn })
      startGame({ floor: G.selectedFloor, entities: G.entitiesOn, coop: true })
      break
    case 'resume': resume(); break
    case 'quit': quitToTitle(); break
  }
})
$('#set-entities').addEventListener('click', e => { const v = e.target.dataset.v; if (v) { G.entitiesOn = v === 'true'; renderFloors() } })
$('#host-name').addEventListener('change', e => { setName(e.target.value.trim() || myName); if (net.online) { const me = net.players.get(net.id); if (me) me.name = myName; sendAll('name', { name: myName }); refreshLobby() } })
$('#join-code').addEventListener('keydown', e => { if (e.key === 'Enter') void joinRoom() })
function syncSettings () {
  $('#set-sens').value = settings.sensitivity
  $('#set-vol').value = settings.volume
  for (const b of document.querySelectorAll('#set-quality button')) b.setAttribute('aria-pressed', String(b.dataset.q === settings.quality))
  for (const b of document.querySelectorAll('#set-invert button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.invertY)))
  for (const b of document.querySelectorAll('#set-cat button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.cat)))
}
$('#set-sens').addEventListener('input', e => { settings.sensitivity = +e.target.value; saveSettings() })
$('#set-vol').addEventListener('input', e => { settings.volume = +e.target.value; A.S.setVolume(settings.volume); saveSettings() })
$('#set-quality').addEventListener('click', e => { const q = e.target.dataset.q; if (!q) return; settings.quality = q; saveSettings(); syncSettings(); setStatus('#settings-status', 'Graphics change when you next load the page.') })
$('#set-invert').addEventListener('click', e => { const v = e.target.dataset.v; if (!v) return; settings.invertY = v === 'true'; saveSettings(); syncSettings() })
$('#set-cat').addEventListener('click', e => { const v = e.target.dataset.v; if (!v) return; settings.cat = v === 'true'; saveSettings(); syncSettings(); if (G.mode !== 'title') setupCat() })

// ═════════════ boot ═════════════
bindFullscreenButtons()
initInput(canvas, { onPause: reason => { if (reason === 'unlock') pause() } })
initGamepad(input, { sprintStick: true, held: { [BTN.A]: 'interact', [BTN.LT]: 'breath', [BTN.LB]: 'sprint' }, press: { [BTN.A]: 'interact', [BTN.RT]: 'interact', [BTN.B]: 'crouch', [BTN.RS]: 'crouch', [BTN.Y]: 'flashlight', [BTN.X]: 'soda', [BTN.UP]: 'glowstick', [BTN.RB]: 'glowstick', [BTN.DOWN]: 'windup' } })
if (touch) initTouchControls($('#touch'))
// a quiet floor 1 behind the title screen
G.entitiesOn = true
loadFloor(1, false)
G.entitiesOn = true
G.F.lights.forEach(l => { l.off = false })
updateProfile()
showScreen('title')
fade(0, 1500)
requestAnimationFrame(frame)

window.__cr = { G, P, net, startGame, request, hostKill, loadFloor, progress, myId, findInteraction, useInteraction, nextFloor }
void DOOR_W; void ROOM; void sendHost
