// looks.js: every horror entity as a recipe over the shared rigged human (see creature.js)
import * as THREE from 'three'
import { Creature, M, mouthParts, hairStrands, claw, bend, attachTo } from './creature.js'

const FING = ['index', 'middle', 'ring', 'pinky']
const inv = (a, b) => a.map((v, i) => 1 / v * b[i])
function clawsOn (bones, side, len, r, mat) {
  for (const f of FING) attachTo(bones[`${f}_04_leaf_${side}`] || bones[`${f}_03_${side}`], claw(len, r, mat), [0, 0, 0], [0, 0, 0])
}
function eyesOn (head, o = {}) {
  const g = new THREE.Group(), m = M.glow(o.color ?? 0xfff6e0)
  g.userData.face = 'eyes'
  for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(o.r ?? 0.006, 8, 6), m); e.position.set(s * 0.034, o.y ?? 0.185, o.z ?? 0.088); g.add(e) }
  head.add(g); return g
}

// coarse burlap weave (cached)
let _burlap = null
function burlapTex () {
  if (_burlap) return _burlap
  const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d')
  g.fillStyle = '#8a7656'; g.fillRect(0, 0, 256, 256)
  for (let i = 0; i < 256; i += 4) { g.fillStyle = `rgba(40,28,14,${0.25 + Math.random() * 0.2})`; g.fillRect(i, 0, 1.5, 256); g.fillRect(0, i + 2, 256, 1.5) }
  for (let i = 0; i < 40; i++) { g.fillStyle = `rgba(${50 + Math.random() * 40},${10 + Math.random() * 10},8,${0.2 + Math.random() * 0.3})`; g.beginPath(); g.arc(Math.random() * 256, Math.random() * 256, 4 + Math.random() * 20, 0, 7); g.fill() }
  _burlap = new THREE.CanvasTexture(c); _burlap.colorSpace = THREE.SRGBColorSpace; _burlap.wrapS = _burlap.wrapT = THREE.RepeatWrapping; _burlap.repeat.set(3, 3)
  return _burlap
}
// a hanging skirt / gown hem made of irregular cloth strips that sway
function skirt (color, len) {
  const g = new THREE.Group(), m = new THREE.MeshStandardMaterial({ color, roughness: 0.95, side: THREE.DoubleSide })
  const n = 22
  for (let i = 0; i < n; i++) {
    const a = i / n * Math.PI * 2, L = len * (0.75 + Math.random() * 0.4)
    const geo = new THREE.PlaneGeometry(0.09, L, 1, 5); geo.translate(0, -L / 2, 0)
    const pos = geo.attributes.position; for (let k = 0; k < pos.count; k++) { const y = pos.getY(k); pos.setZ(k, -y * 0.22 + Math.sin(y * 13 + i) * 0.008) }
    geo.computeVertexNormals()
    const s = new THREE.Mesh(geo, m); s.position.set(Math.sin(a) * 0.15, 0, Math.cos(a) * 0.12); s.rotation.y = a; g.add(s)
  }
  // dark stain band near the hem
  return g
}
export const LOOKS = {
  // ── Sanity's Edge ──
  // the tall one: nearly three metres of starved, charred-dark body. Arms to its knees, fingers like knitting needles,
  // a jaw hanging open past the collarbone. Frozen mid-stride whenever you look at it.
  tallOne: () => ({
    body: 'm', height: 2.9,
    skin: { palette: 'ash', spec: 0.15, ribs: 1, spine: 1, veins: 0.25, bruises: 0.6, blood: 0.55, rot: 0.3, wet: 0.08, eyes: 1, mouth: 1, mouthSize: [0.036, 0.04], dirt: 0.2, bump: 1.6, wound: [0, 1.1, 0.1, 0.08] },
    scale: {
      spine_01: [0.78, 1.12, 0.72], spine_02: [0.95, 1.1, 0.9], spine_03: [1.05, 1.05, 1.0],
      neck_01: [0.8, 1.5, 0.8], Head: [1.12, 0.78, 1.18],
      upperarm_l: [0.7, 1.35, 0.7], upperarm_r: [0.7, 1.35, 0.7], lowerarm_l: [0.95, 1.3, 0.95], lowerarm_r: [0.95, 1.3, 0.95],
      hand_l: [1.2, 1.25, 1.2], hand_r: [1.2, 1.25, 1.2],
      thigh_l: [0.72, 1.12, 0.72], thigh_r: [0.72, 1.12, 0.72], calf_l: [0.9, 1.1, 0.9], calf_r: [0.9, 1.1, 0.9],
      index_02_l: [0.8, 1.9, 0.8], middle_02_l: [0.8, 2.0, 0.8], ring_02_l: [0.8, 1.9, 0.8], pinky_02_l: [0.8, 1.7, 0.8],
      index_02_r: [0.8, 1.9, 0.8], middle_02_r: [0.8, 2.0, 0.8], ring_02_r: [0.8, 1.9, 0.8], pinky_02_r: [0.8, 1.7, 0.8],
    },
    offset: { clavicle_l: [0, 0, -0.18], clavicle_r: [0, 0, 0.18], spine_03: [0.18, 0, 0], neck_01: [0.25, 0, 0] },
    twitch: { Head: 0.25, neck_01: 0.08 },
    clips: { idle: 'Idle_Loop', walk: 'Walk_Loop', run: 'Sprint_Loop' },
    attach (b) {
      attachTo(b.Head, mouthParts({ width: 0.03, open: 0.03, teeth: 9, toothLen: 0.014 }), [0, 0.095, 0.095])
      eyesOn(b.Head, { r: 0.0045, y: 0.17, z: 0.08, color: 0xffe8c8 })
      clawsOn(b, 'l', 0.07, 0.004, M.dark(0x0d0b09, 0.5)); clawsOn(b, 'r', 0.07, 0.004, M.dark(0x0d0b09, 0.5))
    },
    pose (b, t, st) {
      // jaw hangs and works slowly; when chasing it opens wider
      bend(b.Head, -0.1 + Math.sin(t * 0.7) * 0.05, 0, st.watched ? 0.35 : Math.sin(t * 3.1) * 0.12)
    },
  }),
  // the patient: a skeletal woman on all fours with her head turned all the way round, elbows bent the wrong way,
  // autopsy stitches up her chest and black hair dragging on the floor
  patient: () => ({
    body: 'f',
    skin: { palette: 'pale', ribs: 0.8, spine: 1, veins: 0.6, bruises: 0.7, blood: 0.6, rot: 0.25, wet: 0.15, eyes: 1, mouth: 1, mouthSize: [0.03, 0.03], stitches: 1, dirt: 0.7, bump: 1.4, wound: [0, 1.25, 0.1, 0.09] },
    scale: { spine_01: [0.8, 1.15, 0.8], spine_02: [0.85, 1.12, 0.85], upperarm_l: [0.75, 1.25, 0.75], upperarm_r: [0.75, 1.25, 0.75], thigh_l: [0.75, 1.05, 0.75], thigh_r: [0.75, 1.05, 0.75], lowerarm_l: [0.85, 1.2, 0.85], lowerarm_r: [0.85, 1.2, 0.85] },
    offset: { neck_01: [0, 1.4, 0], Head: [0, 1.6, 0.5], lowerarm_l: [0, 0, -0.55], lowerarm_r: [0, 0, 0.55] },
    twitch: { Head: 0.5, hand_l: 0.3, hand_r: 0.3 },
    clips: { idle: 'Crawl_Idle_Loop', walk: 'Crawl_Fwd_Loop', run: 'Crawl_Fwd_Loop' },
    attach (b) {
      attachTo(b.Head, hairStrands(80, 0.75, 0.105), [0, 0.17, -0.01])
      attachTo(b.Head, mouthParts({ width: 0.026, open: 0.026, teeth: 8 }), [0, 0.098, 0.093])
      eyesOn(b.Head, { r: 0.008, y: 0.165, z: 0.082, color: 0xf4f2e8 })
    },
  }),
  // the nurse: stained gown, face lost under old bandages, neck snapped so her head lies on her shoulder, a scalpel
  nurse: () => ({
    body: 'f', height: 1.86,
    skin: { palette: 'corpse', veins: 0.6, bruises: 0.6, blood: 0.7, rot: 0.35, wet: 0.2, eyes: 0, mouth: 0, face: false, bandage: true, dirt: 0.5, garment: [1, 0.42, 1.5, 0.3], cloth: 0x5c5648, cloth2: 0x423e34, tear: 0.25, bump: 1.2, wound: [0.05, 1.3, 0.12, 0.1] },
    scale: { spine_01: [0.85, 1.05, 0.85], upperarm_l: [0.85, 1.12, 0.85], upperarm_r: [0.85, 1.12, 0.85] },
    offset: { neck_01: [0.15, 0, 1.15], Head: [0.25, 0.3, 0.35], upperarm_r: [0, 0, 0] },
    twitch: { Head: 0.35, neck_01: 0.12, hand_l: 0.25 },
    clips: { idle: 'Idle_Loop', walk: 'Walk_Formal_Loop', run: 'Zombie_Run_Fwd_Loop' },
    attach (b) {
      // skirt flare hanging from the hips
      attachTo(b.pelvis, skirt(0x4e493d, 0.62), [0, 0.12, 0], [0, 0, 0])
      // scalpel
      const sc = new THREE.Group(); const bl = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.09, 0.016), M.metal(0xb0b8bc)); bl.position.y = 0.11; sc.add(bl)
      const hd = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.1, 0.012), M.metal(0x6a7076)); hd.position.y = 0.04; sc.add(hd)
      attachTo(b.hand_r, sc, [0.01, 0.06, 0.02], [0.3, 0, 1.4])
    },
  }),

  // ── S.O.S. Isolation ──
  // husk: a crew member still in the torn remains of an EVA suit, helmet visor cracked, what is left of the face inside
  husk: () => ({
    body: 'm',
    skin: { palette: 'corpse', rot: 0.9, veins: 0.8, bruises: 0.8, blood: 0.6, wet: 0.3, eyes: 1, mouth: 1, mouthSize: [0.03, 0.028], dirt: 0.2, garment: [2, 0.0, 1.52, 1.2], cloth: 0x8f8b80, cloth2: 0x66625a, tear: 0.55, bump: 1.4, wound: [0.06, 1.2, 0.13, 0.12] },
    scale: {},
    offset: { neck_01: [0.25, 0, 0.3], spine_03: [0.2, 0, 0.1] },
    twitch: { Head: 0.4, neck_01: 0.15 },
    clips: { idle: 'Zombie_Idle_Loop', walk: 'Zombie_Walk_Fwd_Loop', run: 'Zombie_Run_Fwd_Loop', attack: 'Zombie_Bite' },
    attach (b) {
      const helm = new THREE.Group()
      const shell = new THREE.Mesh(new THREE.SphereGeometry(0.155, 18, 14, 0, Math.PI * 2, 0, Math.PI * 0.82), M.glass()); helm.add(shell)
      // the visor is split with a crack and smeared from inside
      const crack = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.0015, 3, 24, 1.4), M.glow(0x9aa4aa)); crack.rotation.set(0.3, 0.9, 0.4); helm.add(crack)
      const crack2 = crack.clone(); crack2.rotation.set(-0.6, 0.6, 1.9); helm.add(crack2)
      const smear = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8, -0.4, 0.8, 1.2, 0.6), new THREE.MeshStandardMaterial({ color: 0x2a0303, roughness: 0.2, transparent: true, opacity: 0.7, depthWrite: false })); helm.add(smear)
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.025, 8, 20), M.metal(0x7c8084)); ring.rotation.x = Math.PI / 2; ring.position.y = -0.1; helm.add(ring)
      attachTo(b.Head, helm, [0, 0.13, 0.02], [0.25, 0, 0])
      attachTo(b.Head, mouthParts({ width: 0.028, open: 0.024, teeth: 8 }), [0, 0.098, 0.093])
      const pack = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.45, 0.16), M.cloth(0x4a4740, 0.8)); attachTo(b.spine_03, pack, [0, 0.0, -0.17])
      const hose = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.014, 6, 12, Math.PI), M.dark(0x262626, 0.6)); attachTo(b.spine_03, hose, [0.12, 0.12, -0.05], [0, Math.PI / 2, 0])
    },
  }),
  // the merged one: a crewman's upper body grafted to the front of the spider, arms out, head hanging
  graft: () => ({
    body: 'm',
    skin: { palette: 'corpse', rot: 1, veins: 1, bruises: 1, blood: 0.9, wet: 0.4, eyes: 1, mouth: 1, mouthSize: [0.034, 0.04], ribs: 0.7, dirt: 0, bump: 1.8, wound: [0, 0.95, 0, 0.2] },
    scale: { thigh_l: [0.01, 0.01, 0.01], thigh_r: [0.01, 0.01, 0.01], upperarm_l: [0.9, 1.25, 0.9], upperarm_r: [0.9, 1.25, 0.9], lowerarm_l: [1, 1.15, 1], lowerarm_r: [1, 1.15, 1] },
    offset: { neck_01: [0.5, 0, 0.4], spine_01: [-0.35, 0, 0] },
    twitch: { Head: 0.6, hand_l: 0.4, hand_r: 0.4, lowerarm_l: 0.2 },
    clips: { idle: 'Zombie_Idle_Loop', walk: 'Zombie_Idle_Loop', run: 'Zombie_Scratch', attack: 'Zombie_Bite' },
    attach (b) {
      attachTo(b.Head, mouthParts({ width: 0.03, open: 0.034, teeth: 9 }), [0, 0.095, 0.094])
      eyesOn(b.Head, { r: 0.006, color: 0xff3020 })
      clawsOn(b, 'l', 0.05, 0.004, M.bone()); clawsOn(b, 'r', 0.05, 0.004, M.bone())
    },
  }),

  // ── St. Ambrose / Vertigo Freight ──
  // the orderly: a huge man in filthy scrubs and a rubber apron, sack hood stitched over his head
  orderly: () => ({
    body: 'm', height: 2.05,
    skin: { palette: 'corpse', veins: 0.7, bruises: 0.5, blood: 0.75, rot: 0.2, wet: 0.2, eyes: 0, mouth: 0, face: false, dirt: 0.6, garment: [3, 0.08, 1.48, 0.42], cloth: 0x4c5a52, cloth2: 0x36403a, tear: 0.15, bump: 1.2 },
    scale: { spine_02: [1.2, 1.0, 1.15], spine_03: [1.25, 1.0, 1.2], upperarm_l: [1.2, 1.05, 1.2], upperarm_r: [1.2, 1.05, 1.2], lowerarm_l: [1.1, 1.05, 1.1], lowerarm_r: [1.1, 1.05, 1.1], thigh_l: [1.15, 1, 1.15], thigh_r: [1.15, 1, 1.15], neck_01: [1.2, 0.8, 1.2] },
    offset: { spine_03: [0.2, 0, 0], neck_01: [0.15, 0, 0] },
    twitch: { Head: 0.15 },
    clips: { idle: 'Zombie_Idle_Loop', walk: 'Zombie_Walk_Fwd_Loop', run: 'Jog_Fwd_Loop', attack: 'Zombie_Bite', search: 'Idle_LookAround_Loop' },
    attach (b, c) {
      // a burlap sack pulled over his head, tied at the neck: two ragged eye holes, a stitched mouth slit
      const hood = new THREE.Group(); hood.userData.face = 'hood'
      const sack = new THREE.MeshStandardMaterial({ color: 0x4f4231, roughness: 1, map: burlapTex(), bumpMap: burlapTex(), bumpScale: 0.004 })
      const sg = new THREE.SphereGeometry(0.106, 22, 16), sp = sg.attributes.position
      for (let i = 0; i < sp.count; i++) { const x = sp.getX(i), y = sp.getY(i), z = sp.getZ(i), n = Math.sin(x * 61) * Math.cos(y * 47) * Math.sin(z * 53); sp.setXYZ(i, x * (1 + n * 0.05), y < -0.05 ? y * 0.85 : y, z * (1 + n * 0.05)) }
      sg.computeVertexNormals()
      const bag = new THREE.Mesh(sg, sack); bag.scale.set(1, 1.18, 1.06); hood.add(bag)
      for (const sx of [-1, 1]) { const hole = new THREE.Mesh(new THREE.CircleGeometry(0.017, 9), M.dark(0x000000)); hole.position.set(sx * 0.036, 0.03, 0.111); hole.scale.y = 0.8 + Math.random() * 0.4; hood.add(hole) }
      const st = M.dark(0x1a0f08)
      for (let i = 0; i < 7; i++) { const t = new THREE.Mesh(new THREE.BoxGeometry(0.003, 0.02, 0.003), st); t.position.set(-0.04 + i * 0.013, -0.04, 0.106); t.rotation.z = 0.6; hood.add(t) }
      const tie = new THREE.Mesh(new THREE.TorusGeometry(0.066, 0.009, 5, 16), new THREE.MeshStandardMaterial({ color: 0x241d14, roughness: 1 })); tie.rotation.x = Math.PI / 2; tie.position.y = -0.085; hood.add(tie)
      attachTo(b.Head, hood, [0, 0.12, 0.005])
      const apron = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.78, 1, 4), new THREE.MeshStandardMaterial({ color: 0x1c1a17, roughness: 0.25, metalness: 0.1, side: THREE.DoubleSide })); attachTo(b.spine_01, apron, [0, -0.05, 0.16])
      const bl = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.4), new THREE.MeshStandardMaterial({ color: 0x3a0404, roughness: 0.1, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false })); attachTo(b.spine_01, bl, [0.04, -0.18, 0.162])
      // eyes behind the holes in the hood (lit when he hunts) and a length of steel pipe in the right hand
      c.eyeGlow = eyesOn(b.Head, { r: 0.007, y: 0.15, z: 0.12, color: 0x1c1010 })
      const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.85, 8), new THREE.MeshStandardMaterial({ color: 0x5b4c3e, roughness: 0.45, metalness: 0.8 }))
      attachTo(b.hand_r, pipe, [0.0, 0.08, 0.03], [0, 0, 0])
    },
  }),
  // Vertigo Freight's stowaway: a long, wet, pale thing in the rags of a conductor's coat. Arms too long,
  // head carried low and forward, jaw unhinged. Eyes go red when it has your scent.
  gaunt: () => ({
    body: 'm', height: 2.45,
    skin: { palette: 'drowned', ribs: 1, spine: 1, veins: 1, bruises: 0.7, blood: 0.5, rot: 0.5, wet: 0.35, spec: 0.5, eyes: 1, mouth: 1, mouthSize: [0.036, 0.042], dirt: 0.5, garment: [4, 0.62, 1.45, 0.36], cloth: 0x1d1c1f, cloth2: 0x121114, tear: 0.25, bump: 1.4, wound: [0, 1.0, 0.1, 0.1] },
    scale: {
      spine_01: [0.78, 1.1, 0.75], spine_02: [0.9, 1.08, 0.85], neck_01: [0.8, 1.45, 0.8], Head: [1.1, 0.85, 1.12],
      upperarm_l: [0.75, 1.3, 0.75], upperarm_r: [0.75, 1.3, 0.75], lowerarm_l: [0.9, 1.3, 0.9], lowerarm_r: [0.9, 1.3, 0.9],
      thigh_l: [0.75, 1.08, 0.75], thigh_r: [0.75, 1.08, 0.75],
      index_02_l: [0.8, 1.6, 0.8], middle_02_l: [0.8, 1.7, 0.8], ring_02_l: [0.8, 1.6, 0.8], index_02_r: [0.8, 1.6, 0.8], middle_02_r: [0.8, 1.7, 0.8], ring_02_r: [0.8, 1.6, 0.8],
    },
    offset: { spine_03: [0.3, 0, 0], neck_01: [0.45, 0, 0], Head: [-0.35, 0, 0], clavicle_l: [0, 0, -0.15], clavicle_r: [0, 0, 0.15] },
    twitch: { Head: 0.35, neck_01: 0.1, hand_l: 0.2, hand_r: 0.2 },
    clips: { idle: 'Zombie_Idle_Loop', walk: 'Walk_Loop', search: 'Idle_LookAround_Loop', run: 'Sprint_Loop', scream: 'Zombie_Scratch', lunge: 'Zombie_Bite' },
    attach (b, c) {
      attachTo(b.Head, mouthParts({ width: 0.032, open: 0.036, teeth: 10, toothLen: 0.018 }), [0, 0.094, 0.094])
      c.eyeGlow = eyesOn(b.Head, { r: 0.0065, color: 0xd8d2c4 })
      clawsOn(b, 'l', 0.06, 0.004, M.dark(0x1a1512, 0.3)); clawsOn(b, 'r', 0.06, 0.004, M.dark(0x1a1512, 0.3))
      // coat tails: long torn strips hanging from the waist
      attachTo(b.pelvis, skirt(0x18171a, 0.95), [0, 0.18, 0])
    },
  }),
  // dead passengers: slumped in their seats, grey and swollen. Their heads follow you down the aisle.
  passenger: (seed = Math.random()) => ({
    body: seed < 0.5 ? 'm' : 'f',
    skin: { palette: 'drowned', rot: 0.8, veins: 0.7, bruises: 0.9, blood: 0.35, wet: 0.2, eyes: 1, mouth: 0.8, mouthSize: [0.026, 0.02], dirt: 0.3, garment: [3, 0.4, 1.5, 0.5], cloth: seed < 0.33 ? 0x2a2c34 : seed < 0.66 ? 0x3a2f26 : 0x2f3a33, cloth2: 0x1a1a1a, tear: 0.1, seed: seed * 40, bump: 1.1 },
    offset: { neck_01: [0.35, 0, (seed - 0.5) * 0.8] },
    twitch: { Head: 0.08 },
    clips: { idle: 'Sitting_Idle_Loop' },
    attach (b, c) { c.eyeGlow = eyesOn(b.Head, { r: 0.004, color: 0xbfb8a8 }) },
  }),
  // St. Ambrose's patients: thin figures in hospital gowns who stand in the dark at the end of a corridor and watch
  phantom: (seed = Math.random()) => ({
    body: seed < 0.5 ? 'f' : 'm', height: 1.75 + seed * 0.2,
    skin: { palette: 'pale', ribs: 0.6, spine: 0.6, veins: 0.9, bruises: 0.7, blood: 0.5, rot: 0.3, wet: 0.15, eyes: 1, mouth: 1, mouthSize: [0.03, 0.03], stitches: seed < 0.5 ? 1 : 0, dirt: 0.5, garment: [1, 0.55, 1.48, 0.25], cloth: 0x3c4648, cloth2: 0x2a3234, tear: 0.35, seed: seed * 40, bump: 1.2 },
    scale: { spine_01: [0.82, 1.08, 0.82], upperarm_l: [0.8, 1.15, 0.8], upperarm_r: [0.8, 1.15, 0.8] },
    offset: { neck_01: [0.1, 0, 0.5 * (seed - 0.5)], Head: [0.2, 0, 0.25] },
    twitch: { Head: 0.3, hand_l: 0.2, hand_r: 0.2 },
    clips: { idle: 'Idle_Loop' },
    attach (b, c) {
      if (seed < 0.5) attachTo(b.Head, hairStrands(60, 0.6, 0.1), [0, 0.17, -0.01])
      c.eyeGlow = eyesOn(b.Head, { r: 0.006, color: 0xe8e4d8 })
      attachTo(b.pelvis, skirt(0x323a3c, 0.55), [0, 0.16, 0])
    },
  }),
  // the freight thing: something that was a maintenance worker, skin burnt and peeled, arms dislocated to the floor
  hauler: () => ({
    body: 'm', height: 2.15,
    skin: { palette: 'burnt', rot: 0.4, veins: 1, bruises: 0.6, blood: 0.8, wet: 0.3, eyes: 1, mouth: 1, mouthSize: [0.036, 0.042], ribs: 0.5, dirt: 0.8, garment: [4, 0.0, 0.95, 0.2], cloth: 0x3c3a2a, cloth2: 0x2a281c, tear: 0.5, bump: 1.8 },
    scale: { upperarm_l: [0.85, 1.45, 0.85], upperarm_r: [0.85, 1.45, 0.85], lowerarm_l: [0.95, 1.3, 0.95], lowerarm_r: [0.95, 1.3, 0.95], spine_03: [1.1, 1, 1.1], neck_01: [0.8, 1.4, 0.8] },
    offset: { spine_02: [0.35, 0, 0], neck_01: [-0.5, 0, 0], Head: [-0.3, 0, 0], clavicle_l: [0, 0, -0.25], clavicle_r: [0, 0, 0.25] },
    twitch: { Head: 0.3, hand_l: 0.3, hand_r: 0.3 },
    clips: { idle: 'Zombie_Idle_Loop', walk: 'Zombie_Walk_Fwd_Loop', run: 'Zombie_Run_Fwd_Loop', attack: 'Zombie_Scratch' },
    attach (b) {
      attachTo(b.Head, mouthParts({ width: 0.032, open: 0.036, teeth: 10, toothLen: 0.016 }), [0, 0.094, 0.094])
      eyesOn(b.Head, { r: 0.007, color: 0xffd090 })
      clawsOn(b, 'l', 0.06, 0.005, M.bone()); clawsOn(b, 'r', 0.06, 0.005, M.bone())
      // a hook through the shoulder, chain hanging
      const hook = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.008, 6, 12, Math.PI * 1.4), M.metal(0x5a4a3c)); attachTo(b.clavicle_r, hook, [0, 0.1, 0.05], [0, 0, 0.5])
    },
  }),
}

export function makeLook (assets, name, extra, seed) {
  const L = LOOKS[name](seed); if (extra) Object.assign(L, extra)
  const c = new Creature(assets, L); c.name = name; return c
}
