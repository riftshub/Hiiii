// creature.js: realistic horror creatures built on a rigged human base.
// Base meshes + animations: Quaternius "Universal Animation Library" 1 & 2 (CC0 1.0, quaternius.com).
// Everything that makes them wrong (skin, gore, proportions, broken joints, extra parts) happens here in code.
import * as THREE from 'three'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
import { clone as skClone } from 'three/addons/utils/SkeletonUtils.js'

// ───────────────────────── loading ─────────────────────────
const cache = new Map()
export function loadCreatures (base = './models/') {
  if (cache.has(base)) return cache.get(base)
  const loader = new GLTFLoader()
  const get = f => new Promise(resolve => loader.load(base + f, g => resolve(g), undefined, () => resolve(null)))
  // detailed bodies (real faces) on computers; phones keep the light mannequin bodies
  const hd = !Creature.low
  const p = Promise.all([get('creature_m.glb'), get('creature_f.glb'), hd ? get('body_m_hd.glb') : null, hd ? get('body_f_hd.glb') : null]).then(([m, f, mh, fh]) => {
    if (!m) throw new Error('creature_m.glb missing')
    const clips = new Map(); for (const c of m.animations) clips.set(c.name, c)
    const A = { m: mh || m, f: fh || f || m, clips, hd: !!(mh || fh) }
    if (mh) A.m.face = landmarks(mh)
    if (fh) A.f.face = landmarks(fh)
    return A
  })
  cache.set(base, p); return p
}

// find the nose tip on a detailed body (bind space) and place eyes and mouth from it
function landmarks (g) {
  let pos = null; g.scene.traverse(o => { if (o.isSkinnedMesh && !pos) pos = o.geometry.attributes.position })
  if (!pos) return null
  let top = -1e9; for (let i = 0; i < pos.count; i++) top = Math.max(top, pos.getY(i))
  let nz = -1e9, ny = 0
  for (let i = 0; i < pos.count; i++) { const y = pos.getY(i); if (y > top - 0.3 && y < top - 0.08 && Math.abs(pos.getX(i)) < 0.03 && pos.getZ(i) > nz) { nz = pos.getZ(i); ny = y } }
  return { top, nose: [0, ny, nz], eyes: [0.032, ny + 0.036, nz - 0.03], mouth: [0, ny - 0.042, nz - 0.012] }
}

// ───────────────────────── skin shader ─────────────────────────
// All detail is painted in bind-pose space (the model's own coordinates), so it sticks to the body while it moves.
// Model space: metres, +Y up, +Z = the way it faces, feet at y=0, head top ~1.82 (male) / 1.80 (female), T-pose arms along X.
const NOISE = /* glsl */`
varying vec3 vBind;
float h3 (vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float n3 (vec3 x) { vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(h3(i), h3(i + vec3(1,0,0)), f.x), mix(h3(i + vec3(0,1,0)), h3(i + vec3(1,1,0)), f.x), f.y),
             mix(mix(h3(i + vec3(0,0,1)), h3(i + vec3(1,0,1)), f.x), mix(h3(i + vec3(0,1,1)), h3(i + vec3(1,1,1)), f.x), f.y), f.z); }
#ifdef CR_LOW
#define CR_OCT 2
#else
#define CR_OCT 4
#endif
float fbm (vec3 p) { float a = 0.5, s = 0.0; for (int i = 0; i < CR_OCT; i++) { s += a * n3(p); p = p * 2.03 + 3.1; a *= 0.5; } return s; }
uniform vec3 uBase, uMottle, uVein, uBruise, uBlood, uCloth, uCloth2;
uniform float uVeins, uBruises, uBloodAmt, uRot, uWet, uRibs, uSpine, uEyes, uMouth, uDirt, uSeed, uStitches;
uniform vec4 uGarment;   // x: type (0 none, 1 gown, 2 suit, 3 scrubs, 4 rags), y: bottom, z: top, w: sleeve reach (|x|)
uniform float uTear, uHead, uBandage;
uniform vec2 uMouthSz;
uniform vec3 uEyeP; uniform vec2 uMouthP;
uniform float uSpecK, uAlb; // uHead: 1 = paint face details, 0 = skip (helmeted etc)
uniform vec4 uBloodZone; // xyz centre (bind space), w radius: an extra wound
`
// returns height for bump and writes colour/rough through out params
const PAINT = /* glsl */`
float skinPaint (vec3 p, inout vec3 col, inout float rough, inout float metal) {
  vec3 q = p + uSeed;
  float big = fbm(q * 6.0), fine = n3(q * 90.0), mid = fbm(q * 18.0);
  // fade detail that is smaller than a pixel (stops sparkle/aliasing at a distance or on low resolutions)
  float px = length(fwidth(p));
  float dF = clamp(1.0 - px * 90.0, 0.0, 1.0), dM = clamp(1.0 - px * 30.0, 0.0, 1.0);
  float h = (fine - 0.5) * 0.25 * dF + (mid - 0.5) * 0.4 * dM + (fbm(q * 28.0) - 0.5) * 0.35 * dF;
  col = mix(uBase, uMottle, smoothstep(0.3, 0.7, big));
  col *= 0.7 + 0.6 * mid;
  col = mix(col, uMottle * 0.6, smoothstep(0.6, 0.85, fbm(q * 2.5 + 2.0)) * 0.6);
  // veins: thin ridges of a warped noise field
  float vn = fbm(q * vec3(5.0, 2.2, 5.0) + n3(q * 4.0) * 1.6);
  float vein = (1.0 - smoothstep(0.0, 0.022, abs(vn - 0.5))) * (1.0 - 0.6 * smoothstep(1.5, 1.6, p.y));
  col = mix(col, uVein, vein * uVeins);
  h += vein * uVeins * 0.35;
  // bruising / necrotic patches
  float br = smoothstep(0.58, 0.8, fbm(q * 2.2 + 7.0));
  col = mix(col, uBruise, br * uBruises);
  // rot: green-grey sheen and pitting
  float rot = smoothstep(0.45, 0.85, fbm(q * 4.5 + 11.0)) * uRot;
  col = mix(col, col * vec3(0.55, 0.62, 0.45), rot);
  h -= rot * smoothstep(0.6, 0.9, n3(q * 40.0)) * 0.6;
  rough = 0.93 - uWet * 0.5 - mid * 0.08;
  // creases and pores darken
  col *= 0.75 + 0.25 * smoothstep(0.2, 0.7, fbm(q * 25.0));
  metal = 0.0;
  float ax = abs(p.x);
  // ribs: ridges across the torso front and sides, sunken between them; and a caved belly
  float torso = smoothstep(0.18, 0.12, ax) * smoothstep(1.13, 1.2, p.y) * smoothstep(1.47, 1.4, p.y) * smoothstep(-0.04, 0.02, p.z);
  float rib = pow(abs(sin((p.y - 1.15) * 52.0 + ax * 9.0)), 6.0);
  h += torso * uRibs * (rib * 3.0 - 0.6) * clamp(1.0 - px * 12.0, 0.0, 1.0);
  col *= 1.0 - torso * uRibs * (1.0 - rib) * 0.55;
  float belly = smoothstep(0.14, 0.05, ax) * smoothstep(0.95, 1.05, p.y) * smoothstep(1.17, 1.1, p.y) * step(0.0, p.z);
  col *= 1.0 - belly * uRibs * 0.3;
  // spine knuckles down the back
  float sp = smoothstep(0.025, 0.0, ax) * step(p.z, 0.0) * smoothstep(0.95, 1.05, p.y) * smoothstep(1.55, 1.45, p.y);
  h += sp * uSpine * pow(abs(sin(p.y * 70.0)), 3.0) * 1.6;
  // face: hollow eye sockets, a dark stretched mouth, blood from both
  float head = smoothstep(1.53, 1.58, p.y) * uHead;
  vec2 eL = vec2(p.x - uEyeP.x, p.y - uEyeP.y), eR = vec2(p.x + uEyeP.x, p.y - uEyeP.y);
  float eye = (smoothstep(0.026, 0.01, length(eL * vec2(1.0, 1.4))) + smoothstep(0.026, 0.01, length(eR * vec2(1.0, 1.4)))) * step(uEyeP.z, p.z) * head;
  col = mix(col, vec3(0.012, 0.006, 0.004), eye * uEyes);
  h -= eye * uEyes * 1.4;
  float mouth = smoothstep(uMouthSz.x, uMouthSz.x * 0.6, abs(p.x)) * smoothstep(uMouthSz.y, uMouthSz.y * 0.5, abs(p.y - uMouthP.x + abs(p.x) * 0.25)) * step(uMouthP.y, p.z) * head;
  col = mix(col, vec3(0.03, 0.0, 0.0), mouth * uMouth);
  h -= mouth * uMouth;
  // tears of blood running down from eyes and mouth
  float run = smoothstep(0.7, 1.0, n3(vec3(p.x * 160.0, 0.0, uSeed))) * step(0.05, p.z) * head;
  float under = smoothstep(uEyeP.y + 0.005, uEyeP.y - 0.015, p.y) * smoothstep(uEyeP.y - 0.145, uEyeP.y - 0.105, p.y);
  float eyeCol = max(smoothstep(0.016, 0.006, abs(abs(p.x) - uEyeP.x)), 0.0);
  float trail = (eyeCol * under * uEyes + smoothstep(0.03, 0.0, abs(p.x)) * smoothstep(uMouthP.x - 0.005, uMouthP.x - 0.025, p.y) * smoothstep(uMouthP.x - 0.125, uMouthP.x - 0.065, p.y) * uMouth) * (0.4 + run);
  // blood: splashes on hands, chest and from the wound zone; drips run downward (stretched in y)
  float drip = fbm(vec3(q.x * 30.0, q.y * 3.0, q.z * 30.0));
  float zone = smoothstep(uBloodZone.w, uBloodZone.w * 0.3, length(p - uBloodZone.xyz) - max(0.0, uBloodZone.y - p.y) * 0.4 * step(p.y, uBloodZone.y));
  float hands = smoothstep(0.6, 0.75, ax) * step(p.y, 1.55);
  float bl = clamp((smoothstep(0.55, 0.7, drip) * (hands * 0.9 + smoothstep(1.25, 1.45, p.y) * step(0.0, p.z) * 0.5) + zone) * uBloodAmt + trail * uBloodAmt, 0.0, 1.0);
  col = mix(col, uBlood * (0.6 + 0.6 * fine), bl);
  rough = mix(rough, 0.12, bl * 0.8);
  // dirt rising from the feet
  float dirt = smoothstep(0.45, 0.0, p.y + (big - 0.5) * 0.3) * uDirt;
  col = mix(col, col * vec3(0.35, 0.3, 0.25), dirt);
  // stitches: a Y-incision down the chest (autopsy) if asked
  float inc = smoothstep(0.006, 0.0, abs(p.x)) * smoothstep(0.95, 1.0, p.y) * smoothstep(1.42, 1.38, p.y) * step(0.0, p.z);
  float st = inc * step(0.5, fract(p.y * 90.0)) + smoothstep(0.012, 0.0, abs(p.x)) * smoothstep(0.004, 0.0, abs(fract(p.y * 45.0) - 0.5) * 0.03) * smoothstep(0.95, 1.0, p.y) * smoothstep(1.42, 1.38, p.y) * step(0.0, p.z);
  col = mix(col, vec3(0.06, 0.02, 0.02), clamp(inc + st, 0.0, 1.0) * uStitches);
  h -= inc * uStitches * 0.8;
  // old bandages wound round the head (face hidden)
  if (uBandage > 0.5) {
    float hb = smoothstep(1.5, 1.53, p.y);
    float ang = atan(p.x, p.z);
    float band = fract(p.y * 30.0 + ang * 0.35 + sin(ang * 3.0) * 0.08);
    float edge = smoothstep(0.0, 0.25, band) * smoothstep(1.0, 0.75, band);
    vec3 bc = vec3(0.42, 0.38, 0.29) * (0.88 + 0.12 * edge) * (0.85 + 0.2 * n3(q * 150.0));
    float seep = smoothstep(0.5, 0.75, fbm(q * 9.0 + 3.0)) + smoothstep(0.03, 0.0, length(vec2(p.x - uEyeP.x, p.y - uEyeP.y))) * step(0.0, p.z) + smoothstep(0.035, 0.0, abs(p.y - uMouthP.x)) * smoothstep(0.04, 0.0, abs(p.x)) * step(0.0, p.z);
    bc = mix(bc, mix(vec3(0.38, 0.27, 0.12), vec3(0.18, 0.02, 0.02), smoothstep(0.6, 1.0, seep)), clamp(seep, 0.0, 1.0) * 0.9);
    col = mix(col, bc, hb);
    rough = mix(rough, mix(0.95, 0.35, smoothstep(0.7, 1.0, seep)), hb);
    h = mix(h, edge * 0.35 + (n3(q * 150.0) - 0.5) * 0.2 + fbm(q * 20.0) * 0.4, hb);
  }
  // garments painted on the body
  float gt = uGarment.x;
  if (gt > 0.5) {
    float inG = step(uGarment.y, p.y) * step(p.y, uGarment.z) * step(ax, uGarment.w);
    float wv = n3(q * vec3(220.0, 220.0, 220.0));
    float fold = fbm(q * vec3(4.0, 14.0, 4.0));
    vec3 cc = mix(uCloth, uCloth2, smoothstep(0.3, 0.8, fold)) * (0.85 + 0.25 * wv);
    // old stains on cloth
    float stain = smoothstep(0.55, 0.75, fbm(q * 3.5 + 21.0));
    cc = mix(cc, cc * vec3(0.55, 0.42, 0.3), stain * 0.7);
    float cbl = smoothstep(0.62, 0.72, fbm(q * vec3(6.0, 2.0, 6.0) + 5.0)) * uBloodAmt;
    cc = mix(cc, uBlood * 0.7, cbl);
    // tears: holes in the garment show the skin underneath
    float tear = step(1.0 - uTear * 0.5, fbm(q * 7.0 + 31.0) + 0.2);
    float use = inG * (1.0 - tear);
    col = mix(col, cc, use);
    rough = mix(rough, gt > 1.5 && gt < 2.5 ? 0.45 : 0.9, use);
    h = mix(h, (fold - 0.5) * 0.9 + wv * 0.08, use);
    if (gt > 1.5 && gt < 2.5) { // suit: seams and panels
      float seam = smoothstep(0.004, 0.0, abs(fract(p.y * 6.0) - 0.5) * 0.17) + smoothstep(0.004, 0.0, abs(ax - 0.11));
      col = mix(col, col * 0.5, seam * use);
      h -= seam * use * 0.5;
    }
  }
  return h;
}
`
// bump from screen-space derivatives of the painted height (same maths as three's bumpmap chunk)
const BUMP = /* glsl */`
vec3 bumpN (vec3 surf_pos, vec3 surf_norm, float hgt, float fd, float k) {
  vec2 dHdxy = clamp(vec2(dFdx(hgt), dFdy(hgt)) * k, vec2(-0.06), vec2(0.06));
  vec3 vSigmaX = normalize(dFdx(surf_pos)), vSigmaY = normalize(dFdy(surf_pos)), vN = surf_norm;
  vec3 R1 = cross(vSigmaY, vN), R2 = cross(vN, vSigmaX);
  float fDet = dot(vSigmaX, R1) * fd;
  vec3 vGrad = sign(fDet) * (dHdxy.x * R1 + dHdxy.y * R2);
  return normalize(abs(fDet) * surf_norm - vGrad);
}
`
const C = v => new THREE.Color(v)
export const SKIN = {
  corpse: { base: 0x564e44, mottle: 0x3a342b, vein: 0x3a3c44, bruise: 0x4a2a3a, blood: 0x3a0303 },
  pale: { base: 0x70685e, mottle: 0x4f4840, vein: 0x40424a, bruise: 0x5b3348, blood: 0x420404 },
  ash: { base: 0x0b0a09, mottle: 0x050404, vein: 0x020202, bruise: 0x130807, blood: 0x2a0202 },
  burnt: { base: 0x3a2a22, mottle: 0x1a120e, vein: 0x5a1a0e, bruise: 0x2a0a06, blood: 0x2a0404 },
  drowned: { base: 0x7d8a86, mottle: 0x56635f, vein: 0x2e3f5a, bruise: 0x3a3f55, blood: 0x2d0606 },
  porcelain: { base: 0xd8d0c4, mottle: 0xbcb2a4, vein: 0x8a7e70, bruise: 0x7a6a5c, blood: 0x4a0606 },
}
export function skinMaterial (o = {}) {
  const pal = { ...SKIN[o.palette || 'corpse'], ...o.colors }
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6, metalness: 0, side: THREE.FrontSide })
  const u = {
    uBase: { value: C(pal.base) }, uMottle: { value: C(pal.mottle) }, uVein: { value: C(pal.vein) }, uBruise: { value: C(pal.bruise) }, uBlood: { value: C(pal.blood) },
    uCloth: { value: C(o.cloth ?? 0x6a665a) }, uCloth2: { value: C(o.cloth2 ?? 0x4a473f) },
    uVeins: { value: o.veins ?? 0.5 }, uBruises: { value: o.bruises ?? 0.4 }, uBloodAmt: { value: o.blood ?? 0.4 }, uRot: { value: o.rot ?? 0.2 },
    uWet: { value: o.wet ?? 0.15 }, uRibs: { value: o.ribs ?? 0 }, uSpine: { value: o.spine ?? 0 }, uEyes: { value: o.eyes ?? 1 }, uMouth: { value: o.mouth ?? 0.6 },
    uDirt: { value: o.dirt ?? 0.4 }, uSeed: { value: o.seed ?? Math.random() * 50 }, uStitches: { value: o.stitches ?? 0 },
    uGarment: { value: new THREE.Vector4(...(o.garment || [0, 0, 0, 0])) }, uTear: { value: o.tear ?? 0 }, uHead: { value: o.face === false ? 0 : 1 }, uBandage: { value: o.bandage ? 1 : 0 }, uMouthSz: { value: new THREE.Vector2(...(o.mouthSize || [0.032, 0.012])) }, uSpecK: { value: o.spec ?? 1 }, uEyeP: { value: new THREE.Vector3(...(o.eyeP || [0.034, 1.705, 0.04])) }, uMouthP: { value: new THREE.Vector2(...(o.mouthP || [1.625, 0.05])) }, uAlb: { value: o.albedo ?? Creature.albedo },
    uBloodZone: { value: new THREE.Vector4(...(o.wound || [0, -9, 0, 0.001])) },
    uBumpK: { value: o.bump ?? 1.0 },
  }
  mat.userData.u = u
  if (o.low) mat.defines = { CR_LOW: '' }
  mat.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, u)
    sh.vertexShader = 'varying vec3 vBind;\n' + sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvBind = position;')
    sh.fragmentShader = NOISE + 'uniform float uBumpK;\n' + PAINT + BUMP + sh.fragmentShader
      .replace('#include <map_fragment>', `#include <map_fragment>
        vec3 sCol; float sRough, sMetal; float sH = skinPaint(vBind, sCol, sRough, sMetal);
        diffuseColor.rgb = sCol * uAlb;`)
      .replace('#include <roughnessmap_fragment>', 'float roughnessFactor = clamp(sRough, 0.05, 1.0);')
      .replace('#include <lights_fragment_end>', '#include <lights_fragment_end>\n float sSpec = mix(0.22 * uSpecK, 1.0, smoothstep(0.65, 0.2, sRough)); reflectedLight.directSpecular *= sSpec; reflectedLight.indirectSpecular *= sSpec;')
      .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n normal = bumpN(-vViewPosition, normal, sH, faceDirection, uBumpK * 0.8);')
  }
  mat.customProgramCacheKey = () => 'creature-skin-v6' + (o.low ? 'L' : '')
  return mat
}

// lank, greasy hair: fine dark streaks (cached canvas)
let _hair = null
function hairTex () {
  if (_hair || typeof document === 'undefined') return _hair
  const c = document.createElement('canvas'); c.width = 64; c.height = 256; const g = c.getContext('2d')
  g.fillStyle = '#4a4440'; g.fillRect(0, 0, 64, 256)
  for (let i = 0; i < 160; i++) { const x = Math.random() * 64; g.strokeStyle = `rgba(${Math.random() < 0.5 ? '10,8,7' : '120,110,100'},${0.3 + Math.random() * 0.5})`; g.lineWidth = 0.6 + Math.random(); g.beginPath(); g.moveTo(x, 0); g.bezierCurveTo(x + Math.random() * 6 - 3, 90, x + Math.random() * 6 - 3, 170, x + Math.random() * 8 - 4, 256); g.stroke() }
  _hair = new THREE.CanvasTexture(c); _hair.colorSpace = THREE.SRGBColorSpace; _hair.wrapS = _hair.wrapT = THREE.RepeatWrapping; _hair.repeat.set(4, 1)
  return _hair
}
// plain helper materials for attachments
export const M = {
  dark: (c = 0x050404, r = 0.9) => new THREE.MeshStandardMaterial({ color: c, roughness: r }),
  wet: (c = 0x2a0303) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.15, metalness: 0.05 }),
  bone: () => new THREE.MeshStandardMaterial({ color: 0xcbbfa5, roughness: 0.55 }),
  tooth: () => new THREE.MeshStandardMaterial({ color: 0xb8ab88, roughness: 0.35 }),
  glow: (c = 0xffffff) => new THREE.MeshBasicMaterial({ color: c, fog: false }),
  cloth: (c = 0x5c584c, r = 0.95) => new THREE.MeshStandardMaterial({ color: c, roughness: r, side: THREE.DoubleSide }),
  glass: () => new THREE.MeshStandardMaterial({ color: 0x0a0d10, roughness: 0.3, metalness: 0, transparent: true, opacity: 0.22, depthWrite: false }),
  metal: (c = 0x8a9096) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.3, metalness: 0.9 }),
  hair: () => new THREE.MeshStandardMaterial({ color: 0x0b0908, roughness: 0.85, side: THREE.DoubleSide, map: hairTex(), bumpMap: hairTex(), bumpScale: 0.003 }),
}

// ───────────────────────── geometry helpers for attachments ─────────────────────────
// a ring of teeth in a gaping jaw
export function mouthParts (o = {}) {
  const g = new THREE.Group(); g.userData.face = 'mouth'; const w = o.width ?? 0.05, open = o.open ?? 0.05, n = o.teeth ?? 9
  if (o.hole) { const hole = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 8), M.dark(0x0a0101, 0.4)); hole.scale.set(w, open, 0.02); g.add(hole) }
  const tm = M.tooth(), tg = new THREE.ConeGeometry(0.0045, o.toothLen ?? 0.016, 4)
  for (const s of [1, -1]) for (let i = 0; i < n; i++) {
    const a = (i / (n - 1) - 0.5) * 2.4, t = new THREE.Mesh(tg, tm)
    t.position.set(Math.sin(a) * w * 0.92, s * open * 0.85, Math.cos(a) * 0.012 + 0.008); t.rotation.z = s > 0 ? Math.PI : 0
    t.scale.y = 0.7 + Math.random() * 0.8; g.add(t)
  }
  return g
}
// strands of long hair: thin bent ribbons hanging from the scalp
export function hairStrands (n = 60, len = 0.55, spread = 0.09) {
  const g = new THREE.Group(), m = M.hair(); g.userData.face = 'scalp'
  const N = n * 2
  // the scalp: a cap of hair over the crown that the strands hang from
  const cap = new THREE.Mesh(new THREE.SphereGeometry(spread * 1.06, 18, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), M.hair()); cap.scale.set(1, 0.95, 1.12); cap.position.set(0, -0.02, -0.01); g.add(cap)
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2 + Math.random() * 0.05
    // leave the face clear apart from a few strands hanging over it
    const front = Math.cos(a) > 0.55
    if (front && Math.random() < 0.8) continue
    const r = spread * (0.85 + Math.random() * 0.2), L = len * (front ? 0.9 : 0.6 + Math.random() * 0.6)
    const geo = new THREE.PlaneGeometry(0.006 + Math.random() * 0.01, L, 1, 8)
    geo.translate(0, -L / 2, 0)
    const pos = geo.attributes.position
    for (let k = 0; k < pos.count; k++) { const y = pos.getY(k); pos.setZ(k, Math.sin(y * 11 + i) * 0.006 + (y < -0.05 ? (y + 0.05) * (y + 0.05) * 0.25 : 0)) }
    geo.computeVertexNormals()
    const s = new THREE.Mesh(geo, m); s.position.set(Math.sin(a) * r, -Math.random() * 0.02, Math.cos(a) * r); s.rotation.y = a; s.rotation.x = -0.06
    g.add(s)
  }
  return g
}
// a long finger/claw: tapered segments
export function claw (len = 0.2, r = 0.007, mat = M.bone()) {
  const g = new THREE.Group(); const c = new THREE.Mesh(new THREE.ConeGeometry(r, len, 5), mat); c.position.y = len / 2; g.add(c); return g
}

// ───────────────────────── the creature ─────────────────────────
const _q = new THREE.Quaternion(), _e = new THREE.Euler()
export class Creature {
  static low = false // set true on phones: cheaper skin shader
  static albedo = 1 // per-game brightness trim (some games light things much harder than others)
  /**
   * look = {
   *   body: 'm' | 'f', height (m, default natural), skin: skinMaterial options,
   *   scale: { boneName: [x,y,z] }  per-bone scale (bones are Y-along-length),
   *   offset: { boneName: [rx,ry,rz] }  extra rotation added every frame after animation,
   *   twitch: { boneName: amount }  random jerks,
   *   attach (bones, creature) -> void  add props/extra parts,
   *   clips: { idle, walk, run, attack, ... } names in the clip library,
   * }
   */
  constructor (assets, look = {}) {
    this.look = look
    const src = look.body === 'f' ? assets.f : assets.m
    this.root = new THREE.Group()
    this.model = skClone(src.scene)
    if (look.faceNegZ) this.model.rotation.y = Math.PI
    this.root.add(this.model)
    const F = src.face
    this.face = F
    this.mat = skinMaterial({ low: Creature.low, ...(look.skin || {}), ...(F ? { eyeP: [F.eyes[0], F.eyes[1], F.eyes[2] - 0.04], mouthP: [F.mouth[1], F.mouth[2] - 0.035] } : {}) })
    this.meshes = []
    this.model.traverse(o => {
      if (o.isSkinnedMesh || o.isMesh) { o.material = this.mat; o.castShadow = true; o.receiveShadow = false; o.frustumCulled = false; this.meshes.push(o) }
    })
    this.bones = {}; this.rest = []
    this.model.traverse(o => { if (o.isBone) { this.bones[o.name] = o; this.rest.push([o, o.position.clone(), o.quaternion.clone(), o.scale.clone()]) } })
    const nat = look.body === 'f' ? 1.8 : 1.82
    this.k = (look.height || nat) / nat
    this.model.scale.setScalar(this.k)
    this.mixer = new THREE.AnimationMixer(this.model)
    this.clips = assets.clips; this.actions = {}; this.cur = null; this.t = 0
    this.twitchT = 0; this.tw = {}
    // per-bone scale overrides; remember the rest scale to multiply
    this.scales = Object.entries(look.scale || {}).filter(([n]) => this.bones[n]).map(([n, s]) => [this.bones[n], new THREE.Vector3(...s)])
    this.offsets = Object.entries(look.offset || {}).filter(([n]) => this.bones[n]).map(([n, r]) => [this.bones[n], new THREE.Quaternion().setFromEuler(new THREE.Euler(...r))])
    if (look.attach) look.attach(this.bones, this)
    // detailed bodies: move eyes / teeth / hair onto this face (they were placed for the mannequin's head)
    if (F) this.reseat(F)
    // attachments follow the same per-game brightness trim as the skin
    if (Creature.albedo !== 1) this.model.traverse(o => { if (o.isMesh && !o.isSkinnedMesh && o.material?.color && !o.material.isMeshBasicMaterial && !o.material.userData.trimmed) { o.material.color.multiplyScalar(Creature.albedo); o.material.userData.trimmed = true } })
    this.root.traverse(o => { if (o.isMesh) { o.frustumCulled = false; if (!o.isSkinnedMesh && o.castShadow === false && !(o.material?.isMeshBasicMaterial)) o.castShadow = true } })
  }
  /** bind-space point -> local position under a bone */
  at (boneName, p) {
    const sk = this.meshes.find(m => m.isSkinnedMesh)?.skeleton, b = this.bones[boneName]
    if (!sk || !b) return null
    const i = sk.bones.indexOf(b); return new THREE.Vector3(...p).applyMatrix4(sk.boneInverses[i])
  }
  reseat (F) {
    const head = this.bones.Head; if (!head) return
    for (const ch of [...head.children]) {
      const t = ch.userData.face; if (!t) continue
      if (t === 'eyes') { const v = this.at('Head', [0, F.eyes[1], F.eyes[2] + 0.006]); ch.position.copy(v); for (const e of ch.children) { e.position.set(Math.sign(e.position.x) * F.eyes[0], 0, 0) } }
      else if (t === 'mouth') ch.position.copy(this.at('Head', [0, F.mouth[1], F.mouth[2] - 0.004]))
      else if (t === 'scalp') ch.position.copy(this.at('Head', [0, F.top - 0.035, F.nose[2] - 0.13]))
      else if (t === 'hood') ch.position.copy(this.at('Head', [0, F.top - 0.11, F.nose[2] - 0.115]))
    }
  }
  action (name) {
    if (!name) return null
    if (this.actions[name]) return this.actions[name]
    const c = this.clips.get(name); if (!c) return null
    const a = this.mixer.clipAction(c); this.actions[name] = a; return a
  }
  /** cross-fade to a clip; once = play once and hold the last frame */
  play (name, { fade = 0.25, speed = 1, once = false, restart = false } = {}) {
    const a = this.action(name); if (!a) return
    a.timeScale = speed
    if (this.cur === a && !restart) return
    a.reset(); a.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity); a.clampWhenFinished = once
    a.enabled = true; a.setEffectiveWeight(1); a.play()
    if (this.cur && this.cur !== a) this.cur.crossFadeTo(a, fade, false)
    this.cur = a; this.curName = name
  }
  setSpeed (s) { if (this.cur) this.cur.timeScale = s }
  /** advance animation; st = free-form state the look's pose() can read */
  update (dt, st = {}) {
    this.t += dt
    // undo last frame's distortions (put back what the mixer last wrote), let the mixer advance, then remember its result.
    // (the mixer only rewrites values that changed, so bones must hold exactly what it wrote, never our extra offsets)
    if (this.saved) for (let i = 0; i < this.rest.length; i++) { const b = this.rest[i][0], sv = this.saved[i]; b.position.copy(sv[0]); b.quaternion.copy(sv[1]); b.scale.copy(sv[2]) }
    this.mixer.update(dt)
    if (!this.saved) this.saved = this.rest.map(() => [new THREE.Vector3(), new THREE.Quaternion(), new THREE.Vector3()])
    for (let i = 0; i < this.rest.length; i++) { const b = this.rest[i][0], sv = this.saved[i]; sv[0].copy(b.position); sv[1].copy(b.quaternion); sv[2].copy(b.scale) }
    for (const [b, s] of this.scales) b.scale.copy(s)
    for (const [b, q] of this.offsets) b.quaternion.multiply(q)
    const L = this.look
    if (L.twitch) {
      this.twitchT -= st.rdt ?? dt
      if (this.twitchT <= 0) { this.twitchT = 0.05 + Math.random() * (st.frenzy ? 0.15 : 0.6); for (const n in L.twitch) this.tw[n] = (Math.random() < 0.5 ? 1 : 0) * L.twitch[n] }
      for (const n in L.twitch) { const b = this.bones[n]; if (b && this.tw[n]) { _q.setFromEuler(_e.set((Math.random() - 0.5) * this.tw[n], (Math.random() - 0.5) * this.tw[n], (Math.random() - 0.5) * this.tw[n])); b.quaternion.multiply(_q) } }
    }
    if (L.pose) L.pose(this.bones, this.t, st, this)
  }
  dispose () { this.mixer.stopAllAction(); this.root.removeFromParent(); this.mat.dispose() }
}
// rotate a bone by an extra euler (used inside pose callbacks)
export function bend (bone, x = 0, y = 0, z = 0) { if (!bone) return; _q.setFromEuler(_e.set(x, y, z)); bone.quaternion.multiply(_q) }
export function attachTo (bone, obj, pos = [0, 0, 0], rot = [0, 0, 0], scl = 1) {
  if (!bone) return obj
  obj.position.set(...pos); obj.rotation.set(...rot); if (typeof scl === 'number') obj.scale.setScalar(scl); else obj.scale.set(...scl)
  bone.add(obj); return obj
}

// ───────────────────────── ready-made rigged models (Sketchfab etc.) ─────────────────────────
// Same play()/update() api as Creature, for models that come with their own skeleton, textures and clips.
const modelCache = new Map()
export function loadModel (url) {
  if (!modelCache.has(url)) modelCache.set(url, new Promise(resolve => new GLTFLoader().load(url, g => resolve(g), undefined, () => resolve(null))))
  return modelCache.get(url)
}
const cleanName = n => n.replace(/^mixamorig[:]?/, '').replace(/_\d+$/, '')
export class ModelCreature {
  /**
   * o = { height | length: size to fit (m), aliases: { wantedName: 'clip' | { clip, speed } }, faceNegZ, albedo, rough,
   *       twitch: { boneName: amount }, pose (bones, t, st, me), attach (bones, me) }
   */
  constructor (gltf, o = {}) {
    this.look = o
    this.root = new THREE.Group()
    this.model = skClone(gltf.scene)
    const holder = new THREE.Group(); holder.add(this.model); this.root.add(holder)
    this.mats = new Set()
    this.model.traverse(m => {
      if (!m.isMesh) return
      m.castShadow = true; m.frustumCulled = false
      for (const mt of [].concat(m.material)) {
        if (this.mats.has(mt)) continue
        this.mats.add(mt)
        const a = o.albedo ?? Creature.albedo
        if (mt.color && a !== 1) mt.color.multiplyScalar(a)
        if (o.rough != null && 'roughness' in mt) mt.roughness = o.rough
        if ('specularIntensity' in mt) mt.specularIntensity = Math.min(mt.specularIntensity ?? 1, 0.5)
      }
    })
    this.bones = {}; this.boneList = []
    this.model.traverse(b => { if (b.isBone) { this.bones[cleanName(b.name)] = b; this.boneList.push(b) } })
    this.mixer = new THREE.AnimationMixer(this.model)
    // clips without root motion (walks move in place; the game moves the body)
    this.clips = new Map()
    for (const c of gltf.animations) {
      const cc = c.clone()
      for (const tr of cc.tracks) {
        if (/hips[^.]*\.position$/i.test(tr.name)) { const v = tr.values; for (let i = 3; i < v.length; i += 3) { v[i] = v[0]; v[i + 2] = v[2] } }
      }
      this.clips.set(c.name.replace(/^Armature\|/, ''), cc)
    }
    // pose it the way it will move before measuring (some clips rescale the whole skeleton)
    const mc = o.measureClip && this.clips.get(o.measureClip)
    let ma = null; if (mc) { ma = this.mixer.clipAction(mc); ma.play(); this.mixer.update(0.01) }
    this.model.updateMatrixWorld(true)
    // measure the body as the skeleton actually poses it (some exports hide a x100 in the bones)
    const box = new THREE.Box3(), tmp = new THREE.Box3()
    this.model.traverse(m => {
      if (m.isSkinnedMesh) { m.skeleton.update(); m.computeBoundingBox(); tmp.copy(m.boundingBox).applyMatrix4(m.matrixWorld); box.union(tmp) }
      else if (m.isMesh) { m.geometry.computeBoundingBox(); tmp.copy(m.geometry.boundingBox).applyMatrix4(m.matrixWorld); box.union(tmp) }
    })
    const size = box.getSize(new THREE.Vector3())
    const k = o.height ? o.height / size.y : o.length ? o.length / Math.max(size.x, size.z) : 1
    this.model.scale.multiplyScalar(k)
    this.model.position.set(-(box.min.x + box.max.x) / 2 * k, -box.min.y * k, -(box.min.z + box.max.z) / 2 * k)
    // autoFace: turn it so its head points along +z (the way every other creature faces)
    if (o.autoFace) {
      this.model.updateMatrixWorld(true)
      const hb = this.model.getObjectByProperty('isBone', true) && [...Object.entries(this.bones)]
      const head = this.bones.Head, hips = this.bones.Hips
      if (head && hips) { const a = head.getWorldPosition(new THREE.Vector3()), b = hips.getWorldPosition(new THREE.Vector3()); this.autoYaw = Math.atan2(-(a.x - b.x), a.z - b.z) }
      void hb
    }
    holder.rotation.y = (this.autoYaw || 0) + (o.faceNegZ ? Math.PI : 0) + (o.yaw || 0)
    if (ma) { ma.stop(); this.mixer.uncacheAction(mc) }
    this.actions = {}; this.cur = null; this.t = 0; this.twitchT = 0; this.tw = {}
    if (o.attach) o.attach(this.bones, this)
  }
  resolve (name) { const al = this.look.aliases?.[name]; if (!al) return [name, 1]; return typeof al === 'string' ? [al, 1] : [al.clip, al.speed ?? 1] }
  play (name, { fade = 0.25, speed = 1, once = false, restart = false } = {}) {
    const [clipName, mul] = this.resolve(name)
    const c = this.clips.get(clipName); if (!c) return
    const a = this.actions[clipName] || (this.actions[clipName] = this.mixer.clipAction(c))
    a.timeScale = speed * mul
    if (this.cur === a && !restart) return
    a.reset(); a.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity); a.clampWhenFinished = once
    a.enabled = true; a.setEffectiveWeight(1); a.play()
    if (this.cur && this.cur !== a) this.cur.crossFadeTo(a, fade, false)
    this.cur = a; this.curName = name
  }
  update (dt, st = {}) {
    this.t += dt
    if (this.saved) for (let i = 0; i < this.boneList.length; i++) { const b = this.boneList[i], sv = this.saved[i]; b.position.copy(sv[0]); b.quaternion.copy(sv[1]); b.scale.copy(sv[2]) }
    this.mixer.update(dt)
    if (!this.saved) this.saved = this.boneList.map(() => [new THREE.Vector3(), new THREE.Quaternion(), new THREE.Vector3()])
    for (let i = 0; i < this.boneList.length; i++) { const b = this.boneList[i], sv = this.saved[i]; sv[0].copy(b.position); sv[1].copy(b.quaternion); sv[2].copy(b.scale) }
    const L = this.look
    if (L.twitch) {
      this.twitchT -= st.rdt ?? dt
      if (this.twitchT <= 0) { this.twitchT = 0.05 + Math.random() * (st.frenzy ? 0.15 : 0.6); for (const n in L.twitch) this.tw[n] = (Math.random() < 0.5 ? 1 : 0) * L.twitch[n] }
      for (const n in L.twitch) { const b = this.bones[n]; if (b && this.tw[n]) { _q.setFromEuler(_e.set((Math.random() - 0.5) * this.tw[n], (Math.random() - 0.5) * this.tw[n], (Math.random() - 0.5) * this.tw[n])); b.quaternion.multiply(_q) } }
    }
    if (L.pose) L.pose(this.bones, this.t, st, this)
  }
  dispose () { this.mixer.stopAllAction(); this.root.removeFromParent() }
}
