// St. Ambrose: shared settings

/** Co-op relay on the same Render server as the Minecraft world (path /hollow) */
export const COOP_SERVER = 'wss://gl-1-lh5u.onrender.com/hollow'

export const coopServerUrl = () => {
  const { hostname, protocol, host } = window.location
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    const port = new URLSearchParams(location.search).get('relayPort') || '8080'
    return `${protocol === 'https:' ? 'wss' : 'ws'}://${hostname}:${port}/hollow`
  }
  if (hostname.endsWith('.onrender.com')) return `wss://${host}/hollow`
  return COOP_SERVER
}

export const WALK = 2.15
export const SPRINT = 4.3
export const CROUCH = 1.1
export const RADIUS = 0.3
export const EYE = 1.62
export const CROUCH_EYE = 1.0
export const STAMINA_DRAIN = 22 // per second while sprinting (of 100)
export const STAMINA_REGEN = 14

export const DEFAULT_SETTINGS = { sensitivity: 1, volume: 0.85, quality: 'auto', invertY: false, grain: true, bob: true }

export const isTouchDevice = () => (navigator.maxTouchPoints > 0 && matchMedia('(pointer: coarse)').matches) || /Android|iPhone|iPad/i.test(navigator.userAgent)
