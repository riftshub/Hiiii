// St. Ambrose: game loop, player, items, the Orderly, co-op glue.
import * as THREE from 'three'
import { buildWorld, mulberry } from './world.js'
import { setTextureSize } from './textures.js'
import { Orderly, orderlyRig, loadRigAssets } from './orderly.js'
import { createRig } from './render.js'
import { itemMesh, NOTES, OBJECTIVES, KEY_ITEMS, ITEM_NAMES } from './items.js'
import { input, initInput, initTouchControls, consumePressed, consumeLook } from './input.js'
import { initGamepad, BTN } from '../../gamekit/gamepad.js'
import { net, on, connect, disconnect, sendAll, sendHost, sendTo } from '../../gamekit/net.js'
import { createAvatar } from '../../gamekit/avatar.js'
import { bindFullscreenButtons } from '../../gamekit/fullscreen.js'
import * as A from './audio.js'
import { DEFAULT_SETTINGS, coopServerUrl, isTouchDevice, WALK, SPRINT, CROUCH, RADIUS, EYE, CROUCH_EYE, STAMINA_DRAIN, STAMINA_REGEN } from './config.js'
import { $, touch, esc, setText, setStatus, ui, showScreen, backScreen, clearStack, setHud, fade, toast, subtitle, setPrompt } from './ui.js'

// ═════════════ settings ═════════════
const store = {
  get (k, fallback) { try { return { ...fallback, ...JSON.parse(localStorage.getItem(k) || '{}') } } catch { return { ...fallback } } },
  set (k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} },
}
const settings = store.get('hollow.settings', DEFAULT_SETTINGS)
const saveSettings = () => store.set('hollow.settings', settings)
const progress = store.get('hollow.progress', { escapes: 0, tapes: 0, best: 0 })
let myName = (() => { try { return localStorage.getItem('hollow.name') || '' } catch { return '' } })() || `Visitor ${Math.floor(100 + Math.random() * 900)}`
const quality = settings.quality === 'auto' ? (touch ? 'low' : 'high') : settings.quality
const HIGH = quality === 'high'
document.body.classList.toggle('touch-ui', touch)

// ═════════════ renderer, world ═════════════
// let the browser paint the loading text before the (heavy) texture and level build starts
await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 40)))
const canvas = $('#view')
const scene = new THREE.Scene()
const rigs = createRig(canvas, { HIGH, scene })
const { renderer, camera, post, rt, postScene, postCam, hemi, rig, torch, spill, ir, lampPool, dustMat, beamMat } = rigs
post.uniforms.grain.value = settings.grain ? post.uniforms.grain.value : 0
setTextureSize(HIGH ? 1024 : 512)
const LAYOUT_SEED = 1337
const W = buildWorld(scene, { seed: LAYOUT_SEED, quality })
W.build()
for (const d of W.doors) { d.locked0 = d.locked; d.open0 = d.open; d.chain0 = !!d.chain }

const itemGroup = new THREE.Group()
scene.add(itemGroup)
const thrown = []
const dummy = new THREE.Object3D()

// ═════════════ state ═════════════
const myId = () => net.id ?? 'local'
const isHost = () => net.isHost
const now = () => performance.now() / 1000
const wrapA = a => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a }
const clamp = (v, a, b) => Math.max(a, Math.min(b, v))
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t) }
const START = { x: 0, z: -4.5, yaw: Math.PI }

const G = {
  mode: 'title', paused: false, coop: false, t: 0, playT: 0, clockT: 0,
  items: new Map(), keys: new Set(), notes: new Set(), cut: false, rage: 0, ended: false,
  registry: new Map(), avatars: new Map(), orderly: null, model: null, ov: { x: -22, z: -31, yaw: 0, speed: 0, mode: 'patrol', attackT: 0, look: 0 }, ot: null,
  fear: 0, glitch: 0, blackout: 0, dir: { phone: 95, bang: 40, thunder: 60, blackout: 260, whisper: 50 }, thunderFlash: 0,
  checkpoint: { ...START }, hum: null, stepAcc: 0, scrapeT: 0, breathT: 0, heartT: 0, lastZone: 'main', mouse: false, stateT: 0, owT: 0, titleT: 0,
  validPois: null, awayFrom: null, pending: null, wipeT: 0,
}
const P = {
  x: START.x, z: START.z, yaw: START.yaw, pitch: 0, eye: EYE, vx: 0, vz: 0, speed: 0,
  crouch: false, sprint: false, stamina: 100, tired: false,
  battery: 100, spare: 0, bottles: 0, flashOn: false, nvOn: false, swapT: 0, flick: 1, flickT: 0,
  hidden: null, hideT: 1, hideFrom: null, hideCam: null, hideYaw: 0, hideBreath: 100, holding: false,
  down: false, caught: false, caughtT: 0, downT: 0, noise: 0, burst: 0, burstT: 0, stepAcc: 0, bob: 0, hold: 0, holdKind: '', caughtCount: 0, hurt: 0,
}

// ═════════════ effects, shared by everyone ═════════════
const emit = (kind, data = {}) => { playFx(kind, data); sendAll('fx', { kind, data }) }
const pos = (x, z, y = 1.2) => ({ x, y, z })
const orderlyAt = () => pos(G.ov.x, G.ov.z, 1.4)

function playFx (kind, d) {
  switch (kind) {
    case 'door': {
      const door = W.doorById(d.id)
      if (!door || door.chain) return
      if (door.target === (d.o ? 1 : 0) && door.open === (d.o ? 1 : 0)) return
      W.setDoor(door, !!d.o)
      A.play(d.o ? 'door_open' : 'door_close', { pos: pos(door.x, door.z, 1.2), vol: d.by === 'o' ? 0.8 : 0.9 })
      break
    }
    case 'unlock': {
      const door = W.doorById(d.id)
      if (!door) return
      door.locked = false
      W.nav?.refreshLocks?.()
      A.play('door_unlock', { pos: pos(door.x, door.z, 1.1) })
      break
    }
    case 'taken': takeItem(d); break
    case 'glass': A.play('glass', { pos: pos(d.x, d.z, 0.2), vol: 1, max: 80 }); break
    case 'bang': A.play('bang', { pos: pos(d.x, d.z, 1.5), vol: 1, max: 90 }); break
    case 'phone': {
      const pp = W.phonePos
      G.phoneRing = 9
      if (pp) A.play('phone_ring', { pos: pos(pp.x, pp.z, pp.y), vol: 1, max: 70, ref: 3 })
      break
    }
    case 'thunder': G.thunderFlash = 1; A.play('thunder', { vol: 0.8 }); break
    case 'blackout': G.blackout = d.t ?? 20; A.play('bang', { pos: pos(P.x, P.z, 2), vol: 0.8 }); A.play('flash_flicker', { vol: 0.7 }); break
    case 'whisper': A.play('whisper', { pos: pos(d.x, d.z, 1.5), vol: 0.9, max: 20 }); break
    case 'alert':
      A.play('roar', { pos: orderlyAt(), vol: 1, max: 80, ref: 4 })
      A.play('stinger', { vol: 0.8 })
      if (G.ov.mode !== 'chase') G.ov.mode = 'chase'
      break
    case 'notice': A.play('growl', { pos: orderlyAt(), vol: 0.8, max: 40 }); break
    case 'lost': break
    case 'check': {
      const h = W.hides.find(q => q.id === d.id)
      if (h?.kind === 'locker') {
        h.target = 1; A.play('locker_open', { pos: pos(h.x, h.z, 1.2), vol: 0.9 })
        setTimeout(() => { h.target = 0; if (!(P.hidden && P.hidden.id === h.id)) A.play('locker_close', { pos: pos(h.x, h.z, 1.2), vol: 0.7 }) }, 1500)
      } else if (h) A.play('cloth', { pos: pos(h.x, h.z, 0.4), vol: 0.8 })
      break
    }
    case 'grab':
      A.play('roar', { pos: orderlyAt(), vol: 1, max: 80, ref: 4 })
      if (d.id === myId()) { P.caught = true; P.caughtT = 0; if (P.hidden) { const h = P.hidden; if (h.kind === 'locker') h.target = 1 } }
      break
    case 'catch':
      A.play('bang', { pos: pos(P.x, P.z, 1), vol: 0.8 })
      if (d.id === myId()) beCaught()
      else { const r = G.registry.get(d.id); if (r) r.down = true; toast(`${nameOf(d.id)} was caught.`) }
      break
    case 'revive':
      if (d.id === myId() && P.down) standUp(false)
      else { const r = G.registry.get(d.id); if (r) r.down = false }
      break
    case 'respawn': if (isHost() && G.orderly) sendOrderlyAway(d.x, d.z); break
    case 'wipe': if (P.down) standUp(true); break
    case 'cut': cutChain(); break
    case 'end': endGame(d); break
  }
}
const nameOf = id => (id === myId() ? myName : net.players.get(id)?.name ?? 'Someone')

// ═════════════ items ═════════════
function genItems () {
  const rng = mulberry((Math.random() * 1e9) | 0)
  const pick = arr => arr[Math.floor(rng() * arr.length)]
  const out = []
  let n = 0
  const add = (kind, s, extra = {}) => out.push({ id: `i${n++}`, kind, x: s.x, y: s.y, z: s.z, ...extra })
  const S = W.spots
  add('wardKey', pick(S.wardKey))
  const east = S.recordsKey.filter(s => s.wing === 'E')
  add('recordsKey', pick(east.length ? east : S.recordsKey))
  add('annexKey', pick(S.annexKey))
  add('boltCutters', pick(S.boltCutters))
  for (const k of ['note1', 'note2', 'note3', 'note4', 'note5', 'note6']) for (const s of S[k] ?? []) add('note', s, { note: s.id })
  for (const s of S.battery ?? []) if (rng() > 0.45) add('battery', s)
  for (const s of S.bottle ?? []) if (rng() > 0.4) add('bottle', s)
  for (const s of S.stand ?? []) { const r = rng(); if (r < 0.3) add('battery', s); else if (r < 0.55) add('bottle', s) }
  return out
}

function clearItems () {
  for (const it of G.items.values()) if (it.mesh) { itemGroup.remove(it.mesh); it.mesh.traverse(o => { if (o.isMesh) { o.geometry.dispose?.() } }) }
  G.items.clear()
}
function placeItems (list) {
  clearItems()
  for (const d of list) {
    const it = { ...d }
    const m = itemMesh(d.kind)
    m.position.set(d.x, d.y, d.z)
    m.rotation.y = (parseInt(d.id.slice(1), 10) * 2.399) % 6.28
    if (d.kind === 'boltCutters' && d.y > 0.2) m.rotation.z = 0
    itemGroup.add(m)
    it.mesh = m
    G.items.set(d.id, it)
  }
}
const itemList = () => [...G.items.values()].map(({ id, kind, x, y, z, note }) => ({ id, kind, x, y, z, note }))

function takeItem ({ id, by }) {
  const it = G.items.get(id)
  if (!it) return
  G.items.delete(id)
  itemGroup.remove(it.mesh)
  const mine = by === myId()
  if (mine) A.play(it.kind === 'note' ? 'paper' : 'pickup', { vol: 0.8 })
  else A.play('pickup', { pos: pos(it.x, it.z, it.y), vol: 0.6 })
  if (KEY_ITEMS.has(it.kind)) {
    G.keys.add(it.kind)
    if (mine) { P.burst = Math.max(P.burst, 3); P.burstT = 0.4 }
    toast(`${mine ? 'You have' : nameOf(by) + ' found'} ${ITEM_NAMES[it.kind]}.`)
    if (mine) A.play('keys', { vol: 0.6 })
    G.checkpoint = { x: it.x, z: it.z, yaw: P.yaw }
    if (isHost() || !G.coop) G.checkpoint = safeCheckpoint(mine ? P : (G.registry.get(by) ?? P))
  } else if (it.kind === 'note') {
    G.notes.add(it.note)
    if (mine) openNote(it.note)
    else toast(`${nameOf(by)} found a note.`)
  } else if (mine) {
    if (it.kind === 'battery') { P.spare++; toast('A battery. Press nothing: it swaps in when the old one dies.', 3600) }
    if (it.kind === 'bottle') { P.bottles++; toast('A bottle. Throw it to pull him away.', 3200) }
  }
}
const safeCheckpoint = p => ({ x: p.x, z: p.z, yaw: p.yaw ?? 0 })

function openNote (id) {
  const n = NOTES[id]
  if (!n) return
  setText($('#note-title'), n.title)
  setText($('#note-text'), n.text.map(t => `<p>${esc(t)}</p>`).join('') + (n.sig ? `<p class="sig">${esc(n.sig)}</p>` : ''), true)
  G.paused = !G.coop
  showScreen('note')
  document.exitPointerLock?.()
  input.pressed.clear()
}

// ═════════════ doors, locks, the chain ═════════════
function doorLabel (d) { return d.label ?? 'door' }
function tryDoor (d) {
  if (d.chain) return
  if (d.locked) {
    if (d.keyId && G.keys.has(d.keyId)) {
      emit('unlock', { id: d.id })
      G.checkpoint = safeCheckpoint(P)
      P.burst = Math.max(P.burst, 4); P.burstT = 0.5
      return
    }
    A.play('door_locked', { pos: pos(d.x, d.z, 1.1), vol: 0.9 })
    P.burst = Math.max(P.burst, 3.5); P.burstT = 0.4
    toast(d.keyId ? `The ${doorLabel(d)} is locked.` : 'It will not move.')
    return
  }
  const o = d.target < 0.5 ? 1 : 0
  emit('door', { id: d.id, o, by: 'p' })
  P.burst = Math.max(P.burst, o ? 5 : 3); P.burstT = 0.5
}

function cutChain () {
  if (G.cut) return
  G.cut = true
  const d = W.doorById('front')
  d.chain = false; d.locked = false; d.swing = -1
  if (W.chainGroup) W.chainGroup.visible = false
  W.nav?.refreshLocks?.()
  W.setDoor(d, true)
  A.play('chain_cut', { vol: 1 })
  A.play('door_break', { pos: pos(0, 0, 1.2), vol: 0.8 })
  G.rage = 14
  subtitle('He heard that.', 3500)
  if (isHost() && G.orderly) {
    const o = G.orderly
    const tgt = hostPlayers().find(p => !p.down) ?? { x: 0, z: -4, id: myId() }
    o.mode = 'chase'; o.target = tgt.id; o.chaseT = 0; o.loseT = 0; o.path = null; o.lastSeen = { x: tgt.x, z: tgt.z, id: tgt.id }
    o.aw.set(tgt.id, 1.5)
    emit('alert', {})
  }
}

// ═════════════ the Orderly ═════════════
const orderlyHooks = {
  door: d => sendAll('fx', { kind: 'door', data: { id: d.id, o: 1, by: 'o' } }) || playFx('door', { id: d.id, o: 1, by: 'o' }),
  grab: id => emit('grab', { id }),
  catch: id => emit('catch', { id }),
  alert: () => emit('alert', {}),
  notice: () => emit('notice', {}),
  lost: () => emit('lost', {}),
  check: h => emit('check', { id: h.id }),
}

function playerView (id, s) {
  return {
    id, x: s.x, z: s.z, yaw: s.yaw, crouch: !!s.crouch, sprint: !!s.sprint, flash: !!s.flash, nv: !!s.nv, hidden: !!s.hidden, hideId: s.hideId ?? null,
    down: !!s.down, noise: s.noise ?? 0, breath: !!s.breath,
  }
}
function localState () {
  return {
    x: +P.x.toFixed(2), z: +P.z.toFixed(2), yaw: +P.yaw.toFixed(2), pitch: +P.pitch.toFixed(2), speed: +P.speed.toFixed(2), crouch: P.crouch, sprint: P.sprint,
    flash: lightOn() && P.flashOn, nv: P.nvOn && P.battery > 0, hidden: !!P.hidden, hideId: P.hidden?.id ?? null, down: P.down, noise: +P.noise.toFixed(1), breath: P.holding,
  }
}
function hostPlayers () {
  const arr = [playerView(myId(), localState())]
  for (const [id, r] of G.registry) { if (id !== myId() && now() - r.t < 4) arr.push(playerView(id, r)) }
  return arr
}
function validPois () {
  if (G.validPois) return G.validPois
  G.validPois = W.pois.filter(p => W.nav.path(0, -6, p[0], p[1]))
  return G.validPois
}
function sendOrderlyAway (x, z) {
  const o = G.orderly
  const far = validPois().filter(p => Math.hypot(p[0] - x, p[1] - z) > 26)
  const p = far.length ? far[(Math.random() * far.length) | 0] : validPois()[0]
  o.x = p[0]; o.z = p[1]; o.path = null; o.mode = 'patrol'; o.aw.clear(); o.suspect = null; o.grabbed = null; o.attackT = 0
  o.pickPatrol(hostPlayers())
}

// ═════════════ the patients: figures in gowns standing in the dark, watching. Only on this screen (not synced).
// They never touch you. Get close, or put your light on them for a moment, and they are gone.
const phantoms = []
loadRigAssets().then(({ a, makeLook }) => {
  for (let i = 0; i < 2; i++) {
    const c = makeLook(a, 'phantom', { faceNegZ: false }, Math.random())
    c.play('Idle_Loop'); c.update(Math.random() * 3)
    c.root.visible = false; scene.add(c.root)
    phantoms.push({ c, on: false, wait: 40 + i * 35 + Math.random() * 30, life: 0, lit: 0 })
  }
}).catch(() => {})
const _cd = new THREE.Vector3()
function updatePhantoms (dt) {
  if (!phantoms.length || G.mode !== 'playing') return
  camera.getWorldDirection(_cd)
  const fx = _cd.x, fz = _cd.z, fl = Math.hypot(fx, fz) || 1
  for (const ph of phantoms) {
    const c = ph.c
    if (!ph.on) {
      ph.wait -= dt
      if (ph.wait > 0) continue
      // somewhere ahead of you, far enough to be just a shape at the edge of the light
      const ahead = validPois().filter(p => { const dx = p[0] - P.x, dz = p[1] - P.z, d = Math.hypot(dx, dz); return d > 8 && d < 17 && (dx * fx + dz * fz) / (d * fl) > 0.75 })
      if (!ahead.length) { ph.wait = 4; continue }
      const p = ahead[(Math.random() * ahead.length) | 0]
      c.root.position.set(p[0] + (Math.random() - 0.5) * 0.6, 0, p[1] + (Math.random() - 0.5) * 0.6)
      c.root.visible = true; ph.on = true; ph.life = 18 + Math.random() * 14; ph.lit = 0
      continue
    }
    const dx = P.x - c.root.position.x, dz = P.z - c.root.position.z, d = Math.hypot(dx, dz)
    c.root.rotation.y = Math.atan2(dx, dz) // always facing you
    c.update(dt)
    const inBeam = P.flashOn && lightOn() && d < 11 && ((-dx * fx - dz * fz) / (d * fl)) > 0.93
    ph.lit = inBeam ? ph.lit + dt : Math.max(0, ph.lit - dt)
    ph.life -= dt
    if (d < 5.5 || ph.lit > 0.7 || ph.life <= 0) {
      if (d < 9) { A.play('whisper', { pos: A.at(c.root.position.x, c.root.position.z, 1.5), vol: 0.7, max: 16 }); G.fear = Math.min(1, G.fear + 0.25) }
      c.root.visible = false; ph.on = false; ph.wait = 45 + Math.random() * 60
    }
  }
}

function ensureOrderly () {
  if (!G.model) {
    G.model = orderlyRig()
    scene.add(G.model.root)
  }
  if (isHost() && !G.orderly) {
    G.orderly = new Orderly(W)
    if (G.ot) G.orderly.restore(G.ot)
  }
}
function dropOrderly () {
  if (G.model) { scene.remove(G.model.root); G.model = null }
  G.orderly = null
  G.ot = null
}

// ═════════════ game flow ═════════════
function resetWorld () {
  for (const d of W.doors) {
    d.locked = d.locked0; d.chain = d.chain0; d.swing = d.swing ?? 1
    d.target = d.open0; d.open = d.open0 + (d.open0 > 0.5 ? -0.01 : 0.01)
  }
  const fd = W.doorById('front'); if (fd) { fd.swing = 1 }
  if (W.chainGroup) W.chainGroup.visible = true
  for (const h of W.hides) if (h.kind === 'locker') { h.target = 0 }
  W.nav?.refreshLocks?.()
  G.cut = false
}

const sleep = ms => new Promise(r => setTimeout(r, ms))

async function startGame ({ items = null, coop = false, snap = null } = {}) {
  A.S.init()
  void A.startBeds()
  G.coop = coop
  fade(1, 250)
  await sleep(280)
  clearStack()
  resetWorld()
  const list = items ?? genItems()
  placeItems(list)
  G.keys = new Set(snap?.keys ?? [])
  G.notes = new Set(snap?.notes ?? [])
  if (snap?.cut) cutChain()
  if (snap?.doors) for (const [id, locked, o] of snap.doors) { const d = W.doorById(id); if (d && !d.chain) { d.locked = locked; d.target = o; } }
  W.nav?.refreshLocks?.()
  G.ended = false; G.rage = 0; G.blackout = 0; G.playT = 0; G.clockT = 0; G.fear = 0; G.glitch = 0
  G.dir = { phone: 80 + Math.random() * 40, bang: 35 + Math.random() * 20, thunder: 40 + Math.random() * 40, blackout: 240 + Math.random() * 120, whisper: 40 + Math.random() * 30 }
  G.checkpoint = { ...START }
  G.registry.clear()
  clearAvatars()
  Object.assign(P, {
    x: START.x, z: START.z, yaw: START.yaw, pitch: 0, eye: EYE, vx: 0, vz: 0, speed: 0, crouch: false, sprint: false, stamina: 100, tired: false,
    battery: 100, spare: 0, bottles: 0, flashOn: true, nvOn: false, swapT: 0, hidden: null, hideT: 1, down: false, caught: false, caughtT: 0, noise: 0, burst: 0, hold: 0, caughtCount: 0, hurt: 0, holding: false, hideBreath: 100,
  })
  if (G.model) dropOrderly()
  G.ov = { x: -22, z: -31, yaw: 0, speed: 0, mode: 'patrol', attackT: 0, look: 0 }
  ensureOrderly()
  G.mode = 'playing'; G.paused = false
  setHud(true)
  showScreen(null)
  input.enabled = true
  input.pressed.clear()
  setPrompt('')
  if (!touch) void canvas.requestPointerLock?.()
  fade(0, 2200)
  toast('11:42 PM. St. Ambrose State Hospital. Closed since 1993.', 5200)
  setTimeout(() => { if (G.mode === 'playing') subtitle('Find a way out.', 3500) }, 3800)
}

function quitToTitle () {
  disconnect()
  G.coop = false
  G.mode = 'title'; G.paused = false
  input.enabled = false
  setHud(false)
  document.exitPointerLock?.()
  dropOrderly()
  clearAvatars()
  G.registry.clear()
  clearItems()
  resetWorld()
  P.flashOn = false; P.nvOn = false; P.hidden = null; P.down = false; P.caught = false
  clearStack()
  showScreen('title')
  fade(0, 800)
  updateProfile()
}

function beCaught () {
  P.down = true; P.caught = false; P.downT = 0; P.caughtCount++; P.hurt = 1
  if (P.hidden) leaveHide(true)
  A.play('scream', { vol: 0.9 })
  A.play('stinger', { vol: 0.8 })
  const solo = !G.coop || net.players.size <= 1
  setText($('#caught-text'), solo ? CAUGHT_TEXT[Math.min(CAUGHT_TEXT.length - 1, P.caughtCount - 1)] : 'You are on the floor. Someone has to get to you, or you have to wait.')
  const btn = document.querySelector('#screen-caught [data-go=retry]')
  if (btn) btn.style.display = solo ? '' : 'none'
  G.wipeT = 0
  setTimeout(() => { if (P.down && G.mode === 'playing') { showScreen('caught'); document.exitPointerLock?.() } }, 1100)
}
const CAUGHT_TEXT = [
  'You wake up somewhere else. Your hands are shaking. The tape is still running.',
  'Again. The pipe, then the floor. You wake up with the taste of metal in your mouth.',
  'He does not hurry. He never has to. You wake up and the tape is still running.',
  'Four. Five. You stop counting. The building has all night.',
]

function standUp (toCheckpoint) {
  P.down = false; P.caught = false; P.hurt = 0.4
  if (toCheckpoint) {
    const c = G.checkpoint
    P.x = c.x; P.z = c.z; P.yaw = c.yaw; P.pitch = 0
    const [rx, rz] = W.colliders.resolve(P.x, P.z, RADIUS); P.x = rx; P.z = rz
    emit('respawn', { id: myId(), x: P.x, z: P.z })
  }
  P.hidden = null; P.hideT = 1
  showScreen(null)
  input.enabled = true
  if (!touch) void canvas.requestPointerLock?.()
  toast(toCheckpoint ? 'You are back where you last felt safe.' : 'A hand on your shoulder. Up.')
}

function endGame () {
  if (G.ended) return
  G.ended = true
  const tape = G.notes.size >= 5
  const t = Math.floor(G.playT)
  const mm = String(Math.floor(t / 60)).padStart(2, '0'), ss = String(t % 60).padStart(2, '0')
  $('#screen-ending').dataset.kind = tape ? 'tape' : 'escape'
  setText($('#ending-title'), tape ? 'The tape' : 'Out')
  setText($('#ending-meta'), `Notes ${G.notes.size}/6 · Time ${mm}:${ss} · Caught ${P.caughtCount}`)
  setText($('#ending-text'), (tape ? ENDING_TAPE : ENDING_ESCAPE).map(p => `<p>${esc(p)}</p>`).join(''), true)
  A.play('ending_out', { vol: 1 })
  fade(1, 2600)
  input.enabled = false
  document.exitPointerLock?.()
  setTimeout(() => { setHud(false); showScreen('ending'); fade(0, 1500) }, 2800)
  if (tape) progress.tapes++; else progress.escapes++
  progress.best = progress.best ? Math.min(progress.best, t) : t
  store.set('hollow.progress', progress)
}
const ENDING_ESCAPE = [
  'The air outside smells of rain and cut grass. You do not stop running until the gate.',
  'Behind you the front doors stand open on a dark lobby. Nothing comes out of it. Somewhere on the top floor a single light goes out, and then, in the east wing, one that was never on.',
  'You tell them the building is empty. You almost believe it.',
]
const ENDING_TAPE = [
  'At home you watch the tape from the start. Seven hours of corridors, and your own breathing.',
  'At 00:14:08, in the records room, you turn to read a folder. In the doorway behind you, at the edge of the light, someone is standing with a pipe, and he stays there until you leave.',
  'You rewind it again. Then you notice the timestamp on the last frame. The tape is running longer than you were inside.',
  'The notes were right. He was never hunting you. He was keeping the door.',
]

// ═════════════ light helpers ═════════════
const lightOn = () => P.swapT <= 0 && P.battery > 0
const slots = lampPool.map(light => ({ light, lamp: null }))

function lampLevel (l, t) {
  if (l.state === 'dead') return 0
  if (G.blackout > 0 && !l.red) return 0
  let lvl
  if (l.state === 'on') lvl = 1 + Math.sin(t * 95 + l.phase) * 0.02
  else if (l.state === 'red') lvl = 0.8 + Math.sin(t * 2.2 + l.phase) * 0.2
  else {
    const a = Math.sin(t * 7.1 + l.phase) * Math.sin(t * 13.7 + l.phase * 2.1) * Math.sin(t * 2.3 + l.phase * 0.5) + Math.sin(t * 61 + l.phase) * 0.08
    const th = 0.42 - l.flick * 0.4
    lvl = a > th ? 1 : a > th - 0.12 ? 0.3 : 0.03
  }
  // the tubes stutter around him
  const dO = Math.hypot(l.x - G.ov.x, l.z - G.ov.z)
  if (dO < 8 && !l.red && G.mode === 'playing') lvl *= Math.sin(t * 47 + l.phase) * Math.sin(t * 19.3) > -0.25 + dO * 0.03 ? 1 : 0.12
  return lvl
}

function updateLamps (dt, t) {
  const cx = camera.position.x, cz = camera.position.z
  const cand = []
  for (const l of W.lamps) {
    const lvl = lampLevel(l, t)
    l.lvl = lvl
    if (l.state !== 'dead') {
      if (l.red) l.mat.color.setRGB(lvl, 0.1 * lvl, 0.07 * lvl)
      else l.mat.emissiveIntensity = 1.2 * l.base * lvl
    }
    if (lvl < 0.04) continue
    const d2 = (l.x - cx) ** 2 + (l.z - cz) ** 2
    if (d2 > 19 * 19) continue
    if (d2 > 4 && !W.colliders.clear(cx, cz, l.x, l.z)) continue
    l.d2 = d2
    cand.push(l)
  }
  cand.sort((a, b) => a.d2 - b.d2)
  const top = cand.slice(0, slots.length)
  const wanted = new Set(top)
  for (const s of slots) if (s.lamp && !wanted.has(s.lamp)) { s.lamp = null }
  const have = new Set(slots.map(s => s.lamp))
  for (const l of top) {
    if (have.has(l)) continue
    const s = slots.find(q => !q.lamp)
    if (!s) break
    s.lamp = l; s.light.intensity = 0; s.light.position.set(l.x, 2.75, l.z); s.light.color.set(l.color)
    have.add(l)
  }
  for (const s of slots) {
    const l = s.lamp
    const target = l ? (l.red ? 7 : 5.5) * l.lvl * l.base * smooth(19, 9, Math.sqrt(l.d2)) : 0
    s.light.intensity += (target - s.light.intensity) * Math.min(1, dt * 14)
  }
}

// ═════════════ player ═════════════
const hostNoise = (x, z, r, strong = false) => { if (isHost()) G.orderly?.hear(x, z, r, { strong }); else sendHost('noise', { x: +x.toFixed(1), z: +z.toFixed(1), r, strong }) }
const dirOf = () => ({ x: -Math.sin(P.yaw) * Math.cos(P.pitch), y: Math.sin(P.pitch), z: -Math.cos(P.yaw) * Math.cos(P.pitch) })

function updatePlayer (dt) {
  const look = consumeLook()
  look.x = clamp(look.x, -240, 240); look.y = clamp(look.y, -240, 240)
  if (G.playT < 0.5) { look.x = 0; look.y = 0 }
  const sens = 0.0022 * settings.sensitivity
  const free = !P.down && !P.caught
  if (free) {
    P.yaw -= look.x * sens
    P.pitch -= look.y * sens * (settings.invertY ? -1 : 1)
  }
  P.pitch = clamp(P.pitch, -1.45, 1.45)

  // crouch toggles
  if (consumePressed('crouch') && free && !P.hidden) P.crouch = !P.crouch

  if (P.hidden) { updateHidden(dt); return }

  let mx = 0, my = 0
  if (free) {
    mx = input.move.x; my = input.move.y
    const len = Math.hypot(mx, my)
    if (len > 1) { mx /= len; my /= len }
  }
  const wantSprint = free && input.held.sprint && my > 0.25 && !P.crouch && !P.tired && P.stamina > 0
  P.sprint = wantSprint
  if (input.held.sprint && P.crouch && my > 0.25 && free) P.crouch = false
  const mag = Math.min(1, Math.hypot(mx, my))
  const base = P.sprint ? SPRINT : P.crouch ? CROUCH : WALK
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw)
  const tx = (cy * mx - sy * my) * base * (P.sprint ? 1 : mag)
  const tz = (-sy * mx - cy * my) * base * (P.sprint ? 1 : mag)
  const k = Math.min(1, dt * (mag > 0.01 ? 9 : 12))
  P.vx += (tx - P.vx) * k; P.vz += (tz - P.vz) * k
  const nx = P.x + P.vx * dt, nz = P.z + P.vz * dt
  const [rx, rz] = W.colliders.resolve(nx, nz, RADIUS)
  P.speed = Math.hypot(rx - P.x, rz - P.z) / Math.max(dt, 1e-4)
  P.x = rx; P.z = rz

  // stamina
  if (P.sprint && P.speed > 1) { P.stamina -= STAMINA_DRAIN * dt; if (P.stamina <= 0) { P.stamina = 0; P.tired = true; A.play('gasp', { vol: 0.5 }) } }
  else P.stamina = Math.min(100, P.stamina + STAMINA_REGEN * dt * (P.speed < 0.3 ? 1.6 : 1))
  if (P.tired && P.stamina > 35) P.tired = false

  // footsteps and head bob
  const stride = P.sprint ? 2.1 : P.crouch ? 1.1 : 1.45
  if (P.speed > 0.35) {
    P.stepAcc += P.speed * dt
    P.bob += P.speed * dt * (P.sprint ? 1.9 : 2.6)
    if (P.stepAcc > stride) {
      P.stepAcc = 0
      A.play('step_lino', { vol: P.sprint ? 0.85 : P.crouch ? 0.16 : 0.5 })
    }
  }
  const eyeT = P.down ? 0.22 : P.crouch ? CROUCH_EYE : EYE
  P.eye += (eyeT - P.eye) * Math.min(1, dt * (P.down ? 3 : 8))

  // noise he can hear
  let n = 0
  if (P.speed > 0.35) n = P.sprint ? 11 : P.crouch ? 1.8 : 4.5
  if (P.burstT > 0) { P.burstT -= dt; n = Math.max(n, P.burst) } else P.burst = 0
  P.noise = P.down ? 0 : n
}

function updateHidden (dt) {
  const h = P.hidden
  P.speed = 0; P.vx = P.vz = 0; P.sprint = false
  if (P.hideT < 1) P.hideT = Math.min(1, P.hideT + dt / 0.42)
  // limited view out of the slats
  const lim = h.kind === 'locker' ? 0.62 : 1.4
  P.yaw = P.hideYaw + clamp(wrapA(P.yaw - P.hideYaw), -lim, lim)
  P.pitch = clamp(P.pitch, h.kind === 'locker' ? -0.45 : -0.2, h.kind === 'locker' ? 0.45 : 0.5)
  // holding your breath
  const wantHold = input.held.breath && P.hideT >= 1
  if (wantHold && P.hideBreath > 0 && !P.gasping) {
    P.holding = true
    P.hideBreath -= dt * 21
    if (P.hideBreath <= 0) { P.hideBreath = 0; P.holding = false; P.gasping = true; P.burst = 6; P.burstT = 0.7; A.play('gasp', { vol: 0.9 }) }
  } else {
    P.holding = false
    P.hideBreath = Math.min(100, P.hideBreath + dt * 13)
    if (P.gasping && P.hideBreath > 40) P.gasping = false
  }
  let n = 0
  if (P.burstT > 0) { P.burstT -= dt; n = P.burst } else P.burst = 0
  P.noise = n
}

function enterHide (h) {
  P.hidden = h; P.hideT = 0
  P.hideFrom = { x: camera.position.x, y: camera.position.y, z: camera.position.z }
  P.crouch = false
  if (h.kind === 'locker') {
    P.hideCam = { x: h.x - Math.sin(h.yaw) * 0.07, y: h.camY, z: h.z - Math.cos(h.yaw) * 0.07 }
    P.hideYaw = h.yaw + Math.PI
    h.target = 1
    A.play('locker_open', { pos: pos(h.x, h.z, 1.2), vol: 0.7 })
    setTimeout(() => { if (P.hidden === h) { h.target = 0; A.play('locker_close', { pos: pos(h.x, h.z, 1.2), vol: 0.5 }) } }, 480)
    P.pitch = 0
  } else {
    P.hideCam = { x: h.x, y: 0.33, z: h.z }
    P.hideYaw = P.yaw
    A.play('cloth', { vol: 0.7 })
  }
  P.x = P.hideCam.x; P.z = P.hideCam.z
  P.hideBreath = 100; P.gasping = false
  P.burst = 2.5; P.burstT = 0.4
  subtitle(touch ? 'Hold the breath button when he comes close.' : 'Hold Space to hold your breath when he comes close.', 3600)
}

function leaveHide (silent = false) {
  const h = P.hidden
  if (!h) return
  let ex = h.x, ez = h.z
  if (h.kind === 'locker') { ex = h.x + Math.sin(h.yaw) * 0.8; ez = h.z + Math.cos(h.yaw) * 0.8; h.target = 1; setTimeout(() => { h.target = 0 }, 700) } else {
    for (const [dx, dz] of [[0.95, 0], [-0.95, 0], [0, 1.45], [0, -1.45], [0.95, 1.0], [-0.95, -1.0]]) {
      const [rx, rz] = W.colliders.resolve(h.x + dx, h.z + dz, RADIUS)
      if (Math.hypot(rx - (h.x + dx), rz - (h.z + dz)) < 0.03) { ex = rx; ez = rz; break }
      ex = rx; ez = rz
    }
  }
  const [rx, rz] = W.colliders.resolve(ex, ez, RADIUS)
  P.x = rx; P.z = rz
  P.hidden = null; P.holding = false; P.hideT = 1
  P.eye = h.kind === 'locker' ? EYE : 0.5
  P.crouch = h.kind !== 'locker'
  if (!silent) { if (h.kind === 'locker') A.play('locker_open', { pos: pos(h.x, h.z, 1.2), vol: 0.5 }); else A.play('cloth', { vol: 0.6 }) }
}

// ═════════════ what you are looking at ═════════════
function findTarget () {
  if (P.down || P.caught) return null
  if (P.hidden) return P.hideT >= 1 ? { kind: 'unhide', label: P.hidden.kind === 'locker' ? 'Climb out' : 'Slide out' } : null
  const ex = P.x, ey = P.eye, ez = P.z
  const f = dirOf()
  let best = null, bestS = -9
  const consider = (t, x, y, z, reach, minDot, bias = 0) => {
    const dx = x - ex, dy = y - ey, dz = z - ez
    const d = Math.hypot(dx, dy, dz)
    if (d > reach) return
    const dot = (dx * f.x + dy * f.y + dz * f.z) / (d || 1)
    if (dot < minDot - (d < 0.8 ? 0.3 : 0)) return
    const s = dot * 2 - d * 0.3 + bias
    if (s > bestS) { bestS = s; best = t }
  }
  for (const it of G.items.values()) {
    consider({ kind: 'item', it, label: it.kind === 'note' ? 'Read the note' : `Pick up ${ITEM_NAMES[it.kind]}` }, it.x, it.y + 0.03, it.z, 2.0, 0.93, 0.5)
  }
  for (const d of W.doors) {
    if (d.chain) {
      const need = G.keys.has('boltCutters')
      consider({ kind: 'chain', label: need ? 'Hold to cut the chain' : 'The chain is padlocked' , ok: need }, 0, 1.05, -0.2, 2.3, 0.7, 0.4)
      continue
    }
    const hw = d.w / 2
    const px = d.axis === 'x' ? clamp(ex, d.at - hw, d.at + hw) : d.c
    const pz = d.axis === 'x' ? d.c : clamp(ez, d.at - hw, d.at + hw)
    const open = d.target > 0.5
    const label = d.locked ? (d.keyId && G.keys.has(d.keyId) ? `Unlock the ${doorLabel(d)}` : `${cap(doorLabel(d))} (locked)`) : open ? `Close the ${doorLabel(d)}` : `Open the ${doorLabel(d)}`
    consider({ kind: 'door', d, label }, px, 1.0, pz, 2.0, 0.72)
  }
  for (const h of W.hides) {
    if (h.kind === 'locker') {
      const facing = (ex - h.x) * Math.sin(h.yaw) + (ez - h.z) * Math.cos(h.yaw)
      if (facing < 0.25) continue
      consider({ kind: 'hide', h, label: 'Hide in the locker' }, h.x, 1.2, h.z, 1.9, 0.85, 0.2)
    } else {
      const dx = Math.max(Math.abs(ex - h.x) - 0.5, 0), dz = Math.max(Math.abs(ez - h.z) - 1.05, 0)
      if (Math.hypot(dx, dz) > 1.0) continue
      consider({ kind: P.crouch ? 'hide' : 'info', h, label: P.crouch ? 'Slide under the bed' : 'Crouch to hide under the bed' }, h.x, 0.5, h.z, 3.0, 0.45, -0.1)
    }
  }
  if (G.coop) for (const [id, r] of G.registry) if (r.down && id !== myId()) consider({ kind: 'revive', id, label: `Hold to help ${nameOf(id)} up` }, r.x, 0.4, r.z, 2.4, 0.2, 0.6)
  return best
}
const cap = s => s.charAt(0).toUpperCase() + s.slice(1)

function updateInteraction (dt) {
  const t = findTarget()
  const held = input.held.interact || G.mouse
  const tapped = consumePressed('interact')
  let label = t?.label ?? ''
  let prog = -1
  const holdLen = t?.kind === 'chain' ? 4 : 2.4
  const holdable = t && ((t.kind === 'chain' && t.ok) || t.kind === 'revive')
  if (holdable && held) {
    P.hold += dt / holdLen
    prog = P.hold
    if (t.kind === 'chain') {
      P.burst = 40; P.burstT = 0.25
      P.rattleT = (P.rattleT ?? 0) - dt
      if (P.rattleT <= 0) { P.rattleT = 0.5; A.play('chain_rattle', { pos: pos(0, -0.3, 1), vol: 0.9 }) }
      if (!P.cutWarned) { P.cutWarned = true; subtitle('This is going to be loud.', 2500) }
    }
    if (P.hold >= 1) {
      P.hold = 0
      if (t.kind === 'chain') { emit('cut', {}) } else if (t.kind === 'revive') emit('revive', { id: t.id })
    }
  } else {
    P.hold = Math.max(0, P.hold - dt * 1.5)
    if (holdable && P.hold > 0.01) prog = P.hold
    if (!holdable) P.cutWarned = false
  }
  setPrompt(label, holdable ? Math.max(prog, 0) : -1)
  if (tapped && t) {
    switch (t.kind) {
      case 'item': hostPickup(t.it.id); break
      case 'door': tryDoor(t.d); break
      case 'hide': enterHide(t.h); break
      case 'unhide': leaveHide(); break
      case 'chain': if (!t.ok) { A.play('chain_rattle', { pos: pos(0, -0.3, 1), vol: 0.6 }); subtitle('Thick. You need something to cut it.', 2600); P.burst = 6; P.burstT = 0.4 } break
      default: break
    }
  }
}
function hostPickup (id) {
  if (isHost()) { if (G.items.has(id)) emit('taken', { id, by: myId() }) } else sendHost('req', { kind: 'pickup', id })
}

// ═════════════ throwing ═════════════
function throwBottle () {
  if (P.bottles <= 0 || P.hidden || P.down || P.caught) return
  P.bottles--
  const f = dirOf()
  const m = itemMesh('bottle')
  m.scale.setScalar(1.2)
  scene.add(m)
  thrown.push({ m, x: P.x + f.x * 0.4, y: P.eye - 0.1, z: P.z + f.z * 0.4, vx: f.x * 10.5, vy: f.y * 10.5 + 2.2, vz: f.z * 10.5, spin: Math.random() * 6 })
  A.play('throw', { vol: 0.7 })
  P.burst = Math.max(P.burst, 3); P.burstT = 0.3
}
function updateThrown (dt) {
  for (let i = thrown.length - 1; i >= 0; i--) {
    const b = thrown[i]
    b.vy -= 9.8 * dt
    const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt, nz = b.z + b.vz * dt
    let hit = false
    if (ny < 0.05) hit = true
    else if (ny > 3.1) { b.vy = -Math.abs(b.vy) * 0.3; b.y = 3.05; b.x = nx; b.z = nz }
    else {
      for (const c of W.colliders.near(nx, nz, 0.1)) {
        if (!W.colliders.active(c)) continue
        if (nx > c.x1 && nx < c.x2 && nz > c.z1 && nz < c.z2 && (c.tall || ny < 0.9)) { hit = true; break }
      }
    }
    if (hit) {
      emit('glass', { x: b.x, z: b.z })
      hostNoise(b.x, b.z, 26, true)
      scene.remove(b.m); thrown.splice(i, 1)
      continue
    }
    b.x = nx; b.z = nz; if (ny <= 3.1) b.y = ny
    b.spin += dt * 12
    b.m.position.set(b.x, b.y, b.z); b.m.rotation.set(b.spin, b.spin * 0.7, 0)
  }
}

// ═════════════ flashlight, night vision, battery ═════════════
function updateTorch (dt, t) {
  if (consumePressed('flashlight') && !P.down) {
    if (P.nvOn) { P.nvOn = false; P.flashOn = true; A.play('nv_off', { vol: 0.5 }) } else P.flashOn = !P.flashOn
    A.play('flash_click', { vol: 0.5 })
    P.burst = Math.max(P.burst, 1.5); P.burstT = 0.2
  }
  if (consumePressed('nv') && !P.down) {
    P.nvOn = !P.nvOn
    if (P.nvOn) P.flashOn = false
    A.play(P.nvOn ? 'nv_on' : 'nv_off', { vol: 0.6 })
  }
  if (consumePressed('throw')) throwBottle()

  if (P.swapT > 0) P.swapT -= dt
  if (lightOn() && (P.flashOn || P.nvOn)) {
    P.battery -= dt * (P.nvOn ? 0.9 : 0.3)
    if (P.battery <= 0) {
      P.battery = 0
      if (P.spare > 0) { P.spare--; P.battery = 100; P.swapT = 1.9; A.play('cloth', { vol: 0.8 }); toast('The light dies. You swap in a new battery.', 2800) } else { toast('The battery is dead.', 3500); A.play('flash_flicker', { vol: 0.6 }) }
    }
  }
  // stutter: weak battery or something near
  let f = 1
  if (P.battery < 15 && P.battery > 0) f *= (Math.sin(t * 23) + Math.sin(t * 37.3) > -1.3 + P.battery / 14 ? 1 : 0.15)
  if (G.fear > 0.5 && Math.random() < dt * G.fear * 1.6 && P.flickT <= 0) { P.flickT = 0.05 + Math.random() * 0.22; if (Math.random() < 0.4) A.play('flash_flicker', { vol: 0.35 }) }
  if (P.flickT > 0) { P.flickT -= dt; f *= 0.06 }
  P.flick += (f - P.flick) * Math.min(1, dt * 40)

  const lit = lightOn()
  torch.intensity = lit && P.flashOn && !P.down ? 95 * P.flick : 0
  spill.intensity = lit && P.flashOn && !P.down ? 5.5 * P.flick : 0
  ir.intensity = lit && P.nvOn && !P.down ? 70 : 0
  rigs.dustMat.uniforms.uOn.value = torch.intensity > 1 ? 1 : 0
  beamMat.uniforms.uOn.value = torch.intensity > 1 ? P.flick : 0
}

// ═════════════ camera ═════════════
const tmpQ = new THREE.Quaternion(), offs = new THREE.Vector3()
function updateCamera (dt, t) {
  let cx = P.x, cy = P.eye, cz = P.z
  let bobY = 0, bobX = 0
  if (settings.bob && !P.hidden && !P.down) {
    const amp = P.sprint ? 0.045 : 0.022
    bobY = Math.sin(P.bob * 2) * amp * Math.min(1, P.speed)
    bobX = Math.sin(P.bob) * amp * 0.6 * Math.min(1, P.speed)
  }
  // slow breathing
  const breathe = Math.sin(t * 1.4) * 0.004
  let sx = 0, sy = 0, roll = 0
  const shake = G.fear * 0.0025 + (P.caught ? 0.02 : 0) + (P.holding ? 0.0 : 0)
  if (shake > 0) { sx = (Math.sin(t * 31) + Math.sin(t * 47.3)) * shake; sy = (Math.sin(t * 29.1) + Math.sin(t * 53.7)) * shake }
  if (P.hidden) {
    const k = P.hideT * P.hideT * (3 - 2 * P.hideT)
    cx = P.hideFrom.x + (P.hideCam.x - P.hideFrom.x) * k
    cy = P.hideFrom.y + (P.hideCam.y - P.hideFrom.y) * k
    cz = P.hideFrom.z + (P.hideCam.z - P.hideFrom.z) * k
    // a held breath steadies the picture; a held breath that runs out shakes it
    sx *= P.holding ? 0.2 : 1; sy *= P.holding ? 0.2 : 1
  }
  if (P.caught) {
    const tgt = Math.atan2(-(G.ov.x - P.x), -(G.ov.z - P.z))
    P.yaw += wrapA(tgt - P.yaw) * Math.min(1, dt * 9)
    P.pitch += (0.3 - P.pitch) * Math.min(1, dt * 5)
    P.eye += (1.3 - P.eye) * Math.min(1, dt * 4)
  }
  if (P.down) { roll = 1.25; P.pitch += (-0.2 - P.pitch) * Math.min(1, dt * 3) }
  const right = { x: Math.cos(P.yaw), z: -Math.sin(P.yaw) }
  camera.position.set(cx + right.x * bobX, cy + bobY + breathe, cz + right.z * bobX)
  camera.rotation.set(P.pitch + sx, P.yaw + sy, roll)
  camera.updateMatrixWorld()

  // the torch hangs a little behind where you look
  offs.set(0.16, -0.13, -0.05).applyQuaternion(camera.quaternion)
  rig.position.copy(camera.position).add(offs)
  const lag = P.hidden ? 30 : P.sprint ? 5 : 8.5
  rig.quaternion.slerp(camera.quaternion, 1 - Math.exp(-dt * lag))
  rig.updateMatrixWorld(true)
  void tmpQ
  dummy.position.copy(camera.position)
  rigs.dustMat.uniforms.uCam.value.copy(camera.position)
  const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(rig.quaternion)
  rigs.dustMat.uniforms.uDir.value.copy(fwd)
  rigs.dustMat.uniforms.uTime.value = t
  beamMat.uniforms.uTime.value = t
}

// ═════════════ the Orderly, per frame ═════════════
function updateOrderly (dt, t) {
  const ov = G.ov
  const o = G.orderly
  if (o && isHost()) {
    if (G.rage > 0) {
      G.rage -= dt
      if (o.mode !== 'attack') { o.loseT = 0; if (o.mode !== 'chase') { o.mode = 'chase'; o.chaseT = 0 } }
    }
    o.update(dt, hostPlayers(), orderlyHooks)
    Object.assign(ov, { x: o.x, z: o.z, yaw: o.yaw, speed: o.speed, mode: o.mode, attackT: o.attackT, look: o.look })
    G.owT -= dt
    if (G.owT <= 0 && G.coop) { G.owT = 0.1; sendAll('ow', o.snap()) }
    directorHost(dt)
  } else if (G.ot) {
    const s = G.ot
    const k = Math.min(1, dt * 11)
    ov.x += (s.x - ov.x) * k; ov.z += (s.z - ov.z) * k
    ov.yaw += wrapA(s.yaw - ov.yaw) * k
    ov.speed = s.speed; ov.mode = s.mode; ov.attackT = s.atk; ov.look = s.look
  }
  updatePhantoms(dt)
  const m = G.model
  if (m) {
    m.update(dt, ov)
    const chase = ov.mode === 'chase' || ov.mode === 'attack'
    m.eyes?.(chase || P.nvOn, chase ? 0xff3a22 : 0xffd29a)
  }
}

function directorHost (dt) {
  if (!isHost() || G.mode !== 'playing') return
  const D = G.dir
  const pls = hostPlayers()
  const anyone = pls.find(p => !p.down) ?? pls[0]
  D.phone -= dt; D.bang -= dt; D.thunder -= dt; D.blackout -= dt; D.whisper -= dt
  if (D.phone <= 0) {
    D.phone = 150 + Math.random() * 120
    emit('phone', {})
    const pp = W.phonePos
    if (G.orderly && pp) G.orderly.hear(pp.x, pp.z, 90, { strong: true })
  }
  if (D.bang <= 0) {
    D.bang = 40 + Math.random() * 50
    const far = validPois().filter(p => Math.hypot(p[0] - anyone.x, p[1] - anyone.z) > 14)
    const p = far.length ? far[(Math.random() * far.length) | 0] : null
    if (p) { emit('bang', { x: p[0], z: p[1] }); if (Math.random() < 0.3) G.orderly?.hear(p[0], p[1], 90, { strong: false }) }
  }
  if (D.thunder <= 0) { D.thunder = 55 + Math.random() * 80; emit('thunder', {}) }
  if (D.blackout <= 0) { D.blackout = 300 + Math.random() * 160; emit('blackout', { t: 16 + Math.random() * 10 }) }
  if (D.whisper <= 0) {
    D.whisper = 45 + Math.random() * 50
    if (G.fear < 0.45 && anyone) { const a = Math.random() * 6.28; emit('whisper', { x: anyone.x + Math.cos(a) * 3, z: anyone.z + Math.sin(a) * 3 }) }
  }
}

// ═════════════ sound that follows the Orderly ═════════════
function updateOrderlySound (dt) {
  const ov = G.ov
  const p = orderlyAt()
  const dist = Math.hypot(ov.x - P.x, ov.z - P.z)
  const chase = ov.mode === 'chase' || ov.mode === 'attack'
  // his hum: you hear it while he is not hunting, and it stops when he is
  if (!G.hum || G.hum.ended) G.hum = A.S.play('orderly_hum', { pos: p, loop: true, vol: 0, ref: 3, max: 45, rolloff: 1.1 })
  const humVol = chase ? 0 : ov.mode === 'search' ? 0.25 : 0.9
  G.hum.setVol(humVol * smooth(35, 4, dist) * (G.mode === 'playing' ? 1 : 0), 0.4)
  G.hum.setPos(p)
  // footsteps from how far he has moved
  if (ov.speed > 0.3) {
    G.stepAcc += ov.speed * dt
    const stride = chase ? 1.5 : 0.95
    if (G.stepAcc > stride) {
      G.stepAcc = 0
      A.play('step_boot', { pos: pos(ov.x, ov.z, 0.1), vol: chase ? 1 : 0.75, ref: 3, max: 50 })
    }
    if (!chase) {
      G.scrapeT -= dt
      if (G.scrapeT <= 0) { G.scrapeT = 1.1 + Math.random() * 0.8; A.play('scrape', { pos: pos(ov.x, ov.z, 0.1), vol: 0.8, ref: 3, max: 45 }) }
    }
  }
  // breathing when he is close and hunting
  G.breathT -= dt
  if (G.breathT <= 0 && dist < 7 && (chase || ov.mode === 'search')) { G.breathT = chase ? 1.8 : 2.8; A.play('orderly_breath', { pos: p, vol: 0.9, ref: 1.5, max: 20 }) }
}

// ═════════════ fear, heartbeat, mix ═════════════
function updateFear (dt) {
  const ov = G.ov
  const d = Math.hypot(ov.x - P.x, ov.z - P.z)
  const los = d < 40 && W.colliders.clear(ov.x, ov.z, P.x, P.z)
  let target = 0
  if (G.mode === 'playing' && !P.down) {
    if (ov.mode === 'chase' || ov.mode === 'attack') target = 1
    else if (los && d < 14) target = 0.25 + 0.6 * (1 - d / 14)
    else if (d < 7) target = 0.3 * (1 - d / 7)
    if (P.hidden && (ov.mode === 'search' || ov.mode === 'investigate') && d < 9) target = Math.max(target, 0.75)
  }
  G.fear += (target - G.fear) * Math.min(1, dt * (target > G.fear ? 2.2 : 0.5))
  G.losNow = los
  G.glitch += (Math.max(los && d < 5 ? (1 - d / 5) * 0.8 : 0, G.fear > 0.9 ? 0.3 : 0, P.caught ? 1 : 0, G.phoneRing > 0 ? 0.05 : 0) - G.glitch) * Math.min(1, dt * 3)
  if (G.phoneRing > 0) G.phoneRing -= dt
  G.heartT -= dt
  if (G.fear > 0.35 && G.heartT <= 0) { G.heartT = 1.1 - G.fear * 0.55; A.play('heart', { vol: 0.25 + G.fear * 0.55 }) }
}

function updateAudioMix (dt) {
  const ov = G.ov
  const d = Math.hypot(ov.x - P.x, ov.z - P.z)
  const outside = G.mode === 'playing' ? smooth(10, 2.5, Math.hypot(P.x, P.z + 1)) * (P.z > -9 ? 1 : 0) : 0
  A.updateBeds(dt, {
    fear: G.mode === 'playing' ? G.fear : 0.1,
    chasing: G.mode === 'playing' && (ov.mode === 'chase' || ov.mode === 'attack') && d < 45,
    stat: Math.min(1, G.glitch * 0.9),
    outside: G.cut ? Math.max(outside, P.z > -2 ? 1 : 0) : outside * 0.5,
    humNear: smooth(25, 3, d),
  })
  const f = dirOf()
  A.S.listener({ x: camera.position.x, y: camera.position.y, z: camera.position.z }, f)
}

// ═════════════ other players ═════════════
function clearAvatars () {
  for (const av of G.avatars.values()) { av.model.dispose(); scene.remove(av.model.group); scene.remove(av.spot, av.spot.target) }
  G.avatars.clear()
}
function ensureAvatar (id, d) {
  let av = G.avatars.get(id)
  if (av) return av
  const model = createAvatar(id, { outfit: 'explorer', name: nameOf(id), shadows: HIGH })
  scene.add(model.group)
  const spot = new THREE.SpotLight(0xfff0d6, 0, 20, 0.42, 0.6, 1.4)
  scene.add(spot, spot.target)
  av = { model, spot, x: d.x, z: d.z, yaw: d.yaw, pitch: 0, t: d }
  G.avatars.set(id, av)
  return av
}
function updateAvatars (dt) {
  for (const [id, av] of G.avatars) {
    const s = av.t
    const k = Math.min(1, dt * 12)
    av.x += (s.x - av.x) * k; av.z += (s.z - av.z) * k
    av.yaw += wrapA(s.yaw - av.yaw) * k
    av.pitch += ((s.pitch ?? 0) - av.pitch) * k
    av.model.group.visible = !s.hidden
    av.model.update(dt, { x: av.x, z: av.z, yaw: av.yaw, pitch: av.pitch, speed: s.speed ?? 0, crouch: !!s.crouch, down: !!s.down, hidden: !!s.hidden, flashlight: !!s.flash, y: 0 })
    const on = s.flash && !s.hidden && !s.down
    av.spot.intensity += ((on ? 55 : 0) - av.spot.intensity) * Math.min(1, dt * 15)
    const ey = s.crouch ? 1.0 : 1.5
    av.spot.position.set(av.x - Math.sin(av.yaw) * 0.25, ey, av.z - Math.cos(av.yaw) * 0.25)
    av.spot.target.position.set(av.x - Math.sin(av.yaw) * 5, ey + Math.tan(av.pitch ?? 0) * 5, av.z - Math.cos(av.yaw) * 5)
    void id
  }
}

// ═════════════ networking ═════════════
let sendT = 0
function sendState (dt) {
  sendT -= dt
  if (sendT > 0 || !net.online) return
  sendT = 0.085
  sendAll('state', localState())
}
on('state', (d, from) => {
  G.registry.set(from, { ...d, id: from, t: now() })
  if (G.mode === 'playing') ensureAvatar(from, d).t = d
})
on('ow', d => { G.ot = d; if (isHost()) return })
on('fx', d => playFx(d.kind, d.data ?? {}))
on('req', (d, from) => {
  if (!isHost()) return
  if (d.kind === 'pickup' && G.items.has(d.id)) emit('taken', { id: d.id, by: from })
})
on('noise', d => { if (isHost()) G.orderly?.hear(d.x, d.z, d.r, { strong: !!d.strong }) })
on('start', d => {
  if (isHost()) return
  void startGame({ items: d.items, coop: true, snap: d.snap })
})
on('peerJoin', d => {
  toast(`${d.name} joined.`)
  if (isHost() && G.mode === 'playing') sendTo(d.id, 'start', { items: itemList(), snap: gameSnap() })
  refreshLobby()
})
on('peerLeave', d => {
  toast(`${nameOf(d.id)} left.`)
  G.registry.delete(d.id)
  const av = G.avatars.get(d.id)
  if (av) { av.model.dispose(); scene.remove(av.model.group); scene.remove(av.spot, av.spot.target); G.avatars.delete(d.id) }
  refreshLobby()
})
on('hostChange', ({ isHost: me }) => {
  if (me && G.mode === 'playing') {
    G.orderly = new Orderly(W)
    if (G.ot) G.orderly.restore(G.ot)
    toast('You are now the host.')
  }
  refreshLobby()
})
on('disconnected', () => {
  if (G.mode === 'title') { setStatus('#lobby-status', 'Disconnected from the co-op server.', true); return }
  if (G.mode === 'playing') {
    toast('Lost the connection. Carrying on alone.', 4000)
    clearAvatars(); G.registry.clear(); G.coop = false
    if (!G.orderly) G.orderly = new Orderly(W)
  }
})
on('roster', () => refreshLobby())
on('name', (d, from) => { const p = net.players.get(from); if (p) p.name = d.name; refreshLobby() })

function gameSnap () {
  return {
    keys: [...G.keys], notes: [...G.notes], cut: G.cut,
    doors: W.doors.filter(d => !d.chain).map(d => [d.id, d.locked, d.target]),
  }
}

// ═════════════ HUD ═════════════
let hudT = 0
function updateHud (dt) {
  hudT -= dt
  if (hudT > 0) return
  hudT = 0.1
  const t = Math.floor(G.playT)
  setText($('#tcode'), `${String(Math.floor(t / 3600)).padStart(2, '0')}:${String(Math.floor(t / 60) % 60).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`)
  const mins = 42 + Math.floor(G.playT / 6)
  const h24 = (23 + Math.floor(mins / 60)) % 24
  const mm = String(mins % 60).padStart(2, '0')
  setText($('#clock'), `${((h24 + 11) % 12) + 1}:${mm} ${h24 >= 12 ? 'PM' : 'AM'}`)
  setText($('#datestamp'), mins >= 60 ? 'OCT 31 1996' : 'OCT 30 1996')
  const pct = Math.max(0, Math.round(P.battery))
  setText($('#bat-pct'), `${P.swapT > 0 ? 'SWAP' : pct + '%'}${P.spare ? ` +${P.spare}` : ''}${P.bottles ? `  ◍${P.bottles}` : ''}`)
  $('#bat-bar').style.width = `${pct}%`
  $('#bat').classList.toggle('low', pct < 20)
  setText($('#nvtag'), P.nvOn ? 'NIGHT VISION' : '')
  setText($('#place'), (W.roomAt(P.x, P.z)?.name ?? '').toUpperCase())
  setText($('#goal'), objective())
  const st = $('#stam'); st.style.opacity = P.stamina < 99 ? '1' : '0'; $('#stam-bar').style.width = `${P.stamina}%`
  const br = $('#breath'); br.classList.toggle('is-on', !!P.hidden && P.hideT >= 1); $('#breath-bar').style.width = `${P.hideBreath}%`
  if (G.coop && net.online) {
    setText($('#team'), [...net.players.values()].map(p => { const r = p.id === myId() ? { down: P.down } : G.registry.get(p.id); return `<span class="${r?.down ? 'down' : ''}">${esc(p.name)}${p.id === myId() ? ' (you)' : ''}${r?.down ? ' · down' : ''}</span>` }).join(''), true)
  } else setText($('#team'), '')
}
function objective () {
  if (G.cut) return OBJECTIVES.run
  if (G.keys.has('boltCutters')) return OBJECTIVES.cut
  if (G.keys.has('annexKey')) return OBJECTIVES.cutters
  if (G.keys.has('recordsKey')) return OBJECTIVES.annex
  if (G.keys.has('wardKey')) return OBJECTIVES.records
  if (G.playT > 70 || G.notes.size) return OBJECTIVES.ward
  return OBJECTIVES.start
}
function updateProfile () {
  const bits = []
  if (progress.escapes + progress.tapes) bits.push(`Got out ${progress.escapes + progress.tapes} time${progress.escapes + progress.tapes === 1 ? '' : 's'}`)
  if (progress.tapes) bits.push('Saw the tape')
  if (progress.best) bits.push(`Best ${Math.floor(progress.best / 60)}m ${progress.best % 60}s`)
  setText($('#profile'), bits.length ? bits.join(' · ') : 'Headphones recommended. It is dark in there on purpose.')
}

// ═════════════ post and mood ═════════════
function updatePost (dt, t) {
  const u = post.uniforms
  u.time.value = t
  u.fear.value += (G.fear - u.fear.value) * Math.min(1, dt * 6)
  u.glitch.value = G.mode === 'playing' ? G.glitch : 0.04 + (Math.sin(t * 0.7) > 0.95 ? 0.4 : 0)
  u.nv.value += ((P.nvOn && P.battery > 0 && P.swapT <= 0 ? 1 : 0) - u.nv.value) * Math.min(1, dt * 12)
  P.hurt = Math.max(0, P.hurt - dt * 0.6)
  u.flash.value = P.hurt
  u.down.value += ((P.down ? 1 : 0) - u.down.value) * Math.min(1, dt * 3)
  G.thunderFlash = Math.max(0, G.thunderFlash - dt * 3)
  u.flick.value = 1 + G.thunderFlash * 0.7
  u.exposure.value = P.nvOn ? 1.15 : 1.35
  hemi.intensity = (P.nvOn ? 0.55 : 0.22) + G.thunderFlash * (Math.sin(t * 60) > -0.4 ? 0.7 : 0.1)
  if (G.blackout > 0) G.blackout -= dt
  $('#hurt').style.opacity = String(Math.min(1, P.hurt * 0.9 + (P.caught ? 0.6 : 0)))
  $('#slit').classList.toggle('is-on', !!P.hidden && P.hidden.kind === 'locker' && P.hideT >= 1)
}

// ═════════════ the frame ═════════════
let last = performance.now()
function frame (ts) {
  requestAnimationFrame(frame)
  const dt = Math.max(0, Math.min(0.05, (ts - last) / 1000))
  last = ts
  G.t += dt
  const t = G.t

  if (G.mode === 'title') {
    // the lobby behind the title: a camera that barely moves, a tube that dies and comes back
    G.titleT += dt
    camera.position.set(0.6 + Math.sin(G.titleT * 0.11) * 0.25, 1.55 + Math.sin(G.titleT * 0.5) * 0.01, -6.5)
    camera.rotation.set(-0.03 + Math.sin(G.titleT * 0.17) * 0.015, Math.PI + 0.1 + Math.sin(G.titleT * 0.09) * 0.07, 0)
    camera.updateMatrixWorld()
    G.ov.x = -40; G.ov.z = -40
    torch.intensity = 0; spill.intensity = 0; ir.intensity = 0; beamMat.uniforms.uOn.value = 0; rigs.dustMat.uniforms.uOn.value = 0
    rigs.dustMat.uniforms.uCam.value.copy(camera.position)
    updateLamps(dt, t); W.update(dt); updatePost(dt, t); A.updateBeds(dt, { fear: 0.05 })
    render()
    return
  }

  // menus that cover the game
  if (ui.current && ui.current !== 'caught') input.pressed.clear()
  if (consumePressed('pause')) { if (ui.current === 'pause') resume(); else pause() }
  if (G.mode === 'playing' && !G.paused) {
    G.playT += dt
    if (!(ui.current && ui.current !== 'caught' && !G.coop)) {
      updatePlayer(dt)
      if (!P.down) updateInteraction(dt); else setPrompt('')
      updateTorch(dt, t)
    }
    updateThrown(dt)
    W.update(dt)
    updateOrderly(dt, t)
    updateFear(dt)
    updateCamera(dt, t)
    updateLamps(dt, t)
    updateAvatars(dt)
    updateOrderlySound(dt)
    updateAudioMix(dt)
    sendState(dt)
    updateHud(dt)
    updatePost(dt, t)
    checkExit(dt)
    reviveWatch(dt)
  } else if (G.mode === 'playing') {
    updateCamera(0, t)
  }
  render()
}

function render () {
  renderer.setRenderTarget(rt)
  renderer.render(scene, camera)
  renderer.setRenderTarget(null)
  renderer.render(postScene, postCam)
}

function checkExit () {
  if (G.cut && !G.ended && P.z > 0.9 && Math.abs(P.x) < 3) {
    emit('end', {})
  }
}
// in co-op, if everyone is down they all get up at the last safe place
function reviveWatch (dt) {
  if (!G.coop || !isHost() || !P.down) return
  const others = [...G.registry.values()].filter(r => now() - r.t < 4)
  if (others.every(r => r.down)) { G.wipeT += dt; if (G.wipeT > 6) { G.wipeT = 0; emit('wipe', {}); standUp(true) } } else G.wipeT = 0
  P.downT += dt
  if (P.downT > 60) { P.downT = 0; standUp(true) }
}

// ═════════════ menus ═════════════
function pause () {
  if (G.mode !== 'playing' || (ui.current && ui.current !== 'caught')) return
  if (ui.current === 'caught') return
  G.paused = !G.coop
  input.pressed.clear()
  setText($('#pause-note'), net.online ? 'The hospital keeps going. In co-op, so does everything in it.' : 'Everything waits for you.')
  showScreen('pause')
  document.exitPointerLock?.()
}
function resume () {
  G.paused = false
  input.pressed.clear()
  showScreen(null)
  if (!touch) void canvas.requestPointerLock?.()
}

function refreshLobby () {
  if (!net.online) return
  setText($('#lobby-code'), net.code || '- - - -')
  setText($('#lobby-roster'), [...net.players.values()].map(p => `<li>${esc(p.name)}${p.id === net.hostId ? '<small>host</small>' : ''}${p.id === net.id ? '<small>you</small>' : ''}</li>`).join(''), true)
  const startBtn = $('#lobby-start'); if (startBtn) startBtn.style.display = isHost() ? '' : 'none'
  setText($('#lobby-hint'), isHost() ? 'Share this code with up to three friends, then open the doors.' : 'Waiting for the host to open the doors.')
}
async function openRoom () {
  showScreen('lobby', { push: true })
  $('#host-name-field').style.display = ''
  $('#host-name').value = myName
  setStatus('#lobby-status', 'Opening a room… (the server can take up to a minute to wake up)')
  try { await connect({ url: coopServerUrl(), mode: 'create', name: myName }); setStatus('#lobby-status', ''); refreshLobby() } catch (err) { setStatus('#lobby-status', err.message, true) }
}
async function joinRoom () {
  const name = $('#join-name').value.trim() || myName
  const code = $('#join-code').value.trim().toUpperCase()
  if (code.length !== 4) { setStatus('#join-status', 'Room codes are four letters.', true); return }
  setName(name)
  setStatus('#join-status', 'Joining… (the server can take up to a minute to wake up)')
  try {
    await connect({ url: coopServerUrl(), mode: 'join', code, name: myName })
    setStatus('#join-status', '')
    showScreen('lobby', { push: true })
    $('#host-name-field').style.display = 'none'
    refreshLobby()
  } catch (err) { setStatus('#join-status', err.message, true) }
}
const setName = n => { myName = n.slice(0, 14); try { localStorage.setItem('hollow.name', myName) } catch {} }

document.addEventListener('click', e => {
  const btn = e.target.closest('[data-go]')
  if (!btn) return
  A.S.init()
  switch (btn.dataset.go) {
    case 'play': disconnect(); void startGame({}); break
    case 'host': void openRoom(); break
    case 'join': showScreen('join', { push: true }); $('#join-name').value = myName; break
    case 'join-go': void joinRoom(); break
    case 'howto': showScreen('howto', { push: true }); break
    case 'settings': syncSettings(); showScreen('settings', { push: true }); break
    case 'back': backScreen(); break
    case 'leave': disconnect(); clearStack(); showScreen('title'); break
    case 'lobby-start': {
      if (!isHost()) return
      const items = genItems()
      sendAll('start', { items, snap: null })
      void startGame({ items, coop: true })
      break
    }
    case 'resume': resume(); break
    case 'quit': quitToTitle(); break
    case 'close-note': G.paused = false; showScreen(null); if (!touch) void canvas.requestPointerLock?.(); break
    case 'retry': standUp(true); break
    case 'after-ending': quitToTitle(); break
  }
})
$('#host-name').addEventListener('change', e => { setName(e.target.value.trim() || myName); if (net.online) { const me = net.players.get(net.id); if (me) me.name = myName; sendAll('name', { name: myName }); refreshLobby() } })
$('#join-code').addEventListener('keydown', e => { if (e.key === 'Enter') void joinRoom() })
function syncSettings () {
  $('#set-sens').value = settings.sensitivity
  $('#set-vol').value = settings.volume
  for (const b of document.querySelectorAll('#set-quality button')) b.setAttribute('aria-pressed', String(b.dataset.q === settings.quality))
  for (const b of document.querySelectorAll('#set-grain button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.grain)))
  for (const b of document.querySelectorAll('#set-bob button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.bob)))
  for (const b of document.querySelectorAll('#set-invert button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.invertY)))
}
$('#set-sens').addEventListener('input', e => { settings.sensitivity = +e.target.value; saveSettings() })
$('#set-vol').addEventListener('input', e => { settings.volume = +e.target.value; A.S.setVolume(settings.volume); saveSettings() })
$('#set-quality').addEventListener('click', e => { const q = e.target.dataset.q; if (!q) return; settings.quality = q; saveSettings(); syncSettings(); setStatus('#settings-status', 'Graphics change when you next load the page.') })
$('#set-grain').addEventListener('click', e => { const v = e.target.dataset.v; if (!v) return; settings.grain = v === 'true'; post.uniforms.grain.value = settings.grain ? (HIGH ? 0.06 : 0.045) : 0; saveSettings(); syncSettings() })
$('#set-bob').addEventListener('click', e => { const v = e.target.dataset.v; if (!v) return; settings.bob = v === 'true'; saveSettings(); syncSettings() })
$('#set-invert').addEventListener('click', e => { const v = e.target.dataset.v; if (!v) return; settings.invertY = v === 'true'; saveSettings(); syncSettings() })

window.addEventListener('mousedown', e => { if (e.button === 0 && input.locked) G.mouse = true })
window.addEventListener('mouseup', e => { if (e.button === 0) G.mouse = false })

// ═════════════ boot ═════════════
bindFullscreenButtons()
initInput(canvas, { onPause: reason => { if (reason === 'unlock') { if (G.mode === 'playing' && !ui.current && !P.down) pause() } else if (ui.current === 'pause') resume(); else pause() } })
initGamepad(input, {
  sprintStick: true,
  held: { [BTN.A]: 'interact', [BTN.LT]: 'breath', [BTN.LB]: 'sprint' },
  press: { [BTN.A]: 'interact', [BTN.B]: 'crouch', [BTN.RS]: 'crouch', [BTN.Y]: 'flashlight', [BTN.X]: 'nv', [BTN.RT]: 'throw', [BTN.RB]: 'throw' },
})
if (touch) initTouchControls($('#touch'))
document.addEventListener('visibilitychange', () => { if (document.hidden && G.mode === 'playing' && !G.coop && !ui.current) pause() })
window.addEventListener('resize', () => { rigs.resize() })

syncSettings()
A.S.setVolume(settings.volume)
updateProfile()
showScreen('title')
$('#loading').style.display = 'none'
fade(0, 1800)
requestAnimationFrame(frame)

window.__hl = { phantoms, G, P, W, net, scene, camera, startGame, quitToTitle, emit, genItems, findTarget, tryDoor, enterHide, leaveHide, standUp, settings, throwBottle, takeItem, hostPickup, cutChain, endGame, playFx }
void isTouchDevice; void Orderly
