// The Orderly: Walter Pell. His body (built from the shared anatomy kit) and the brain that hunts you.
import * as THREE from 'three'
import { buildHead, limbGeo, torsoGeo, handGeo, footGeo, skinMat, clothMat, mergedMesh } from '../../gamekit/anatomy.js'

// ═════════════════════ body ═════════════════════
function scrubTex () {
  const s = 256
  const c = document.createElement('canvas'); c.width = c.height = s
  const g = c.getContext('2d')
  g.fillStyle = '#bdb8a2'; g.fillRect(0, 0, s, s)
  let seed = 77
  const r = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647 }
  for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(${120 + r() * 40 | 0},${110 + r() * 30 | 0},${80 + r() * 30 | 0},${0.05 + r() * 0.1})`; g.beginPath(); g.arc(r() * s, r() * s, 6 + r() * 30, 0, 7); g.fill() }
  // old blood: browns, long drips from the chest, splatter
  for (let i = 0; i < 18; i++) { const x = r() * s, y = r() * s * 0.6; g.fillStyle = `rgba(${70 + r() * 30 | 0},${8 + r() * 10 | 0},${8},${0.35 + r() * 0.4})`; g.beginPath(); g.ellipse(x, y, 4 + r() * 22, 3 + r() * 14, r() * 3, 0, 7); g.fill(); g.fillRect(x, y, 2 + r() * 2, 30 + r() * 120) }
  for (let i = 0; i < 160; i++) { g.fillStyle = `rgba(60,8,8,${0.3 + r() * 0.5})`; g.beginPath(); g.arc(r() * s, r() * s, 0.6 + r() * 2.4, 0, 7); g.fill() }
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  return t
}

export function orderlyModel () {
  const root = new THREE.Group()
  const body = new THREE.Group()
  body.scale.setScalar(1.19)
  root.add(body)

  const scrubs = clothMat(0xffffff, 0.92); scrubs.map = scrubTex()
  const trousers = clothMat(0x7d8776, 0.92); trousers.map = scrubTex(); trousers.color.setHex(0x9aa593)
  const skin = skinMat(0x8d948b, { rough: 0.65, veins: true, bump: 0.02 })
  const apron = new THREE.MeshPhysicalMaterial({ color: 0x1a1d18, roughness: 0.3, clearcoat: 0.8, clearcoatRoughness: 0.35, side: THREE.DoubleSide })
  const glove = new THREE.MeshPhysicalMaterial({ color: 0xb7a233, roughness: 0.35, clearcoat: 0.6, clearcoatRoughness: 0.3 })
  const boot = new THREE.MeshPhysicalMaterial({ color: 0x121312, roughness: 0.3, clearcoat: 0.9, clearcoatRoughness: 0.25 })
  const mask = new THREE.MeshStandardMaterial({ color: 0x9aa09a, roughness: 0.95, side: THREE.DoubleSide, bumpMap: scrubs.map, bumpScale: 0.01 })
  const capM = clothMat(0x6c7f6a, 0.95); capM.side = THREE.DoubleSide
  const pipeM = new THREE.MeshStandardMaterial({ color: 0x6b5b4a, roughness: 0.5, metalness: 0.8 })
  const strap = new THREE.MeshStandardMaterial({ color: 0xaab0aa, roughness: 0.9 })

  const joint = (parent, x, y, z) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); return g }
  const add = (geo, m, parent, x = 0, y = 0, z = 0) => { const me = new THREE.Mesh(geo, m); me.position.set(x, y, z); me.castShadow = true; me.receiveShadow = true; parent.add(me); return me }

  const hips = joint(body, 0, 0.93, 0)
  add(new THREE.SphereGeometry(1, 18, 12).scale(0.19, 0.13, 0.13), trousers, hips)
  const spine = joint(hips, 0, 0.08, 0)
  add(torsoGeo({ h: 0.5, hip: 0.17, waist: 0.16, chest: 0.19, shoulder: 0.22, neck: 0.06, depth: 0.7, belly: 0.025 }), scrubs, spine, 0, -0.03, 0)
  // butcher's apron
  const ap = add(new THREE.CylinderGeometry(0.2, 0.25, 0.95, 18, 1, true, -1.1, 2.2).scale(1, 1, 0.72), apron, spine, 0, -0.18, 0.012)
  ap.castShadow = false
  add(new THREE.BoxGeometry(0.03, 0.18, 0.02), apron, spine, -0.11, 0.42, 0.12) // neck strap
  add(new THREE.BoxGeometry(0.03, 0.18, 0.02), apron, spine, 0.11, 0.42, 0.12)
  const neck = joint(spine, 0, 0.445, 0)
  add(limbGeo(0.06, 0.07, 0.1, { bulge: 0 }), skin, neck, 0, 0.08, 0)
  const head = joint(neck, 0, 0.09, 0.02)
  const hs = 0.118
  const face = buildHead({ skin, eyeColor: 0xc6d0c9, browColor: 0x30302c, lipColor: 0x6e5048, headOpts: { gaunt: 0.7, jaw: 1.15, brow: 1.4, nose: 1.1, chin: 1.15 }, eyeSize: 0.95 })
  face.group.scale.setScalar(hs)
  face.group.position.set(0, 0.095, 0.01)
  head.add(face.group)
  // surgical mask over the nose and mouth, pleated, with ear loops
  const mk = new THREE.Group()
  mk.add(new THREE.Mesh(new THREE.CylinderGeometry(0.84, 0.74, 0.62, 28, 1, true, Math.PI * 0.5 - 1.05, 2.1), mask))
  for (let i = 0; i < 3; i++) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.855 - i * 0.015, 0.84 - i * 0.015, 0.02, 28, 1, true, Math.PI * 0.5 - 1.05, 2.1), mask); p.position.y = 0.16 - i * 0.18; mk.add(p) }
  mk.scale.set(1, 1, 1.13); mk.position.set(0, -0.36, 0.1)
  face.group.add(mk)
  for (const s of [-1, 1]) {
    const loop = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.7, 4), strap)
    loop.rotation.set(0, 0, Math.PI / 2); loop.rotation.y = s * 0.9
    loop.position.set(s * 0.9, -0.2, 0.0)
    loop.scale.set(1, 1, 1)
    face.group.add(loop)
  }
  // cloth cap
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.98, 22, 12, 0, Math.PI * 2, 0, Math.PI * 0.44), capM)
  cap.scale.set(1, 0.95, 1.05); cap.position.set(0, 0.34, -0.04)
  face.group.add(cap)
  const brim = new THREE.Mesh(new THREE.TorusGeometry(0.93, 0.05, 6, 28, Math.PI * 2), capM)
  brim.rotation.x = Math.PI / 2; brim.scale.set(1, 1.05, 1); brim.position.set(0, 0.5, -0.04)
  face.group.add(brim)
  face.irisMat.emissive.setHex(0x1c1010); face.irisMat.emissiveIntensity = 1

  // arms: short sleeves, bare veined forearms, long yellow rubber gloves
  const arms = [-1, 1].map(side => {
    const shoulder = joint(spine, side * 0.235, 0.43, 0)
    add(limbGeo(0.062, 0.05, 0.27, { bulge: 0.22, at: 0.35 }), scrubs, shoulder, 0, -0.01, 0)
    const elbow = joint(shoulder, 0, -0.29, 0)
    add(limbGeo(0.05, 0.04, 0.3, { bulge: 0.14, at: 0.22 }), skin, elbow, 0, 0, 0)
    const wrist = joint(elbow, 0, -0.31, 0)
    add(limbGeo(0.047, 0.047, 0.16, { bulge: 0.04 }), glove, wrist, 0, 0.1, 0) // gauntlet cuff
    const hg = handGeo({ fingerLen: 1.2, thick: 1.15, claws: 0, curl: 0.2 })
    if (side < 0) { hg.skin.scale(-1, 1, 1) }
    const hand = add(hg.skin, glove, wrist, 0, 0, 0)
    hand.rotation.y = side * -Math.PI / 2
    return { shoulder, elbow, wrist, side }
  })
  // a length of steel pipe in the right hand
  const pipe = joint(arms[1].wrist, 0, -0.05, 0.02)
  add(new THREE.CylinderGeometry(0.024, 0.024, 1.25, 10).translate(0, -0.45, 0), pipeM, pipe)
  add(new THREE.CylinderGeometry(0.032, 0.032, 0.06, 10).translate(0, 0.1, 0), glove, pipe)
  const stain = add(new THREE.CylinderGeometry(0.0255, 0.0255, 0.3, 10).translate(0, -0.95, 0), new THREE.MeshStandardMaterial({ color: 0x3a0b0b, roughness: 0.6 }), pipe)
  void stain
  // legs: scrub trousers, rubber boots
  const legs = [-1, 1].map(side => {
    const hip = joint(hips, side * 0.095, -0.02, 0)
    add(limbGeo(0.085, 0.06, 0.43, { bulge: 0.1, at: 0.25 }), trousers, hip, 0, 0, 0)
    const knee = joint(hip, 0, -0.43, 0)
    add(limbGeo(0.062, 0.05, 0.42, { bulge: 0.14, at: 0.28 }), trousers, knee, 0, 0, 0)
    add(limbGeo(0.058, 0.062, 0.26, { bulge: 0 }), boot, knee, 0, -0.2, 0) // boot shaft
    const ankle = joint(knee, 0, -0.44, 0)
    add(footGeo({ len: 0.33, w: 0.062, h: 0.085 }), boot, ankle, 0, -0.015, 0)
    return { hip, knee, ankle }
  })
  root.traverse(o => { if (o.isMesh) o.frustumCulled = true })

  let phase = 0, headTwitch = 0, twitchT = 2, twitchTarget = 0, lean = 0, jitter = 0
  const api = {
    root, head, face,
    eyes (on, color = 0xff2a1a) {
      face.irisMat.emissive.setHex(on ? color : 0x1c1010); face.irisMat.emissiveIntensity = on ? 2.4 : 1
    },
    /** st: { x, z, yaw, speed, mode, attackT, look } */
    update (dt, st) {
      root.position.set(st.x, 0, st.z)
      root.rotation.y = st.yaw + Math.PI
      const speed = st.speed ?? 0
      const chase = st.mode === 'chase' || st.mode === 'attack'
      phase += dt * (speed > 0.1 ? (chase ? 8.2 : 4.4) * Math.min(1.4, speed / (chase ? 3.8 : 1.3)) : 0)
      const s = Math.sin(phase), c = Math.cos(phase)
      const amp = speed > 0.1 ? Math.min(1, speed / (chase ? 3.8 : 1.2)) * (chase ? 0.95 : 0.55) : 0
      jitter += dt
      lean += (((chase ? 0.42 : st.mode === 'search' ? 0.3 : 0.2)) - lean) * Math.min(1, dt * 3)
      legs.forEach((l, i) => {
        const ph = i ? -s : s, pc = i ? -c : c
        l.hip.rotation.x = -ph * amp * 0.8
        l.knee.rotation.x = Math.max(0, -pc) * amp * 1.3 + 0.05
        l.ankle.rotation.x = (ph > 0 ? -ph * 0.35 : -ph * 0.15) * amp
      })
      hips.position.y = 0.93 + (speed > 0.1 ? Math.abs(c) * 0.03 * amp : Math.sin(jitter * 0.9) * 0.004)
      hips.rotation.y = s * amp * 0.14
      spine.rotation.y = -s * amp * 0.2
      spine.rotation.x = lean + (st.attackT ?? 0) * 0.5
      spine.rotation.z = Math.sin(jitter * 0.5) * 0.02 + (chase ? 0 : 0.045) // a permanent list to one side
      // head: hangs low, then snaps toward something, tilts like a dog hearing
      twitchT -= dt
      if (twitchT <= 0) { twitchT = 0.8 + Math.random() * 3; twitchTarget = (Math.random() - 0.5) * (st.mode === 'search' || st.mode === 'investigate' ? 1.4 : 0.7) }
      headTwitch += (twitchTarget - headTwitch) * Math.min(1, dt * (Math.random() < 0.03 ? 40 : 3))
      head.rotation.y = headTwitch + (st.look ?? 0)
      head.rotation.x = 0.28 + (chase ? -0.15 : 0)
      head.rotation.z = Math.sin(jitter * 0.7) * 0.05 + 0.12
      face.update(dt)
      // arms: left hangs and sways; right drags the pipe (or raises it to strike)
      const atk = st.attackT ?? 0
      arms[0].shoulder.rotation.x = -s * amp * 0.5 - atk * 1.2
      arms[0].elbow.rotation.x = -0.15 - atk * 0.4
      arms[0].shoulder.rotation.z = 0.08
      let raise = chase ? 1.0 : 0
      raise = Math.max(raise, atk)
      arms[1].shoulder.rotation.x = s * amp * 0.25 + 0.08 - raise * 2.2
      arms[1].elbow.rotation.x = -0.1 - raise * 0.5
      arms[1].shoulder.rotation.z = -0.1 - raise * 0.1
      // the pipe trails behind along the floor when walking
      pipe.rotation.x = raise > 0.3 ? -0.3 - raise * 0.3 : 0.95 + Math.sin(phase * 2) * 0.03 * amp
      pipe.rotation.z = 0.05
    },
  }
  return api
}

// ═════════════════════ realistic rigged body ═════════════════════
// Same api as orderlyModel(); shows the simple body until the rigged one (../../gamekit/looks.js) has loaded.
let rigAssets = null
export function loadRigAssets () {
  if (!rigAssets) rigAssets = Promise.all([import('../../gamekit/creature.js'), import('../../gamekit/looks.js')])
    .then(([cr, lk]) => { cr.Creature.low = matchMedia('(pointer: coarse)').matches; cr.Creature.albedo = 0.42; return cr.loadCreatures('../gamekit/models/').then(a => ({ a, makeLook: lk.makeLook })) })
  return rigAssets
}
export function orderlyRig () {
  const simple = orderlyModel()
  const root = new THREE.Group(); root.add(simple.root)
  const w = { root, head: simple.head, face: simple.face, eyes: (on, col) => simple.eyes(on, col), update: (dt, st) => simple.update(dt, st), real: null }
  // the simple model positions its own root; the wrapper root stays at the origin
  loadRigAssets().then(({ a, makeLook }) => {
    const c = makeLook(a, 'orderly', { faceNegZ: true })
    root.remove(simple.root); root.add(c.root)
    w.real = c; w.head = c.bones.Head
    let eyeOn = false
    w.eyes = (on, color = 0xff2a1a) => { eyeOn = on; if (c.eyeGlow) for (const e of c.eyeGlow.children) e.material.color.setHex(on ? color : 0x1c1010) }
    w.update = (dt, st) => {
      c.root.position.set(st.x, 0, st.z); c.root.rotation.y = st.yaw + Math.PI
      const sp = st.speed ?? 0, L = c.look.clips
      const role = st.mode === 'attack' ? 'attack' : (st.mode === 'chase' && sp > 0.4) ? 'run' : sp > 0.1 ? 'walk' : (st.mode === 'search' || st.mode === 'investigate') ? 'search' : 'idle'
      const ts = role === 'walk' ? Math.min(1.5, Math.max(0.6, sp / 1.2)) : role === 'run' ? Math.min(1.4, Math.max(0.8, sp / 3.6)) : 1
      c.play(L[role] || L.idle, { speed: ts, fade: 0.25, once: role === 'attack' })
      c.update(dt, { frenzy: role === 'run' || role === 'attack' })
      // the brain's head-turn (looking around a room) on top of the animation
      if (st.look && c.bones.Head) { const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, st.look * 0.8, 0)); c.bones.Head.quaternion.multiply(q) }
      void eyeOn
    }
  }).catch(e => console.warn('rigged orderly unavailable, keeping the simple model', e))
  return w
}

// ═════════════════════ brain ═════════════════════
const wrap = a => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a }

export class Orderly {
  constructor (W) {
    this.W = W
    this.x = -22; this.z = -31; this.yaw = 0
    this.mode = 'patrol' // patrol | idle | investigate | chase | search | attack | wait
    this.speed = 0
    this.path = null; this.pi = 0
    this.aw = new Map()
    this.t = 0
    this.idleT = 0
    this.target = null
    this.lastSeen = null
    this.loseT = 0
    this.chaseT = 0
    this.searchT = 0
    this.searchPts = []
    this.doorPause = 0
    this.attackT = 0
    this.grabbed = null
    this.stuckT = 0; this.lastPos = [this.x, this.z]; this.lastCheck = 0
    this.repathT = 0
    this.directorT = 20
    this.suspect = null
    this.checking = null
    this.look = 0
    this.stepAcc = 0
    this.fearNear = 0
    this.blind = 0 // seconds he can't see (thrown bottle distraction etc.)
    this.stunT = 0
    this.alerted = false
    this.invisibleTo = new Set()
    this.pickPatrol()
  }

  // ── public helpers ──
  hear (x, z, loud = 8, opts = {}) {
    const d = Math.hypot(x - this.x, z - this.z)
    const eff = loud * (this.W.colliders.clear(this.x, this.z, x, z) ? 1 : 0.65)
    if (d > eff) return false
    if (this.mode === 'chase' || this.mode === 'attack') return true
    this.noiseSpot = [x, z]
    this.noiseLoud = Math.max(this.noiseLoud ?? 0, loud)
    if (this.mode !== 'investigate' || opts.strong) { this.goInvestigate(x, z) }
    return true
  }
  snap () { return { x: +this.x.toFixed(2), z: +this.z.toFixed(2), yaw: +this.yaw.toFixed(2), mode: this.mode, speed: +this.speed.toFixed(2), atk: +this.attackT.toFixed(2), look: +this.look.toFixed(2) } }
  restore (s) { this.x = s.x; this.z = s.z; this.yaw = s.yaw; this.mode = s.mode === 'attack' ? 'search' : s.mode; this.path = null }

  // ── decisions ──
  pickPatrol (players = []) {
    const W = this.W
    const pois = W.pois
    const choices = []
    for (const p of pois) {
      const d = Math.hypot(p[0] - this.x, p[1] - this.z)
      if (d < 6) continue
      let wgt = 1
      // leans toward where the players are, without ever knowing
      for (const q of players) if (!q.down) wgt += 2.2 / (1 + Math.hypot(p[0] - q.x, p[1] - q.z) / 10)
      choices.push([p, wgt])
    }
    if (!choices.length) return
    for (let tries = 0; tries < 6; tries++) {
      let sum = 0; for (const c of choices) sum += c[1]
      let r = Math.random() * sum, pick = choices[0][0]
      for (const c of choices) { r -= c[1]; if (r <= 0) { pick = c[0]; break } }
      const path = W.nav.path(this.x, this.z, pick[0], pick[1])
      if (path) { this.path = path; this.pi = 0; this.mode = 'patrol'; return }
    }
    this.mode = 'idle'; this.idleT = 3
  }
  goInvestigate (x, z) {
    const path = this.W.nav.path(this.x, this.z, x, z)
    if (!path) return
    this.path = path; this.pi = 0; this.mode = 'investigate'
    this.idleT = 0
  }
  startSearch (x, z) {
    this.mode = 'search'
    this.searchT = 9 + Math.random() * 7
    this.searchPts = []
    this.path = null
    this.lastSeen = { x, z }
    // a handful of places around the last known spot, and any hiding place close by
    const W = this.W
    for (let i = 0; i < 4; i++) {
      const a = Math.random() * 6.28, r = 3 + Math.random() * 6
      const px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r
      if (W.nav.snap(px, pz)) this.searchPts.push({ x: px, z: pz })
    }
    for (const h of W.hides) {
      const d = Math.hypot(h.x - x, h.z - z)
      if (d < 7 && (this.suspect === h.id || Math.random() < 0.4)) this.searchPts.unshift({ ...this.approach(h), hide: h })
    }
    if (this.suspect) {
      const h = W.hides.find(q => q.id === this.suspect)
      if (h) this.searchPts.unshift({ ...this.approach(h), hide: h, urgent: true })
      this.suspect = null
    }
    this.nextSearch()
  }
  /** where he stands to look into a hiding place (the place itself is solid) */
  approach (h) {
    const W = this.W
    const tries = h.kind === 'locker'
      ? [[Math.sin(h.yaw) * 0.9, Math.cos(h.yaw) * 0.9]]
      : [[1.1, 0], [-1.1, 0], [0, 1.6], [0, -1.6]]
    for (const [dx, dz] of tries) {
      if (W.nav.snap(h.x + dx, h.z + dz)) return { x: h.x + dx, z: h.z + dz }
    }
    return { x: h.x + tries[0][0], z: h.z + tries[0][1] }
  }
  nextSearch () {
    for (;;) {
      const p = this.searchPts.shift()
      if (!p) { this.path = null; return false }
      const path = this.W.nav.path(this.x, this.z, p.x, p.z)
      if (!path) continue // somewhere he cannot get to (behind a locked door)
      this.current = p
      this.path = path
      this.pi = 0
      return true
    }
  }

  // ── per-frame ──
  /**
   * players: [{ id, x, z, yaw, crouch, sprint, moving, flash, nv, hidden, hideId, down, noise, breath }]
   * hooks: { step(x,z,run), door(d), grab(id), found(id, hide), alert(), lost(), check(hide), mode(m, prev) }
   */
  update (dt, players, hooks) {
    this.t += dt
    const W = this.W
    const prev = this.mode
    this.blind = Math.max(0, this.blind - dt)
    if (this.stunT > 0) { this.stunT -= dt; this.speed = 0; return }
    this.doorPause = Math.max(0, this.doorPause - dt)
    this.directorT -= dt

    // perception
    let seenBest = null
    let nearest = 99
    for (const p of players) {
      if (p.down) { this.aw.set(p.id, 0); continue }
      const dx = p.x - this.x, dz = p.z - this.z
      const d = Math.hypot(dx, dz)
      nearest = Math.min(nearest, d)
      let aw = this.aw.get(p.id) ?? 0
      let visible = false
      if (!p.hidden && this.blind <= 0 && this.mode !== 'attack') {
        const ang = Math.atan2(-dx, -dz)
        const diff = Math.abs(wrap(ang - this.yaw))
        const chasing = this.mode === 'chase'
        const fov = chasing ? 1.6 : 1.0
        let range = 6.5
        if (p.flash) range = 15
        if (p.nv) range = Math.max(range, 8)
        if (p.sprint) range *= 1.2
        if (p.crouch) range *= 0.65
        if (chasing) range *= 1.5
        if ((diff < fov || d < 1.8) && d < range && W.colliders.clear(this.x, this.z, p.x, p.z)) {
          visible = true
          aw += dt * (0.6 + (1 - d / range) * 3.2)
          p._seen = true
        }
      }
      // sound
      if (!p.hidden && !visible && p.noise > 0) {
        const eff = p.noise * (W.colliders.clear(this.x, this.z, p.x, p.z) ? 1 : 0.6)
        if (d < eff) { aw += dt * (0.7 + (1 - d / eff)); this.noiseSpot = [p.x, p.z] }
      }
      if (!visible) aw -= dt * 0.22
      aw = Math.max(0, Math.min(1.5, aw))
      this.aw.set(p.id, aw)
      if (visible && (!seenBest || aw > seenBest.aw)) seenBest = { p, aw, d }
      // a hiding player who is heard breathing next to him
      if (p.hidden && d < 3.2 && (this.mode === 'search' || this.mode === 'investigate' || this.mode === 'idle' || this.mode === 'patrol')) {
        const chance = p.breath ? 0.03 : 0.35
        if (Math.random() < chance * dt) { this.suspect = p.hideId; this.startSearch(p.x, p.z) }
      }
    }
    this.fearNear = nearest
    if (seenBest) this.lastSeen = { x: seenBest.p.x, z: seenBest.p.z, id: seenBest.p.id }

    // state changes from awareness
    if (this.mode !== 'chase' && this.mode !== 'attack') {
      if (seenBest && seenBest.aw >= 1) {
        this.mode = 'chase'; this.target = seenBest.p.id; this.chaseT = 0; this.loseT = 0; this.path = null; this.doorPause = 0.4
        hooks.alert?.(seenBest.p.id)
      } else {
        // heard or half-seen something: go and look
        let top = null
        for (const [id, aw] of this.aw) if (aw >= 0.38 && (!top || aw > top.aw)) top = { id, aw }
        if (top && (this.mode === 'patrol' || this.mode === 'idle' || this.mode === 'search')) {
          const pl = players.find(q => q.id === top.id)
          if (pl && !pl.hidden) { this.goInvestigate(pl.x, pl.z); hooks.notice?.() }
        }
      }
    }

    // behaviour
    if (this.mode === 'attack') this.doAttack(dt, players, hooks)
    else if (this.mode === 'chase') this.doChase(dt, players, hooks, seenBest)
    else if (this.mode === 'search') this.doSearch(dt, players, hooks)
    else if (this.mode === 'investigate') this.doWalk(dt, 1.85, hooks, () => { this.idleT = 2.5; this.mode = 'search'; this.startSearch(this.x, this.z) })
    else if (this.mode === 'idle') this.doIdle(dt, players)
    else this.doWalk(dt, 1.2, hooks, () => { this.mode = 'idle'; this.idleT = 2.5 + Math.random() * 3 })

    if (this.mode !== prev) hooks.mode?.(this.mode, prev)

    // director: now and then, drift toward where the players actually are
    if (this.directorT <= 0 && (this.mode === 'patrol' || this.mode === 'idle')) {
      this.directorT = 35 + Math.random() * 25
      this.pickPatrol(players)
    }
    // stuck check
    if (this.t - this.lastCheck > 1.2) {
      this.lastCheck = this.t
      const moved = Math.hypot(this.x - this.lastPos[0], this.z - this.lastPos[1])
      if (this.speed > 0.4 && moved < 0.15 && this.doorPause <= 0) {
        this.stuckT++
        this.path = null
        if (this.mode === 'patrol' || this.mode === 'investigate') this.pickPatrol(players)
        if (this.stuckT > 4) { this.stuckT = 0; this.nudge() }
      } else this.stuckT = 0
      this.lastPos = [this.x, this.z]
    }
  }

  nudge () {
    const s = this.W.nav.snap(this.x, this.z)
    if (s) { const [px, pz] = this.W.nav.centre(s[0], s[1]); this.x = px; this.z = pz }
  }

  doIdle (dt, players) {
    this.speed = 0
    this.idleT -= dt
    this.look = Math.sin(this.t * 0.8) * 0.7
    this.yaw += Math.sin(this.t * 0.6) * dt * 0.4
    if (this.idleT <= 0) this.pickPatrol(players)
  }

  /** follow this.path at a speed; call done() on arrival */
  doWalk (dt, speed, hooks, done) {
    if (!this.path || this.pi >= this.path.length) { this.speed = 0; done?.(); return }
    const [tx, tz] = this.path[this.pi]
    this.steer(tx, tz, speed, dt, hooks)
    if (Math.hypot(tx - this.x, tz - this.z) < 0.55) { this.pi++; if (this.pi >= this.path.length) { this.speed = 0; this.path = null; done?.() } }
  }

  steer (tx, tz, speed, dt, hooks) {
    const dx = tx - this.x, dz = tz - this.z
    const d = Math.hypot(dx, dz) || 1
    const want = Math.atan2(-dx, -dz)
    const diff = wrap(want - this.yaw)
    const turn = (this.mode === 'chase' ? 9 : this.mode === 'search' ? 4 : 3) * dt
    this.yaw += Math.max(-turn, Math.min(turn, diff))
    this.look *= 0.9
    // doors in the way
    this.openDoorsAhead(dx / d, dz / d, hooks)
    if (this.doorPause > 0) { this.speed = 0; return }
    const facing = Math.max(0.15, Math.cos(Math.min(1.4, Math.abs(diff))))
    const v = speed * facing
    const nx = this.x + (dx / d) * v * dt, nz = this.z + (dz / d) * v * dt
    const [rx, rz] = this.W.colliders.resolve(nx, nz, 0.36)
    this.speed = Math.hypot(rx - this.x, rz - this.z) / dt
    this.x = rx; this.z = rz
    // footsteps
    this.stepAcc += this.speed * dt
    const stride = this.mode === 'chase' ? 1.5 : 0.95
    if (this.stepAcc > stride) { this.stepAcc = 0; hooks.step?.(this.x, this.z, this.mode === 'chase') }
  }

  openDoorsAhead (fx, fz, hooks) {
    for (const d of this.W.doors) {
      if (d.open >= 0.5 || d.locked || d.chain || d.wedged) continue
      const dx = d.x - this.x, dz = d.z - this.z
      const dist = Math.hypot(dx, dz)
      if (dist < 1.55 && (dx * fx + dz * fz) / (dist || 1) > 0.25) {
        this.W.setDoor(d, true)
        hooks.door?.(d)
        this.doorPause = this.mode === 'chase' ? 0.18 : 0.55
        return
      }
    }
  }

  doChase (dt, players, hooks, seen) {
    const p = players.find(q => q.id === (seen?.p.id ?? this.target)) ?? players.find(q => !q.down)
    this.chaseT += dt
    if (!p || p.down) {
      // everyone he knew about is down: lose interest
      const other = players.find(q => !q.down && !q.hidden && (this.aw.get(q.id) ?? 0) > 0.5)
      if (other) this.target = other.id
      else { this.startSearch(this.x, this.z); this.mode = 'search'; hooks.lost?.(); return }
    }
    const tgt = p ?? players[0]
    if (seen) { this.loseT = 0; this.target = seen.p.id } else this.loseT += dt
    const dx = tgt.x - this.x, dz = tgt.z - this.z
    const d = Math.hypot(dx, dz)
    const speed = Math.min(4.15, 3.5 + this.chaseT * 0.05) * (this.blind > 0 ? 0.4 : 1)
    this.repathT -= dt
    if (seen && d < 9 && this.W.colliders.clear(this.x, this.z, tgt.x, tgt.z)) {
      this.path = [[tgt.x, tgt.z]]; this.pi = 0
    } else if (this.repathT <= 0) {
      this.repathT = 0.35
      const tx = seen ? tgt.x : (this.lastSeen?.x ?? tgt.x), tz = seen ? tgt.z : (this.lastSeen?.z ?? tgt.z)
      this.path = this.W.nav.path(this.x, this.z, tx, tz) ?? this.path
      this.pi = 0
    }
    if (this.path && this.pi < this.path.length) {
      const [tx, tz] = this.path[this.pi]
      this.steer(tx, tz, speed, dt, hooks)
      if (Math.hypot(tx - this.x, tz - this.z) < 0.5 && this.pi < this.path.length - 1) this.pi++
    }
    // grab
    if (d < 1.2 && seen && !tgt.hidden && !tgt.down) {
      this.mode = 'attack'; this.attackT = 0; this.grabbed = tgt.id; this.speed = 0
      hooks.grab?.(tgt.id)
      return
    }
    // lost them
    if (this.loseT > 4.2 && (this.aw.get(tgt.id) ?? 0) < 0.6) {
      this.startSearch(this.lastSeen?.x ?? this.x, this.lastSeen?.z ?? this.z)
      hooks.lost?.()
    }
    // they ducked into a hiding place right in front of him
    if (tgt.hidden && d < 6 && this.loseT < 1.5) this.suspect = tgt.hideId
  }

  doAttack (dt, players, hooks) {
    this.attackT += dt
    this.speed = 0
    const p = players.find(q => q.id === this.grabbed)
    if (p) { const ang = Math.atan2(-(p.x - this.x), -(p.z - this.z)); this.yaw += wrap(ang - this.yaw) * Math.min(1, dt * 14) }
    if (this.attackT > 0.9) {
      hooks.catch?.(this.grabbed)
      this.grabbed = null
      this.attackT = 0
      this.startSearch(this.x, this.z)
      this.searchT = 7
    }
  }

  doSearch (dt, players, hooks) {
    this.searchT -= dt
    if (this.pausedLook > 0) { this.pausedLook -= dt; this.speed = 0; this.look = Math.sin(this.t * 3) * 0.9; return }
    const cur = this.current
    if (!this.path) {
      if (!this.nextSearch()) { if (this.searchT <= 0) { this.mode = 'idle'; this.idleT = 2; hooks.lost?.() } else this.pausedLook = 1.2; return }
    }
    this.doWalk(dt, 1.55, hooks, () => {
      this.path = null
      const h = cur?.hide
      if (h) {
        // open the locker or look under the bed
        hooks.check?.(h)
        this.pausedLook = 1.6
        const hit = players.find(q => q.hidden && q.hideId === h.id && !q.down)
        if (hit) { this.mode = 'attack'; this.attackT = 0; this.grabbed = hit.id; hooks.found?.(hit.id, h); hooks.grab?.(hit.id) }
      } else this.pausedLook = 1.4
    })
    if (this.searchT <= 0 && !this.path && !this.searchPts.length) { this.mode = 'idle'; this.idleT = 2; hooks.lost?.() }
  }
}
