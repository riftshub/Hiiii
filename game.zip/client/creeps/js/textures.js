// Creeps: canvas-painted surfaces for an abandoned children's play centre.
import * as THREE from 'three'

let seed = 1234567
const rand = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646 }
const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return [c, c.getContext('2d')] }

function grime (g, w, h, amount = 1) {
  for (let i = 0; i < 260 * amount; i++) {
    g.fillStyle = `rgba(${30 + rand() * 30},${25 + rand() * 20},${20 + rand() * 20},${rand() * 0.07})`
    const r = 2 + rand() * 18
    g.beginPath(); g.arc(rand() * w, rand() * h, r, 0, Math.PI * 2); g.fill()
  }
  for (let i = 0; i < 60 * amount; i++) {
    g.strokeStyle = `rgba(20,15,10,${rand() * 0.08})`
    g.lineWidth = 1
    g.beginPath(); const x = rand() * w, y = rand() * h; g.moveTo(x, y); g.lineTo(x + (rand() - 0.5) * 40, y + (rand() - 0.5) * 40); g.stroke()
  }
}

const tex = (c, repeat = [1, 1], srgb = true) => {
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(repeat[0], repeat[1])
  t.anisotropy = 4
  if (srgb) t.colorSpace = THREE.SRGBColorSpace
  return t
}

/** interlocking foam mats */
function foam () {
  const [c, g] = canvas(256, 256)
  const cols = ['#c2443f', '#3d6fb0', '#d9b23c', '#4f9a5a']
  for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) {
    g.fillStyle = cols[(x + y * 2 + (x ^ y)) % 4]
    g.fillRect(x * 128, y * 128, 128, 128)
    // puzzle teeth
    g.fillStyle = cols[(x + y * 2 + 1) % 4]
    for (let k = 0; k < 4; k++) g.fillRect(x * 128 + 16 + k * 28, y * 128, 14, 8)
    g.fillStyle = 'rgba(0,0,0,.08)'
    for (let i = 0; i < 400; i++) g.fillRect(x * 128 + rand() * 128, y * 128 + rand() * 128, 1, 1)
  }
  g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 2
  g.strokeRect(1, 1, 254, 254); g.beginPath(); g.moveTo(128, 0); g.lineTo(128, 256); g.moveTo(0, 128); g.lineTo(256, 128); g.stroke()
  grime(g, 256, 256, 1.2)
  return c
}

/** play-mat carpet with roads */
function carpetRoads () {
  const [c, g] = canvas(512, 512)
  g.fillStyle = '#4c7a4a'; g.fillRect(0, 0, 512, 512)
  g.fillStyle = '#5a5e63'
  g.fillRect(0, 220, 512, 72); g.fillRect(220, 0, 72, 512)
  g.strokeStyle = '#e8e1c8'; g.setLineDash([18, 16]); g.lineWidth = 4
  g.beginPath(); g.moveTo(0, 256); g.lineTo(512, 256); g.moveTo(256, 0); g.lineTo(256, 512); g.stroke(); g.setLineDash([])
  const house = (x, y, col) => { g.fillStyle = col; g.fillRect(x, y, 60, 46); g.fillStyle = '#7a2e2e'; g.beginPath(); g.moveTo(x - 6, y); g.lineTo(x + 30, y - 28); g.lineTo(x + 66, y); g.fill(); g.fillStyle = '#2b2b2b'; g.fillRect(x + 22, y + 20, 16, 26) }
  house(60, 90, '#d9b23c'); house(360, 80, '#3d6fb0'); house(70, 380, '#c2443f'); house(370, 370, '#e8e1c8')
  g.fillStyle = '#3a6fa0'; g.beginPath(); g.ellipse(420, 180, 40, 22, 0, 0, 7); g.fill()
  for (let i = 0; i < 4000; i++) { g.fillStyle = `rgba(0,0,0,${rand() * 0.12})`; g.fillRect(rand() * 512, rand() * 512, 2, 2) }
  grime(g, 512, 512, 2)
  return c
}

/** checker lino */
function lino (a = '#d9d3c3', b = '#7a8a8e') {
  const [c, g] = canvas(256, 256)
  for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) { g.fillStyle = (x + y) % 2 ? a : b; g.fillRect(x * 64, y * 64, 64, 64) }
  grime(g, 256, 256, 1.5)
  return c
}

/** wallpaper: pastel stripes, a border of ducks/stars, crayon doodles, wainscot */
function wallpaper (base = '#e6c9d0', stripe = '#efd9de', doodles = true) {
  const [c, g] = canvas(512, 512)
  g.fillStyle = base; g.fillRect(0, 0, 512, 512)
  g.fillStyle = stripe
  for (let x = 0; x < 512; x += 64) g.fillRect(x, 0, 28, 512)
  // border band
  g.fillStyle = '#f3e7c9'; g.fillRect(0, 290, 512, 34)
  for (let x = 16; x < 512; x += 64) {
    g.fillStyle = '#d9b23c'
    star(g, x + 12, 307, 9)
    g.fillStyle = '#3d6fb0'; g.beginPath(); g.arc(x + 44, 307, 7, 0, 7); g.fill()
  }
  // wainscot (lower panel)
  g.fillStyle = '#7a8e96'; g.fillRect(0, 324, 512, 188)
  g.fillStyle = 'rgba(0,0,0,.12)'; for (let x = 0; x < 512; x += 128) g.fillRect(x, 324, 3, 188)
  g.fillStyle = 'rgba(255,255,255,.1)'; g.fillRect(0, 324, 512, 4)
  if (doodles) {
    const crayon = ['#c2443f', '#3d6fb0', '#4f9a5a', '#2b2b2b', '#d96a2b']
    for (let k = 0; k < 4; k++) {
      g.strokeStyle = crayon[k % crayon.length]; g.lineWidth = 3; g.lineCap = 'round'
      const x = 40 + rand() * 430, y = 360 + rand() * 110
      // stick figure
      g.beginPath(); g.arc(x, y, 9, 0, 7); g.moveTo(x, y + 9); g.lineTo(x, y + 34); g.moveTo(x - 12, y + 18); g.lineTo(x + 12, y + 18); g.moveTo(x, y + 34); g.lineTo(x - 9, y + 50); g.moveTo(x, y + 34); g.lineTo(x + 9, y + 50); g.stroke()
    }
    // one drawing scribbled out
    g.strokeStyle = '#2b2b2b'; g.lineWidth = 2
    const sx = 200 + rand() * 100
    for (let i = 0; i < 40; i++) { g.beginPath(); g.moveTo(sx + rand() * 50, 380 + rand() * 50); g.lineTo(sx + rand() * 50, 380 + rand() * 50); g.stroke() }
    // sun
    g.strokeStyle = '#d9b23c'; g.lineWidth = 3
    g.beginPath(); g.arc(440, 380, 14, 0, 7); g.stroke()
    for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; g.beginPath(); g.moveTo(440 + Math.cos(a) * 18, 380 + Math.sin(a) * 18); g.lineTo(440 + Math.cos(a) * 26, 380 + Math.sin(a) * 26); g.stroke() }
  }
  // water damage streaks from the ceiling
  for (let i = 0; i < 4; i++) {
    const x = rand() * 512
    const grad = g.createLinearGradient(0, 0, 0, 200 + rand() * 200)
    grad.addColorStop(0, 'rgba(110,80,40,.35)'); grad.addColorStop(1, 'rgba(110,80,40,0)')
    g.fillStyle = grad; g.fillRect(x, 0, 10 + rand() * 30, 400)
  }
  grime(g, 512, 512, 1.6)
  return c
}

function star (g, x, y, r) {
  g.beginPath()
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5; const rr = i % 2 ? r * 0.45 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr) }
  g.closePath(); g.fill()
}

/** vinyl padded wall panels */
function padding (col = '#3f8f8a') {
  const [c, g] = canvas(256, 256)
  g.fillStyle = '#1d1d22'; g.fillRect(0, 0, 256, 256)
  for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) {
    const grad = g.createRadialGradient(x * 128 + 64, y * 128 + 50, 10, x * 128 + 64, y * 128 + 64, 90)
    grad.addColorStop(0, shade(col, 1.25)); grad.addColorStop(1, shade(col, 0.75))
    g.fillStyle = grad
    roundRect(g, x * 128 + 4, y * 128 + 4, 120, 120, 18); g.fill()
  }
  grime(g, 256, 256, 1)
  // a tear with yellow foam showing
  g.fillStyle = '#d9c26a'; g.beginPath(); g.ellipse(170, 200, 12, 5, 0.6, 0, 7); g.fill()
  return c
}

function shade (hex, k) {
  const n = parseInt(hex.slice(1), 16)
  const r = Math.min(255, ((n >> 16) & 255) * k), gg = Math.min(255, ((n >> 8) & 255) * k), b = Math.min(255, (n & 255) * k)
  return `rgb(${r | 0},${gg | 0},${b | 0})`
}
function roundRect (g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath() }

function ceilingTiles () {
  const [c, g] = canvas(256, 256)
  g.fillStyle = '#c9c4b6'; g.fillRect(0, 0, 256, 256)
  for (let i = 0; i < 3000; i++) { g.fillStyle = `rgba(0,0,0,${rand() * 0.15})`; g.fillRect(rand() * 256, rand() * 256, 1, 1) }
  g.fillStyle = '#8a857a'
  for (let k = 0; k <= 256; k += 128) { g.fillRect(k - 2, 0, 4, 256); g.fillRect(0, k - 2, 256, 4) }
  // stain
  const grad = g.createRadialGradient(80, 170, 4, 80, 170, 46)
  grad.addColorStop(0, 'rgba(120,85,40,.45)'); grad.addColorStop(0.8, 'rgba(120,85,40,.15)'); grad.addColorStop(1, 'rgba(120,85,40,0)')
  g.fillStyle = grad; g.fillRect(0, 100, 160, 140)
  return c
}

function plywood () {
  const [c, g] = canvas(256, 256)
  g.fillStyle = '#c7a477'; g.fillRect(0, 0, 256, 256)
  for (let y = 0; y < 256; y += 2) { g.fillStyle = `rgba(110,70,30,${0.05 + Math.abs(Math.sin(y * 0.09 + Math.sin(y * 0.013) * 3)) * 0.12})`; g.fillRect(0, y, 256, 2) }
  grime(g, 256, 256, 0.6)
  return c
}

/** a child's drawing / poster */
function poster (kind) {
  const [c, g] = canvas(256, 320)
  g.fillStyle = '#f2ead6'; g.fillRect(0, 0, 256, 320)
  g.lineCap = 'round'
  if (kind === 0) { // "SMILE!" poster with a mascot face, faded
    g.fillStyle = '#d9b23c'; g.beginPath(); g.arc(128, 140, 80, 0, 7); g.fill()
    g.fillStyle = '#2b2b2b'; g.beginPath(); g.arc(98, 120, 10, 0, 7); g.arc(158, 120, 10, 0, 7); g.fill()
    g.strokeStyle = '#2b2b2b'; g.lineWidth = 7; g.beginPath(); g.arc(128, 150, 45, 0.2, Math.PI - 0.2); g.stroke()
    g.font = '900 44px system-ui, sans-serif'; g.textAlign = 'center'; g.fillStyle = '#c2443f'; g.fillText('SMILE!', 128, 290)
  } else if (kind === 1) { // "NO RUNNING"
    g.font = '900 40px system-ui, sans-serif'; g.textAlign = 'center'; g.fillStyle = '#3d6fb0'
    g.fillText('NO', 128, 90); g.fillText('RUNNING', 128, 140)
    g.strokeStyle = '#c2443f'; g.lineWidth = 10; g.beginPath(); g.arc(128, 225, 60, 0, 7); g.moveTo(85, 182); g.lineTo(171, 268); g.stroke()
  } else if (kind === 2) { // crayon family drawing with an extra tall figure
    g.strokeStyle = '#2b2b2b'; g.lineWidth = 4
    const fig = (x, h, col) => { g.strokeStyle = col; g.beginPath(); g.arc(x, 300 - h, 14, 0, 7); g.moveTo(x, 314 - h); g.lineTo(x, 270); g.moveTo(x - 18, 300 - h * 0.6); g.lineTo(x + 18, 300 - h * 0.6); g.moveTo(x, 270); g.lineTo(x - 12, 300); g.moveTo(x, 270); g.lineTo(x + 12, 300); g.stroke() }
    fig(50, 120, '#3d6fb0'); fig(100, 110, '#c2443f'); fig(150, 80, '#4f9a5a')
    fig(215, 250, '#111') // the tall one
    g.fillStyle = '#111'; g.font = '700 22px system-ui'; g.fillText('MY FRENDS', 20, 30)
  } else { // "PLAY HAPPY" with handprints
    const cols = ['#c2443f', '#3d6fb0', '#d9b23c', '#4f9a5a']
    for (let i = 0; i < 9; i++) { g.fillStyle = cols[i % 4]; g.globalAlpha = 0.7; g.beginPath(); g.ellipse(40 + (i % 3) * 85, 70 + Math.floor(i / 3) * 80, 26, 30, 0, 0, 7); g.fill() }
    g.globalAlpha = 1; g.font = '900 34px system-ui'; g.textAlign = 'center'; g.fillStyle = '#2b2b2b'; g.fillText('PLAY HAPPY', 128, 300)
  }
  grime(g, 256, 320, 1.4)
  return c
}

const cache = new Map()
const mat = (key, make) => { if (!cache.has(key)) cache.set(key, make()); return cache.get(key) }
const std = (opts) => new THREE.MeshStandardMaterial(opts)

export const M = {
  foam: () => mat('foam', () => std({ map: tex(foam(), [1, 1]), roughness: 0.85 })),
  carpet: () => mat('carpet', () => std({ map: tex(carpetRoads(), [1, 1]), roughness: 0.95 })),
  lino: () => mat('lino', () => std({ map: tex(lino(), [1, 1]), roughness: 0.45 })),
  linoDark: () => mat('linoDark', () => std({ map: tex(lino('#3a3440', '#1f1b24'), [1, 1]), roughness: 0.5 })),
  wallPink: () => mat('wallPink', () => std({ map: tex(wallpaper('#e2bfc8', '#ebd0d6'), [1, 1]), roughness: 0.9 })),
  wallBlue: () => mat('wallBlue', () => std({ map: tex(wallpaper('#bcd2df', '#cfe0ea'), [1, 1]), roughness: 0.9 })),
  wallMint: () => mat('wallMint', () => std({ map: tex(wallpaper('#c3dccb', '#d5e8da', false), [1, 1]), roughness: 0.9 })),
  wallYellow: () => mat('wallYellow', () => std({ map: tex(wallpaper('#eadcae', '#f2e7c2'), [1, 1]), roughness: 0.9 })),
  padTeal: () => mat('padTeal', () => std({ map: tex(padding('#3f8f8a'), [1, 1]), roughness: 0.55 })),
  padPink: () => mat('padPink', () => std({ map: tex(padding('#b0566f'), [1, 1]), roughness: 0.55 })),
  ceiling: () => mat('ceiling', () => std({ map: tex(ceilingTiles(), [1, 1]), roughness: 0.95 })),
  wood: () => mat('wood', () => std({ map: tex(plywood(), [1, 1]), roughness: 0.7 })),
  plastic: color => mat('plastic' + color, () => std({ color, roughness: 0.38, metalness: 0.0 })),
  matte: color => mat('matte' + color, () => std({ color, roughness: 0.9 })),
  metal: () => mat('metal', () => std({ color: 0x8a9094, roughness: 0.35, metalness: 0.8 })),
  dark: () => mat('dark', () => std({ color: 0x1d1c20, roughness: 0.7, metalness: 0.2 })),
  poster: k => mat('poster' + k, () => std({ map: tex(poster(k)), roughness: 0.9 })),
  screen: () => mat('screen', () => new THREE.MeshBasicMaterial({ color: 0x2a5a4a })),
  fabric: color => mat('fabric' + color, () => std({ color, roughness: 1 })),
  glass: () => mat('glass', () => std({ color: 0x9fb6c0, roughness: 0.05, transparent: true, opacity: 0.25 })),
  light: () => mat('light', () => new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff4dc, emissiveIntensity: 1.4 })),
}
