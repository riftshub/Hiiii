// Creeps sound: the recorded files in ../audio/ (hosted with the site).
import { createSound } from '../../gamekit/sound.js'
import names from '../audio/index.js'

export const S = createSound({ base: new URL('../audio/', import.meta.url).href, names })
S.prefetch()

const beds = {}
export async function startBeds () {
  await S.init()
  if (beds.room) return
  beds.room = S.bed('amb_playroom', { vol: 0.55 })
  beds.vent = S.bed('amb_vent', { vol: 0.2 })
  beds.drone = S.bed('amb_drone', { vol: 0 })
  beds.chase = S.bed('music_chase', { vol: 0, music: true })
  beds.box = S.bed('music_box', { vol: 0, music: true })
}

let chase = 0
export function updateBeds (dt, { fear = 0, chasing = false, elevator = false }) {
  if (!beds.room) return
  chase += ((chasing ? 1 : 0) - chase) * Math.min(1, dt * (chasing ? 3 : 0.5))
  beds.chase.setVol(chase * 0.8, 0.2)
  beds.drone.setVol(fear * 0.5, 0.5)
  beds.room.setVol(0.5 - chase * 0.3, 0.5)
  beds.box.setVol(elevator ? 0.35 : 0, 0.6)
}

export const play = (name, opts) => S.play(name, opts)
export const at = (x, z, y = 1.2) => ({ x, y, z })
