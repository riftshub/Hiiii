// Unified input: keyboard + mouse (pointer lock) on desktop, joystick + buttons on touch screens.
import { isTouchDevice } from './config.js'

export const input = {
  move: { x: 0, y: 0 }, // x: right, y: forward
  look: { x: 0, y: 0 }, // accumulated pixels, consumed each frame
  held: { sprint: false, breath: false, interact: false },
  pressed: new Set(), // one-frame actions: interact, crouch, flashlight, soda, glowstick, windup, pause
  touch: false,
  enabled: false,
  locked: false,
}

const keys = new Set()
const press = action => input.pressed.add(action)

export function consumePressed (action) {
  if (!input.pressed.has(action)) return false
  input.pressed.delete(action)
  return true
}

export function consumeLook () {
  const l = { x: input.look.x, y: input.look.y }
  input.look.x = 0
  input.look.y = 0
  return l
}

const updateKeyboardMove = () => {
  if (input.touch && joystickActive) return
  input.move.x = (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0)
  input.move.y = (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0) - (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0)
  input.held.sprint = keys.has('ShiftLeft') || keys.has('ShiftRight')
  input.held.breath = keys.has('Space')
}

let mouseRight = false
let joystickActive = false

export function initInput (canvas, { onPause } = {}) {
  input.touch = isTouchDevice()

  window.addEventListener('keydown', e => {
    if (!input.enabled) return
    if (e.target instanceof HTMLInputElement) return
    if (e.repeat) { if (e.code === 'Space') e.preventDefault(); return }
    keys.add(e.code)
    switch (e.code) {
      case 'KeyE': press('interact'); input.held.interact = true; break
      case 'KeyC': case 'ControlLeft': press('crouch'); break
      case 'KeyF': press('flashlight'); break
      case 'Digit1': case 'KeyR': press('soda'); break
      case 'Digit2': case 'KeyG': press('glowstick'); break
      case 'Digit3': case 'KeyT': press('windup'); break
      case 'Escape': case 'KeyP': press('pause'); onPause?.(); break
      case 'Tab': e.preventDefault(); break
    }
    if (['Space', 'ArrowUp', 'ArrowDown', 'ControlLeft'].includes(e.code)) e.preventDefault()
    updateKeyboardMove()
  })
  window.addEventListener('keyup', e => {
    keys.delete(e.code)
    if (e.code === 'KeyE') input.held.interact = false
    updateKeyboardMove()
  })
  window.addEventListener('blur', () => {
    keys.clear()
    mouseRight = false
    updateKeyboardMove()
  })

  // Mouse look with pointer lock
  canvas.addEventListener('mousedown', e => {
    if (!input.enabled || input.touch) return
    if (!document.pointerLockElement) { void canvas.requestPointerLock?.(); return }
    if (e.button === 0) press('interact')
    if (e.button === 2) { mouseRight = true; updateKeyboardMove() }
  })
  window.addEventListener('mouseup', e => { if (e.button === 2) { mouseRight = false; updateKeyboardMove() } })
  canvas.addEventListener('contextmenu', e => e.preventDefault())
  document.addEventListener('pointerlockchange', () => {
    input.locked = document.pointerLockElement === canvas
    if (!input.locked && input.enabled && !input.touch) onPause?.('unlock')
  })
  window.addEventListener('mousemove', e => {
    if (!input.locked) return
    input.look.x += e.movementX
    input.look.y += e.movementY
  })
}

// ───────── touch controls ─────────

export function initTouchControls (root) {
  const stick = root.querySelector('[data-touch="stick"]')
  const knob = root.querySelector('[data-touch="knob"]')
  const lookPad = root.querySelector('[data-touch="look"]')
  let stickId = null
  let stickOrigin = null
  const stickRadius = 56

  const setKnob = (dx, dy) => { knob.style.transform = `translate(${dx}px, ${dy}px)` }

  stick.addEventListener('touchstart', e => {
    e.preventDefault()
    const t = e.changedTouches[0]
    stickId = t.identifier
    const r = stick.getBoundingClientRect()
    stickOrigin = { x: r.left + r.width / 2, y: r.top + r.height / 2 }
    joystickActive = true
  }, { passive: false })
  stick.addEventListener('touchmove', e => {
    e.preventDefault()
    for (const t of e.changedTouches) {
      if (t.identifier !== stickId) continue
      let dx = t.clientX - stickOrigin.x
      let dy = t.clientY - stickOrigin.y
      const len = Math.hypot(dx, dy)
      if (len > stickRadius) { dx *= stickRadius / len; dy *= stickRadius / len }
      setKnob(dx, dy)
      input.move.x = dx / stickRadius
      input.move.y = -dy / stickRadius
      // push the stick all the way to run
      input.held.sprint = len > stickRadius * 0.98 && -dy > stickRadius * 0.7
    }
  }, { passive: false })
  const endStick = e => {
    for (const t of e.changedTouches) {
      if (t.identifier !== stickId) continue
      stickId = null
      joystickActive = false
      setKnob(0, 0)
      input.move.x = 0
      input.move.y = 0
      input.held.sprint = false
    }
  }
  stick.addEventListener('touchend', endStick)
  stick.addEventListener('touchcancel', endStick)

  const lookTouches = new Map()
  lookPad.addEventListener('touchstart', e => {
    e.preventDefault()
    for (const t of e.changedTouches) lookTouches.set(t.identifier, { x: t.clientX, y: t.clientY })
  }, { passive: false })
  lookPad.addEventListener('touchmove', e => {
    e.preventDefault()
    for (const t of e.changedTouches) {
      const last = lookTouches.get(t.identifier)
      if (!last) continue
      input.look.x += (t.clientX - last.x) * 2.2
      input.look.y += (t.clientY - last.y) * 2.2
      lookTouches.set(t.identifier, { x: t.clientX, y: t.clientY })
    }
  }, { passive: false })
  const endLook = e => { for (const t of e.changedTouches) lookTouches.delete(t.identifier) }
  lookPad.addEventListener('touchend', endLook)
  lookPad.addEventListener('touchcancel', endLook)

  // Buttons: data-action (tap) or data-hold (held while pressed)
  for (const btn of root.querySelectorAll('[data-action], [data-hold]')) {
    const action = btn.dataset.action
    const hold = btn.dataset.hold
    btn.addEventListener('touchstart', e => {
      e.preventDefault()
      e.stopPropagation()
      btn.classList.add('is-down')
      if (action) press(action)
      if (hold) input.held[hold] = true
    }, { passive: false })
    const up = e => {
      e.preventDefault()
      btn.classList.remove('is-down')
      if (hold) input.held[hold] = false
    }
    btn.addEventListener('touchend', up)
    btn.addEventListener('touchcancel', up)
  }
}
