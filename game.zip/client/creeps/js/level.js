// Creeps: builds a floor from the room templates. Same floor number + seed = same layout,
// so floors can be replayed (with or without creatures).
import * as THREE from 'three'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { TEMPLATES, LOBBY, ROOM, HALF, WALL_H, BALL_PALETTE } from './rooms.js'
import { M } from './textures.js'

export const DOOR_W = 1.7
export const DOOR_H = 2.35

export function mulberry32 (a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0
    let t = Math.imul(a ^ a >>> 15, 1 | a)
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t
    return ((t ^ t >>> 14) >>> 0) / 4294967296
  }
}

/** Difficulty and size for a floor number (1, 2, 3, ...) */
export function floorParams (n, entitiesOn = true) {
  const size = Math.min(6, 3 + Math.floor((n - 1) / 3)) // 3x3 .. 6x6 rooms
  const sizeZ = Math.min(6, 3 + Math.floor(n / 3))
  return {
    w: size, h: sizeZ,
    tokens: Math.min(8, 3 + Math.floor((n - 1) / 2)),
    peekers: entitiesOn ? Math.min(4, 1 + Math.floor(n / 3)) : 0,
    mannequins: entitiesOn ? Math.min(14, 2 + n) : 0,
    mimics: entitiesOn && n >= 3 ? Math.min(4, 1 + Math.floor((n - 3) / 3)) : 0,
    stalker: entitiesOn && n >= 2,
    stalkerSpeed: Math.min(4.1, 3.45 + n * 0.04),
    batteries: 0, sodas: 2 + (n % 2), glowsticks: 3, windups: n >= 2 ? 2 : 1,
  }
}

export const floorSeed = n => (Math.imul(n, 2654435761) ^ 0x5eed) >>> 0

/** Room graph: spanning tree + a few loops so there's always more than one way round */
function makeLayout (n, rng) {
  const { w, h } = floorParams(n)
  const cells = []
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) cells.push({ i, j, links: new Set(), template: null, rot: 0 })
  const at = (i, j) => (i >= 0 && j >= 0 && i < w && j < h ? cells[j * w + i] : null)
  const key = (a, b) => `${a.i},${a.j}`
  const visited = new Set()
  const stack = [cells[0]]
  visited.add(key(cells[0]))
  const nb = c => [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([di, dj]) => at(c.i + di, c.j + dj)).filter(Boolean)
  while (stack.length) {
    const c = stack[stack.length - 1]
    const opts = nb(c).filter(o => !visited.has(key(o)))
    if (!opts.length) { stack.pop(); continue }
    const o = opts[Math.floor(rng() * opts.length)]
    c.links.add(o); o.links.add(c)
    visited.add(key(o))
    stack.push(o)
  }
  for (const c of cells) for (const o of nb(c)) if (!c.links.has(o) && rng() < 0.22) { c.links.add(o); o.links.add(c) }
  // exit = farthest room from the start (BFS)
  const dist = new Map([[cells[0], 0]])
  const q = [cells[0]]
  while (q.length) { const c = q.shift(); for (const o of c.links) if (!dist.has(o)) { dist.set(o, dist.get(c) + 1); q.push(o) } }
  const edge = c => c.i === 0 || c.j === 0 || c.i === w - 1 || c.j === h - 1
  let exit = null
  const score = c => dist.get(c) + (c.i + c.j) * 2 // far by path and far across the floor
  for (const c of dist.keys()) if (c !== cells[0] && edge(c) && (!exit || score(c) > score(exit))) exit = c
  // elevator shafts go through an outside wall
  const outsideDirs = c => [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([di, dj]) => !at(c.i + di, c.j + dj))
  cells[0].elevatorDir = outsideDirs(cells[0]).find(d => d[1] === -1) ?? outsideDirs(cells[0])[0]
  exit.elevatorDir = outsideDirs(exit).find(d => d[0] !== 0) ?? outsideDirs(exit)[0]
  // templates: shuffle bag so all 16 get used before repeats
  let bag = []
  for (const c of cells) {
    if (c === cells[0] || c === exit) { c.template = LOBBY; continue }
    if (!bag.length) { bag = TEMPLATES.slice(); for (let k = bag.length - 1; k > 0; k--) { const r = Math.floor(rng() * (k + 1)); [bag[k], bag[r]] = [bag[r], bag[k]] } }
    c.template = bag.pop()
    c.rot = Math.floor(rng() * 4)
  }
  return { cells, start: cells[0], exit, w, h, at }
}

export function buildFloor (scene, n, { entities = true, quality = 'high' } = {}) {
  const high = quality === 'high'
  const rng = mulberry32(floorSeed(n))
  const params = floorParams(n, entities)
  const layout = makeLayout(n, rng)
  const root = new THREE.Group()
  root.name = `floor-${n}`
  scene.add(root)
  const statics = new Map()
  const colliders = [] // { minX,maxX,minZ,maxZ, wall? }
  const hideSpots = []
  const spots = [] // item / token candidate positions
  const lights = [] // { x, y, z, color, broken, room }
  const mannequinSpots = []
  const spinners = []
  const screens = []
  const doorways = [] // { x, z, axis: 'x'|'z', a: cell, b: cell }
  let ballMesh = null
  const ballPositions = []

  const tmp = new THREE.Matrix4()
  const addGeo = (geom, mat, matrix) => {
    const g = geom.clone()
    g.applyMatrix4(matrix)
    if (!statics.has(mat)) statics.set(mat, [])
    statics.get(mat).push(g)
  }

  // ── room builder API (local coords -> world) ──
  const makeR = cell => {
    const cx = cell.i * ROOM, cz = cell.j * ROOM
    const rot = cell.rot * Math.PI / 2
    const cos = Math.round(Math.cos(rot)), sin = Math.round(Math.sin(rot))
    const T = (x, z) => [cx + x * cos + z * sin, cz - x * sin + z * cos]
    const box3 = (w, h, d, mat, x, y, z, { ry = 0, rx = 0, rz = 0, solid = true, cover = false } = {}) => {
      const [wx, wz] = T(x, z)
      tmp.compose(new THREE.Vector3(wx, y + h / 2, wz), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry + rot, rz, 'YXZ')), new THREE.Vector3(1, 1, 1))
      addGeo(uvBox(w, h, d), mat, tmp)
      if (solid && y < 1.2) {
        const a = Math.abs(((ry + rot) % Math.PI + Math.PI) % Math.PI)
        const swap = Math.abs(a - Math.PI / 2) < 0.4
        const hw = (swap ? d : w) / 2 + (Math.abs(Math.sin(ry * 2)) > 0.3 ? 0.15 : 0), hd = (swap ? w : d) / 2
        colliders.push({ minX: wx - hw, maxX: wx + hw, minZ: wz - hd, maxZ: wz + hd, cover })
      }
    }
    const R = {
      rng,
      box: box3,
      cyl (rt, rb, h, mat, x, y, z, { solid = false } = {}) {
        const [wx, wz] = T(x, z)
        tmp.makeTranslation(wx, y + h / 2, wz)
        addGeo(new THREE.CylinderGeometry(rt, rb, h, 14), mat, tmp)
        if (solid) { const r = Math.max(rt, rb); colliders.push({ minX: wx - r, maxX: wx + r, minZ: wz - r, maxZ: wz + r }) }
      },
      ball (r, mat, x, y, z) {
        const [wx, wz] = T(x, z)
        tmp.makeTranslation(wx, y + r, wz)
        addGeo(new THREE.SphereGeometry(r, 12, 9), mat, tmp)
      },
      solid (x0, x1, z0, z1) {
        const [ax, az] = T(x0, z0), [bx, bz] = T(x1, z1)
        colliders.push({ minX: Math.min(ax, bx), maxX: Math.max(ax, bx), minZ: Math.min(az, bz), maxZ: Math.max(az, bz) })
      },
      balls (x0, x1, z0, z1, count) {
        for (let k = 0; k < count; k++) {
          const [wx, wz] = T(x0 + rng() * (x1 - x0), z0 + rng() * (z1 - z0))
          ballPositions.push([wx, 0.07 + rng() * 0.38, wz, Math.floor(rng() * BALL_PALETTE.length)])
        }
      },
      hide (type, x, z, yaw, label) {
        const [wx, wz] = T(x, z)
        const wyaw = yaw + rot
        buildHideProp(R, type, x, z, yaw)
        hideSpots.push({ id: `h${hideSpots.length}`, type, inside: { x: wx, z: wz }, yaw: wyaw, label, room: cell, exit: null })
      },
      spot (x, y, z) { const [wx, wz] = T(x, z); spots.push({ x: wx, y, z: wz, room: cell }) },
      light (x, z, { broken = false, color = 0xfff4dc } = {}) {
        const [wx, wz] = T(x, z)
        tmp.makeTranslation(wx, WALL_H - 0.03, wz)
        addGeo(new THREE.BoxGeometry(1.2, 0.05, 0.6), M.dark(), tmp)
        lights.push({ x: wx, y: WALL_H - 0.12, z: wz, color, broken: broken || rng() < 0.12, room: cell, level: 0, phase: rng() * 100 })
      },
      mannequin (x, z, yaw) { const [wx, wz] = T(x, z); mannequinSpots.push({ x: wx, z: wz, yaw: yaw + rot, room: cell }) },
      poster (k, x, y, z, ry) {
        const [wx, wz] = T(x, z)
        tmp.compose(new THREE.Vector3(wx, y, wz), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, ry + rot, (rng() - 0.5) * 0.08)), new THREE.Vector3(1, 1, 1))
        addGeo(new THREE.PlaneGeometry(0.8, 1.0), M.poster(k), tmp)
      },
      // ── composite props ──
      cabinet (x, z, ry) {
        box3(0.75, 1.8, 0.7, M.plastic([0x2b2b55, 0x552b2b, 0x2b553a][Math.floor(rng() * 3)]), x, 0, z, { ry })
        R.screen(x - Math.sin(ry) * 0.36, 1.3, z - Math.cos(ry) * 0.36, ry + Math.PI)
      },
      screen (x, y, z, ry, small = false) {
        const [wx, wz] = T(x, z)
        const m = new THREE.Mesh(new THREE.PlaneGeometry(small ? 0.45 : 0.5, small ? 0.35 : 0.38), new THREE.MeshBasicMaterial({ color: [0x3a7a68, 0x5a3a7a, 0x7a5a2a][Math.floor(rng() * 3)] }))
        m.position.set(wx, y, wz)
        m.rotation.y = ry + rot + Math.PI
        root.add(m)
        screens.push({ mesh: m, phase: rng() * 10 })
      },
      balloon (x, y, z, color) {
        R.ball(0.22, M.plastic(color), x, y, z)
        R.box(0.005, y - 0.45, 0.005, M.matte(0xdddddd), x, 0.45, z, { solid: false })
      },
      tube (x, z, yaw, label) {
        const [wx, wz] = T(x, z)
        tmp.compose(new THREE.Vector3(wx, 0.5, wz), new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0).set(0, yaw + rot, 0)), new THREE.Vector3(1, 1, 1))
        const g = new THREE.CylinderGeometry(0.55, 0.55, 2.2, 16, 1, true).rotateX(Math.PI / 2)
        addGeo(g, M.plastic(0xe8c23a), tmp)
        R.solid(x - 0.6, x + 0.6, z - 0.6, z + 0.6)
        hideSpots.push({ id: `h${hideSpots.length}`, type: 'tube', inside: { x: wx, z: wz }, yaw: yaw + rot, label, room: cell, exit: null })
      },
      net (x, z) {
        const netMat = M.matte(0x2b2b2b)
        for (const s of [-1, 1]) box3(3.2, 0.9, 0.02, netMat, x, 1.42, z + s * 1.6, { solid: false })
      },
      shelf (x, z, len) {
        box3(0.5, 2.1, len, M.metal(), x, 0, z)
        for (let lvl = 0; lvl < 4; lvl++) {
          for (let k = 0; k < 4; k++) {
            const col = BALL_PALETTE[Math.floor(rng() * BALL_PALETTE.length)]
            const kind = rng()
            if (kind < 0.5) R.box(0.32, 0.25, 0.32, M.plastic(col), x, 0.05 + lvl * 0.5, z - len / 2 + 0.4 + k * (len - 0.8) / 3, { solid: false, ry: rng() })
            else R.ball(0.14, M.fabric(col), x, 0.05 + lvl * 0.5, z - len / 2 + 0.4 + k * (len - 0.8) / 3)
          }
        }
      },
      puppet (x, y, z, color) {
        R.box(0.35, 0.5, 0.25, M.fabric(color), x, y, z, { solid: false, rx: 0.3 })
        R.ball(0.17, M.fabric(0xf0d8c0), x, y + 0.45, z + 0.12)
        R.ball(0.035, M.dark(), x - 0.06, y + 0.62, z + 0.27)
        R.ball(0.035, M.dark(), x + 0.06, y + 0.62, z + 0.27)
      },
      carousel (x, z) {
        const [wx, wz] = T(x, z)
        const g = new THREE.Group()
        g.position.set(wx, 0, wz)
        const base = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.4, 0.3, 32), M.plastic(0xd94141))
        base.position.y = 0.15
        const top = new THREE.Mesh(new THREE.ConeGeometry(2.6, 0.9, 32), M.plastic(0xe8c23a))
        top.position.y = 2.9
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 2.6, 12), M.metal())
        pole.position.y = 1.4
        g.add(base, top, pole)
        for (let k = 0; k < 6; k++) {
          const a = k * Math.PI / 3
          const horse = new THREE.Group()
          const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 0.5, 4, 8), M.plastic([0xf2ead6, 0x3d78c9, 0xe07ab0][k % 3]))
          body.rotation.z = Math.PI / 2
          const head = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.4, 0.2), body.material)
          head.position.set(0.42, 0.25, 0)
          head.rotation.z = -0.4
          const p = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 2.4, 6), M.metal())
          p.position.y = 0.4
          horse.add(body, head, p)
          horse.position.set(Math.cos(a) * 1.7, 1.0 + (k % 2) * 0.2, Math.sin(a) * 1.7)
          horse.rotation.y = -a
          g.add(horse)
        }
        g.traverse(o => { if (o.isMesh) { o.castShadow = high; o.receiveShadow = high } })
        root.add(g)
        spinners.push({ obj: g, speed: 0.12 })
        colliders.push({ minX: wx - 2.3, maxX: wx + 2.3, minZ: wz - 2.3, maxZ: wz + 2.3 })
      },
      rack (x, z) {
        box3(1.8, 0.05, 0.6, M.metal(), x, 1.2, z, { solid: false })
        box3(1.8, 1.25, 0.05, M.metal(), x, 0, z)
        for (let k = 0; k < 5; k++) R.ball(0.15, M.fabric(BALL_PALETTE[Math.floor(rng() * 6)]), x - 0.7 + k * 0.35, 1.25, z)
      },
      letterBlock (x, z, s, letter, color) {
        const [wx, wz] = T(x, z)
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), letterMaterial(letter, color))
        mesh.position.set(wx, s / 2, wz)
        mesh.rotation.y = rot + (rng() - 0.5) * 0.5
        mesh.castShadow = high; mesh.receiveShadow = high
        root.add(mesh)
        colliders.push({ minX: wx - s / 2 - 0.1, maxX: wx + s / 2 + 0.1, minZ: wz - s / 2 - 0.1, maxZ: wz + s / 2 + 0.1, cover: s >= 1 })
      },
    }
    return R
  }

  // ── shells: floor, ceiling, walls with doorways ──
  for (const cell of layout.cells) {
    const cx = cell.i * ROOM, cz = cell.j * ROOM
    const t = cell.template
    tmp.makeRotationX(-Math.PI / 2).setPosition(cx, 0, cz)
    addGeo(uvPlane(ROOM, ROOM, t.floor === 'carpet' ? 12 : 2), M[t.floor](), tmp)
    tmp.makeRotationX(Math.PI / 2).setPosition(cx, WALL_H, cz)
    addGeo(uvPlane(ROOM, ROOM, 2.4), M.ceiling(), tmp)
    const wallMat = M[t.wall]()
    const sides = [
      { dir: [1, 0], nb: layout.at(cell.i + 1, cell.j) }, { dir: [-1, 0], nb: layout.at(cell.i - 1, cell.j) },
      { dir: [0, 1], nb: layout.at(cell.i, cell.j + 1) }, { dir: [0, -1], nb: layout.at(cell.i, cell.j - 1) },
    ]
    cell.freeSides = []
    for (const side of sides) {
      const open = side.nb && cell.links.has(side.nb)
      if (!side.nb || !open) cell.freeSides.push(side.dir)
      const isShaft = cell.elevatorDir && cell.elevatorDir[0] === side.dir[0] && cell.elevatorDir[1] === side.dir[1]
      wall(cx, cz, side.dir, open ? 'door' : isShaft ? 'elevator' : 'solid', wallMat)
      if (open && (side.dir[0] > 0 || side.dir[1] > 0)) doorways.push({ x: cx + side.dir[0] * HALF, z: cz + side.dir[1] * HALF, axis: side.dir[0] ? 'x' : 'z', a: cell, b: side.nb })
    }
  }

  function wall (cx, cz, dir, kind, mat) {
    const t = 0.2
    const along = dir[0] !== 0 ? 'z' : 'x'
    const px = cx + dir[0] * (HALF - t / 2), pz = cz + dir[1] * (HALF - t / 2)
    const seg = (a0, a1, y0, y1) => {
      const len = a1 - a0, mid = (a0 + a1) / 2
      const w = along === 'x' ? len : t, d = along === 'x' ? t : len
      const x = along === 'x' ? cx + mid : px, z = along === 'x' ? pz : cz + mid
      tmp.makeTranslation(x, (y0 + y1) / 2, z)
      addGeo(uvBox(w, y1 - y0, d), mat, tmp)
      if (y0 < 1) colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, wall: true })
    }
    if (kind === 'solid' || kind === 'elevator') {
      if (kind === 'solid') seg(-HALF, HALF, 0, WALL_H)
      return
    }
    const dw = DOOR_W / 2
    seg(-HALF, -dw, 0, WALL_H)
    seg(dw, HALF, 0, WALL_H)
    seg(-dw, dw, DOOR_H, WALL_H)
    // door frame trim
    const trim = M.plastic(0xf2ead6)
    for (const s of [-1, 1]) {
      const x = along === 'x' ? cx + s * (dw + 0.04) : px + dir[0] * 0.02, z = along === 'x' ? pz + dir[1] * 0.02 : cz + s * (dw + 0.04)
      tmp.makeTranslation(x, DOOR_H / 2, z)
      addGeo(new THREE.BoxGeometry(along === 'x' ? 0.08 : 0.26, DOOR_H, along === 'x' ? 0.26 : 0.08), trim, tmp)
    }
  }

  // ── elevators (start and exit) ──
  const elevators = {}
  for (const [name, cell] of [['start', layout.start], ['exit', layout.exit]]) {
    const dir = cell.elevatorDir
    const cx = cell.i * ROOM, cz = cell.j * ROOM
    elevators[name] = buildElevator(cx, cz, dir, name === 'exit')
  }

  function buildElevator (cx, cz, dir, isExit) {
    const t = 0.2
    const along = dir[0] !== 0 ? 'z' : 'x'
    const px = cx + dir[0] * (HALF - t / 2), pz = cz + dir[1] * (HALF - t / 2)
    const wallMat = M.metal()
    const gap = 0.9
    // wall with an elevator opening (replaces the solid wall already built: we draw a front plate over it)
    const seg = (a0, a1, y0, y1, mat) => {
      const len = a1 - a0, mid = (a0 + a1) / 2
      const w = along === 'x' ? len : t + 0.02, d = along === 'x' ? t + 0.02 : len
      const x = along === 'x' ? cx + mid : px, z = along === 'x' ? pz : cz + mid
      tmp.makeTranslation(x, (y0 + y1) / 2, z)
      addGeo(uvBox(w, y1 - y0, d), mat, tmp)
      if (y0 < 1) colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, wall: true })
    }
    const roomWall = M[(cx === layout.start.i * ROOM && cz === layout.start.j * ROOM ? layout.start : layout.exit).template.wall]()
    seg(-HALF, -gap - 0.3, 0, WALL_H, roomWall)
    seg(gap + 0.3, HALF, 0, WALL_H, roomWall)
    seg(-gap - 0.3, gap + 0.3, 2.3, WALL_H, roomWall)
    // brushed-steel surround
    for (const s2 of [-1, 1]) seg(s2 > 0 ? gap : -gap - 0.3, s2 > 0 ? gap + 0.3 : -gap, 0, 2.3, M.metal())
    // the car behind the wall
    const depth = 2.4
    const ex = cx + dir[0] * (HALF + depth / 2), ez = cz + dir[1] * (HALF + depth / 2)
    const W = along === 'x' ? 2.2 : depth, D = along === 'x' ? depth : 2.2
    tmp.makeRotationX(-Math.PI / 2).setPosition(ex, 0.01, ez)
    addGeo(uvPlane(W, D, 1), M.linoDark(), tmp)
    tmp.makeRotationX(Math.PI / 2).setPosition(ex, 2.4, ez)
    addGeo(uvPlane(W, D, 1), M.metal(), tmp)
    const side = (sx, sz, w, d) => { tmp.makeTranslation(sx, 1.2, sz); addGeo(uvBox(w, 2.4, d), wallMat, tmp); colliders.push({ minX: sx - w / 2, maxX: sx + w / 2, minZ: sz - d / 2, maxZ: sz + d / 2, wall: true }) }
    if (along === 'x') {
      side(ex - 1.15, ez, 0.1, depth); side(ex + 1.15, ez, 0.1, depth); side(ex, ez + dir[1] * (depth / 2 + 0.05), 2.4, 0.1)
    } else {
      side(ex, ez - 1.15, depth, 0.1); side(ex, ez + 1.15, depth, 0.1); side(ex + dir[0] * (depth / 2 + 0.05), ez, 0.1, 2.4)
    }
    // sliding doors (dynamic)
    const doors = []
    for (const s of [-1, 1]) {
      const leaf = new THREE.Mesh(new THREE.BoxGeometry(along === 'x' ? gap : 0.06, 2.25, along === 'x' ? 0.06 : gap), M.metal())
      const bx = along === 'x' ? cx + s * gap / 2 : px, bz = along === 'x' ? pz : cz + s * gap / 2
      leaf.position.set(bx, 1.125, bz)
      leaf.userData = { s, bx, bz }
      root.add(leaf)
      doors.push(leaf)
    }
    // indicator light above the doors
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), new THREE.MeshBasicMaterial({ color: isExit ? 0xff3b30 : 0x6aff8a }))
    lamp.position.set(along === 'x' ? cx : px - dir[0] * 0.12, 2.5, along === 'x' ? pz - dir[1] * 0.12 : cz)
    root.add(lamp)
    // button panel inside the car
    const panel = { x: ex - dir[0] * 0.2 + (along === 'x' ? 0.95 : 0), y: 1.2, z: ez - dir[1] * 0.2 + (along === 'x' ? 0 : 0.95) }
    const collider = { minX: Math.min(...doors.map(d => d.position.x)) - (along === 'x' ? gap / 2 : 0.05), maxX: Math.max(...doors.map(d => d.position.x)) + (along === 'x' ? gap / 2 : 0.05), minZ: Math.min(...doors.map(d => d.position.z)) - (along === 'x' ? 0.05 : gap / 2), maxZ: Math.max(...doors.map(d => d.position.z)) + (along === 'x' ? 0.05 : gap / 2), elevator: isExit ? 'exit' : 'start' }
    colliders.push(collider)
    return {
      doors, lamp, collider, open: 0, target: isExit ? 0 : 1, along, dir, inside: { x: ex, z: ez }, panel, front: { x: cx + dir[0] * (HALF - 1.2), z: cz + dir[1] * (HALF - 1.2) },
      yawOut: Math.atan2(dir[0], dir[1]), // facing out of the elevator into the room
      contains (x, z) { return Math.abs(x - ex) < (along === 'x' ? 1.1 : depth / 2) && Math.abs(z - ez) < (along === 'x' ? depth / 2 : 1.1) },
    }
  }

  // ── furniture from the templates ──
  for (const cell of layout.cells) {
    const R = makeR(cell)
    cell.template.build(R, { exit: cell === layout.exit })
    cell.center = { x: cell.i * ROOM, z: cell.j * ROOM }
  }

  // ball-pit balls: one instanced mesh
  if (ballPositions.length) {
    ballMesh = new THREE.InstancedMesh(new THREE.SphereGeometry(0.075, 8, 6), new THREE.MeshStandardMaterial({ roughness: 0.35 }), ballPositions.length)
    const m = new THREE.Matrix4()
    const c = new THREE.Color()
    ballPositions.forEach(([x, y, z, ci], i) => { m.makeTranslation(x, y, z); ballMesh.setMatrixAt(i, m); ballMesh.setColorAt(i, c.setHex(BALL_PALETTE[ci])) })
    root.add(ballMesh)
  }

  // ── merge statics ──
  for (const [mat, geoms] of statics) {
    const list = geoms.map(g => (g.index ? g.toNonIndexed() : g))
    for (const g of list) {
      if (!g.attributes.uv) g.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2))
      if (!g.attributes.normal) g.computeVertexNormals()
      for (const name of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(name)) g.deleteAttribute(name)
    }
    const mesh = new THREE.Mesh(mergeGeometries(list), mat)
    mesh.receiveShadow = high
    mesh.castShadow = high && mat !== M.ceiling()
    root.add(mesh)
  }

  // ── hide-spot exits: first free point in front of each spot ──
  const free = (x, z, r = 0.32) => !colliders.some(c => x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r)
  for (const h of hideSpots) {
    for (const d of [0.9, 1.2, 1.5, 1.9, 2.4]) {
      for (const da of [0, 0.5, -0.5, 1.0, -1.0, 1.6, -1.6, Math.PI]) {
        const a = h.yaw + da
        const x = h.inside.x - Math.sin(a) * d, z = h.inside.z - Math.cos(a) * d
        if (free(x, z)) { h.exit = { x, z }; break }
      }
      if (h.exit) break
    }
    if (!h.exit) h.exit = { x: h.room.center.x, z: h.room.center.z }
  }

  // ── tokens, items, entities: chosen from the spots ──
  const pickFrom = (arr, k, exclude = new Set()) => {
    const pool = arr.filter(a => !exclude.has(a))
    const out = []
    while (out.length < k && pool.length) out.push(pool.splice(Math.floor(rng() * pool.length), 1)[0])
    return out
  }
  const usable = spots.filter(s => s.room !== layout.start)
  const used = new Set()
  const tokenSpots = pickFrom(usable, params.tokens, used)
  tokenSpots.forEach(s => used.add(s))
  const itemSpots = []
  const addItems = (kind, count) => pickFrom(usable, count, used).forEach(s => { used.add(s); itemSpots.push({ ...s, kind }) })
  addItems('battery', params.batteries)
  addItems('soda', params.sodas)
  addItems('glowstick', params.glowsticks)
  addItems('windup', params.windups)
  const mimicSpots = pickFrom(usable, params.mimics, used)
  mimicSpots.forEach(s => used.add(s))
  const mannequins = pickFrom(mannequinSpots.filter(s => s.room !== layout.start && s.room !== layout.exit), params.mannequins)

  // room-centre spawn points for respawns (never the exit)
  const spawnRooms = layout.cells.filter(c => c !== layout.exit)

  return {
    n, params, root, colliders, hideSpots, lights, spinners, screens, doorways, elevators, layout,
    tokens: tokenSpots.map((s, i) => ({ id: `t${i}`, x: s.x, y: s.y, z: s.z })),
    items: itemSpots.map((s, i) => ({ id: `i${i}`, kind: s.kind, x: s.x, y: s.y, z: s.z })),
    mimics: mimicSpots.map((s, i) => ({ id: `m${i}`, x: s.x, y: s.y, z: s.z })),
    mannequins: mannequins.map((s, i) => ({ id: `q${i}`, x: s.x, z: s.z, yaw: s.yaw })),
    spawnRooms,
    rng,
    cellAt (x, z) { return layout.at(Math.round(x / ROOM), Math.round(z / ROOM)) },
    free,
    dispose () {
      root.traverse(o => { if (o.isMesh) o.geometry.dispose() })
      scene.remove(root)
    },
  }
}

// ── hide-spot props (the visible furniture for spots that need one) ──
function buildHideProp (R, type, x, z, yaw) {
  const fx = -Math.sin(yaw), fz = -Math.cos(yaw) // the way the opening faces
  switch (type) {
    case 'cubby': case 'cupboard': case 'locker': case 'booth': {
      const color = type === 'cubby' ? 0xe8c23a : type === 'booth' ? 0xd94141 : type === 'locker' ? 0x5a7a8a : 0xc7a477
      const mat = type === 'cupboard' ? M.wood() : M.plastic(color)
      const h = type === 'cubby' ? 1.5 : 2.0
      R.box(0.9, h, 0.9, mat, x, 0, z, { ry: yaw })
      // door panel slightly proud of the front
      R.box(0.8, h - 0.1, 0.04, M.plastic(type === 'locker' ? 0x6a8a9a : 0xf2ead6), x + fx * 0.47, 0.05, z + fz * 0.47, { ry: yaw, solid: false })
      for (let k = 0; k < 3; k++) R.box(0.4, 0.03, 0.05, M.dark(), x + fx * 0.5, h - 0.45 + k * 0.08, z + fz * 0.5, { ry: yaw, solid: false })
      break
    }
    case 'chest': case 'bin': {
      R.box(1.2, 0.7, 0.75, M.plastic(type === 'chest' ? 0x3d78c9 : 0xe07ab0), x, 0, z, { ry: yaw })
      R.box(1.24, 0.1, 0.8, M.plastic(type === 'chest' ? 0xe8c23a : 0xf2ead6), x, 0.7, z, { ry: yaw, solid: false })
      if (type === 'bin') for (let k = 0; k < 5; k++) R.ball(0.16, M.fabric(BALL_PALETTE[k]), x - 0.4 + k * 0.2, 0.68, z)
      break
    }
    case 'stall': {
      R.box(0.06, 1.9, 1.25, M.plastic(0x7aa3b8), x - 0.62 * fz * 0 + fx * 0.6, 0.15, z + fz * 0.6, { ry: yaw + Math.PI / 2, solid: true })
      break
    }
    default: break // counter, table, frame, curtain, block, ballpit, tube: the furniture is already there
  }
}

// ── geometry helpers with world-scaled UVs ──
function uvBox (w, h, d, scale = 2.4) {
  const g = new THREE.BoxGeometry(w, h, d)
  const uv = g.attributes.uv
  // face order: +x, -x, +y, -y, +z, -z (4 verts each)
  const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]]
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) {
    const i = f * 4 + k
    uv.setXY(i, uv.getX(i) * dims[f][0] / scale, uv.getY(i) * dims[f][1] / (f < 2 || f > 3 ? WALL_H : scale))
  }
  return g
}

function uvPlane (w, d, scale) {
  const g = new THREE.PlaneGeometry(w, d)
  const uv = g.attributes.uv
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w / scale, uv.getY(i) * d / scale)
  return g
}

const letterCache = new Map()
function letterMaterial (letter, color) {
  const key = letter + color
  if (letterCache.has(key)) return letterCache.get(key)
  const c = document.createElement('canvas')
  c.width = c.height = 128
  const g = c.getContext('2d')
  g.fillStyle = '#' + color.toString(16).padStart(6, '0'); g.fillRect(0, 0, 128, 128)
  g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 8; g.strokeRect(6, 6, 116, 116)
  g.fillStyle = '#f2ead6'; g.font = '900 86px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'
  g.fillText(letter, 64, 70)
  for (let i = 0; i < 300; i++) { g.fillStyle = `rgba(0,0,0,${Math.random() * 0.1})`; g.fillRect(Math.random() * 128, Math.random() * 128, 2, 2) }
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  const m = new THREE.MeshStandardMaterial({ map: t, roughness: 0.7 })
  letterCache.set(key, m)
  return m
}
