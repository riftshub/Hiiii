// "Switch game" bar at the bottom of the main menu: links to the site's other games.
import { subscribe } from 'valtio'
import { activeModalStack, miscUiState } from './globalState'

const GAMES = [
  { name: 'Vertigo Freight', blurb: 'Horror on a night train', href: './vertigo/', lamp: '#e8a33d' },
  { name: 'Creeps', blurb: 'Endless haunted play centre', href: './creeps/', lamp: '#e0738f' },
  { name: 'Night Owl Market', blurb: 'Run a shop where not every customer is human', href: './market/', lamp: '#ff5fa2' },
  { name: 'Little Lantern', blurb: 'Free the souls the Spindle Witch stole', href: './lantern/', lamp: '#ffb547' },
  { name: 'St. Ambrose', blurb: 'A realistic night in a closed hospital', href: './hollow/', lamp: '#d9d6c6' },
]

const createBar = (): HTMLElement => {
  const style = document.createElement('style')
  style.textContent = `
    #game-switcher {
      position: fixed; left: 50%; bottom: max(12px, env(safe-area-inset-bottom)); transform: translateX(-50%);
      z-index: 30; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: center;
      max-width: calc(100vw - 24px); font: 600 14px/1.1 system-ui, sans-serif; color: #e9e2d0;
    }
    #game-switcher > span { color: #a9b1b9; font-weight: 500; text-shadow: 0 1px 4px #000; }
    #game-switcher a {
      display: inline-flex; align-items: center; gap: 9px; padding: 8px 14px 8px 11px; border-radius: 4px;
      background: rgba(10, 14, 20, 0.82); border: 1px solid rgba(233, 226, 208, 0.25);
      color: inherit; text-decoration: none; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.45);
    }
    #game-switcher a:hover { border-color: var(--lamp); background: rgba(24, 20, 16, 0.92); }
    #game-switcher a:focus-visible { outline: 2px solid var(--lamp); outline-offset: 3px; }
    #game-switcher .lamp { width: 9px; height: 9px; border-radius: 50%; background: var(--lamp); box-shadow: 0 0 10px var(--lamp); flex: none; }
    #game-switcher small { display: block; font-weight: 400; font-size: 11px; color: #a9b1b9; margin-top: 2px; }
    @media (max-width: 900px) { #game-switcher small { display: none; } }
    @media (max-width: 520px) { #game-switcher { font-size: 13px; gap: 6px; } #game-switcher > span { display: none; } #game-switcher a { padding: 7px 10px 7px 9px; gap: 7px; } }
  `
  document.head.appendChild(style)
  const bar = document.createElement('nav')
  bar.id = 'game-switcher'
  bar.setAttribute('aria-label', 'Switch game')
  const label = document.createElement('span')
  label.textContent = 'Switch game:'
  bar.appendChild(label)
  for (const g of GAMES) {
    const a = document.createElement('a')
    a.href = g.href
    a.style.setProperty('--lamp', g.lamp)
    a.innerHTML = `<span class="lamp" aria-hidden="true"></span><span>${g.name}<small>${g.blurb}</small></span>`
    bar.appendChild(a)
  }
  // fullscreen toggle (not available on iPhone, so it hides itself there)
  const root = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => Promise<void> }
  const doc = document as Document & { webkitFullscreenElement?: Element | null, webkitExitFullscreen?: () => Promise<void> }
  const canFs = !!(root.requestFullscreen || root.webkitRequestFullscreen)
  const isFs = () => !!(doc.fullscreenElement || doc.webkitFullscreenElement)
  const fs = document.createElement('a')
  fs.href = '#'
  fs.style.setProperty('--lamp', '#8fc79c')
  const syncFs = () => { fs.innerHTML = `<span class="lamp" aria-hidden="true"></span><span>${isFs() ? 'Exit fullscreen' : 'Fullscreen'}</span>` }
  fs.addEventListener('click', e => {
    e.preventDefault()
    const done = isFs() ? (doc.exitFullscreen ?? doc.webkitExitFullscreen)?.call(doc) : (root.requestFullscreen ?? root.webkitRequestFullscreen)?.call(root)
    void Promise.resolve(done).catch(() => {})
  })
  document.addEventListener('fullscreenchange', syncFs)
  document.addEventListener('webkitfullscreenchange', syncFs)
  syncFs()
  if (canFs) bar.appendChild(fs)
  document.body.appendChild(bar)
  return bar
}

const bar = createBar()

const update = () => {
  const onMainMenu = activeModalStack.length === 0 && !miscUiState.gameLoaded
  bar.style.display = onMainMenu ? '' : 'none'
}

subscribe(activeModalStack, update)
subscribe(miscUiState, update)
update()
