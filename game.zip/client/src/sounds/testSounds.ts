import { createSoundMap } from './soundsMap'

//@ts-expect-error
globalThis.window = {}

// Dynamic import so the generated sounds file loads after the window shim above
// @ts-ignore generated at build time
await import('../../generated/sounds.js')

const soundMap = createSoundMap('1.20.1')
console.log(soundMap?.getSoundUrl('ambient.cave'))

export {}
