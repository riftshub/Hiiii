// St. Ambrose: screens, HUD text and small helpers shared by the game code.
import { isTouchDevice } from './config.js'

export const $ = s => document.querySelector(s)
export const touch = isTouchDevice()
export const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

const textCache = new WeakMap()
export const setText = (el, text, html = false) => {
  if (!el || textCache.get(el) === text) return
  textCache.set(el, text)
  if (html) el.innerHTML = text; else el.textContent = text
}
export const setStatus = (sel, text, bad = false) => { const el = $(sel); if (!el) return; el.textContent = text; el.classList.toggle('bad', bad) }

const screens = ['title', 'join', 'lobby', 'howto', 'settings', 'pause', 'note', 'caught', 'ending']
export const ui = { current: 'title', stack: [] }
export function showScreen (name, { push = false } = {}) {
  if (push && ui.current) ui.stack.push(ui.current)
  for (const s of screens) $(`#screen-${s}`)?.classList.toggle('is-open', s === name)
  ui.current = name
  const first = name && $(`#screen-${name}`)?.querySelector('input, button')
  if (first && !touch) setTimeout(() => first.focus({ preventScroll: true }), 30)
}
export const backScreen = () => showScreen(ui.stack.pop() ?? 'title')
export const clearStack = () => { ui.stack.length = 0 }
export const setHud = on => { $('#hud').classList.toggle('is-on', on); $('#touch').classList.toggle('is-on', on && touch) }
export const fade = (to, ms) => { const el = $('#fade'); el.style.transition = `opacity ${ms}ms`; el.style.opacity = String(to) }

let toastTimer
export const toast = (text, ms = 3200) => { const el = $('#toast'); el.textContent = text; el.style.opacity = '1'; clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.style.opacity = '0' }, ms) }
let subTimer
export const subtitle = (text, ms = 3600) => { const el = $('#sub'); el.textContent = text; el.style.opacity = '1'; clearTimeout(subTimer); subTimer = setTimeout(() => { el.style.opacity = '0' }, ms) }

/** the "press E to ..." line; progress 0..1 draws a bar under it */
let lastPrompt = ''
export function setPrompt (label, progress = -1) {
  const el = $('#prompt')
  const key = label + '|' + (progress >= 0 ? Math.round(progress * 50) : -1)
  if (key === lastPrompt) return
  lastPrompt = key
  el.classList.toggle('is-on', !!label)
  if (!label) { el.innerHTML = ''; return }
  el.innerHTML = `${touch ? '' : '<b>E</b>'}${esc(label)}${progress >= 0 ? `<span class="bar"><i style="width:${Math.round(progress * 100)}%"></i></span>` : ''}`
}
