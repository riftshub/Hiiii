// St. Ambrose sound: the recorded files in ../audio/ (hosted with the site).
import { createSound } from '../../gamekit/sound.js'
import names from '../audio/index.js'

export const S = createSound({ base: new URL('../audio/', import.meta.url).href, names })
S.prefetch()

const beds = {}
export async function startBeds () {
  await S.init()
  if (beds.hall) return
  beds.hall = S.bed('amb_hall', { vol: 0.6 })
  beds.hum = S.bed('amb_hum', { vol: 0.05 })
  beds.drone = S.bed('drone_fear', { vol: 0 })
  beds.chase = S.bed('music_chase', { vol: 0, music: true })
  beds.static = S.bed('static_loop', { vol: 0 })
  beds.out = S.bed('outside', { vol: 0 })
}
let chase = 0
export function updateBeds (dt, { fear = 0, chasing = false, stat = 0, outside = 0, humNear = 0 }) {
  if (!beds.hall) return
  chase += ((chasing ? 1 : 0) - chase) * Math.min(1, dt * (chasing ? 2.5 : 0.35))
  beds.chase.setVol(chase * 0.85, 0.15)
  beds.drone.setVol(Math.min(1, fear + chase * 0.3) * 0.55, 0.4)
  beds.hall.setVol((0.62 - chase * 0.3) * (1 - outside * 0.8), 0.4)
  beds.hum.setVol(0.05 + humNear * 0.04, 0.5)
  beds.static.setVol(stat * 0.5, 0.1)
  beds.out.setVol(outside * 0.6, 0.6)
}
export const play = (name, opts) => S.play(name, opts)
export const at = (x, z, y = 1.2) => ({ x, y, z })
