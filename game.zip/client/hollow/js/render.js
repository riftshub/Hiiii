// St. Ambrose: renderer, camcorder post-processing, flashlight rig, dust and light pool.
import * as THREE from 'three'
import { beamCookie } from './textures.js'

export function createRig (canvas, { HIGH, scene }) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, HIGH ? 1.5 : 1))
  renderer.shadowMap.enabled = HIGH
  renderer.shadowMap.type = THREE.PCFSoftShadowMap
  const RENDER_SCALE = HIGH ? 1 : 0.75

  scene.background = new THREE.Color(0x030405)
  scene.fog = new THREE.FogExp2(0x05070a, 0.045)
  const camera = new THREE.PerspectiveCamera(72, 1, 0.04, 140)
  camera.rotation.order = 'YXZ'
  scene.add(camera)

  // ── post: everything the camcorder does to the picture ──
  const rt = new THREE.WebGLRenderTarget(4, 4, { type: THREE.HalfFloatType, samples: HIGH ? 4 : 0 })
  const post = new THREE.ShaderMaterial({
    uniforms: {
      tDiffuse: { value: rt.texture }, time: { value: 0 }, fear: { value: 0 }, flash: { value: 0 }, nv: { value: 0 }, glitch: { value: 0 },
      grain: { value: HIGH ? 0.06 : 0.045 }, exposure: { value: 1.35 }, res: { value: new THREE.Vector2(1, 1) }, down: { value: 0 }, flick: { value: 1 },
    },
    defines: { BLOOM: HIGH ? 1 : 0 },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
    fragmentShader: /* glsl */`
      uniform sampler2D tDiffuse; uniform float time, fear, flash, grain, exposure, nv, glitch, down, flick; uniform vec2 res;
      varying vec2 vUv;
      float rand(vec2 c){ return fract(sin(dot(c, vec2(12.9898, 78.233))) * 43758.5453); }
      vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0); }
      void main(){
        vec2 uv = vUv;
        // tape tracking errors: bands of sideways tearing that grow with interference
        float band = floor(uv.y * 90.0);
        float tear = step(0.985 - glitch * 0.12, rand(vec2(band, floor(time * 9.0)))) * (rand(vec2(band, time)) - 0.5);
        uv.x += tear * (0.01 + glitch * 0.06);
        uv.y += (rand(vec2(floor(time * 30.0), 3.0)) - 0.5) * glitch * 0.004;
        // a slow handheld wobble in the lens
        uv += vec2(sin(time * 0.9), cos(time * 0.73)) * 0.0006;
        float ca = 0.0008 + fear * 0.0022 + glitch * 0.004;
        vec2 c = (uv - 0.5) * ca * (1.0 + length(uv - 0.5) * 3.0);
        vec3 col = vec3(texture2D(tDiffuse, uv + c).r, texture2D(tDiffuse, uv).g, texture2D(tDiffuse, uv - c).b);
        #if BLOOM
        vec3 bl = vec3(0.0);
        for (int i = 0; i < 10; i++) {
          float a = float(i) / 10.0 * 6.2831853;
          float r = 0.004 + 0.009 * float(i - (i / 2) * 2) + 0.004;
          vec3 s = texture2D(tDiffuse, uv + vec2(cos(a), sin(a) * res.x / res.y) * r).rgb;
          bl += max(s - 0.7, 0.0);
        }
        col += bl * 0.085;
        #endif
        col *= exposure * flick;
        // night vision: an infra-red sensor. everything is green and grainy, bright things bloom
        if (nv > 0.001) {
          float l = dot(col, vec3(0.3, 0.59, 0.11));
          l = pow(clamp(l * 2.6, 0.0, 2.0), 0.72);
          float sp = rand(uv * res * 0.5 + time) ;
          vec3 g = vec3(0.1, 1.0, 0.22) * l * (0.82 + sp * 0.3);
          g += vec3(0.0, 0.05, 0.01);
          col = mix(col, g, nv);
        }
        col = aces(col);
        float l2 = dot(col, vec3(0.2126, 0.7152, 0.0722));
        col = mix(vec3(l2), col, mix(0.82, 1.0, nv));
        col += vec3(-0.003, 0.004, 0.012) * (1.0 - smoothstep(0.0, 0.3, l2)) * (1.0 - nv);
        // vignette (tighter with fear)
        float v = smoothstep(0.85, 0.18 - fear * 0.1, length((vUv - 0.5) * vec2(1.0, 0.86)));
        col *= mix(0.22, 1.0, v);
        // scanlines of the CCD
        col *= 0.965 + 0.035 * sin(vUv.y * res.y * 1.2);
        col = mix(col, vec3(0.3, 0.015, 0.015) * (0.6 + v), flash * (0.85 - v * 0.4));
        col = mix(col, vec3(dot(col, vec3(0.3, 0.6, 0.1))) * vec3(0.8, 0.2, 0.2), down * 0.6);
        col = pow(col, vec3(1.0 / 2.2));
        col += (rand(vUv * res + fract(time) * 37.0) - 0.5) * grain * (1.0 + nv * 1.4 + glitch);
        // static snow during heavy interference
        col += step(0.9992 - glitch * 0.02, rand(vUv * res * 0.7 + time)) * glitch * 0.5;
        gl_FragColor = vec4(col, 1.0);
      }`,
    depthTest: false, depthWrite: false,
  })
  const postScene = new THREE.Scene()
  const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1)
  postScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), post))

  const resize = () => {
    const w = window.innerWidth, h = window.innerHeight
    renderer.setSize(w, h, false)
    const pr = renderer.getPixelRatio()
    rt.setSize(Math.max(2, Math.floor(w * pr * RENDER_SCALE)), Math.max(2, Math.floor(h * pr * RENDER_SCALE)))
    post.uniforms.res.value.set(w, h)
    camera.aspect = w / h
    camera.updateProjectionMatrix()
  }
  window.addEventListener('resize', resize)
  resize()

  // ── lights ──
  const hemi = new THREE.HemisphereLight(0x2b3a52, 0x0a0908, 0.22)
  scene.add(hemi)
  // the flashlight hangs a little behind the view so it sways when you turn: that lag is most of what makes it feel held
  const rig = new THREE.Object3D()
  scene.add(rig)
  const torch = new THREE.SpotLight(0xfff0d6, 0, 30, 0.4, 0.8, 1.35)
  torch.map = beamCookie()
  torch.castShadow = HIGH
  torch.shadow.mapSize.set(1024, 1024)
  torch.shadow.bias = -0.0006
  torch.shadow.normalBias = 0.02
  torch.shadow.camera.near = 0.1
  rig.add(torch, torch.target)
  torch.target.position.set(0, 0, -1)
  // a wide soft spill so the room around the beam isn't pitch black
  const spill = new THREE.SpotLight(0xffe8c8, 0, 14, 1.15, 1, 1.8)
  rig.add(spill, spill.target)
  spill.target.position.set(0, 0, -1)
  // the camcorder's infra-red illuminator
  const ir = new THREE.SpotLight(0xffffff, 0, 22, 0.8, 0.9, 1.2)
  camera.add(ir, ir.target)
  ir.target.position.set(0, 0, -1)
  const lampPool = Array.from({ length: HIGH ? 5 : 3 }, () => { const l = new THREE.PointLight(0xfff0d0, 0, 10, 1.6); scene.add(l); return l })

  // ── dust in the beam ──
  const N = HIGH ? 220 : 90
  const dustPos = new Float32Array(N * 3)
  const dustSeed = new Float32Array(N)
  for (let i = 0; i < N; i++) { dustPos[i * 3] = (Math.random() - 0.5) * 12; dustPos[i * 3 + 1] = Math.random() * 3; dustPos[i * 3 + 2] = (Math.random() - 0.5) * 12; dustSeed[i] = Math.random() * 100 }
  const dg = new THREE.BufferGeometry()
  dg.setAttribute('position', new THREE.BufferAttribute(dustPos, 3))
  dg.setAttribute('seed', new THREE.BufferAttribute(dustSeed, 1))
  const dustMat = new THREE.ShaderMaterial({
    uniforms: { uCam: { value: new THREE.Vector3() }, uDir: { value: new THREE.Vector3(0, 0, -1) }, uOn: { value: 0 }, uTime: { value: 0 }, uPx: { value: renderer.getPixelRatio() * (innerHeight / 720) } },
    vertexShader: `uniform vec3 uCam, uDir; uniform float uTime, uPx; attribute float seed; varying float vA;
      void main(){
        vec3 p = position;
        p.x += sin(uTime * 0.2 + seed) * 0.6; p.y += sin(uTime * 0.15 + seed * 1.3) * 0.5 + uTime * 0.02; p.z += cos(uTime * 0.17 + seed * 0.7) * 0.6;
        // wrap the cloud around the camera so it follows you
        vec3 w = mod(p - uCam + vec3(6.0, 1.5, 6.0), vec3(12.0, 3.0, 12.0)) - vec3(6.0, 1.5, 6.0);
        vec3 wp = uCam + w;
        vec3 d = wp - uCam; float dist = length(d);
        float cone = smoothstep(0.93, 0.985, dot(normalize(d), uDir));
        vA = cone * smoothstep(9.0, 1.5, dist) * smoothstep(0.3, 1.0, dist) * (0.5 + 0.5 * sin(uTime * 1.3 + seed * 9.0));
        vec4 mv = viewMatrix * vec4(wp, 1.0);
        gl_PointSize = uPx * (26.0 / max(0.6, -mv.z)) * (0.6 + fract(seed) * 0.6);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `uniform float uOn; varying float vA; void main(){ vec2 c = gl_PointCoord - 0.5; float a = smoothstep(0.5, 0.0, length(c)); gl_FragColor = vec4(vec3(1.0, 0.95, 0.85), a * vA * uOn * 0.55); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
  })
  const dust = new THREE.Points(dg, dustMat)
  dust.frustumCulled = false
  scene.add(dust)

  // ── a faint visible beam ──
  const beamMat = new THREE.ShaderMaterial({
    uniforms: { uOn: { value: 0 }, uTime: { value: 0 } },
    vertexShader: `varying vec3 vN; varying vec3 vP; varying float vT; void main(){ vT = position.z; vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vP = mv.xyz; gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform float uOn, uTime; varying vec3 vN; varying vec3 vP; varying float vT;
      void main(){ float t = clamp(-vT / 22.0, 0.0, 1.0); float rim = pow(abs(dot(normalize(vN), normalize(-vP))), 1.6);
        float a = uOn * rim * (1.0 - t) * (1.0 - t) * 0.07 * (0.85 + 0.15 * sin(uTime * 3.0 + vT)); gl_FragColor = vec4(1.0, 0.94, 0.82, a); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false,
  })
  const beam = new THREE.Mesh(new THREE.ConeGeometry(Math.tan(0.4) * 22, 22, 24, 1, true).translate(0, -11, 0).rotateX(Math.PI / 2), beamMat)
  beam.frustumCulled = false
  // the cone's apex is at the origin of the rig, pointing down -z
  rig.add(beam)

  return { renderer, camera, post, rt, postScene, postCam, hemi, rig, torch, spill, ir, lampPool, dust, dustMat, beam, beamMat, HIGH, resize }
}
