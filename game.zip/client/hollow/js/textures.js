// St. Ambrose: procedural surface materials. Every surface gets a colour map, a normal map (computed
// from a painted height field) and a roughness map, so the flashlight rakes across plaster grain,
// peeling paint, cracked linoleum and wet patches the way it would on the real thing.
import * as THREE from 'three'

// ───────── noise ─────────
const hash = (x, y, s) => {
  let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0
  h = (h ^ (h >>> 13)) * 1274126177 | 0
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295
}
const smooth = t => t * t * (3 - 2 * t)
function vnoise (u, v, p, s) {
  const x = u * p, y = v * p
  const x0 = Math.floor(x), y0 = Math.floor(y)
  const fx = smooth(x - x0), fy = smooth(y - y0)
  const a = hash(((x0 % p) + p) % p, ((y0 % p) + p) % p, s)
  const b = hash((((x0 + 1) % p) + p) % p, ((y0 % p) + p) % p, s)
  const c = hash(((x0 % p) + p) % p, (((y0 + 1) % p) + p) % p, s)
  const d = hash((((x0 + 1) % p) + p) % p, (((y0 + 1) % p) + p) % p, s)
  return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy
}
/** tileable fractal noise in 0..1 */
function fbm (u, v, base, oct, s) {
  let sum = 0, amp = 0.5, tot = 0, p = base
  for (let i = 0; i < oct; i++) { sum += vnoise(u, v, p, s + i * 17) * amp; tot += amp; amp *= 0.5; p *= 2 }
  return sum / tot
}
let seedState = 1
const rnd = () => { seedState = (seedState * 16807) % 2147483647; return seedState / 2147483647 }
const seedRnd = n => { seedState = (n * 2654435761 % 2147483647) || 1 }

const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x))
const mix = (a, b, t) => a + (b - a) * t
const rgb = hex => [(hex >> 16) & 255, (hex >> 8) & 255, hex & 255]

// ───────── canvas plumbing ─────────
function makeSurface (w, h) {
  const color = document.createElement('canvas'); color.width = w; color.height = h
  const gc = color.getContext('2d', { willReadFrequently: true })
  return {
    w, h, color, gc,
    height: new Float32Array(w * h).fill(0.5), // 0..1
    rough: new Float32Array(w * h).fill(0.85),
    metal: null,
  }
}
/** paint a per-pixel function into the colour canvas: fn(u, v, x, y) -> [r,g,b] (0..255) */
function paintPixels (S, fn) {
  const img = S.gc.getImageData(0, 0, S.w, S.h)
  const d = img.data
  for (let y = 0; y < S.h; y++) {
    for (let x = 0; x < S.w; x++) {
      const c = fn(x / S.w, y / S.h, x, y)
      const i = (y * S.w + x) * 4
      d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255
    }
  }
  S.gc.putImageData(img, 0, 0)
}
/** blend a shape drawn with canvas ops into the height/rough fields: draw(g) onto a scratch canvas, white = affected */
function stampField (S, draw, field, amount, mode = 'add') {
  const c = document.createElement('canvas'); c.width = S.w; c.height = S.h
  const g = c.getContext('2d', { willReadFrequently: true })
  g.fillStyle = '#000'; g.fillRect(0, 0, S.w, S.h)
  draw(g)
  const d = g.getImageData(0, 0, S.w, S.h).data
  const f = field === 'height' ? S.height : S.rough
  for (let i = 0; i < f.length; i++) {
    const m = d[i * 4] / 255
    if (m <= 0) continue
    f[i] = mode === 'set' ? mix(f[i], amount, m) : clamp(f[i] + amount * m)
  }
}
function toTextures (S, { normalStrength = 2, srgb = true } = {}) {
  const { w, h } = S
  // roughness map (green channel read by three)
  const rc = document.createElement('canvas'); rc.width = w; rc.height = h
  const rg = rc.getContext('2d')
  const ri = rg.createImageData(w, h)
  for (let i = 0; i < w * h; i++) { const v = clamp(S.rough[i]) * 255; ri.data[i * 4] = v; ri.data[i * 4 + 1] = v; ri.data[i * 4 + 2] = S.metal ? clamp(S.metal[i]) * 255 : 0; ri.data[i * 4 + 3] = 255 }
  rg.putImageData(ri, 0, 0)
  // normal map from the height field (wraps, so tiles stay seamless)
  const nc = document.createElement('canvas'); nc.width = w; nc.height = h
  const ng = nc.getContext('2d')
  const ni = ng.createImageData(w, h)
  const H = S.height
  const at = (x, y) => H[((y + h) % h) * w + ((x + w) % w)]
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dx = (at(x - 1, y) - at(x + 1, y)) * normalStrength * w * 0.012
      const dy = (at(x, y + 1) - at(x, y - 1)) * normalStrength * w * 0.012
      const l = Math.hypot(dx, dy, 1)
      const i = (y * w + x) * 4
      ni.data[i] = (dx / l * 0.5 + 0.5) * 255; ni.data[i + 1] = (dy / l * 0.5 + 0.5) * 255; ni.data[i + 2] = (1 / l * 0.5 + 0.5) * 255; ni.data[i + 3] = 255
    }
  }
  ng.putImageData(ni, 0, 0)
  const mk = (canvas, color) => {
    const t = new THREE.CanvasTexture(canvas)
    t.wrapS = t.wrapT = THREE.RepeatWrapping
    t.anisotropy = 8
    if (color) t.colorSpace = THREE.SRGBColorSpace
    return t
  }
  return { map: mk(S.color, srgb), normalMap: mk(nc, false), roughnessMap: mk(rc, false), metalnessMap: S.metal ? mk(rc, false) : null }
}

// ───────── drawing helpers ─────────
function crackPath (g, x, y, ang, len, w, depth = 0) {
  g.beginPath(); g.moveTo(x, y)
  let cx = x, cy = y, a = ang
  const steps = Math.floor(len / 5)
  for (let i = 0; i < steps; i++) {
    a += (rnd() - 0.5) * 0.7
    cx += Math.cos(a) * 5; cy += Math.sin(a) * 5
    g.lineTo(cx, cy)
    if (depth < 2 && rnd() < 0.07) { const sx = cx, sy = cy; g.stroke(); crackPath(g, sx, sy, a + (rnd() - 0.5) * 1.6, len * 0.4, w * 0.7, depth + 1); g.beginPath(); g.moveTo(sx, sy) }
  }
  g.lineWidth = w; g.stroke()
}
function blob (g, x, y, rx, ry, rot, fillStyle, points = 14, jag = 0.35) {
  g.save(); g.translate(x, y); g.rotate(rot)
  g.beginPath()
  for (let i = 0; i <= points; i++) {
    const a = (i / points) * Math.PI * 2
    const k = 1 - jag * 0.5 + rnd() * jag
    const px = Math.cos(a) * rx * k, py = Math.sin(a) * ry * k
    if (i === 0) g.moveTo(px, py); else g.lineTo(px, py)
  }
  g.closePath(); g.fillStyle = fillStyle; g.fill(); g.restore()
}

// ═════════════ surfaces ═════════════
// size: texture edge in pixels. Each recipe returns { S, opts } for toTextures.

function wallSurface (size, variant) {
  seedRnd(100 + variant)
  const S = makeSurface(size, size)
  const palettes = [
    { upper: 0xa9b8a2, lower: 0x4c6755, trim: 0xd7d3bf },  // institutional green
    { upper: 0xcfc6a8, lower: 0x6e6a52, trim: 0xe4dec6 },  // old cream over olive
    { upper: 0xa7b6bb, lower: 0x435761, trim: 0xd3d9d6 },  // cold blue-grey
    { upper: 0xc2b788, lower: 0x74603a, trim: 0xded6b4 },  // nicotine yellow
  ]
  const P = palettes[variant % palettes.length]
  const up = rgb(P.upper), lo = rgb(P.lower), tr = rgb(P.trim)
  const dado = 0.64 // fraction down from the top where the paint band starts
  const seed = variant * 31 + 5
  // large peel patches in the lower paint (where the plaster shows)
  const peels = []
  for (let i = 0; i < 7; i++) peels.push({ x: rnd(), y: dado + 0.04 + rnd() * 0.3, rx: 0.02 + rnd() * 0.07, ry: 0.02 + rnd() * 0.06 })
  // water runs from the ceiling
  const runs = []
  for (let i = 0; i < 4; i++) runs.push({ x: rnd(), w: 0.02 + rnd() * 0.05, len: 0.25 + rnd() * 0.6 })
  const peelAt = (u, v) => { let m = 0; for (const p of peels) { const d = Math.hypot((u - p.x) / p.rx, (v - p.y) / p.ry); const wob = fbm(u, v, 16, 2, seed + 3) * 0.5; m = Math.max(m, clamp(1.15 - d - wob + 0.3)) } return m }
  paintPixels(S, (u, v, x, y) => {
    const band = v > dado
    const g1 = fbm(u, v, 6, 4, seed)
    const g2 = fbm(u, v, 48, 2, seed + 9)
    let c = band ? lo : up
    let r = c[0], g = c[1], b = c[2]
    // plaster grain and soft grime
    const grime = 0.72 + g1 * 0.5
    r *= grime; g *= grime; b *= grime
    const fine = 0.94 + g2 * 0.12
    r *= fine; g *= fine; b *= fine
    // dado rail
    const dd = Math.abs(v - dado)
    if (dd < 0.008) { r = tr[0] * 0.9; g = tr[1] * 0.9; b = tr[2] * 0.9 }
    // soot / damp toward the ground, tide mark above the floor
    const damp = clamp((v - 0.86) * 5)
    const dm = fbm(u, v * 1.4, 10, 3, seed + 21)
    const tide = smooth(clamp((dm - 0.35) * 3)) * damp
    r = mix(r, r * 0.35, tide); g = mix(g, g * 0.38, tide); b = mix(b, b * 0.3, tide)
    // mould: black-green fuzz in the damp corners
    const mo = fbm(u, v, 22, 3, seed + 41)
    const mold = clamp((mo - 0.58) * 6) * clamp(damp * 1.4 + (v < 0.12 ? (0.12 - v) * 8 : 0))
    r = mix(r, 22, mold * 0.85); g = mix(g, 30, mold * 0.85); b = mix(b, 20, mold * 0.85)
    // water stain runs
    for (const q of runs) {
      const dx = Math.abs(u - q.x - (fbm(u, v, 12, 2, seed + 55) - 0.5) * 0.08)
      const along = v / q.len
      if (along < 1 && dx < q.w) {
        const e = (1 - dx / q.w) * (1 - along) * (0.6 + g2 * 0.5)
        const edge = smooth(clamp((e - 0.1) * 4)) * 0.55 + (e > 0.12 && e < 0.2 ? 0.2 : 0)
        r = mix(r, r * 0.55, edge); g = mix(g, g * 0.5, edge); b = mix(b, b * 0.38, edge)
      }
    }
    // peeling paint exposing grey plaster
    if (band) {
      const pm = peelAt(u, v)
      if (pm > 0.05) {
        const edge = pm < 0.4 ? 0.55 : 1
        r = mix(r, 168 * edge * grime, smooth(pm)); g = mix(g, 160 * edge * grime, smooth(pm)); b = mix(b, 146 * edge * grime, smooth(pm))
      }
    }
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  // height: plaster grain, dado ridge, recessed peels and cracks
  const { w, h } = S
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w, v = y / h
      let hh = 0.55 + (fbm(u, v, 12, 3, seed + 7) - 0.5) * 0.3 + (fbm(u, v, 80, 1, seed + 8) - 0.5) * 0.05
      const dd = Math.abs(v - dado)
      if (dd < 0.01) hh += 0.2 * (1 - dd / 0.01)
      if (v > dado) {
        const pm = peelAt(u, v)
        hh -= smooth(clamp(pm * 1.5)) * 0.25
        S.rough[y * w + x] = mix(0.42, 0.9, smooth(clamp(pm * 2))) + (fbm(u, v, 12, 2, seed + 61) - 0.5) * 0.25
      } else S.rough[y * w + x] = 0.88 + (fbm(u, v, 20, 2, seed + 62) - 0.5) * 0.12
      // paint gloss gets duller toward the damp
      if (v > 0.86) S.rough[y * w + x] += 0.1
      S.height[y * w + x] = hh
    }
  }
  const cracks = (g) => {
    g.strokeStyle = '#fff'; g.lineCap = 'round'
    for (let i = 0; i < 3; i++) crackPath(g, rnd() * w, rnd() * h * 0.7, Math.PI / 2 + (rnd() - 0.5) * 1.2, 50 + rnd() * 130, 0.8 + rnd() * 0.8)
  }
  stampField(S, cracks, 'height', -0.35)
  // draw the cracks dark into the colour map too
  S.gc.save(); S.gc.strokeStyle = 'rgba(38,32,24,.38)'; S.gc.lineCap = 'round'
  for (let i = 0; i < 3; i++) crackPath(S.gc, rnd() * w, rnd() * h * 0.7, Math.PI / 2 + (rnd() - 0.5) * 1.2, 50 + rnd() * 130, 0.8 + rnd() * 0.6)
  S.gc.restore()
  return toTextures(S, { normalStrength: 1.1 })
}

function floorSurface (size, kind) {
  seedRnd(kind === 'ward' ? 301 : 302)
  const S = makeSurface(size, size)
  const tiles = kind === 'ward' ? 8 : 10 // tiles across one repeat
  const A = kind === 'ward' ? rgb(0x86795c) : rgb(0x838a80), B = kind === 'ward' ? rgb(0x70694f) : rgb(0x626d63)
  const seed = kind === 'ward' ? 3 : 4
  const puddles = []
  for (let i = 0; i < 4; i++) puddles.push({ x: rnd(), y: rnd(), r: 0.04 + rnd() * 0.09 })
  const tileVar = []
  for (let i = 0; i < tiles * tiles; i++) tileVar.push(0.82 + rnd() * 0.3)
  paintPixels(S, (u, v) => {
    const tx = Math.floor(u * tiles), ty = Math.floor(v * tiles)
    const chk = (tx + ty) % 2 === 0
    let c = chk ? A : B
    const tv = tileVar[(ty % tiles) * tiles + (tx % tiles)]
    const fu = u * tiles - tx, fv = v * tiles - ty
    const grout = Math.min(fu, 1 - fu, fv, 1 - fv) < 0.035
    const dirt = fbm(u, v, 7, 4, seed)
    const scuff = fbm(u * 1.0, v * 6.0, 8, 2, seed + 11) // streaky wear
    let k = tv * (0.55 + dirt * 0.65) * (0.9 + (scuff - 0.5) * 0.4)
    let r = c[0] * k, g = c[1] * k, b = c[2] * k
    // flecks in the lino
    const fl = hash(Math.floor(u * 512), Math.floor(v * 512), seed)
    if (fl > 0.985) { r += 40; g += 40; b += 38 }
    if (grout) { r = 38 + dirt * 20; g = 36 + dirt * 18; b = 30 + dirt * 14 }
    // dried dark stains
    const st = fbm(u, v, 4, 4, seed + 31)
    const stain = clamp((st - 0.62) * 6)
    r = mix(r, r * 0.35, stain); g = mix(g, g * 0.32, stain); b = mix(b, b * 0.28, stain)
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  const { w, h } = S
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w, v = y / h
      const fu = (u * tiles) % 1, fv = (v * tiles) % 1
      const edge = Math.min(fu, 1 - fu, fv, 1 - fv)
      let hh = 0.55 + (fbm(u, v, 40, 2, seed + 5) - 0.5) * 0.1
      if (edge < 0.035) hh -= 0.35; else if (edge < 0.07) hh -= (0.07 - edge) * 3
      S.height[y * w + x] = hh
      // worn centres are duller; the lino is slightly satin
      const wear = fbm(u, v, 5, 3, seed + 12)
      S.rough[y * w + x] = 0.42 + wear * 0.4
    }
  }
  // wet patches: smooth, mirror-like, dark
  const pud = g => { for (const p of puddles) { blob(g, p.x * w, p.y * h, p.r * w, p.r * w * 0.7, rnd() * 3, '#fff', 18, 0.5) } }
  stampField(S, pud, 'rough', 0.08, 'set')
  S.gc.save(); S.gc.globalAlpha = 0.5
  for (const p of puddles) blob(S.gc, p.x * w, p.y * h, p.r * w, p.r * w * 0.7, 0, 'rgba(10,12,10,1)', 18, 0.5)
  S.gc.restore()
  // cracks across the tiles
  const cr = g => { g.strokeStyle = '#fff'; g.lineCap = 'round'; for (let i = 0; i < 3; i++) crackPath(g, rnd() * w, rnd() * h, rnd() * 6.28, 50 + rnd() * 110, 1.0) }
  stampField(S, cr, 'height', -0.3)
  S.gc.strokeStyle = 'rgba(15,14,10,.5)'; S.gc.lineCap = 'round'
  for (let i = 0; i < 3; i++) crackPath(S.gc, rnd() * w, rnd() * h, rnd() * 6.28, 50 + rnd() * 110, 0.9)
  return toTextures(S, { normalStrength: 1.6 })
}

function ceilingSurface (size) {
  seedRnd(401)
  const S = makeSurface(size, size)
  const n = 4
  const tv = Array.from({ length: n * n }, () => 0.8 + rnd() * 0.3)
  const sag = Array.from({ length: n * n }, () => rnd() < 0.18)
  paintPixels(S, (u, v) => {
    const tx = Math.floor(u * n), ty = Math.floor(v * n)
    const fu = u * n - tx, fv = v * n - ty
    const bar = Math.min(fu, 1 - fu, fv, 1 - fv) < 0.025
    const f = fbm(u, v, 8, 3, 9)
    let k = tv[(ty % n) * n + (tx % n)] * (0.7 + f * 0.5)
    if (sag[(ty % n) * n + (tx % n)]) k *= 0.7
    let r = 190 * k, g = 186 * k, b = 168 * k
    const hole = hash(Math.floor(u * 256), Math.floor(v * 256), 4)
    if (hole > 0.93) { r *= 0.55; g *= 0.55; b *= 0.5 }
    const stain = clamp((fbm(u, v, 3, 4, 17) - 0.55) * 5)
    r = mix(r, r * 0.55, stain); g = mix(g, g * 0.42, stain); b = mix(b, b * 0.25, stain)
    if (bar) { r = 120 * (0.7 + f * 0.4); g = 118 * (0.7 + f * 0.4); b = 108 * (0.7 + f * 0.4) }
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  const { w, h } = S
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w, v = y / h
      const fu = (u * n) % 1, fv = (v * n) % 1
      const edge = Math.min(fu, 1 - fu, fv, 1 - fv)
      let hh = 0.5 + (fbm(u, v, 64, 1, 5) - 0.5) * 0.06
      if (edge < 0.03) hh += 0.25
      S.height[y * w + x] = hh
      S.rough[y * w + x] = 0.95
    }
  }
  return toTextures(S, { normalStrength: 1.0 })
}

function tileSurface (size) {
  seedRnd(501)
  const S = makeSurface(size, size)
  const n = 16
  paintPixels(S, (u, v) => {
    const fu = (u * n) % 1, fv = (v * n) % 1
    const edge = Math.min(fu, 1 - fu, fv, 1 - fv)
    const tx = Math.floor(u * n), ty = Math.floor(v * n)
    const tv = 0.88 + hash(tx, ty, 6) * 0.14
    const f = fbm(u, v, 6, 4, 33)
    let k = tv * (0.62 + f * 0.55)
    let r = 214 * k, g = 218 * k, b = 210 * k
    if (edge < 0.05) { r = 70 * (0.6 + f); g = 68 * (0.6 + f); b = 58 * (0.6 + f) }
    const rust = clamp((fbm(u, v * 0.7, 5, 4, 71) - 0.62) * 6) * clamp(v * 1.8)
    r = mix(r, 130, rust * 0.6); g = mix(g, 66, rust * 0.6); b = mix(b, 30, rust * 0.6)
    const blood = clamp((fbm(u, v, 3, 5, 91) - 0.7) * 9)
    r = mix(r, 80, blood * 0.7); g = mix(g, 8, blood * 0.7); b = mix(b, 8, blood * 0.7)
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  const { w, h } = S
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w, v = y / h
      const fu = (u * n) % 1, fv = (v * n) % 1
      const edge = Math.min(fu, 1 - fu, fv, 1 - fv)
      S.height[y * w + x] = 0.6 - (edge < 0.05 ? 0.4 : 0) + (fbm(u, v, 40, 2, 3) - 0.5) * 0.06
      S.rough[y * w + x] = edge < 0.05 ? 0.9 : 0.18 + fbm(u, v, 8, 3, 12) * 0.5
    }
  }
  const cr = g => { g.strokeStyle = '#fff'; for (let i = 0; i < 3; i++) crackPath(g, rnd() * w, rnd() * h, rnd() * 6.28, 50 + rnd() * 110, 1.4) }
  stampField(S, cr, 'height', -0.4)
  return toTextures(S, { normalStrength: 1.8 })
}

function concreteSurface (size) {
  seedRnd(601)
  const S = makeSurface(size, size)
  paintPixels(S, (u, v) => {
    const f = fbm(u, v, 5, 5, 4)
    const g2 = fbm(u, v, 64, 2, 8)
    let k = 0.45 + f * 0.7
    k *= 0.9 + g2 * 0.2
    let r = 118 * k, g = 120 * k, b = 118 * k
    // form-board seams
    const seam = Math.abs(((v * 4) % 1) - 0.5)
    if (seam > 0.485) { r *= 0.6; g *= 0.6; b *= 0.6 }
    const damp = clamp((fbm(u, v, 3, 5, 77) - 0.55) * 4)
    r = mix(r, r * 0.45, damp); g = mix(g, g * 0.5, damp); b = mix(b, b * 0.5, damp)
    const rust = clamp((fbm(u * 3, v * 0.3, 6, 3, 88) - 0.64) * 8) * 0.8
    r = mix(r, 110, rust); g = mix(g, 52, rust); b = mix(b, 28, rust)
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  const { w, h } = S
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w, v = y / h
      S.height[y * w + x] = 0.5 + (fbm(u, v, 12, 4, 6) - 0.5) * 0.5 + (fbm(u, v, 96, 1, 9) - 0.5) * 0.25
      S.rough[y * w + x] = 0.8 + fbm(u, v, 9, 3, 2) * 0.2
    }
  }
  const cr = g => { g.strokeStyle = '#fff'; g.lineCap = 'round'; for (let i = 0; i < 6; i++) crackPath(g, rnd() * w, rnd() * h, rnd() * 6.28, 90 + rnd() * 220, 1.8) }
  stampField(S, cr, 'height', -0.5)
  return toTextures(S, { normalStrength: 2.4 })
}

function doorSurface (size, variant) {
  seedRnd(700 + variant)
  const w = size, h = size * 2
  const S = makeSurface(w, h)
  const base = variant === 0 ? rgb(0x8a7a58) : variant === 1 ? rgb(0x5d6e5f) : rgb(0x6d6d70)
  paintPixels(S, (u, v) => {
    const f = fbm(u, v, 5, 4, 14 + variant)
    const grain = fbm(u * 0.15, v * 5, 12, 2, 20)
    let k = 0.55 + f * 0.7
    k *= 0.92 + grain * 0.16
    let r = base[0] * k, g = base[1] * k, b = base[2] * k
    // recessed panels
    const inPanel = (v > 0.07 && v < 0.43 && u > 0.14 && u < 0.86) || (v > 0.5 && v < 0.93 && u > 0.14 && u < 0.86)
    if (inPanel) { r *= 0.9; g *= 0.9; b *= 0.9 }
    const peel = clamp((fbm(u, v, 9, 4, 61 + variant) - 0.6) * 6)
    r = mix(r, 130, peel * 0.8); g = mix(g, 108, peel * 0.8); b = mix(b, 78, peel * 0.8)
    // kick plate
    if (v > 0.9) { r = 105 * k; g = 102 * k; b = 92 * k }
    // handle plate
    if (u > 0.82 && u < 0.92 && v > 0.47 && v < 0.55) { r = 160; g = 150; b = 120 }
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w, v = y / h
      let hh = 0.6 + (fbm(u * 0.2, v * 6, 14, 2, 3) - 0.5) * 0.12
      const inP = (v > 0.07 && v < 0.43 && u > 0.14 && u < 0.86) || (v > 0.5 && v < 0.93 && u > 0.14 && u < 0.86)
      const edgeP = inP ? Math.min(u - 0.14, 0.86 - u) : 0
      if (inP) hh -= 0.12 + (edgeP < 0.015 ? -0.1 : 0)
      const peel = clamp((fbm(u, v, 9, 4, 61 + variant) - 0.6) * 6)
      hh -= peel * 0.12
      S.height[y * w + x] = hh
      S.rough[y * w + x] = peel > 0.3 ? 0.9 : 0.55 + fbm(u, v, 16, 2, 7) * 0.3
    }
  }
  return toTextures(S, { normalStrength: 2 })
}

function lockerSurface (size) {
  seedRnd(801)
  const w = size, h = size * 2
  const S = makeSurface(w, h)
  S.metal = new Float32Array(w * h).fill(0.7)
  paintPixels(S, (u, v) => {
    const f = fbm(u, v, 4, 4, 5)
    let k = 0.55 + f * 0.6
    let r = 92 * k, g = 112 * k, b = 104 * k
    // louvre slots, top and bottom
    const slot = (v > 0.06 && v < 0.2 || v > 0.84 && v < 0.96) && u > 0.2 && u < 0.8 && ((v * 60) % 1) > 0.45
    if (slot) { r = 14; g = 14; b = 13 }
    // door seam and handle
    if (u < 0.02 || u > 0.98) { r *= 0.5; g *= 0.5; b *= 0.5 }
    if (u > 0.68 && u < 0.78 && v > 0.45 && v < 0.5) { r = 150; g = 150; b = 142 }
    const rust = clamp((fbm(u * 1.5, v * 0.5, 7, 5, 31) - 0.55) * 5) * (0.3 + v)
    r = mix(r, 122, rust); g = mix(g, 60, rust); b = mix(b, 28, rust)
    const dent = fbm(u, v, 3, 3, 90)
    r *= 0.9 + dent * 0.2; g *= 0.9 + dent * 0.2; b *= 0.9 + dent * 0.2
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w, v = y / h
      const rust = clamp((fbm(u * 1.5, v * 0.5, 7, 5, 31) - 0.55) * 5) * (0.3 + v)
      S.height[y * w + x] = 0.55 + (fbm(u, v, 3, 3, 90) - 0.5) * 0.25 + rust * 0.12 + (fbm(u, v, 80, 1, 3) - 0.5) * 0.04
      S.rough[y * w + x] = mix(0.38 + fbm(u, v, 10, 3, 11) * 0.3, 0.9, rust)
      S.metal[y * w + x] = mix(0.8, 0.1, rust)
    }
  }
  return toTextures(S, { normalStrength: 1.6 })
}

function fabricSurface (size, kind) {
  seedRnd(900 + (kind === 'mattress' ? 1 : 2))
  const S = makeSurface(size, size)
  const mat = kind === 'mattress'
  paintPixels(S, (u, v) => {
    const f = fbm(u, v, 4, 4, 15)
    let r, g, b
    if (mat) {
      const stripe = Math.floor(v * 14) % 2
      r = (stripe ? 188 : 164) * (0.55 + f * 0.7); g = (stripe ? 178 : 152) * (0.55 + f * 0.7); b = (stripe ? 150 : 124) * (0.55 + f * 0.7)
    } else {
      r = 78 * (0.5 + f * 0.8); g = 62 * (0.5 + f * 0.8); b = 50 * (0.5 + f * 0.8)
    }
    const weave = ((Math.floor(u * 256) + Math.floor(v * 256)) % 2) * 0.05
    r *= 1 - weave; g *= 1 - weave; b *= 1 - weave
    const st = clamp((fbm(u, v, 3, 5, 55) - 0.6) * 5)
    r = mix(r, 92, st * 0.7); g = mix(g, 60, st * 0.7); b = mix(b, 20, st * 0.7)
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  const { w, h } = S
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const u = x / w, v = y / h
    S.height[y * w + x] = 0.5 + (((x + y) % 2) * 0.04) + (fbm(u, v, 20, 3, 6) - 0.5) * 0.35
    S.rough[y * w + x] = 0.95
  }
  return toTextures(S, { normalStrength: 1.2 })
}

function woodSurface (size) {
  seedRnd(950)
  const S = makeSurface(size, size)
  paintPixels(S, (u, v) => {
    const plank = Math.floor(u * 2)
    const f = fbm(u * 0.4, v * 8, 10, 4, 3 + plank)
    const ring = Math.sin((u * 2 % 1) * 30 + fbm(u, v * 0.3, 6, 3, 8) * 12) * 0.5 + 0.5
    let k = 0.5 + f * 0.6 + ring * 0.12
    let r = 96 * k, g = 70 * k, b = 46 * k
    const edge = (u * 2) % 1
    if (edge < 0.012 || edge > 0.988) { r *= 0.35; g *= 0.35; b *= 0.35 }
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  const { w, h } = S
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const u = x / w, v = y / h
    const edge = (u * 2) % 1
    S.height[y * w + x] = 0.55 + (fbm(u * 0.4, v * 8, 12, 3, 3) - 0.5) * 0.2 - (edge < 0.012 || edge > 0.988 ? 0.3 : 0)
    S.rough[y * w + x] = 0.6 + fbm(u, v, 10, 2, 9) * 0.3
  }
  return toTextures(S, { normalStrength: 1.8 })
}

function metalSurface (size) {
  seedRnd(980)
  const S = makeSurface(size, size)
  S.metal = new Float32Array(size * size).fill(0.7)
  paintPixels(S, (u, v) => {
    const f = fbm(u, v, 5, 4, 12)
    const rust = clamp((fbm(u, v, 4, 5, 22) - 0.5) * 3.5)
    const k = 0.5 + f * 0.6
    let r = 120 * k, g = 124 * k, b = 122 * k
    r = mix(r, 125 * (0.6 + f * 0.6), rust); g = mix(g, 62 * (0.6 + f * 0.6), rust); b = mix(b, 30 * (0.6 + f * 0.6), rust)
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]
  })
  const { w, h } = S
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const u = x / w, v = y / h
    const rust = clamp((fbm(u, v, 4, 5, 22) - 0.5) * 3.5)
    S.height[y * w + x] = 0.5 + (fbm(u, v, 30, 3, 5) - 0.5) * 0.3 + rust * 0.15
    S.rough[y * w + x] = mix(0.35 + fbm(u, v, 20, 2, 4) * 0.25, 0.92, rust)
    S.metal[y * w + x] = mix(0.9, 0.1, rust)
  }
  return toTextures(S, { normalStrength: 1.4 })
}

// ═════════════ public API ═════════════
let SZ = 512
const cache = new Map()
export function setTextureSize (px) { SZ = px }

/** kind: wall0..3 | floor-hall | floor-ward | ceiling | tile | concrete | door0..2 | locker | mattress | blanket | wood | metal */
const texCache = new Map()
function textures (kind) {
  if (texCache.has(kind)) return texCache.get(kind)
  let tex
  if (kind.startsWith('wall')) tex = wallSurface(SZ, +kind.slice(4))
  else if (kind === 'floor-hall') tex = floorSurface(SZ, 'hall')
  else if (kind === 'floor-ward') tex = floorSurface(SZ, 'ward')
  else if (kind === 'ceiling') tex = ceilingSurface(Math.min(SZ, 256))
  else if (kind === 'tile') tex = tileSurface(SZ)
  else if (kind === 'concrete') tex = concreteSurface(SZ)
  else if (kind.startsWith('door')) tex = doorSurface(Math.min(SZ, 256), +kind.slice(4))
  else if (kind === 'locker') tex = lockerSurface(Math.min(SZ, 256))
  else if (kind === 'mattress' || kind === 'blanket') tex = fabricSurface(Math.min(SZ, 256), kind)
  else if (kind === 'wood') tex = woodSurface(Math.min(SZ, 256))
  else if (kind === 'metal') tex = metalSurface(Math.min(SZ, 256))
  else throw new Error('unknown surface ' + kind)
  texCache.set(kind, tex)
  return tex
}

/** A material by key: 'wall2', 'metal', 'metal#8a8f8c' (tinted), or 'solid#aa3322:0.5:0.1' (plain colour:roughness:metalness) */
export function surface (key) {
  if (cache.has(key)) return cache.get(key)
  let m
  if (key.startsWith('solid')) {
    const [c, r, me] = key.slice(6).split(':')
    m = new THREE.MeshStandardMaterial({ color: parseInt(c, 16), roughness: +(r ?? 0.7), metalness: +(me ?? 0) })
  } else {
    const [kind, tint] = key.split('#')
    const tex = textures(kind)
    m = new THREE.MeshStandardMaterial({
      map: tex.map, normalMap: tex.normalMap, roughnessMap: tex.roughnessMap, roughness: 1, metalness: tex.metalnessMap ? 1 : 0,
      metalnessMap: tex.metalnessMap ?? null, normalScale: new THREE.Vector2(1, 1),
    })
    if (tint) m.color.setHex(parseInt(tint, 16))
  }
  cache.set(key, m)
  return m
}

/** Hand-painted decals (blood, scratches, writing) as alpha textures */
const decalCache = new Map()
export function decalTexture (kind) {
  if (decalCache.has(kind)) return decalCache.get(kind)
  const c = document.createElement('canvas')
  const w = 512, h = 512
  c.width = w; c.height = h
  const g = c.getContext('2d')
  seedRnd(kind.split('').reduce((a, ch) => a + ch.charCodeAt(0), 7))
  g.clearRect(0, 0, w, h)
  if (kind === 'smear') {
    // a dragged smear of dark blood with a drip trail
    for (let i = 0; i < 26; i++) {
      const x = 80 + i * 14 + (rnd() - 0.5) * 12, y = 120 + Math.sin(i * 0.4) * 30 + (rnd() - 0.5) * 18
      blob(g, x, y, 26 + rnd() * 24, 14 + rnd() * 12, rnd() * 0.5, `rgba(${60 + rnd() * 20 | 0},4,6,${0.4 + rnd() * 0.4})`, 12, 0.5)
    }
    for (let i = 0; i < 9; i++) { const x = 100 + rnd() * 320; g.fillStyle = 'rgba(46,3,5,.75)'; g.fillRect(x, 130, 4 + rnd() * 4, 60 + rnd() * 240); blob(g, x + 3, 130 + 60 + rnd() * 200, 6, 8, 0, 'rgba(46,3,5,.8)', 8, 0.2) }
  } else if (kind === 'hand') {
    // a hand print, fingers splayed
    g.fillStyle = 'rgba(70,5,8,.82)'
    blob(g, 256, 330, 70, 80, 0, 'rgba(70,5,8,.82)', 14, 0.2)
    for (let i = 0; i < 5; i++) {
      const a = -Math.PI / 2 + (i - 2) * 0.36 + (i === 0 ? -0.35 : 0)
      const len = i === 0 ? 85 : 120 - Math.abs(i - 2) * 12
      g.save(); g.translate(256 + (i - 2) * 28, 290); g.rotate(a + Math.PI / 2); blob(g, 0, -len / 2, 15, len / 2, 0, 'rgba(70,5,8,.82)', 10, 0.15); g.restore()
    }
    for (let i = 0; i < 6; i++) { g.fillStyle = 'rgba(60,4,6,.7)'; g.fillRect(200 + rnd() * 110, 400, 3, 20 + rnd() * 70) }
  } else if (kind === 'scratch') {
    // four parallel gouges
    g.strokeStyle = 'rgba(20,16,12,.9)'; g.lineCap = 'round'
    for (let i = 0; i < 4; i++) { g.lineWidth = 3 + rnd() * 2; g.beginPath(); g.moveTo(130 + i * 34, 80 + rnd() * 10); g.bezierCurveTo(150 + i * 34, 200, 110 + i * 34, 320, 170 + i * 34, 450 + rnd() * 20); g.stroke() }
  } else if (kind === 'stain') {
    for (let i = 0; i < 12; i++) blob(g, 256 + (rnd() - 0.5) * 130, 256 + (rnd() - 0.5) * 130, 40 + rnd() * 70, 40 + rnd() * 70, rnd() * 3, `rgba(${50 + rnd() * 20 | 0},4,5,${0.25 + rnd() * 0.3})`, 16, 0.6)
    for (let i = 0; i < 40; i++) blob(g, 256 + (rnd() - 0.5) * 360, 256 + (rnd() - 0.5) * 360, 3 + rnd() * 8, 3 + rnd() * 8, 0, 'rgba(44,3,5,.8)', 8, 0.3)
  } else if (kind === 'grime') {
    for (let i = 0; i < 20; i++) blob(g, rnd() * w, rnd() * h, 40 + rnd() * 90, 30 + rnd() * 60, rnd() * 3, `rgba(14,12,8,${0.1 + rnd() * 0.18})`, 14, 0.6)
  } else if (kind.startsWith('text:')) {
    // scrawled writing, uneven and drippy
    const text = kind.slice(5)
    g.fillStyle = 'rgba(78,6,9,.88)'
    g.font = '900 78px "Permanent Marker", "Segoe Print", "Comic Sans MS", cursive'
    g.textAlign = 'center'
    const words = text.split('|')
    words.forEach((wd, i) => {
      g.save(); g.translate(256, 150 + i * 110); g.rotate((rnd() - 0.5) * 0.12); g.fillText(wd, 0, 0); g.restore()
    })
    // drips under the letters
    for (let i = 0; i < 14; i++) { const x = 70 + rnd() * 370; const y = 160 + rnd() * 160; g.fillRect(x, y, 3, 20 + rnd() * 80) }
  }
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.anisotropy = 4
  decalCache.set(kind, t)
  return t
}

/** The flashlight's cookie: a slightly uneven bright disc with a hot centre and ragged edge */
export function beamCookie () {
  const s = 256
  const c = document.createElement('canvas'); c.width = c.height = s
  const g = c.getContext('2d')
  seedRnd(1234)
  const img = g.createImageData(s, s)
  for (let y = 0; y < s; y++) {
    for (let x = 0; x < s; x++) {
      const dx = (x - s / 2) / (s / 2), dy = (y - s / 2) / (s / 2)
      const r = Math.hypot(dx, dy)
      const a = Math.atan2(dy, dx)
      const edge = 0.9 + Math.sin(a * 5 + 1) * 0.015 + (fbm(Math.cos(a) * 0.5 + 0.5, Math.sin(a) * 0.5 + 0.5, 4, 2, 4) - 0.5) * 0.06
      let v = 1 - smooth(clamp((r - edge * 0.55) / (edge * 0.45)))
      // faint ring artefacts like a cheap reflector
      v *= 0.86 + 0.14 * Math.cos(r * 14) * clamp(1 - r) + 0.05 * fbm(x / s, y / s, 6, 2, 8)
      v = clamp(v)
      const i = (y * s + x) * 4
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v * 255
      img.data[i + 3] = 255
    }
  }
  g.putImageData(img, 0, 0)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}
