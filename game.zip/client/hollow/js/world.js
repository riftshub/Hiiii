// St. Ambrose State Hospital: the building. Walls, floors, doors, furniture, lamps, hiding places and
// the places things can be found. Everything static is merged into one mesh per material.
import * as THREE from 'three'
import { Mesher, Colliders, Nav } from './mesher.js'
import { surface, decalTexture } from './textures.js'

export const H = 3.2
const T = 0.2
const CORR = 3.2

export const mulberry = a => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296 }
const hex = n => n.toString(16).padStart(6, '0')
export const solid = (c, r = 0.7, m = 0) => `solid#${hex(c)}:${r}:${m}`

export function buildWorld (scene, { seed = 1, quality = 'high' } = {}) {
  const HIGH = quality === 'high'
  const rng = mulberry(seed)
  const pick = arr => arr[Math.floor(rng() * arr.length)]
  const M = new Mesher()
  const C = new Colliders()
  const group = new THREE.Group()
  scene.add(group)
  const dyn = new THREE.Group() // doors, decals, fixtures: things that aren't merged
  group.add(dyn)

  const W = {
    group, colliders: C, doors: [], rooms: [], lamps: [], hides: [], decals: [], spots: {}, litter: [],
    bounds: { x1: -34, z1: -50, x2: 44, z2: 3 },
  }

  // ═════════ low-level helpers ═════════
  const box = (key, cx, cy, cz, sx, sy, sz, o) => M.box(key, cx, cy, cz, sx, sy, sz, o)
  /** a prop box standing on the floor (or at y0): visual + collider */
  const prop = (key, x, z, sx, sy, sz, { y0 = 0, yaw = 0, tall = false, collide = true, tile = [1 / 2, 1 / 2] } = {}) => {
    box(key, x, y0 + sy / 2, z, sx, sy, sz, { yaw, tile })
    if (collide) {
      const c = Math.abs(Math.cos(yaw)), s = Math.abs(Math.sin(yaw))
      const hx = (sx * c + sz * s) / 2, hz = (sx * s + sz * c) / 2
      C.add(x - hx, z - hz, x + hx, z + hz, { tall: tall || sy > 1.4 })
    }
  }
  const spot = (name, x, y, z, extra = {}) => { (W.spots[name] ??= []).push({ x, y, z, ...extra }) }
  const wallTile = [1 / 2.4, 1 / H]

  // ═════════ walls ═════════
  /**
   * ax 'x': the wall runs along x at z=c; 'z': along z at x=c.
   * gaps: { at, w, kind: 'door' | 'window' | 'open', id, ... }
   * lo/hi: surface for the side toward lower / higher coordinates.
   */
  function wall (ax, c, a1, a2, gaps = [], { lo = 'wall0', hi = 'wall0', ext = true } = {}) {
    const along = (a, b, y0, y1, key, ctr) => {
      // one half-thickness skin per side
      const len = b - a, hgt = y1 - y0
      if (len <= 0.001 || hgt <= 0.001) return
      const mid = (a + b) / 2
      const tile = key.startsWith('wall') ? wallTile : [1 / 2.4, 1 / 2.4]
      const off = [rng() * 5, 0]
      for (const side of [-1, 1]) {
        const k = side < 0 ? lo : hi
        const t = k.startsWith('wall') ? wallTile : tile
        if (ax === 'x') box(k, mid, y0 + hgt / 2, ctr + side * T / 4, len, hgt, T / 2, { tile: t, off })
        else box(k, ctr + side * T / 4, y0 + hgt / 2, mid, T / 2, hgt, len, { tile: t, off })
      }
    }
    const solidBlock = (a, b, y0, y1, tall = true) => {
      along(a, b, y0, y1, lo, c)
      if (y0 === 0 && y1 >= H - 0.01) {
        if (ax === 'x') C.add(a, c - T / 2, b, c + T / 2, { tall })
        else C.add(c - T / 2, a, c + T / 2, b, { tall })
      }
    }
    const sorted = [...gaps].sort((p, q) => p.at - q.at)
    let cur = ext ? a1 - T / 2 : a1
    const end = ext ? a2 + T / 2 : a2
    for (const g of sorted) {
      const g1 = g.at - g.w / 2, g2 = g.at + g.w / 2
      solidBlock(cur, g1, 0, H)
      if (g.kind === 'door') {
        const dh = g.h ?? 2.1
        along(g1, g2, dh, H, lo, c)
        makeDoor(ax, c, g)
      } else if (g.kind === 'window') {
        const sill = g.sill ?? 0.9, wh = g.wh ?? 1.3
        along(g1, g2, 0, sill, lo, c)
        along(g1, g2, sill + wh, H, lo, c)
        if (ax === 'x') C.add(g1, c - T / 2, g2, c + T / 2, { tall: true }); else C.add(c - T / 2, g1, c + T / 2, g2, { tall: true })
        makeWindow(ax, c, g, sill, wh)
      }
      cur = g2
    }
    solidBlock(cur, end, 0, H)
  }

  // ═════════ doors ═════════
  const doorMats = ['door0', 'door1', 'door2']
  const handleMat = surface(solid(0xb09a60, 0.35, 0.8))
  function makeDoor (ax, c, g) {
    const w = g.w
    const d = {
      id: g.id, axis: ax, c, at: g.at, w, h: g.h ?? 2.1, kind: g.kind2 ?? 'room', locked: !!g.locked, keyId: g.keyId ?? null, label: g.label ?? 'door',
      open: g.ajar ?? 0, target: g.ajar ?? 0, swing: g.swing ?? (rng() < 0.5 ? 1 : -1), double: !!g.double, wedged: !!g.wedged,
      x: ax === 'x' ? g.at : c, z: ax === 'x' ? c : g.at, leaves: [], variant: g.variant ?? Math.floor(rng() * 3), chain: !!g.chain,
    }
    const leafW = d.double ? w / 2 : w
    const lw = leafW - 0.02
    const hinges = d.double ? [-1, 1] : [g.hinge ?? (rng() < 0.5 ? -1 : 1)]
    for (const h of hinges) {
      const pivot = new THREE.Group()
      const geo = new THREE.BoxGeometry(lw, d.h, 0.05)
      geo.translate(-h * lw / 2, d.h / 2, 0) // the leaf runs from the hinge toward the middle of the opening
      const mesh = new THREE.Mesh(geo, surface(doorMats[d.variant]))
      mesh.castShadow = true; mesh.receiveShadow = true
      pivot.add(mesh)
      const knob = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.14), handleMat)
      knob.position.set(-h * (lw - 0.12), 1.0, 0)
      pivot.add(knob)
      const hx = d.at + h * w / 2
      pivot.position.set(ax === 'x' ? hx : c, 0, ax === 'x' ? c : hx)
      dyn.add(pivot)
      d.leaves.push({ pivot, mesh, h })
    }
    // blocks the opening while mostly shut
    const hw = 0.09
    const shut = () => d.open < 0.45 && !d.broken
    d.box = ax === 'x' ? C.add(d.at - w / 2, c - hw, d.at + w / 2, c + hw, { tall: true, door: shut, tag: 'door:' + d.id })
      : C.add(c - hw, d.at - w / 2, c + hw, d.at + w / 2, { tall: true, door: shut, tag: 'door:' + d.id })
    d.box.doorRef = d
    W.doors.push(d)
    applyDoor(d)
    return d
  }
  const MAXA = 1.72
  function applyDoor (d) {
    const base = d.axis === 'z' ? -Math.PI / 2 : 0 // local +x runs along +z for walls along z
    for (const l of d.leaves) l.pivot.rotation.y = base + (d.chain ? 0 : d.swing * d.open * MAXA * l.h)
  }

  // ═════════ windows ═════════
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x0a1118, emissive: 0x16283c, emissiveIntensity: 0.9, roughness: 0.1, metalness: 0.2, transparent: true, opacity: 0.88 })
  function makeWindow (ax, c, g, sill, wh) {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(g.w, wh), glassMat)
    mesh.position.set(ax === 'x' ? g.at : c, sill + wh / 2, ax === 'x' ? c : g.at)
    if (ax === 'z') mesh.rotation.y = Math.PI / 2
    mesh.userData.noShadow = true
    dyn.add(mesh)
    // frame and bars
    const fk = solid(0x2a2b2a, 0.5, 0.6)
    const bars = 3
    for (let i = 0; i <= bars; i++) {
      const o = -g.w / 2 + (g.w * i) / bars
      if (ax === 'x') box(fk, g.at + o, sill + wh / 2, c, 0.04, wh, 0.06); else box(fk, c, sill + wh / 2, g.at + o, 0.06, wh, 0.04)
    }
    for (const y of [sill, sill + wh / 2, sill + wh]) {
      if (ax === 'x') box(fk, g.at, y, c, g.w, 0.04, 0.06); else box(fk, c, y, g.at, 0.06, 0.04, g.w)
    }
    W.windows = W.windows ?? []
    W.windows.push({ ax, c, at: g.at, w: g.w, sill, wh, x: ax === 'x' ? g.at : c, z: ax === 'x' ? c : g.at })
  }

  // ═════════ floors and ceilings ═════════
  const floor = (key, x1, z1, x2, z2, tile = 1 / 3) => { M.rect(key, x1, z1, x2, z2, 0, true, tile) }
  const ceil = (x1, z1, x2, z2) => { M.rect('ceiling', x1, z1, x2, z2, H, false, 1 / 2.4) }

  // ═════════ room registry ═════════
  const room = (id, name, x1, z1, x2, z2, kind) => { const r = { id, name, x1, z1, x2, z2, kind, cx: (x1 + x2) / 2, cz: (z1 + z2) / 2 }; W.rooms.push(r); return r }
  W.roomAt = (x, z) => W.rooms.find(r => x >= r.x1 && x <= r.x2 && z >= r.z1 && z <= r.z2) ?? null

  // ═════════ layout ═════════
  // Lobby
  const lobby = room('lobby', 'Main Lobby', -8, -12, 8, 0, 'lobby')
  floor('floor-hall', -8, -12, 8, 0); ceil(-8, -12, 8, 0)
  room('spine1', 'Central Corridor', -1.6, -24, 1.6, -12, 'corridor')
  floor('floor-hall', -1.6, -24, 1.6, -12); ceil(-1.6, -24, 1.6, -12)
  room('cross', 'Ward Corridor', -25.6, -27.2, 25.6, -24, 'corridor')
  floor('floor-hall', -25.6, -27.2, 25.6, -24); ceil(-25.6, -27.2, 25.6, -24)
  room('spine2', 'Records Corridor', -1.6, -36, 1.6, -27.2, 'corridor')
  floor('floor-hall', -1.6, -36, 1.6, -27.2); ceil(-1.6, -36, 1.6, -27.2)

  // lobby shell
  wall('x', 0, -8, 8, [
    { at: 0, w: 2.4, kind: 'door', id: 'front', kind2: 'front', double: true, locked: true, chain: true, label: 'front doors', h: 2.4 },
    { at: -5, w: 1.8, kind: 'window', sill: 0.7, wh: 1.9 }, { at: 5, w: 1.8, kind: 'window', sill: 0.7, wh: 1.9 },
  ], { lo: 'wall1', hi: 'wall1' })
  wall('z', -8, -12, 0, [{ at: -6, w: 1.1, kind: 'door', id: 'admissions', label: 'Admissions', ajar: 0.6 }], { lo: 'wall1', hi: 'wall1' })
  wall('z', 8, -12, 0, [{ at: -6, w: 1.1, kind: 'door', id: 'pharmacy', label: 'Pharmacy', ajar: 0 }], { lo: 'wall1', hi: 'wall1' })
  wall('x', -12, -8, 8, [{ at: 0, w: 2.2, kind: 'door', id: 'lobbyN', double: true, label: 'corridor doors', ajar: 0.5 }], { lo: 'wall0', hi: 'wall1' })
  // Admissions + Pharmacy
  const adm = room('admissions', 'Admissions Office', -16, -11, -8, -1, 'office')
  floor('wood', -16, -11, -8, -1, 1 / 2); ceil(-16, -11, -8, -1)
  wall('x', -11, -16, -8, [], { lo: 'wall3', hi: 'wall1' }); wall('x', -1, -16, -8, [], { lo: 'wall1', hi: 'wall3' })
  wall('z', -16, -11, -1, [{ at: -6, w: 1.6, kind: 'window', sill: 1, wh: 1.2 }], { lo: 'wall3', hi: 'wall3' })
  const pha = room('pharmacy', 'Pharmacy', 8, -11, 16, -1, 'office')
  floor('floor-ward', 8, -11, 16, -1); ceil(8, -11, 16, -1)
  wall('x', -11, 8, 16, [], { lo: 'wall2', hi: 'wall2' }); wall('x', -1, 8, 16, [], { lo: 'wall2', hi: 'wall2' })
  wall('z', 16, -11, -1, [], { lo: 'wall2', hi: 'wall2' })

  // spine walls
  wall('z', -1.6, -24, -12, [], { lo: 'wall0', hi: 'wall0' }); wall('z', 1.6, -24, -12, [], { lo: 'wall0', hi: 'wall0' })
  wall('z', -1.6, -36, -27.2, [], { lo: 'wall2', hi: 'wall0' })
  wall('z', 1.6, -36, -27.2, [], { lo: 'wall0', hi: 'wall3' })
  // east gate across the ward corridor (locked until the ward key)
  wall('z', 1.6, -27.2, -24, [{ at: -25.6, w: 1.5, kind: 'door', id: 'eastGate', kind2: 'gate', locked: true, keyId: 'wardKey', label: 'East Ward gate', variant: 2, hinge: 1 }], { lo: 'wall0', hi: 'wall3', ext: false })

  // ── wards ──
  const bays = [0, 1, 2, 3]
  const wingRooms = []
  for (const side of [-1, 1]) {
    const wname = side < 0 ? 'West Ward' : 'East Ward'
    const xe = i => side * (1.6 + 6 * i) // bay edges
    // corridor walls (door gaps filled below)
    const gapsS = bays.map(i => ({ at: side * (1.6 + 6 * i + 3), w: 1.0, kind: 'door', id: `${side < 0 ? 'w' : 'e'}S${i}`, label: `${wname} room ${side < 0 ? 'A' : 'B'}${i + 1}`, ajar: rng() < 0.45 ? 0.55 + rng() * 0.4 : 0, variant: i % 3 }))
    const gapsN = bays.map(i => ({ at: side * (1.6 + 6 * i + 3), w: 1.0, kind: 'door', id: `${side < 0 ? 'w' : 'e'}N${i}`, label: `${wname} room ${side < 0 ? 'A' : 'B'}${i + 5}`, ajar: rng() < 0.45 ? 0.55 + rng() * 0.4 : 0, variant: (i + 1) % 3 }))
    const [a, b] = side < 0 ? [-25.6, -1.6] : [1.6, 25.6]
    wall('x', -24, a, b, gapsS, { lo: 'wall0', hi: side < 0 ? 'wall2' : 'wall3' })
    wall('x', -27.2, a, b, gapsN, { lo: side < 0 ? 'wall1' : 'wall2', hi: 'wall0' })
    // dividers + back walls
    for (let i = 1; i <= 3; i++) {
      wall('z', xe(i), -35.2, -27.2, [], { lo: 'wall1', hi: 'wall2' })
      wall('z', xe(i), -24, -16, [], { lo: 'wall2', hi: 'wall1' })
    }
    wall('x', -35.2, a, b, bays.map(i => ({ at: side * (1.6 + 6 * i + 3), w: 1.5, kind: 'window', sill: 1.0, wh: 1.2 })), { lo: 'wall2', hi: 'wall1' })
    wall('x', -16, a, b, bays.map(i => ({ at: side * (1.6 + 6 * i + 3), w: 1.5, kind: 'window', sill: 1.0, wh: 1.2 })), { lo: 'wall1', hi: 'wall2' })
    // wing end
    if (side < 0) wall('z', -25.6, -35.2, -16, [{ at: -25.6, w: 1.8, kind: 'window', sill: 0.6, wh: 1.9 }], { lo: 'wall1', hi: 'wall2' })
    for (const i of bays) {
      const x1 = Math.min(xe(i), xe(i + 1)), x2 = Math.max(xe(i), xe(i + 1))
      const letter = side < 0 ? 'A' : 'B'
      wingRooms.push({ side, i, north: false, r: room(`${side < 0 ? 'w' : 'e'}S${i}`, `${wname}, room ${letter}${i + 1}`, x1, -24, x2, -16, 'patient') })
      wingRooms.push({ side, i, north: true, r: room(`${side < 0 ? 'w' : 'e'}N${i}`, `${wname}, room ${letter}${i + 5}`, x1, -35.2, x2, -27.2, 'patient') })
      const mat = i === 3 && side < 0 ? 'tile' : 'floor-ward'
      floor(mat, x1, -35.2, x2, -27.2); ceil(x1, -35.2, x2, -27.2)
      floor('floor-ward', x1, -24, x2, -16); ceil(x1, -24, x2, -16)
    }
  }
  // ── Records ──
  const rec = room('records', 'Records Room', -9, -48, 9, -36, 'records')
  floor('floor-hall', -9, -48, 9, -36); ceil(-9, -48, 9, -36)
  wall('x', -36, -9, 9, [{ at: 0, w: 1.3, kind: 'door', id: 'records', locked: true, keyId: 'recordsKey', label: 'Records Room', kind2: 'gate', variant: 1 }], { lo: 'wall0', hi: 'wall3' })
  wall('x', -48, -9, 9, [], { lo: 'wall3', hi: 'wall3' })
  wall('z', -9, -48, -36, [], { lo: 'wall3', hi: 'wall3' })
  wall('z', 9, -48, -36, [], { lo: 'wall3', hi: 'wall3' })
  // ── Annex ──
  room('annex', 'Annex Corridor', 25.6, -46, 29, -22, 'corridor')
  floor('concrete', 25.6, -46, 29, -22, 1 / 2.4); ceil(25.6, -46, 29, -22)
  wall('z', 25.6, -46, -16, [{ at: -25.6, w: 1.5, kind: 'door', id: 'annexDoor', locked: true, keyId: 'annexKey', label: 'Annex door', kind2: 'gate', variant: 2, hinge: -1 }], { lo: 'wall3', hi: 'concrete' })
  wall('z', 29, -46, -22, [{ at: -26, w: 1.1, kind: 'door', id: 'maint', label: 'Maintenance', variant: 2, ajar: 0.6 }, { at: -39.5, w: 1.4, kind: 'door', id: 'morgue', label: 'Morgue', kind2: 'gate', variant: 2, double: true, ajar: 0 }], { lo: 'concrete', hi: 'tile' })
  wall('x', -46, 25.6, 41, [], { lo: 'concrete', hi: 'tile' })
  wall('x', -22, 25.6, 37, [], { lo: 'concrete', hi: 'concrete' })
  const maint = room('maint', 'Maintenance Room', 29, -30, 37, -22, 'maint')
  floor('concrete', 29, -30, 37, -22, 1 / 2.4); ceil(29, -30, 37, -22)
  wall('x', -30, 29, 37, [], { lo: 'concrete', hi: 'concrete' })
  wall('z', 37, -30, -22, [], { lo: 'concrete', hi: 'concrete' })
  const morgue = room('morgue', 'Morgue', 29, -46, 41, -33, 'morgue')
  floor('tile', 29, -46, 41, -33, 1 / 2.4); ceil(29, -46, 41, -33)
  wall('x', -33, 29, 41, [], { lo: 'tile', hi: 'tile' })
  wall('z', 41, -46, -33, [], { lo: 'tile', hi: 'tile' })

  // ═════════ furniture ═════════
  const metal = 'metal#9aa09c'
  const rustMetal = 'metal#7a746a'
  const wood = 'wood'
  const paper = solid(0xcfc8b0, 0.9)
  const white = solid(0xcfcfc6, 0.5)

  const chair = (x, z, yaw = 0, fallen = false) => {
    if (fallen) {
      box(wood, x, 0.2, z, 0.42, 0.04, 0.42, { yaw, tile: [1, 1] })
      box(wood, x + Math.cos(yaw) * 0.2, 0.42, z - Math.sin(yaw) * 0.2, 0.04, 0.42, 0.4, { yaw: yaw + 0.1 })
      C.add(x - 0.35, z - 0.35, x + 0.35, z + 0.35, { tall: false })
      return
    }
    box(wood, x, 0.45, z, 0.42, 0.04, 0.42, { yaw })
    for (const [lx, lz] of [[-0.18, -0.18], [0.18, -0.18], [-0.18, 0.18], [0.18, 0.18]]) {
      const c = Math.cos(yaw), s = Math.sin(yaw)
      box(wood, x + lx * c + lz * s, 0.22, z - lx * s + lz * c, 0.03, 0.44, 0.03, { yaw })
    }
    const c = Math.cos(yaw), s = Math.sin(yaw)
    box(wood, x + 0 * c + 0.2 * s, 0.75, z - 0 * s + 0.2 * c, 0.4, 0.5, 0.03, { yaw })
    C.add(x - 0.25, z - 0.25, x + 0.25, z + 0.25, { tall: false })
  }
  const desk = (x, z, sx = 1.4, sz = 0.7, yaw = 0) => {
    const c = Math.abs(Math.cos(yaw)), s = Math.abs(Math.sin(yaw))
    box(wood, x, 0.75, z, sx, 0.05, sz, { yaw })
    box(wood, x, 0.37, z, sx - 0.1, 0.7, sz - 0.1, { yaw, tile: [1, 1] })
    C.add(x - (sx * c + sz * s) / 2, z - (sx * s + sz * c) / 2, x + (sx * c + sz * s) / 2, z + (sx * s + sz * c) / 2, { tall: false })
  }
  const rotBox = (x, z, sx, sz, yaw) => {
    const c = Math.abs(Math.cos(yaw)), s = Math.abs(Math.sin(yaw))
    const hx = (sx * c + sz * s) / 2, hz = (sx * s + sz * c) / 2
    return [x - hx, z - hz, x + hx, z + hz]
  }
  const cabinet = (x, z, yaw = 0, w = 0.5, d = 0.6, h = 1.3) => {
    box(metal, x, h / 2, z, w, h, d, { yaw })
    const c = Math.cos(yaw), s = Math.sin(yaw)
    for (let i = 0; i < 3; i++) box(solid(0x1a1a18, 0.6), x + s * (d / 2), h * (0.2 + i * 0.3), z + c * (d / 2), w * 0.9, 0.012, 0.012, { yaw })
    C.add(...rotBox(x, z, w, d, yaw), { tall: h > 1.4 })
  }
  const shelfRack = (x, z, len, yaw = 0, boxesOn = true) => {
    // a steel rack with brown archive boxes. (t along the rack, dz depth) -> world
    const c = Math.cos(yaw), s = Math.sin(yaw)
    const P = (t, dz) => [x + t * c + dz * s, z - t * s + dz * c]
    for (const t of [-len / 2, len / 2]) for (const dz of [-0.28, 0.28]) { const [px, pz] = P(t, dz); box(metal, px, 1.1, pz, 0.05, 2.2, 0.05, { yaw }) }
    for (let lv = 0; lv < 5; lv++) {
      const y = 0.25 + lv * 0.45
      box(metal, x, y, z, len, 0.03, 0.6, { yaw })
      if (boxesOn) {
        let t = -len / 2 + 0.2
        while (t < len / 2 - 0.2) {
          const bw = 0.28 + rng() * 0.18
          if (rng() < 0.85) { const [px, pz] = P(t + bw / 2, 0); box(solid(0x7a6444 + (Math.floor(rng() * 4) << 8), 0.9), px, y + 0.16, pz, bw, 0.28 + rng() * 0.06, 0.4, { yaw }) }
          t += bw + 0.03 + rng() * 0.07
        }
      }
    }
    C.add(...rotBox(x, z, len, 0.6, yaw), { tall: true })
  }
  /** a hospital bed: raised frame so the player can crawl under */
  const bed = (x, z, head = 1, { strapped = false } = {}) => {
    for (const lx of [-0.44, 0.44]) for (const lz of [-0.95, 0.95]) box(metal, x + lx, 0.25, z + lz, 0.04, 0.5, 0.04)
    box(metal, x, 0.52, z, 0.94, 0.04, 2.0, {}) // spring frame
    box('mattress', x, 0.62, z, 0.88, 0.16, 1.9, { tile: [1 / 1.2, 1 / 1.2] })
    box('blanket', x, 0.72, z - head * 0.2, 0.9, 0.06, 1.2, { tile: [1 / 1, 1 / 1] })
    box(solid(0xcfc8b4, 0.9), x, 0.74, z + head * 0.78, 0.5, 0.1, 0.32) // pillow
    box(metal, x, 0.95, z + head * 1.0, 0.94, 0.5, 0.03) // headboard
    if (strapped) for (const dz of [-0.2, 0.4]) { box(solid(0x3a2d22, 0.8), x, 0.7, z + dz, 1.0, 0.012, 0.08) }
    C.add(x - 0.5, z - 1.05, x + 0.5, z + 1.05, { tall: false })
    W.hides.push({ id: `bed${W.hides.length}`, kind: 'bed', x, z, camY: 0.34, face: 0 })
  }
  const nightstand = (x, z, yaw = 0) => {
    prop(wood, x, z, 0.45, 0.55, 0.4, { yaw })
    spot('stand', x, 0.55, z)
  }
  const wheelchair = (x, z, yaw = 0) => {
    const c = Math.cos(yaw), s = Math.sin(yaw)
    for (const sd of [-1, 1]) {
      M.cyl(rustMetal, x + c * sd * 0.3, 0.3, z - s * sd * 0.3, 0.3, 0.025, { axis: 'x', segs: 14, caps: true })
    }
    box(solid(0x23252a, 0.7), x, 0.5, z, 0.46, 0.05, 0.42, { yaw })
    box(solid(0x23252a, 0.7), x - s * 0.2, 0.78, z - c * 0.2, 0.46, 0.5, 0.04, { yaw })
    C.add(x - 0.4, z - 0.4, x + 0.4, z + 0.4, { tall: false })
  }
  const iv = (x, z) => {
    M.cyl(metal, x, 0.9, z, 0.012, 1.8, { segs: 6 })
    M.cyl(metal, x, 0.03, z, 0.28, 0.03, { segs: 10 })
    box(solid(0xcfd4cc, 0.2), x, 1.6, z, 0.12, 0.2, 0.04)
    C.add(x - 0.15, z - 0.15, x + 0.15, z + 0.15, { tall: false })
  }
  const crate = (x, z, s = 0.5, yaw = 0) => prop(solid(0x6a5a3e, 0.9), x, z, s, s * 0.8, s, { yaw })
  const litterPaper = (x, z, n = 8, r = 1.5) => {
    for (let i = 0; i < n; i++) {
      const px = x + (rng() - 0.5) * 2 * r, pz = z + (rng() - 0.5) * 2 * r
      if (C.near(px, pz, 0.1).size && [...C.near(px, pz, 0.1)].some(c => px > c.x1 && px < c.x2 && pz > c.z1 && pz < c.z2)) continue
      box(paper, px, 0.004 + i * 0.0005, pz, 0.21, 0.003, 0.297, { yaw: rng() * 6.28 })
    }
  }
  const locker = (x, z, yaw, id) => {
    // a steel locker you can hide in: five panels and a swinging door. yaw 0 faces +z.
    const c = Math.cos(yaw), s = Math.sin(yaw)
    const w = 0.55, d = 0.55, h = 1.95, th = 0.03
    const W2 = (lx, lz, sx, sz) => ({ x: x + lx * c + lz * s, z: z - lx * s + lz * c, sx, sz })
    const back = W2(0, -d / 2 + th / 2, w, th), left = W2(-w / 2 + th / 2, 0, th, d), right = W2(w / 2 - th / 2, 0, th, d)
    for (const p of [back, left, right]) box(metal, p.x, h / 2, p.z, p.sx, h, p.sz, { yaw })
    box(metal, x, h - th / 2, z, w, th, d, { yaw }); box(metal, x, th / 2, z, w, th, d, { yaw })
    const doorGeo = new THREE.BoxGeometry(w - 0.02, h - 0.04, 0.025)
    doorGeo.translate((w - 0.02) / 2, (h - 0.04) / 2 + 0.02, 0)
    const door = new THREE.Mesh(doorGeo, surface('locker'))
    door.castShadow = true; door.receiveShadow = true
    const pivot = new THREE.Group()
    pivot.position.set(x + (-w / 2) * c + (d / 2) * s, 0, z - (-w / 2) * s + (d / 2) * c)
    pivot.rotation.y = yaw
    pivot.add(door)
    dyn.add(pivot)
    C.add(...rotBox(x, z, w, d, yaw), { tall: true })
    const hide = { id, kind: 'locker', x, z, yaw, camY: 1.55, pivot, open: 0, target: 0 }
    W.hides.push(hide)
    return hide
  }

  // decals
  function decal (kind, x, y, z, w, h, { yaw = 0, pitch = 0, opacity = 1 } = {}) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({
      map: decalTexture(kind), transparent: true, opacity, roughness: kind === 'grime' ? 0.9 : 0.35, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
    }))
    m.position.set(x, y, z)
    m.rotation.set(pitch, yaw, 0, 'YXZ')
    m.receiveShadow = true
    dyn.add(m)
    W.decals.push(m)
    return m
  }
  const wallDecal = (kind, ax, c, at, y, w, h, side = 1, o = {}) => {
    // ax 'x' wall along x at z=c; side = which way the wall faces (+1 toward +z / +x)
    if (ax === 'x') decal(kind, at, y, c + side * (T / 2 + 0.004), w, h, { yaw: side > 0 ? 0 : Math.PI, ...o })
    else decal(kind, c + side * (T / 2 + 0.004), y, at, w, h, { yaw: side > 0 ? Math.PI / 2 : -Math.PI / 2, ...o })
  }
  const floorDecal = (kind, x, z, w, h, o = {}) => decal(kind, x, 0.012, z, w, h, { pitch: -Math.PI / 2, yaw: o.rot ?? rng() * 6.28, ...o })

  // ═════════ lobby ═════════
  {
    // reception desk (L-shape) and the things on it
    prop(wood, -3.6, -8.4, 3.4, 1.05, 0.7)
    prop(wood, -5.35, -7.6, 0.7, 1.05, 1.6)
    box(wood, -3.6, 1.07, -8.4, 3.5, 0.05, 0.8)
    spot('wardKey', -3.0, 1.1, -8.4, { group: 'lobby' })
    spot('battery', -4.4, 1.1, -8.45)
    // the old phone (rings later)
    box(solid(0x14120f, 0.4), -2.4, 1.14, -8.3, 0.22, 0.1, 0.2)
    box(solid(0x14120f, 0.4), -2.4, 1.2, -8.3, 0.2, 0.04, 0.06, {})
    W.phonePos = { x: -2.4, y: 1.15, z: -8.3 }
    // waiting chairs
    for (let i = 0; i < 5; i++) chair(-6 + i * 0.7, -2.4, Math.PI + (rng() - 0.5) * 0.3, i === 3)
    for (let i = 0; i < 4; i++) chair(2.5 + i * 0.7, -2.4, Math.PI + (rng() - 0.5) * 0.3, false)
    spot('wardKey', 3.1, 0.47, -2.4, { group: 'lobby' }) // a chair seat
    wheelchair(5.2, -9.4, 2.6)
    // a dead plant and a rug of litter
    prop(solid(0x4a3a2c, 0.9), 6.9, -1.0, 0.5, 0.45, 0.5)
    for (let i = 0; i < 5; i++) box(solid(0x2b2a1e, 0.9), 6.9 + (rng() - 0.5) * 0.3, 0.75 + i * 0.12, -1.0 + (rng() - 0.5) * 0.3, 0.02, 0.5, 0.02, { yaw: i })
    // a fallen ceiling slab by the stairs
    box(solid(0x6a665c, 0.95), 3.2, 0.1, -9.6, 1.0, 0.2, 0.7, { yaw: 0.4 })
    litterPaper(0, -6, 26, 6)
    // front doors: chain across the handles
    const fd = W.doors.find(d => d.id === 'front')
    // (separate meshes, not merged, so the chain can come off when it is cut)
    W.chainGroup = new THREE.Group()
    const chainMat = surface(solid(0x2b2d2e, 0.35, 0.9))
    const linkGeo = new THREE.TorusGeometry(0.03, 0.0085, 6, 10)
    for (let i = 0; i < 22; i++) {
      const t = -0.82 + i * (1.64 / 21)
      const link = new THREE.Mesh(linkGeo, chainMat)
      link.position.set(t, 1.05 + Math.sin(i * 1.3) * 0.03, -0.1)
      link.rotation.set(0, i % 2 ? Math.PI / 2 : 0, 0.2)
      link.scale.set(1, 1.5, 1)
      link.castShadow = true
      W.chainGroup.add(link)
    }
    const lock = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.2, 0.08), surface(solid(0x3a3d3e, 0.3, 0.9)))
    lock.position.set(0, 1.0, -0.1); lock.castShadow = true
    W.chainGroup.add(lock)
    dyn.add(W.chainGroup)
    spot('chain', 0, 1.05, -0.22)
    // moon patches through the windows
    for (const wx of [-5, 5]) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 4.2), new THREE.MeshBasicMaterial({ map: moonPatch(), transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false, fog: true }))
      m.rotation.x = -Math.PI / 2
      m.position.set(wx + 0.3, 0.02, -2.4)
      dyn.add(m)
    }
    // marks
    wallDecal('smear', 'x', -12, -5, 1.4, 2.0, 1.5, 1)
    wallDecal('text:NOT|SAFE', 'z', -8, -3.8, 1.5, 2.2, 2.2, 1)
  }
  function moonPatch () {
    const c = document.createElement('canvas'); c.width = 128; c.height = 256
    const g = c.getContext('2d')
    g.fillStyle = '#000'; g.fillRect(0, 0, 128, 256)
    const grad = g.createLinearGradient(0, 0, 0, 256)
    grad.addColorStop(0, 'rgba(120,150,200,.9)'); grad.addColorStop(1, 'rgba(120,150,200,0)')
    g.fillStyle = grad
    // window mullion shadows
    for (let i = 0; i < 4; i++) g.fillRect(10 + i * 28, 0, 22, 256)
    g.globalCompositeOperation = 'destination-out'
    g.fillRect(0, 100, 128, 6)
    const t = new THREE.CanvasTexture(c)
    return t
  }

  // ═════════ admissions office ═════════
  {
    desk(-13.5, -4.5, 2.0, 0.8)
    spot('wardKey', -13.2, 0.8, -4.5, { group: 'admissions' })
    chair(-13.5, -3.6, Math.PI, false)
    cabinet(-15.4, -9.5, Math.PI / 2); cabinet(-15.4, -8.7, Math.PI / 2)
    cabinet(-9.2, -2.2, -Math.PI / 2, 0.5, 0.6, 1.3)
    shelfRack(-12.5, -10.3, 2.4, 0, true)
    // key board on the wall (hooks, mostly empty)
    box(wood, -11.2, 1.5, -1.12, 0.8, 0.6, 0.03)
    for (let i = 0; i < 6; i++) box(solid(0xb09a60, 0.4, 0.8), -11.5 + i * 0.12, 1.55, -1.1, 0.02, 0.04, 0.03)
    spot('wardKey', -11.2, 1.45, -1.3, { group: 'admissions' })
    spot('battery', -9.4, 0.85, -2.2)
    spot('note1', -13.9, 0.82, -4.8, { id: 'n1' })
    litterPaper(-12, -6, 16, 3.5)
    wallDecal('grime', 'x', -11, -13, 2.3, 4, 1.5, 1)
  }
  // ═════════ pharmacy ═════════
  {
    prop(wood, 12, -2.4, 6.2, 1.05, 0.6)
    box(wood, 12, 1.07, -2.4, 6.3, 0.05, 0.7)
    shelfRack(10, -10.4, 3.0, 0, false); shelfRack(14, -10.4, 3.0, 0, false)
    for (let i = 0; i < 26; i++) {
      const x = 8.8 + rng() * 6.2
      const lv = Math.floor(rng() * 5)
      box(solid(0x6a4a1c + (Math.floor(rng() * 3) << 12), 0.35), x, 0.4 + lv * 0.45, -10.35, 0.07, 0.14, 0.07)
    }
    spot('battery', 12.6, 1.1, -2.4)
    spot('wardKey', 9.4, 1.1, -2.4, { group: 'pharmacy' })
    prop(solid(0x8a8c88, 0.4, 0.5), 15.4, -6, 0.5, 1.5, 0.8, { tall: true })
    litterPaper(12, -6, 12, 3)
    wallDecal('stain', 'x', -1, 11, 1.2, 2.4, 2.4, -1)
  }

  // ═════════ lockers along the corridors ═════════
    const lk = (x, z, facing, id) => locker(x, z, facing === 'E' ? Math.PI / 2 : facing === 'W' ? -Math.PI / 2 : facing === 'S' ? 0 : Math.PI, id)

  // ═════════ patient rooms ═════════
  const cells = [] // E ward isolation cells
  for (const wr of wingRooms) {
    const r = wr.r
    const east = wr.side > 0
    const back = wr.north ? r.z1 + 0.35 : r.z2 - 0.35
    const toward = wr.north ? 1 : -1 // direction from the back wall toward the corridor
    const headDir = wr.north ? -1 : 1
    const isCell = east && (wr.i === 1 || wr.i === 3) && wr.north
    const isDay = !east && wr.i === 3 && !wr.north
    const isWash = !east && wr.i === 3 && wr.north
    if (isWash) { washroom(r); continue }
    if (isDay) { dayRoom(r); continue }
    if (isCell) {
      // padded cell: a bolted bed with straps, mattresses on the walls
      cells.push(r)
      bed(r.cx, r.cz + (wr.north ? -1.2 : 1.2), headDir, { strapped: true })
      for (const dz of [r.z1 + 0.15, r.z2 - 0.15]) box('mattress', r.cx, 1.3, dz, 5.6, 2.2, 0.1, { tile: [1 / 1.2, 1 / 1.2] })
      for (const dx of [r.x1 + 0.15, r.x2 - 0.15]) box('mattress', dx, 1.3, r.cz, 0.1, 2.2, 7.6, { tile: [1 / 1.2, 1 / 1.2] })
      wallDecal('scratch', 'z', r.x1 + 0.1, r.cz, 1.4, 1.4, 1.4, 1, { opacity: 0.8 })
      continue
    }
    // ordinary room
    const bx = r.cx + (rng() < 0.5 ? -1.5 : 1.5)
    bed(bx, back + toward * 1.2 * 0 + (wr.north ? 1.05 : -1.05), headDir)
    nightstand(bx + (bx < r.cx ? 0.95 : -0.95), back + (wr.north ? 0.28 : -0.28))
    if (rng() < 0.7) chair(r.cx + (bx < r.cx ? 1.6 : -1.6), r.cz + toward * 0.6, rng() * 6)
    if (rng() < 0.55) cabinet(r.x1 + 0.45 + (bx > r.cx ? 0 : 4.6), r.cz + toward * 1.4, wr.north ? 0 : Math.PI)
    if (rng() < 0.4) iv(bx + (bx < r.cx ? 1.5 : -1.5), r.cz)
    if (rng() < 0.3) wheelchair(r.cx + (rng() - 0.5) * 2, r.cz + toward * 1.8, rng() * 6)
    // curtain track and a drawn curtain
    if (rng() < 0.5) box(solid(0x6a7a7c, 0.9), bx + (bx < r.cx ? 0.9 : -0.9), 1.5, back + (wr.north ? 1.6 : -1.6), 0.03, 2.1, 1.8, { yaw: Math.PI / 2 })
    litterPaper(r.cx, r.cz, 6, 2.2)
    if (rng() < 0.5) wallDecal(pick(['smear', 'stain', 'scratch', 'hand']), 'x', wr.north ? -35.2 : -16, r.cx + (rng() - 0.5) * 3, 1.3, 1.6, 1.6, wr.north ? 1 : -1)
    if (rng() < 0.18) wallDecal(pick(['text:HE|HUMS', 'text:STAY|STILL', 'text:DON\'T|SLEEP', 'text:NOT|ALONE']), 'z', east ? r.x2 : r.x1, r.cz, 1.5, 2.0, 2.0, east ? -1 : 1)
    spot('recordsKey', bx + (bx < r.cx ? 0.95 : -0.95), 0.58, back + (wr.north ? 0.28 : -0.28), { group: 'room', room: r.id, wing: east ? 'E' : 'W' })
    spot('battery', r.cx + (rng() - 0.5) * 3, 0.03, r.cz + (rng() - 0.5) * 4)
    spot('bottle', r.cx + (rng() - 0.5) * 3, 0.03, r.cz + toward * 2)
    spot('bottle', r.x1 + 0.4, 0.03, r.cz + (rng() - 0.5) * 3)
  }
  // lockers (now that lk exists)
  lk(-1.225, -16, 'E', 'l1'); lk(1.225, -19, 'W', 'l2')
  lk(-1.225, -31, 'E', 'l3'); lk(1.225, -33.5, 'W', 'l4')
  lk(-12, -26.825, 'S', 'l5'); lk(-20, -24.375, 'N', 'l6')
  lk(8.6, -26.825, 'S', 'l7'); lk(18, -24.375, 'N', 'l8')
  lk(27.3, -45.625, 'S', 'l9')
  // note in the west ward (a patient diary under a pillow-ish spot) and the east
  spot('note3', -17.4, 0.58, -34.3, { id: 'n3' })
  spot('note4', 16.2, 0.58, -34.3, { id: 'n4' })

  function washroom (r) {
    // toilet stalls on the back wall, sinks on the side
    for (let i = 0; i < 3; i++) {
      const x = r.x1 + 1 + i * 1.7
      box(solid(0xbfc3be, 0.3), x, 0.2, r.z1 + 0.5, 0.42, 0.4, 0.55)
      box(solid(0xbfc3be, 0.3), x, 0.55, r.z1 + 0.2, 0.4, 0.4, 0.2)
      C.add(x - 0.25, r.z1, x + 0.25, r.z1 + 0.8, { tall: false })
      if (i < 2) box(solid(0x7a8a86, 0.5, 0.2), x + 0.85, 0.95, r.z1 + 1.1, 0.03, 1.9, 2.0, { yaw: 0 })
    }
    for (let i = 0; i < 2; i++) {
      const z = r.z2 - 1.5 - i * 1.2
      box(solid(0xcfd1cc, 0.25), r.x2 - 0.3, 0.85, z, 0.45, 0.12, 0.55)
      box(solid(0x9a9c98, 0.3, 0.6), r.x2 - 0.15, 1.9, z, 0.03, 0.8, 0.7) // mirror
    }
    C.add(r.x2 - 0.6, r.z2 - 3.4, r.x2, r.z2 - 0.7, { tall: false })
    floorDecal('stain', r.cx + 0.6, r.cz + 1, 2.6, 2.6, { opacity: 0.8 })
    wallDecal('hand', 'x', r.z2, r.cx - 1, 1.3, 1.0, 1.0, -1)
    spot('note2', r.x1 + 1.0, 0.45, r.z1 + 0.5, { id: 'n2' })
    spot('battery', r.cx, 0.03, r.cz)
  }
  function dayRoom (r) {
    // couches in a ring around a dead TV
    const mk = (x, z, w, d, yaw = 0) => { prop('blanket', x, z, w, 0.5, d, { yaw }); box('blanket', x, 0.75, z + (yaw === 0 ? (d > 0.9 ? 0 : 0.0) : 0), w, 0.5, 0.25, { yaw }) }
    mk(r.cx, r.z2 - 1.4, 2.2, 0.9)
    mk(r.x1 + 0.8, r.cz, 0.9, 2.0, Math.PI / 2 * 0)
    prop(wood, r.cx, r.cz - 0.4, 1.2, 0.45, 0.7)
    prop(solid(0x151515, 0.3), r.x2 - 0.9, r.z1 + 1.0, 0.7, 1.4, 0.6, { tall: false })
    box(solid(0x0a0a0a, 0.2), r.x2 - 0.9, 1.65, r.z1 + 1.0, 0.6, 0.5, 0.5)
    box(solid(0x050505, 0.1), r.x2 - 0.9, 1.65, r.z1 + 1.26, 0.52, 0.42, 0.02)
    for (let i = 0; i < 3; i++) chair(r.cx - 1.6 + i * 1.5, r.cz + 1.0, 0.6 * i, i === 1)
    litterPaper(r.cx, r.cz, 14, 2.5)
    wallDecal('smear', 'x', r.z2, r.cx + 1, 1.2, 2, 1.4, -1)
    spot('battery', r.cx, 0.45, r.cz - 0.4)
    spot('bottle', r.cx + 1, 0.03, r.cz + 1)
    spot('recordsKey', r.cx, 0.47, r.cz - 0.4, { group: 'room', room: r.id, wing: 'W' })
  }

  // ═════════ records room ═════════
  {
    const r = rec
    for (let i = 0; i < 3; i++) shelfRack(-4 + i * 4, -42.5, 3.4, Math.PI / 2, true)
    for (let i = 0; i < 2; i++) shelfRack(-2 + i * 4, -39, 3.2, 0, true)
    shelfRack(0, -47.35, 8, 0, true)
    shelfRack(-8.3, -42, 6, Math.PI / 2, true); shelfRack(8.3, -42, 6, Math.PI / 2, true)
    desk(5.2, -38, 1.8, 0.8)
    chair(5.2, -37.1, Math.PI, true)
    spot('annexKey', 5.2, 0.8, -38, { group: 'records' })
    spot('annexKey', -2.2, 0.0, -44.5, { group: 'records' })
    spot('annexKey', 7.6, 1.32, -44.8, { group: 'records' })
    spot('annexKey', -7.1, 0.04, -38.5, { group: 'records' })
    spot('note5', 4.8, 0.82, -38.2, { id: 'n5' })
    spot('battery', -6.5, 0.04, -37.5)
    spot('battery', 2, 0.03, -44)
    litterPaper(0, -42, 40, 7)
    cabinet(-7.5, -37.1, 0); cabinet(-8.2, -37.1, 0)
    wallDecal('text:CASE|NINE', 'x', -36, -4, 1.6, 2.4, 2.4, -1)
    floorDecal('stain', 1, -41, 2.6, 2.6)
  }

  // ═════════ annex: maintenance and morgue ═════════
  {
    // pipes along the ceiling of the annex corridor
    for (const z of [-30, -34, -38, -42]) M.cyl(rustMetal, 27.3, 3.0, z, 0.08, 3.2, { axis: 'x', segs: 8 })
    for (const dz of [0]) M.cyl(rustMetal, 26.0, 2.9, -34, 0.07, 24, { axis: 'z', segs: 8 })
    // maintenance: boiler, bench, shelves
    M.cyl(rustMetal, 35, 1.1, -28.5, 0.7, 2.2, { segs: 14 }); C.add(34.3, -29.2, 35.7, -27.8, { tall: true })
    prop(wood, 31, -29.3, 2.0, 0.9, 0.7)
    shelfRack(36.4, -25.5, 2.4, Math.PI / 2, false)
    spot('boltCutters', 31, 0.92, -29.3, { group: 'maint' })
    spot('boltCutters', 36.4, 0.46, -24.8, { group: 'maint' })
    spot('battery', 30.2, 0.03, -23)
    spot('bottle', 35, 0.03, -23.2)
    crate(30, -23, 0.6); crate(30.6, -23.4, 0.5, 0.5)
    // morgue: drawer wall, slabs, the covered one
    for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) {
      box(solid(0xa9aea8, 0.3, 0.8), 40.82, 0.5 + r * 0.55, -44.3 + c * 0.55, 0.06, 0.48, 0.5)
      box(solid(0x3a3d3a, 0.3, 0.8), 40.78, 0.5 + r * 0.55, -44.3 + c * 0.55, 0.02, 0.05, 0.14)
    }
    C.add(40.5, -45, 41, -42, { tall: true })
    for (const [x, z] of [[33, -40], [36.5, -40]]) {
      for (const dx of [-0.35, 0.35]) for (const dz of [-0.9, 0.9]) box(metal, x + dx, 0.4, z + dz, 0.05, 0.8, 0.05)
      box('metal#c8ccc8', x, 0.84, z, 0.85, 0.06, 2.0)
      C.add(x - 0.5, z - 1.05, x + 0.5, z + 1.05, { tall: false })
    }
    // the sheet-covered shape on the left slab
    box(solid(0xcfcab8, 0.9), 33, 1.0, -40, 0.62, 0.22, 1.7)
    box(solid(0xcfcab8, 0.9), 33, 1.08, -40.6, 0.34, 0.28, 0.4)
    spot('boltCutters', 36.5, 0.9, -40.6, { group: 'morgue' })
    spot('boltCutters', 33.4, 0.04, -35, { group: 'morgue' })
    spot('note6', 31.2, 0.82, -44.8, { id: 'n6' })
    spot('battery', 38, 0.03, -34.5)
    prop(metal, 31.2, -44.8, 1.3, 0.8, 0.7)
    floorDecal('stain', 35, -39.5, 3.6, 3.6, { rot: 0.4 })
    wallDecal('smear', 'x', -33, 36, 1.3, 2.4, 1.6, -1)
    wallDecal('hand', 'x', -46, 33, 1.3, 1.0, 1.0, 1)
    // drain
    box(solid(0x0e0f0e, 0.4, 0.6), 35, 0.005, -39.5, 0.3, 0.005, 0.3)
  }

  // ═════════ wing dressing in the corridors ═════════
  {
    wheelchair(-8, -25.6, 0.4)
    chair(-16, -25.9, 2.2, true)
    box(solid(0x6a665c, 0.95), 4, 0.1, -25.4, 0.9, 0.2, 0.6, { yaw: 0.3 }) // fallen plaster
    box(metal, 12, 0.5, -26.4, 0.9, 0.04, 1.9, { yaw: Math.PI / 2 }) // gurney (rolled aside)
    for (const dx of [-0.4, 0.4]) M.cyl(solid(0x1a1a1a, 0.6), 12 + dx * 2, 0.08, -26.5, 0.08, 0.04, { axis: 'z', segs: 8 })
    litterPaper(-12, -25.6, 20, 12)
    litterPaper(14, -25.6, 14, 10)
    litterPaper(0, -18, 12, 1.3)
    litterPaper(0, -31, 10, 1.3)
    wallDecal('smear', 'x', -24, -16, 1.3, 2.2, 1.5, -1)
    wallDecal('text:IT|KNOWS', 'z', -1.6, -20, 1.5, 2.4, 2.2, 1)
    wallDecal('scratch', 'x', -27.2, 15, 1.4, 1.2, 1.4, 1)
    wallDecal('hand', 'z', 1.6, -31, 1.3, 0.9, 0.9, -1)
    wallDecal('grime', 'x', -27.2, -14, 2.3, 5, 1.6, 1)
    wallDecal('grime', 'x', -24, 6, 2.3, 5, 1.6, -1)
  }
  function sign (text, ax, c, at, y, side) {
    const cv = document.createElement('canvas'); cv.width = 512; cv.height = 128
    const g = cv.getContext('2d')
    g.fillStyle = '#c9c3a8'; g.fillRect(0, 0, 512, 128)
    g.fillStyle = '#1a1a18'; g.textAlign = 'center'; g.textBaseline = 'middle'
    let fs = 64; g.font = `700 ${fs}px "Barlow Condensed", "Arial Narrow", sans-serif`
    while (g.measureText(text).width > 470 && fs > 20) { fs -= 4; g.font = `700 ${fs}px "Barlow Condensed", "Arial Narrow", sans-serif` }
    g.fillText(text, 256, 68)
    g.strokeStyle = '#3a3a30'; g.lineWidth = 6; g.strokeRect(3, 3, 506, 122)
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.35), new THREE.MeshStandardMaterial({ map: t, roughness: 0.6 }))
    if (ax === 'x') { m.position.set(at, y, c + side * (T / 2 + 0.005)); m.rotation.y = side > 0 ? 0 : Math.PI } else { m.position.set(c + side * (T / 2 + 0.005), y, at); m.rotation.y = side > 0 ? Math.PI / 2 : -Math.PI / 2 }
    dyn.add(m)
  }
  sign('WEST WARD', 'x', -27.2, -8, 2.55, 1)
  sign('EAST WARD', 'x', -27.2, 8, 2.55, 1)
  sign('RECORDS', 'x', -36, 0, 2.6, 1)
  sign('ANNEX', 'z', 25.6, -25.6, 2.7, -1)
  sign('ST. AMBROSE STATE HOSPITAL', 'x', -12, 0, 2.7, 1)

  // ═════════ lamps ═════════
  const lampGeo = new THREE.BoxGeometry(1.2, 0.05, 0.22)
  const deadMat = new THREE.MeshStandardMaterial({ color: 0x1a1b1a, roughness: 0.7 })
  const redMat = new THREE.MeshBasicMaterial({ color: 0xff2a1a })
  function lamp (x, z, state, o = {}) {
    const l = { x, y: H - 0.1, z, state, base: o.base ?? 1, color: o.color ?? 0xfff0d0, phase: rng() * 100, flick: o.flick ?? 0, on: state !== 'dead', mesh: null, mat: null, red: state === 'red', room: W.roomAt(x, z)?.id }
    const mat = state === 'dead' ? deadMat : state === 'red' ? redMat : new THREE.MeshStandardMaterial({ color: 0x222222, emissive: l.color, emissiveIntensity: 1.2, roughness: 0.4 })
    const mesh = new THREE.Mesh(state === 'red' ? new THREE.SphereGeometry(0.09, 10, 8) : lampGeo, mat)
    mesh.position.set(x, state === 'red' ? H - 0.25 : H - 0.04, z)
    if (o.rot) mesh.rotation.y = o.rot
    dyn.add(mesh)
    l.mesh = mesh; l.mat = mat
    W.lamps.push(l)
    return l
  }
  // lobby: one tube buzzing
  lamp(-3, -6, 'flicker', { flick: 0.9, base: 0.8 }); lamp(3, -6, 'dead'); lamp(0, -2, 'dead')
  // corridors: a few live, many dead
  lamp(0, -15, 'flicker', { flick: 0.5, base: 0.7 }); lamp(0, -20, 'dead')
  lamp(0, -23, 'red', { color: 0xff2a1a, base: 0.6 })
  lamp(0, -31, 'dead'); lamp(0, -35, 'flicker', { flick: 0.7, base: 0.6 })
  for (let x = -22; x <= 22; x += 6) {
    if (Math.abs(x) < 2) continue
    const r = rng()
    lamp(x, -25.6, r < 0.35 ? 'flicker' : r < 0.45 ? 'on' : 'dead', { flick: 0.4 + rng() * 0.6, base: 0.55, rot: Math.PI / 2 })
  }
  lamp(-23, -25.6, 'red', { color: 0xff2a1a, base: 0.5 }); lamp(23, -25.6, 'red', { color: 0xff2a1a, base: 0.5 })
  // rooms: mostly dead, an odd one alive
  for (const wr of wingRooms) {
    const r = wr.r
    const st = rng() < 0.12 ? 'flicker' : 'dead'
    lamp(r.cx, r.cz, st, { flick: 0.8, base: 0.5 })
  }
  lamp(-12, -6, 'on', { base: 0.4, color: 0xffd8a0 })
  lamp(12, -6, 'dead')
  lamp(0, -42, 'dead'); lamp(-4, -44, 'flicker', { flick: 0.9, base: 0.6 })
  lamp(27.3, -30, 'dead'); lamp(27.3, -40, 'flicker', { flick: 0.8, base: 0.6 }); lamp(27.3, -44, 'red', { color: 0xff2a1a, base: 0.5 })
  lamp(33, -26, 'dead'); lamp(35, -39.5, 'flicker', { flick: 1, base: 0.8, color: 0xd6f0e0 })

  // ═════════ navigation ═════════
  W.pois = [
    [0, -6], [0, -18], [0, -31], [-12, -6], [12, -6], [0, -42], [-22, -25.6], [-14, -25.6], [-6, -25.6],
    [6, -25.6], [14, -25.6], [22, -25.6], [27.3, -34], [27.3, -25], [33, -26], [35, -39.5], [-4, -42], [4, -44],
  ]
  for (const wr of wingRooms) {
    if (wr.r.kind === 'patient') W.pois.push([wr.r.cx, wr.r.cz])
  }
  W.zoneOf = (x, z) => {
    if (x > 25.6) return 'annex'
    if (z < -36 && Math.abs(x) < 9) return 'records'
    if (x > 1.6 && z < -16 && z > -36) return 'east'
    return 'main'
  }

  W.build = () => {
    M.build(group, { shadows: HIGH })
    const doorBoxes = W.doors.map(d => ({ x1: d.box.x1, z1: d.box.z1, x2: d.box.x2, z2: d.box.z2, door: d }))
    W.nav = new Nav(C, { ...W.bounds, cell: 0.5, radius: 0.4, isLocked: d => d.locked || d.wedged, doorBoxes })
    // static dressing that does not need to cast
    dyn.traverse(o => { if (o.isMesh && !o.userData.noShadow && o.material !== glassMat && !W.decals.includes(o)) { o.castShadow = o.castShadow || HIGH } })
  }

  // ═════════ runtime ═════════
  W.update = dt => {
    for (const d of W.doors) {
      if (d.chain) { d.open = 0; continue }
      const diff = d.target - d.open
      if (Math.abs(diff) > 0.001) {
        const sp = (d.speedUp ?? 2.2) * dt
        d.open += Math.sign(diff) * Math.min(Math.abs(diff), sp)
        applyDoor(d)
      }
    }
    for (const h of W.hides) {
      if (h.kind !== 'locker') continue
      const diff = h.target - h.open
      if (Math.abs(diff) > 0.001) {
        h.open += Math.sign(diff) * Math.min(Math.abs(diff), 4 * dt)
        h.pivot.rotation.y = h.yaw - h.open * 1.9
      }
    }
  }
  W.setDoor = (d, open) => { d.target = open ? 1 : 0 }
  W.doorById = id => W.doors.find(d => d.id === id)
  W.dispose = () => {
    scene.remove(group)
    group.traverse(o => { if (o.isMesh) o.geometry?.dispose?.() })
  }
  return W
}
