// St. Ambrose: the things you can pick up, the notes you can read, and what the building asks of you.
import * as THREE from 'three'

const std = (color, rough = 0.5, metal = 0) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal })
const metalMat = (c = 0xb9a368) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.28, metalness: 0.95 })

function tagMesh (color, text) {
  const cv = document.createElement('canvas'); cv.width = 128; cv.height = 64
  const g = cv.getContext('2d')
  g.fillStyle = color; g.fillRect(0, 0, 128, 64)
  g.fillStyle = '#1a1a14'; g.font = '700 34px "Special Elite", monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'
  g.fillText(text, 64, 34)
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace
  return new THREE.Mesh(new THREE.PlaneGeometry(0.06, 0.03), new THREE.MeshStandardMaterial({ map: t, roughness: 0.8, side: THREE.DoubleSide }))
}

export function itemMesh (kind) {
  const g = new THREE.Group()
  if (kind === 'wardKey' || kind === 'recordsKey' || kind === 'annexKey') {
    const col = kind === 'wardKey' ? 0xc8a050 : kind === 'recordsKey' ? 0xc4c8c4 : 0x3a3a3c
    const label = kind === 'wardKey' ? ['#c8483a', 'W'] : kind === 'recordsKey' ? ['#7ab06a', 'R'] : ['#d8c040', 'A']
    const m = metalMat(col)
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.022, 0.003, 6, 16), metalMat(0xb0b0b0)); ring.rotation.x = Math.PI / 2; ring.position.set(-0.04, 0.005, 0); g.add(ring)
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.004, 0.011), m); shaft.position.set(0.02, 0.004, 0); g.add(shaft)
    for (let i = 0; i < 3; i++) { const t = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.004, 0.012 + i * 0.002), m); t.position.set(0.045 - i * 0.012, 0.004, 0.011); g.add(t) }
    const tag = tagMesh(label[0], label[1]); tag.rotation.x = -Math.PI / 2; tag.position.set(-0.09, 0.003, 0.01); g.add(tag)
    const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.0015, 0.0015, 0.05, 4), std(0x222222)); cord.rotation.z = Math.PI / 2; cord.position.set(-0.065, 0.004, 0.005); g.add(cord)
    g.scale.setScalar(1.8)
  } else if (kind === 'battery') {
    for (const dx of [-0.02, 0.02]) {
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.0155, 0.0155, 0.095, 12), std(0x1c4a2a, 0.35, 0.3)); b.rotation.z = Math.PI / 2; b.position.set(0, 0.0155, dx); g.add(b)
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 0.01, 10), metalMat(0xc9c9c9)); top.rotation.z = Math.PI / 2; top.position.set(0.052, 0.0155, dx); g.add(top)
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.0158, 0.0158, 0.02, 12), std(0xc8a830, 0.4, 0.2)); band.rotation.z = Math.PI / 2; band.position.set(-0.02, 0.0155, dx); g.add(band)
    }
    g.scale.setScalar(1.7)
  } else if (kind === 'bottle') {
    const glass = new THREE.MeshPhysicalMaterial({ color: 0x4a2a10, roughness: 0.08, metalness: 0, transmission: 0, transparent: true, opacity: 0.88, clearcoat: 1 })
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.032, 0.15, 12), glass); body.position.y = 0.075; g.add(body)
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.028, 0.06, 12), glass); neck.position.y = 0.18; g.add(neck)
    const lip = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.011, 0.015, 10), glass); lip.position.y = 0.217; g.add(lip)
    g.rotation.z = Math.PI / 2; g.position.y = 0.032
    const outer = new THREE.Group(); outer.add(g); return outer
  } else if (kind === 'boltCutters') {
    const red = std(0x8a1c18, 0.55)
    for (const s of [-1, 1]) {
      const h = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, 0.6, 8), red); h.rotation.z = Math.PI / 2; h.position.set(-0.24, 0.02 + s * 0.014, 0); g.add(h)
      const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.16, 8), std(0x15151a, 0.8)); grip.rotation.z = Math.PI / 2; grip.position.set(-0.46, 0.02 + s * 0.014, 0); g.add(grip)
      const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.012, 0.03), metalMat(0x80848a)); jaw.position.set(0.1, 0.02 + s * 0.012, 0); jaw.rotation.z = s * 0.2; g.add(jaw)
    }
    const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.04, 8), metalMat(0x909090)); bolt.rotation.x = Math.PI / 2; bolt.position.set(0.04, 0.02, 0); g.add(bolt)
    g.position.y = 0.012
  } else if (kind === 'note') {
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.004, 0.15), std(0xd8d0b4, 0.9)); p.position.y = 0.003; g.add(p)
    const p2 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.003, 0.14), std(0xc4bc9e, 0.9)); p2.position.y = 0.006; p2.rotation.y = 0.2; g.add(p2)
    g.scale.setScalar(1.3)
  }
  g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true } })
  return g
}

export const ITEM_NAMES = {
  wardKey: 'the ward key', recordsKey: 'the records key', annexKey: 'the annex key', boltCutters: 'the bolt cutters',
  battery: 'a battery', bottle: 'a bottle', note: 'a note',
}

/** reach in metres: things on the floor need you close */
export const KEY_ITEMS = new Set(['wardKey', 'recordsKey', 'annexKey', 'boltCutters'])

export const NOTES = {
  n1: { title: 'Notice to all staff', text: [
    'ST. AMBROSE STATE HOSPITAL',
    'By order of the State this facility closes permanently on 12 March 1993. All residents have been transferred. Ward 9 is sealed and is not to be entered by anyone for any reason.',
    'The East Ward is to be locked. The key is to be returned to Admissions and signed for.',
    'Night staff are reminded that the orderly assigned to the east wing will be retained until the building is cleared.',
  ], sig: 'Dr. M. Hale, Medical Director' },
  n2: { title: 'Scratched on a napkin', text: [
    'Pell has been on nights since 84. He doesnt sleep. Doesnt eat in the canteen. Hums when he walks.',
    'I stopped hearing the humming last week. That is worse.',
    'If you hear it, you have time. If it stops, you dont.',
  ], sig: 'N. Okafor, RN' },
  n3: { title: 'A patient\'s diary', text: [
    'Day 41. He walks the halls with the pipe. Dragging it so we know. I think he wants us to know.',
    'He checks every locker and every bed. Mum always said if you hold still and dont make a sound it cant find you. I hold my breath until I see stars. He is not stupid. But he gets bored.',
    'Throw something. He always goes to look.',
  ], sig: '' },
  n4: { title: 'Sleep study, subject 9', text: [
    'WALTER PELL (staff volunteer). Protocol: continuous wakefulness.',
    'Day 12: hallucinations, hostility. Day 20: no recorded speech. Does not respond to his name. Pupils fixed.',
    'Day 22: subject was not found in the observation room. The restraints were intact. Hale insists we continue with the next cohort.',
    'I have asked to stop. Request denied.',
  ], sig: 'Dr. R. Ibarra' },
  n5: { title: 'Case file 9', text: [
    'Subject 9 was never discharged and was never found.',
    'The night of the closure the east wing doors were locked from the inside. Staff who went in did not report back.',
    'The annex key was taken out of circulation to keep people away from the morgue. If anyone is reading this: the bolt cutters are in the morgue, and the front doors have been chained.',
    'Not by us.',
  ], sig: '' },
  n6: { title: 'Last page', text: [
    'He is not hurting us. He is guarding the door.',
    'He thinks he is keeping us safe in here, and the longer you stay the more he believes it.',
    'Cut the chain and go. Do not stop to look back. Do not film it.',
  ], sig: 'H.' },
}

export const OBJECTIVES = {
  start: 'Find a way out. The front doors are chained.',
  ward: 'Look for a key to the East Ward.',
  records: 'Find the records room key. Try the East Ward.',
  annex: 'Search the records room for the annex key.',
  cutters: 'Find something to cut the chain. Try the annex.',
  cut: 'Go back to the front doors and cut the chain.',
  run: 'RUN.',
}
