// St. Ambrose: static geometry builder (one merged mesh per material), 2D colliders, line of sight
// and a navigation grid for the Orderly.
import * as THREE from 'three'
import { surface } from './textures.js'

// ───────── merged geometry ─────────
const FACES = [
  { n: [1, 0, 0], r: [0, 0, -1], u: [0, 1, 0] },
  { n: [-1, 0, 0], r: [0, 0, 1], u: [0, 1, 0] },
  { n: [0, 0, 1], r: [1, 0, 0], u: [0, 1, 0] },
  { n: [0, 0, -1], r: [-1, 0, 0], u: [0, 1, 0] },
  { n: [0, 1, 0], r: [1, 0, 0], u: [0, 0, -1] },
  { n: [0, -1, 0], r: [1, 0, 0], u: [0, 0, 1] },
]

export class Mesher {
  constructor () { this.b = new Map() }
  bucket (key) {
    let b = this.b.get(key)
    if (!b) { b = { pos: [], nor: [], uv: [], idx: [] }; this.b.set(key, b) }
    return b
  }
  quad (key, p, n, uv) {
    const b = this.bucket(key)
    const base = b.pos.length / 3
    for (let i = 0; i < 4; i++) { b.pos.push(p[i][0], p[i][1], p[i][2]); b.nor.push(n[0], n[1], n[2]); b.uv.push(uv[i][0], uv[i][1]) }
    b.idx.push(base, base + 1, base + 2, base, base + 2, base + 3)
  }
  /** A box centred at (cx,cy,cz). tile = metres→uv scale (world-space mapping); fit = stretch 0..1 across each face. */
  box (key, cx, cy, cz, sx, sy, sz, { yaw = 0, tile = [1, 1], off = [0, 0], fit = false, skip = [] } = {}) {
    const hx = sx / 2, hy = sy / 2, hz = sz / 2
    const c = Math.cos(yaw), s = Math.sin(yaw)
    const rot = v => [v[0] * c + v[2] * s, v[1], -v[0] * s + v[2] * c]
    FACES.forEach((f, fi) => {
      if (skip.includes(fi)) return
      const n = rot(f.n), r = rot(f.r), u = rot(f.u)
      const hn = Math.abs(f.n[0]) * hx + Math.abs(f.n[1]) * hy + Math.abs(f.n[2]) * hz
      const hr = Math.abs(f.r[0]) * hx + Math.abs(f.r[1]) * hy + Math.abs(f.r[2]) * hz
      const hu = Math.abs(f.u[0]) * hx + Math.abs(f.u[1]) * hy + Math.abs(f.u[2]) * hz
      const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, b]) => [
        cx + n[0] * hn + r[0] * hr * a + u[0] * hu * b,
        cy + n[1] * hn + r[1] * hr * a + u[1] * hu * b,
        cz + n[2] * hn + r[2] * hr * a + u[2] * hu * b,
      ])
      const uv = fit
        ? [[0, 0], [1, 0], [1, 1], [0, 1]]
        : corners.map(p => [(p[0] * r[0] + p[1] * r[1] + p[2] * r[2] + off[0]) * tile[0], (p[0] * u[0] + p[1] * u[1] + p[2] * u[2] + off[1]) * tile[1]])
      this.quad(key, corners, n, uv)
    })
  }
  /** Horizontal rectangle (floor faces up, ceiling faces down) */
  rect (key, x1, z1, x2, z2, y, up = true, tile = 1 / 3) {
    const p = up
      ? [[x1, y, z2], [x2, y, z2], [x2, y, z1], [x1, y, z1]]
      : [[x1, y, z1], [x2, y, z1], [x2, y, z2], [x1, y, z2]]
    this.quad(key, p, [0, up ? 1 : -1, 0], p.map(q => [q[0] * tile, q[2] * tile * (up ? -1 : 1)]))
  }
  /** Cylinder along y (default), x or z */
  cyl (key, cx, cy, cz, r, h, { segs = 10, axis = 'y', caps = true, r2 = null, tile = [1, 1] } = {}) {
    const rb = r, rt = r2 ?? r
    const pt = (a, y, rr) => {
      const x = Math.cos(a) * rr, z = Math.sin(a) * rr
      if (axis === 'y') return [cx + x, cy + y, cz + z]
      if (axis === 'x') return [cx + y, cy + x, cz + z]
      return [cx + x, cy + z, cz + y]
    }
    const nrm = a => {
      const x = Math.cos(a), z = Math.sin(a)
      if (axis === 'y') return [x, 0, z]
      if (axis === 'x') return [0, x, z]
      return [x, z, 0]
    }
    const flip = axis !== 'y' // swapping axes mirrors the winding
    const U = (i, j) => [i / segs * tile[0] * 3, j * (h * tile[1])]
    for (let i = 0; i < segs; i++) {
      const a0 = (i / segs) * Math.PI * 2, a1 = ((i + 1) / segs) * Math.PI * 2
      const n = nrm((a0 + a1) / 2)
      const b0 = pt(a0, -h / 2, rb), b1 = pt(a1, -h / 2, rb), t0 = pt(a0, h / 2, rt), t1 = pt(a1, h / 2, rt)
      if (!flip) this.quad(key, [b1, b0, t0, t1], n, [U(i + 1, 0), U(i, 0), U(i, 1), U(i + 1, 1)])
      else this.quad(key, [b0, b1, t1, t0], n, [U(i, 0), U(i + 1, 0), U(i + 1, 1), U(i, 1)])
      if (caps) {
        const top = axis === 'y' ? [0, 1, 0] : axis === 'x' ? [1, 0, 0] : [0, 0, 1]
        const bot = top.map(v => -v)
        const c0 = pt(0, h / 2, 0), c1 = pt(0, -h / 2, 0)
        const uvc = [[0.5, 0.5], [0, 0], [1, 0], [0.5, 0.5]]
        if (!flip) {
          this.quad(key, [c0, t1, t0, c0], top, uvc)
          this.quad(key, [c1, b0, b1, c1], bot, uvc)
        } else {
          this.quad(key, [c0, t0, t1, c0], top, uvc)
          this.quad(key, [c1, b1, b0, c1], bot, uvc)
        }
      }
    }
  }
  build (parent, { shadows = true } = {}) {
    const out = []
    for (const [key, b] of this.b) {
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.Float32BufferAttribute(b.pos, 3))
      g.setAttribute('normal', new THREE.Float32BufferAttribute(b.nor, 3))
      g.setAttribute('uv', new THREE.Float32BufferAttribute(b.uv, 2))
      g.setIndex(b.idx)
      g.computeBoundingSphere()
      const m = new THREE.Mesh(g, surface(key))
      m.castShadow = shadows
      m.receiveShadow = shadows
      m.frustumCulled = false // the buckets span the whole building
      m.matrixAutoUpdate = false
      m.updateMatrix()
      parent.add(m)
      out.push(m)
    }
    return out
  }
}

// ───────── colliders ─────────
export class Colliders {
  constructor () {
    this.list = []
    this.cell = 4
    this.grid = new Map()
  }
  /** tall: blocks sight too. door: a function () => bool saying whether it's currently shut */
  add (x1, z1, x2, z2, { tall = true, door = null, tag = '' } = {}) {
    const c = { x1: Math.min(x1, x2), z1: Math.min(z1, z2), x2: Math.max(x1, x2), z2: Math.max(z1, z2), tall, door, tag }
    this.list.push(c)
    const k = this.cell
    for (let gx = Math.floor(c.x1 / k); gx <= Math.floor(c.x2 / k); gx++) {
      for (let gz = Math.floor(c.z1 / k); gz <= Math.floor(c.z2 / k); gz++) {
        const key = gx * 4096 + gz
        let arr = this.grid.get(key)
        if (!arr) { arr = []; this.grid.set(key, arr) }
        arr.push(c)
      }
    }
    return c
  }
  near (x, z, r) {
    const k = this.cell
    const out = new Set()
    for (let gx = Math.floor((x - r) / k); gx <= Math.floor((x + r) / k); gx++) {
      for (let gz = Math.floor((z - r) / k); gz <= Math.floor((z + r) / k); gz++) {
        const arr = this.grid.get(gx * 4096 + gz)
        if (arr) for (const c of arr) out.add(c)
      }
    }
    return out
  }
  active (c) { return !c.door || c.door() }
  /** Slide a circle out of everything it overlaps. Returns the corrected position. */
  resolve (x, z, r) {
    for (let pass = 0; pass < 3; pass++) {
      for (const c of this.near(x, z, r + 0.2)) {
        if (!this.active(c)) continue
        const cx = Math.max(c.x1, Math.min(x, c.x2)), cz = Math.max(c.z1, Math.min(z, c.z2))
        let dx = x - cx, dz = z - cz
        const d2 = dx * dx + dz * dz
        if (d2 >= r * r) continue
        if (d2 > 1e-9) {
          const d = Math.sqrt(d2)
          x = cx + dx / d * r; z = cz + dz / d * r
        } else {
          // centre inside the box: push out the shortest way
          const l = x - c.x1, rr = c.x2 - x, t = z - c.z1, b = c.z2 - z
          const m = Math.min(l, rr, t, b)
          if (m === l) x = c.x1 - r; else if (m === rr) x = c.x2 + r; else if (m === t) z = c.z1 - r; else z = c.z2 + r
        }
      }
    }
    return [x, z]
  }
  /** Is the segment a→b free of tall obstacles? (used for sight) */
  clear (ax, az, bx, bz, { all = false } = {}) {
    const dx = bx - ax, dz = bz - az
    const len = Math.hypot(dx, dz)
    const steps = Math.ceil(len / this.cell) + 1
    const seen = new Set()
    for (let i = 0; i <= steps; i++) {
      const t = i / steps
      for (const c of this.near(ax + dx * t, az + dz * t, 0.5)) {
        if (seen.has(c)) continue
        seen.add(c)
        if (!all && !c.tall) continue
        if (!this.active(c)) continue
        if (segBox(ax, az, bx, bz, c)) return false
      }
    }
    return true
  }
}
function segBox (ax, az, bx, bz, c) {
  let t0 = 0, t1 = 1
  const dx = bx - ax, dz = bz - az
  for (const [p, q, lo, hi] of [[dx, ax, c.x1, c.x2], [dz, az, c.z1, c.z2]]) {
    if (Math.abs(p) < 1e-9) { if (q < lo || q > hi) return false } else {
      let a = (lo - q) / p, b = (hi - q) / p
      if (a > b) [a, b] = [b, a]
      t0 = Math.max(t0, a); t1 = Math.min(t1, b)
      if (t0 > t1) return false
    }
  }
  return true
}

// ───────── navigation grid + A* ─────────
export class Nav {
  constructor (colliders, { x1, z1, x2, z2, cell = 0.5, radius = 0.42, isLocked = () => false, doorBoxes = [] }) {
    this.c = colliders
    this.x1 = x1; this.z1 = z1; this.cell = cell
    this.w = Math.ceil((x2 - x1) / cell); this.h = Math.ceil((z2 - z1) / cell)
    this.block = new Uint8Array(this.w * this.h)
    this.doorCells = [] // { door, idx[] }
    this.isLocked = isLocked
    for (let j = 0; j < this.h; j++) {
      for (let i = 0; i < this.w; i++) {
        const x = x1 + (i + 0.5) * cell, z = z1 + (j + 0.5) * cell
        let blocked = 1
        // free if a circle of `radius` there touches no non-door collider
        let free = true
        for (const c of colliders.near(x, z, radius + 0.1)) {
          if (c.door) continue
          const cx = Math.max(c.x1, Math.min(x, c.x2)), cz = Math.max(c.z1, Math.min(z, c.z2))
          if ((x - cx) ** 2 + (z - cz) ** 2 < radius * radius) { free = false; break }
        }
        if (free) blocked = 0
        this.block[j * this.w + i] = blocked
      }
    }
    // doorways are narrower than the grid can resolve: open up a lane through every doorway
    for (const d of doorBoxes) {
      const alongX = (d.x2 - d.x1) > (d.z2 - d.z1)
      const rx1 = alongX ? d.x1 + 0.12 : d.x1 - 0.45, rx2 = alongX ? d.x2 - 0.12 : d.x2 + 0.45
      const rz1 = alongX ? d.z1 - 0.45 : d.z1 + 0.12, rz2 = alongX ? d.z2 + 0.45 : d.z2 - 0.12
      for (let j = 0; j < this.h; j++) for (let i = 0; i < this.w; i++) {
        const x = x1 + (i + 0.5) * cell, z = z1 + (j + 0.5) * cell
        if (x > rx1 && x < rx2 && z > rz1 && z < rz2) this.block[j * this.w + i] = 0
      }
    }
    // locked doors: remember which cells they cover so they can block the search while locked
    for (const d of doorBoxes) {
      const idx = []
      for (let j = 0; j < this.h; j++) for (let i = 0; i < this.w; i++) {
        const x = x1 + (i + 0.5) * cell, z = z1 + (j + 0.5) * cell
        if (x > d.x1 - 0.3 && x < d.x2 + 0.3 && z > d.z1 - 0.3 && z < d.z2 + 0.3) idx.push(j * this.w + i)
      }
      this.doorCells.push({ door: d.door, idx })
    }
    this.lockedMask = new Uint8Array(this.w * this.h)
  }
  refreshLocks () {
    this.lockedMask.fill(0)
    for (const d of this.doorCells) if (this.isLocked(d.door)) for (const i of d.idx) this.lockedMask[i] = 1
  }
  cellOf (x, z) { return [Math.floor((x - this.x1) / this.cell), Math.floor((z - this.z1) / this.cell)] }
  centre (i, j) { return [this.x1 + (i + 0.5) * this.cell, this.z1 + (j + 0.5) * this.cell] }
  walkable (i, j) { return i >= 0 && j >= 0 && i < this.w && j < this.h && !this.block[j * this.w + i] && !this.lockedMask[j * this.w + i] }
  /** nearest walkable cell to a point */
  snap (x, z) {
    const [ci, cj] = this.cellOf(x, z)
    if (this.walkable(ci, cj)) return [ci, cj]
    for (let r = 1; r < 12; r++) {
      for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
        if (Math.max(Math.abs(di), Math.abs(dj)) !== r) continue
        if (this.walkable(ci + di, cj + dj)) return [ci + di, cj + dj]
      }
    }
    return null
  }
  /** returns a list of [x,z] waypoints or null */
  path (sx, sz, gx, gz, maxNodes = 60000) {
    const a = this.snap(sx, sz), b = this.snap(gx, gz)
    if (!a || !b) return null
    this.refreshLocks()
    const W = this.w
    const start = a[1] * W + a[0], goal = b[1] * W + b[0]
    if (start === goal) return [[gx, gz]]
    const g = new Map([[start, 0]])
    const came = new Map()
    const open = new Heap()
    const hx = i => Math.abs(i % W - b[0]) + Math.abs(Math.floor(i / W) - b[1])
    open.push(start, hx(start))
    const closed = new Set()
    let n = 0
    const nb = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]]
    while (open.size && n++ < maxNodes) {
      const cur = open.pop()
      if (cur === goal) break
      if (closed.has(cur)) continue
      closed.add(cur)
      const ci = cur % W, cj = Math.floor(cur / W)
      for (const [di, dj, cost] of nb) {
        const ni = ci + di, nj = cj + dj
        if (!this.walkable(ni, nj)) continue
        if (di && dj && (!this.walkable(ci + di, cj) || !this.walkable(ci, cj + dj))) continue // no corner cutting
        const id = nj * W + ni
        const ng = g.get(cur) + cost
        if (ng < (g.get(id) ?? Infinity)) { g.set(id, ng); came.set(id, cur); open.push(id, ng + hx(id)) }
      }
    }
    if (!came.has(goal)) return null
    const cells = []
    for (let c = goal; c !== start; c = came.get(c)) cells.push(c)
    cells.reverse()
    // string-pull: drop waypoints that have a clear straight line between their neighbours
    const pts = cells.map(c => this.centre(c % W, Math.floor(c / W)))
    const out = []
    let from = [sx, sz]
    let i = 0
    while (i < pts.length) {
      let far = i
      for (let k = pts.length - 1; k > i; k--) if (this.lineFree(from[0], from[1], pts[k][0], pts[k][1])) { far = k; break }
      out.push(pts[far])
      from = pts[far]
      i = far + 1
    }
    out.push([gx, gz])
    return out
  }
  lineFree (ax, az, bx, bz) {
    const d = Math.hypot(bx - ax, bz - az)
    const steps = Math.ceil(d / (this.cell * 0.5))
    for (let s = 0; s <= steps; s++) {
      const t = s / steps
      const [i, j] = this.cellOf(ax + (bx - ax) * t, az + (bz - az) * t)
      if (!this.walkable(i, j)) return false
    }
    return true
  }
}

class Heap {
  constructor () { this.a = [] }
  get size () { return this.a.length }
  push (v, p) {
    const a = this.a
    a.push([v, p])
    let i = a.length - 1
    while (i > 0) { const j = (i - 1) >> 1; if (a[j][1] <= a[i][1]) break; [a[i], a[j]] = [a[j], a[i]]; i = j }
  }
  pop () {
    const a = this.a
    const top = a[0][0]
    const last = a.pop()
    if (a.length) {
      a[0] = last
      let i = 0
      for (;;) {
        const l = i * 2 + 1, r = l + 1
        let m = i
        if (l < a.length && a[l][1] < a[m][1]) m = l
        if (r < a.length && a[r][1] < a[m][1]) m = r
        if (m === i) break;
        [a[i], a[m]] = [a[m], a[i]]
        i = m
      }
    }
    return top
  }
}
