// Little Lantern sound: the recorded files in ../audio/ (hosted with the site).
import { createSound } from '../../gamekit/sound.js'
import names from '../audio/index.js'

export const S = createSound({ base: new URL('../audio/', import.meta.url).href, names })
S.prefetch()

const beds = {}
let scene = 'landing'
let bossOn = false
export async function startBeds () {
  await S.init()
  if (beds.void) return
  beds.void = S.bed('amb_void', { vol: 0.45 })
  beds.waltz = S.bed('music_waltz', { vol: 0, music: true })
  beds.boss = S.bed('music_boss', { vol: 0, music: true })
  beds.hum = S.bed('lantern_hum', { vol: 0 })
  beds.moths = S.bed('moths_loop', { vol: 0 })
  beds.heart = S.bed('heartbeat_loop', { vol: 0 })
}
export const setScene = id => { scene = id }
export const boss = on => { bossOn = on }

let b = 0
export function updateBeds (dt, { beam = false, low = false }) {
  if (!beds.void) return
  b += ((bossOn ? 1 : 0) - b) * Math.min(1, dt * (bossOn ? 2 : 0.4))
  beds.boss.setVol(b * 0.7, 0.3)
  beds.waltz.setVol((scene === 'landing' ? 0.45 : 0.2) * (1 - b), 0.6)
  beds.void.setVol(0.45 - b * 0.2, 0.6)
  beds.hum.setVol(beam ? 0.35 : 0, 0.15)
  beds.moths.setVol(scene === 'bigtop' ? 0.25 : 0, 0.8)
  beds.heart.setVol(low ? 0.6 : 0, 0.4)
}

export const play = (name, opts) => S.play(name, opts)
