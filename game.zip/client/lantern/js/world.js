// Little Lantern: the floating islands. Ground is a set of flat discs and thread bridges hanging over fog.
import * as THREE from 'three'

const placed = (m, x, y, z) => { m.position.set(x, y, z); return m }

export const SPACING = 400 // islands are far apart; the fog hides the others

/**
 * Island layouts in local coordinates (the island's origin is at x = index * SPACING).
 * discs [x, z, r, h], bridges [x1, z1, x2, z2, width], cocoons [x, z] (a hidden soul), motes [x, z] (fireflies),
 * hollows [x, z] (shadow things that drift at you), arena {x, z, r}, gates: where the light-doors stand.
 */
export const ISLANDS = [
  {
    id: 'landing', name: 'The Landing', sky: [0x1a1530, 0x6d5e96], fog: 0x3a3358, ground: 0x4a4560,
    discs: [[0, 0, 11, 0]], bridges: [], cocoons: [], motes: [[4, 4], [-4, -4]], hollows: [],
    entry: { x: 0, z: 6, yaw: 0 }, arena: null,
  },
  {
    id: 'garden', name: 'The Hollow Garden', sky: [0x10161c, 0x4f6b5a], fog: 0x2c3a35, ground: 0x2f3b2a,
    discs: [[0, 0, 9, 0], [0, -26, 12, 0], [-6, -28, 4, 1.1], [-21, -20, 6, 0], [3, -56, 17, 0]],
    bridges: [[0, -8, 0, -15, 2.2], [-10, -24, -16, -21, 1.6], [0, -37, 2, -40, 2.4]],
    cocoons: [[-6, -28, 1.1], [-22, -21, 0]],
    motes: [[3, -20], [-21, -17], [6, -30], [-3, -4], [10, -52], [-8, -56]],
    hollows: [[4, -24], [-3, -33], [-20, -23]],
    entry: { x: 0, z: 5, yaw: 0 }, arena: { x: 3, z: -57, r: 15 },
  },
  {
    id: 'parlour', name: 'The Porcelain Parlour', sky: [0x1c1218, 0x9a6f82], fog: 0x45313c, ground: 0xd8d0c4,
    discs: [[0, 0, 9, 0], [14, -20, 10, 0], [20, -22, 3.5, 1.2], [-6, -24, 7, 0], [0, -54, 17, 0]],
    bridges: [[4, -7, 9, -13, 2], [5, -22, 0, -23, 1.5], [9, -29, 3, -38, 2.2]],
    cocoons: [[20, -22, 1.2], [-8, -26, 0]],
    motes: [[12, -16], [-4, -20], [16, -26], [2, -2], [8, -50], [-9, -58]],
    hollows: [[13, -22], [-5, -26], [10, -18], [6, -33]],
    entry: { x: 0, z: 5, yaw: 0 }, arena: { x: 0, z: -55, r: 15.5 },
  },
  {
    id: 'bigtop', name: 'The Moth Big Top', sky: [0x170f0a, 0x8a5a2a], fog: 0x3c2a1c, ground: 0x5a2626,
    discs: [[0, 0, 9, 0], [-12, -22, 9, 0], [-14, -22, 3, 1.3], [12, -30, 7, 0], [0, -60, 18, 0]],
    bridges: [[-4, -7, -9, -15, 2], [-4, -24, 6, -28, 1.4], [-8, -30, -3, -43, 2.2], [12, -36, 5, -44, 1.4]],
    cocoons: [[-14, -22, 1.3], [13, -31, 0]],
    motes: [[-12, -18], [10, -28], [-6, -26], [2, -3], [9, -58], [-10, -62], [0, -70]],
    hollows: [[-10, -24], [12, -32], [-5, -36], [3, -40]],
    entry: { x: 0, z: 5, yaw: 0 }, arena: { x: 0, z: -61, r: 16 },
  },
  {
    id: 'tower', name: 'The Spindle Tower', sky: [0x0c0a14, 0x40305e], fog: 0x221a33, ground: 0x2a2236,
    discs: [[0, 0, 8, 0], [0, -40, 19, 0]],
    bridges: [[0, -7, 0, -22, 2.4]],
    cocoons: [], motes: [[0, -14], [12, -40], [-12, -40], [0, -52], [0, -28]],
    hollows: [[0, -15]],
    entry: { x: 0, z: 4, yaw: 0 }, arena: { x: 0, z: -40, r: 18 },
  },
]

export const islandOrigin = k => k * SPACING

/** ground height at world x,z on island k, or -Infinity over the void */
export function groundAt (k, wx, wz) {
  const isl = ISLANDS[k]
  const x = wx - islandOrigin(k), z = wz
  let best = -Infinity
  for (const [cx, cz, r, h] of isl.discs) if ((x - cx) ** 2 + (z - cz) ** 2 <= r * r && h > best) best = h
  if (best > -Infinity) return best
  for (const [x1, z1, x2, z2, w] of isl.bridges) {
    const dx = x2 - x1, dz = z2 - z1, L2 = dx * dx + dz * dz
    let t = ((x - x1) * dx + (z - z1) * dz) / L2
    t = Math.max(-0.05, Math.min(1.05, t))
    const px = x1 + dx * t, pz = z1 + dz * t
    if ((x - px) ** 2 + (z - pz) ** 2 <= (w / 2) ** 2) return 0
  }
  return -Infinity
}

// ───────────── materials and little builders ─────────────
const mat = (color, rough = 0.85, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness: rough, ...extra })
const glow = color => new THREE.MeshBasicMaterial({ color })

function rng (seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296 } }

function skyDome (top, bottom) {
  const geo = new THREE.SphereGeometry(180, 32, 16)
  const m = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(top) }, bottom: { value: new THREE.Color(bottom) } },
    vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: `uniform vec3 top; uniform vec3 bottom; varying vec3 vP;
      float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
      void main(){ float y = vP.y; vec3 c = mix(bottom, top, smoothstep(-0.25, 0.55, y));
        // slow swirls of fog light near the horizon
        float band = exp(-pow((y + 0.05) * 6.0, 2.0)) * 0.35; c += bottom * band;
        // stitched seams across the sky: faint dashed lines
        float seam = step(0.985, fract(atan(vP.z, vP.x) * 3.0)) * step(0.5, fract(y * 40.0)) * smoothstep(0.1, 0.5, y) * 0.12; c += vec3(seam);
        gl_FragColor = vec4(c, 1.0); }`,
  })
  const s = new THREE.Mesh(geo, m)
  s.renderOrder = -10
  return s
}

/** the island's rock underside: a rough upside-down cone hanging under each disc */
function rockUnder (r, h, color, seed) {
  const R = rng(seed)
  const geo = new THREE.ConeGeometry(r, r * 1.6 + 3, 14, 4, true)
  geo.rotateX(Math.PI)
  const pos = geo.attributes.position
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i)
    if (y < r * 0.8 + 1.4) { pos.setX(i, pos.getX(i) * (0.8 + R() * 0.4)); pos.setZ(i, pos.getZ(i) * (0.8 + R() * 0.4)) }
  }
  geo.computeVertexNormals()
  const m = new THREE.Mesh(geo, mat(color, 1, { side: THREE.DoubleSide }))
  m.position.y = h - (r * 1.6 + 3) / 2 - 0.02
  return m
}

/**
 * Builds one island's meshes into a group placed at its origin. Returns { group, cocoons, motes, gates, lights, update }
 */
export function buildIsland (k, { quality = 'high' } = {}) {
  const isl = ISLANDS[k]
  const R = rng(1000 + k * 77)
  const g = new THREE.Group()
  g.position.x = islandOrigin(k)
  const top = mat(isl.ground, 0.95)
  const rimMat = mat(0x16121e, 1)
  const anim = []
  // ground discs
  for (const [x, z, r, h] of isl.discs) {
    const d = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.96, 0.6, 40), top)
    d.position.set(x, h - 0.3, z)
    d.receiveShadow = true
    g.add(d)
    const under = rockUnder(r * 0.96, h - 0.6, isl.fog, k * 31 + x * 3 + z)
    under.position.x = x; under.position.z = z
    g.add(under)
    // a stitched rim: little dashes round the edge
    const n = Math.round(r * 5)
    const dash = new THREE.InstancedMesh(new THREE.BoxGeometry(0.07, 0.05, 0.36), glow(0xefe6d2), n)
    const o = new THREE.Object3D()
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; o.position.set(x + Math.cos(a) * (r - 0.25), h + 0.01, z + Math.sin(a) * (r - 0.25)); o.rotation.set(0, -a, 0); o.updateMatrix(); dash.setMatrixAt(i, o.matrix) }
    dash.material.transparent = true; dash.material.opacity = 0.5
    g.add(dash)
  }
  // thread bridges: a woven plank strip with red thread rails
  for (const [x1, z1, x2, z2, w] of isl.bridges) {
    const L = Math.hypot(x2 - x1, z2 - z1) + 1.2
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, 0.12, L), mat(0x6b5a4a, 0.9))
    b.position.set((x1 + x2) / 2, -0.06, (z1 + z2) / 2)
    b.rotation.y = Math.atan2(x2 - x1, z2 - z1)
    g.add(b)
    for (const side of [-1, 1]) {
      const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, L, 5).rotateX(Math.PI / 2), mat(0xb3243a, 0.6))
      rail.position.set(side * w / 2, 0.75, 0)
      b.add(rail)
      for (let t = -L / 2 + 0.3; t < L / 2; t += 2.2) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.8, 4), rimMat); p.position.set(side * w / 2, 0.4, t); b.add(p) }
    }
  }
  // per-island scenery
  const solid = [] // [x, z, r] obstacles the player walks round
  const add = (m, x, y, z, ry = 0) => { m.position.set(x, y, z); m.rotation.y = ry; g.add(m); return m }
  const onDisc = (filter = () => true) => {
    for (let tries = 0; tries < 60; tries++) {
      const d = isl.discs[Math.floor(R() * isl.discs.length)]
      const a = R() * Math.PI * 2, rr = Math.sqrt(R()) * (d[2] - 1.3)
      const x = d[0] + Math.cos(a) * rr, z = d[1] + Math.sin(a) * rr
      if (isl.arena && Math.hypot(x - isl.arena.x, z - isl.arena.z) < isl.arena.r - 2) continue
      if (Math.hypot(x - isl.entry.x, z - isl.entry.z) < 3) continue
      if (isl.cocoons.some(c => Math.hypot(x - c[0], z - c[1]) < 2.4)) continue
      if (!filter(x, z)) continue
      return [x, d[3], z]
    }
    return null
  }
  if (isl.id === 'landing') {
    // grandmother's lamp-post in the middle, an old armchair, a door frame with no house
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.14, 4.2, 8), mat(0x22202a, 0.5, { metalness: 0.6 }))
    add(post, 0, 2.1, 0)
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.35, 14, 10), glow(0xffd28a))
    add(lamp, 0, 4.35, 0)
    solid.push([0, 0, 0.4])
    const chair = new THREE.Group()
    const cm = mat(0x6b2e3a, 0.95)
    chair.add(placed(new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.5, 1.1), cm), 0, 0.25, 0))
    chair.add(placed(new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.2, 0.3), cm), 0, 0.9, -0.45))
    add(chair, -5.5, 0, 3, 0.7)
    solid.push([-5.5, 3, 0.8])
    const frame = new THREE.Group()
    const fm = mat(0xefe6d2, 0.8)
    for (const s of [-0.6, 0.6]) frame.add(placed(new THREE.Mesh(new THREE.BoxGeometry(0.12, 2.3, 0.12), fm), s, 1.15, 0))
    frame.add(placed(new THREE.Mesh(new THREE.BoxGeometry(1.32, 0.12, 0.12), fm), 0, 2.3, 0))
    add(frame, 6, 0, 2.5, -0.9)
  } else if (isl.id === 'garden') {
    // paper-cut trees: flat black silhouettes with holes for leaves, and thorned roses taller than a house
    const treeMat = new THREE.MeshStandardMaterial({ color: 0x0c100c, roughness: 1, side: THREE.DoubleSide })
    for (let i = 0; i < 16; i++) {
      const p = onDisc(); if (!p) continue
      const shape = new THREE.Shape()
      const h = 3 + R() * 3.5, w = 1.6 + R() * 1.6
      shape.moveTo(-0.15, 0); shape.lineTo(-0.12, h * 0.5)
      for (let j = 0; j <= 8; j++) { const a = Math.PI + j / 8 * Math.PI; shape.lineTo(Math.cos(a) * w * (0.8 + R() * 0.4), h * 0.65 + Math.sin(-a) * w * 1.1 * (0.7 + R() * 0.5)) }
      shape.lineTo(0.12, h * 0.5); shape.lineTo(0.15, 0)
      const m = new THREE.Mesh(new THREE.ShapeGeometry(shape), treeMat)
      add(m, p[0], p[1], p[2], R() * Math.PI)
      solid.push([p[0], p[2], 0.35])
    }
    for (let i = 0; i < 8; i++) {
      const p = onDisc(); if (!p) continue
      const rose = new THREE.Group()
      const h = 2.5 + R() * 2.5
      rose.add(placed(new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.1, h, 6), mat(0x1f2e1a)), 0, h / 2, 0))
      for (let t = 0; t < 6; t++) { const th = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.3, 4), mat(0x1f2e1a)); th.position.set(0, 0.4 + t * h / 7, 0); th.rotation.z = (t % 2 ? 1 : -1) * 1.3; rose.add(th) }
      const bloom = new THREE.Mesh(new THREE.IcosahedronGeometry(0.55, 0), mat(0x8a1626, 0.6))
      bloom.position.y = h
      rose.add(bloom)
      add(rose, p[0], p[1], p[2])
      solid.push([p[0], p[2], 0.3])
    }
  } else if (isl.id === 'parlour') {
    // teacups big enough to sit in, a cracked porcelain floor, a long table in the arena
    const porcelain = mat(0xf2ede4, 0.25)
    const blue = mat(0x2d4f9a, 0.3)
    for (let i = 0; i < 9; i++) {
      const p = onDisc(); if (!p) continue
      const s = 0.8 + R() * 1.4
      const cup = new THREE.Group()
      const body = new THREE.Mesh(new THREE.CylinderGeometry(1 * s, 0.65 * s, 1.1 * s, 20, 1, true), porcelain)
      body.material.side = THREE.DoubleSide
      body.position.y = 0.55 * s
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.98 * s, 0.05 * s, 6, 24), blue)
      band.rotation.x = Math.PI / 2; band.position.y = 0.95 * s
      const handle = new THREE.Mesh(new THREE.TorusGeometry(0.35 * s, 0.08 * s, 6, 12, Math.PI * 1.3), porcelain)
      handle.position.set(1.05 * s, 0.55 * s, 0); handle.rotation.z = -0.6
      cup.add(body, band, handle)
      const tipped = R() < 0.3
      if (tipped) { cup.rotation.z = Math.PI / 2; cup.position.y = 1 * s }
      add(cup, p[0], p[1] + (tipped ? s : 0), p[2], R() * 6)
      solid.push([p[0], p[2], s * 0.95])
    }
    // cracks: dark zigzag lines on the floor
    for (let i = 0; i < 14; i++) {
      const p = onDisc(); if (!p) continue
      const pts = [new THREE.Vector3(0, 0, 0)]
      for (let j = 0; j < 6; j++) pts.push(pts[j].clone().add(new THREE.Vector3((R() - 0.5) * 1.2, 0, 0.5 + R() * 0.7)))
      const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x4a3a44 }))
      add(line, p[0], p[1] + 0.02, p[2], R() * 6)
    }
    const a = isl.arena
    const table = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.15, 14), mat(0x3a1f1a, 0.6))
    add(table, a.x, 1.0, a.z + 2)
    for (const [dx, dz] of [[-1, -6.5], [1, -6.5], [-1, 6.5], [1, 6.5]]) add(new THREE.Mesh(new THREE.BoxGeometry(0.15, 1, 0.15), mat(0x3a1f1a)), a.x + dx, 0.5, a.z + 2 + dz)
    const cloth = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.02, 14.2), mat(0xefe6d2, 0.9))
    add(cloth, a.x, 1.09, a.z + 2)
    for (let z = -5; z <= 5; z += 2.5) solid.push([a.x, a.z + 2 + z, 1.4])
  } else if (isl.id === 'bigtop') {
    // striped poles with no tent, bunting of moth wings, a sawdust ring
    const red = mat(0x9a1f1f, 0.7), cream = mat(0xefe6d2, 0.8)
    for (let i = 0; i < 12; i++) {
      const p = onDisc(); if (!p) continue
      const h = 5 + R() * 4
      const pole = new THREE.Group()
      for (let s = 0; s < h; s += 0.6) pole.add(placed(new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.6, 8), (s / 0.6) % 2 ? red : cream), 0, s + 0.3, 0))
      add(pole, p[0], p[1], p[2])
      solid.push([p[0], p[2], 0.25])
    }
    const a = isl.arena
    const ring = new THREE.Mesh(new THREE.TorusGeometry(a.r - 1, 0.25, 6, 60), red)
    ring.rotation.x = Math.PI / 2
    add(ring, a.x, 0.2, a.z)
    const sawdust = new THREE.Mesh(new THREE.CircleGeometry(a.r - 1.2, 48), mat(0xb08a5a, 1))
    sawdust.rotation.x = -Math.PI / 2
    add(sawdust, a.x, 0.005, a.z)
  } else if (isl.id === 'tower') {
    // the tower: a column of spools climbing into the dark behind the arena, threads strung to the rim
    const a = isl.arena
    for (let i = 0; i < 9; i++) {
      const spool = new THREE.Group()
      const r = 3 - i * 0.18
      spool.add(new THREE.Mesh(new THREE.CylinderGeometry(r, r, 2.2, 24), mat([0x6b1a2a, 0x2a2a4a, 0x4a3a1a][i % 3], 0.9)))
      for (const y of [-1.2, 1.2]) spool.add(placed(new THREE.Mesh(new THREE.CylinderGeometry(r + 0.5, r + 0.5, 0.25, 24), mat(0x2a1e14)), 0, y, 0))
      add(spool, a.x, 16 + i * 2.7, a.z - 36)
    }
    const thread = new THREE.LineBasicMaterial({ color: 0xb3243a, transparent: true, opacity: 0.6 })
    for (let i = 0; i < 18; i++) {
      const ang = i / 18 * Math.PI * 2
      const pts = [new THREE.Vector3(a.x + Math.cos(ang) * a.r, 0.2, a.z + Math.sin(ang) * a.r), new THREE.Vector3(a.x, 22, a.z - 36)]
      g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), thread))
    }
  }
  // drifting debris in the void: furniture, doors and toys hanging in the fog (the abstract horror)
  const debris = new THREE.Group()
  const dm = mat(isl.fog, 1)
  const dn = quality === 'high' ? 26 : 12
  for (let i = 0; i < dn; i++) {
    const kind = Math.floor(R() * 4)
    let m
    if (kind === 0) m = new THREE.Mesh(new THREE.BoxGeometry(1, 2.1, 0.1), dm) // a door
    else if (kind === 1) m = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.8, 0.8), dm) // a bed
    else if (kind === 2) m = new THREE.Mesh(new THREE.ConeGeometry(0.4, 1.4, 5), dm) // a spinning top
    else m = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.2, 6, 12), dm) // a hoop
    const a = R() * Math.PI * 2, rr = 45 + R() * 50
    m.position.set(Math.cos(a) * rr, -10 + R() * 30, -25 + Math.sin(a) * rr)
    m.rotation.set(R() * 6, R() * 6, R() * 6)
    m.userData.spin = (R() - 0.5) * 0.2
    m.scale.setScalar(1 + R() * 3)
    debris.add(m)
  }
  g.add(debris)
  anim.push((dt, t) => { for (const m of debris.children) { m.rotation.x += m.userData.spin * dt; m.rotation.y += m.userData.spin * 0.7 * dt; m.position.y += Math.sin(t * 0.3 + m.position.x) * 0.002 } })
  // fog sea below
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshBasicMaterial({ color: isl.fog, transparent: true, opacity: 0.85 }))
  sea.rotation.x = -Math.PI / 2
  sea.position.set(0, -22, -30)
  g.add(sea)
  const sky = skyDome(isl.sky[0], isl.sky[1])
  sky.position.set(0, 0, -30)
  g.add(sky)

  // the light-doors (gates): on the Landing one per island; elsewhere one home that appears after the boss
  const gates = []
  const gateMesh = (color) => {
    const gg = new THREE.Group()
    const arch = new THREE.Mesh(new THREE.TorusGeometry(1.2, 0.09, 8, 30, Math.PI), mat(0x15121f, 0.5))
    arch.position.y = 1.6
    const posts = [-1.2, 1.2].map(x => placed(new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.6, 0.18), mat(0x15121f, 0.5)), x, 0.8, 0))
    const fill = new THREE.Mesh(new THREE.CircleGeometry(1.15, 30, 0, Math.PI), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false }))
    fill.position.y = 1.6
    const fill2 = new THREE.Mesh(new THREE.PlaneGeometry(2.3, 1.6), fill.material)
    fill2.position.y = 0.8
    gg.add(arch, ...posts, fill, fill2)
    gg.userData.fill = fill.material
    return gg
  }
  if (isl.id === 'landing') {
    for (let j = 1; j < ISLANDS.length; j++) {
      const ang = Math.PI * (0.15 + (j - 1) / 3 * 0.7) + Math.PI
      const x = Math.cos(ang) * 8, z = Math.sin(ang) * 8
      const m = gateMesh([0x9ad6a0, 0xf0c0d0, 0xffb060, 0xb090ff][j - 1])
      add(m, x, 0, z, -ang - Math.PI / 2)
      const label = textSprite(ISLANDS[j].name)
      label.position.set(x, 3.4, z)
      g.add(label)
      gates.push({ to: j, x: x + islandOrigin(k), z, mesh: m, label })
    }
  } else {
    const a = isl.arena
    const m = gateMesh(0xffd28a)
    add(m, a.x, 0, a.z - a.r + 2.5, 0)
    m.visible = false
    gates.push({ to: 0, x: a.x + islandOrigin(k), z: a.z - a.r + 2.5, mesh: m, home: true })
  }

  // fireflies (light motes you collect)
  const motes = isl.motes.map(([x, z], i) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), glow(0xfff2a8))
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: 0xffe08a, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }))
    halo.scale.setScalar(0.9)
    m.add(halo)
    const h = groundAt(k, x + islandOrigin(k), z)
    add(m, x, (h > -1e9 ? h : 0) + 1.1, z)
    return { id: `m${i}`, x: x + islandOrigin(k), z, y: (h > -1e9 ? h : 0) + 1.1, mesh: m, taken: false }
  })
  anim.push((dt, t) => { for (const m of motes) { m.mesh.visible = !m.taken; m.mesh.position.y = m.y + Math.sin(t * 2 + m.x) * 0.15 } })

  // cocoons: a soul wound up in thread, hanging from a hook of nothing
  const cocoons = isl.cocoons.map(([x, z, h], i) => {
    const grp = new THREE.Group()
    const geo = new THREE.SphereGeometry(0.42, 16, 12)
    geo.scale(1, 1.6, 1)
    const wound = new THREE.Mesh(geo, mat(0xb3243a, 0.7, { emissive: 0x2a0008 }))
    wound.position.y = 1.5
    const lines = new THREE.Mesh(new THREE.TorusKnotGeometry(0.42, 0.03, 80, 6, 3, 7), mat(0xefe6d2, 0.6))
    lines.scale.set(1, 1.6, 1)
    lines.position.y = 1.5
    const thread = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 6, 3), mat(0xb3243a))
    thread.position.y = 5.2
    const inner = new THREE.PointLight(0xffd28a, 0, 4, 2)
    inner.position.y = 1.5
    grp.add(wound, lines, thread, inner)
    add(grp, x, h, z)
    return { id: `${isl.id}-c${i}`, x: x + islandOrigin(k), y: h + 1.5, z, mesh: grp, wound, lines, inner, progress: 0, freed: false }
  })
  anim.push((dt, t) => { for (const c of cocoons) { if (c.freed) { c.mesh.visible = false; continue } c.mesh.rotation.y = Math.sin(t * 0.7 + c.x) * 0.3; c.lines.rotation.y += dt * (0.3 + c.progress * 6); c.wound.scale.setScalar(1 - c.progress * 0.5); c.inner.intensity = c.progress * 6 } })

  return { k, group: g, gates, motes, cocoons, solid: solid.map(([x, z, r]) => [x + islandOrigin(k), z, r]), update: (dt, t) => { for (const f of anim) f(dt, t); for (const gt of gates) if (gt.mesh.userData.fill) gt.mesh.userData.fill.opacity = 0.4 + Math.sin(t * 2) * 0.15 } }
}

let _halo = null
export function haloTex () {
  if (_halo) return _halo
  const c = document.createElement('canvas')
  c.width = c.height = 64
  const x = c.getContext('2d')
  const r = x.createRadialGradient(32, 32, 0, 32, 32, 32)
  r.addColorStop(0, 'rgba(255,255,255,1)'); r.addColorStop(0.25, 'rgba(255,255,255,.45)'); r.addColorStop(1, 'rgba(255,255,255,0)')
  x.fillStyle = r; x.fillRect(0, 0, 64, 64)
  _halo = new THREE.CanvasTexture(c)
  return _halo
}

export function textSprite (text, color = '#efe6d2') {
  const c = document.createElement('canvas')
  c.width = 512; c.height = 96
  const x = c.getContext('2d')
  x.font = 'italic 44px "IM Fell English", Georgia, serif'
  x.textAlign = 'center'
  x.fillStyle = 'rgba(21,18,31,.6)'
  const w = Math.min(500, x.measureText(text).width + 40)
  x.fillRect(256 - w / 2, 14, w, 66)
  x.fillStyle = color
  x.fillText(text, 256, 62)
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, fog: false }))
  s.scale.set(3.2, 0.6, 1)
  return s
}
