// Night Owl Market sound: the recorded files in ../audio/ (hosted with the site).
import { createSound } from '../../gamekit/sound.js'
import names from '../audio/index.js'

export const S = createSound({ base: new URL('../audio/', import.meta.url).href, names })
S.prefetch()

const beds = {}
export async function startBeds () {
  await S.init()
  if (beds.hum) return
  beds.hum = S.bed('amb_hum', { vol: 0.35 })
  beds.street = S.bed('amb_street', { vol: 0 })
  beds.muzak = S.bed('music_muzak', { vol: 0.3, music: true })
  beds.danger = S.bed('music_danger', { vol: 0, music: true })
}

let danger = 0
export function updateBeds (dt, { inside = true, danger: d = false }) {
  if (!beds.hum) return
  danger += ((d ? 1 : 0) - danger) * Math.min(1, dt * (d ? 3 : 0.6))
  beds.danger.setVol(danger * 0.75, 0.2)
  beds.muzak.setVol((inside ? 0.3 : 0.08) * (1 - danger), 0.4)
  beds.hum.setVol(inside ? 0.35 : 0.1, 0.4)
  beds.street.setVol(inside ? 0.05 : 0.4, 0.4)
}

export const play = (name, opts) => S.play(name, opts)
