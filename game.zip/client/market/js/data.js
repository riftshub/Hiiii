// Night Owl Market: products, tiers, upgrades, guns, and the tells that give a not-quite-human away.

export const TIERS = [
  { n: 1, name: 'Corner shop', cost: 0 },
  { n: 2, name: 'Pantry', cost: 300 },
  { n: 3, name: 'Fresh & chilled', cost: 1200 },
  { n: 4, name: 'Frozen & hot food', cost: 3500 },
  { n: 5, name: 'Gadgets & toys', cost: 9000 },
]

/**
 * display: 'shelf' (gondola face), 'fridge', 'freezer', 'crate', 'grill'
 * cost = what a box of `box` units costs you; price = what one unit sells for
 */
export const PRODUCTS = [
  { id: 'chips', name: 'Crisps', tier: 1, display: 'shelf', box: 12, cost: 10, price: 2.5, color: 0xe8b923, shape: 'bag' },
  { id: 'soda', name: 'Fizzy pop', tier: 1, display: 'shelf', box: 12, cost: 8, price: 2.0, color: 0xd94141, shape: 'can' },
  { id: 'candy', name: 'Sweets', tier: 1, display: 'shelf', box: 16, cost: 7, price: 1.5, color: 0xe07ab0, shape: 'small' },
  { id: 'bread', name: 'Bread', tier: 2, display: 'shelf', box: 10, cost: 11, price: 3.0, color: 0xc9925a, shape: 'loaf' },
  { id: 'soup', name: 'Tinned soup', tier: 2, display: 'shelf', box: 12, cost: 11, price: 2.75, color: 0xb8432f, shape: 'can' },
  { id: 'cereal', name: 'Cereal', tier: 2, display: 'shelf', box: 10, cost: 18, price: 4.5, color: 0x3d78c9, shape: 'tall' },
  { id: 'apples', name: 'Apples', tier: 3, display: 'crate', box: 20, cost: 12, price: 1.8, color: 0xc0392b, shape: 'round' },
  { id: 'milk', name: 'Milk', tier: 3, display: 'fridge', box: 12, cost: 16, price: 3.5, color: 0xf2f2ee, shape: 'tall' },
  { id: 'cheese', name: 'Cheese', tier: 3, display: 'fridge', box: 10, cost: 22, price: 5.5, color: 0xf2c94c, shape: 'small' },
  { id: 'icecream', name: 'Ice cream', tier: 4, display: 'freezer', box: 8, cost: 22, price: 7.0, color: 0xf5d0e0, shape: 'tub' },
  { id: 'pizza', name: 'Frozen pizza', tier: 4, display: 'freezer', box: 8, cost: 30, price: 8.5, color: 0xd96a2b, shape: 'flat' },
  { id: 'hotdog', name: 'Hot dogs', tier: 4, display: 'grill', box: 8, cost: 8, price: 4.0, color: 0xb5523b, shape: 'sausage' },
  { id: 'headphones', name: 'Headphones', tier: 5, display: 'shelf', box: 6, cost: 90, price: 35, color: 0x2b2b30, shape: 'box' },
  { id: 'toys', name: 'Toy robots', tier: 5, display: 'shelf', box: 6, cost: 50, price: 20, color: 0x4fae5c, shape: 'box' },
  { id: 'batteries', name: 'Batteries', tier: 5, display: 'shelf', box: 12, cost: 30, price: 7, color: 0x2f6fd1, shape: 'small' },
]
export const productById = id => PRODUCTS.find(p => p.id === id)

export const UPGRADES = [
  { id: 'cashier', name: 'Hire a cashier', blurb: 'Opens the second till and serves customers by themselves (slowly).', cost: 1500, tier: 2 },
  { id: 'fastDelivery', name: 'Express deliveries', blurb: 'Boxes arrive almost straight away.', cost: 600, tier: 1 },
  { id: 'bigShelves', name: 'Taller shelves', blurb: 'Every shelf holds half as much again.', cost: 2000, tier: 3 },
  { id: 'scanner', name: 'Door scanner', blurb: 'Lets customers in when nobody is at the door. It misses one in four of the wrong ones.', cost: 3000, tier: 3 },
  { id: 'camera', name: 'Night-vision camera', blurb: 'The door screen shows a faint outline round anything that isn\'t quite human. Sometimes.', cost: 5000, tier: 4 },
  { id: 'grill2', name: 'Second grill', blurb: 'Cook eight hot dogs at a time.', cost: 1800, tier: 4 },
]

/**
 * Guns: unlocked one at a time, each upgradable to level 5.
 * dmg per pellet, rate shots/s, mag, reload s, spread rad, pellets
 */
export const GUNS = [
  { id: 'pistol', name: 'Old revolver', cost: 0, dmg: 24, rate: 2.6, mag: 6, reload: 1.4, spread: 0.008, pellets: 1, sound: 'shot_pistol' },
  { id: 'shotgun', name: 'Pump shotgun', cost: 900, dmg: 13, rate: 1.1, mag: 6, reload: 2.2, spread: 0.08, pellets: 8, sound: 'shot_shotgun' },
  { id: 'uzi', name: 'Uzi', cost: 2200, dmg: 11, rate: 11, mag: 32, reload: 1.8, spread: 0.04, pellets: 1, sound: 'shot_uzi' },
  { id: 'rifle', name: 'Hunting rifle', cost: 4800, dmg: 80, rate: 1.3, mag: 5, reload: 2.3, spread: 0, pellets: 1, sound: 'shot_rifle' },
  { id: 'dynamite', name: 'Dynamite', cost: 7500, dmg: 170, rate: 0.4, mag: 1, reload: 2.5, spread: 0, pellets: 0, throw: true, radius: 4.2, sound: 'explosion' },
]
export const gunById = id => GUNS.find(g => g.id === id)
export const upgradeCost = (gun, level) => Math.round(Math.max(150, gun.cost) * 0.45 * level)
export const gunStats = (gun, level = 1) => ({
  ...gun,
  dmg: gun.dmg * (1 + 0.22 * (level - 1)),
  reload: gun.reload * (1 - 0.08 * (level - 1)),
  rate: gun.rate * (1 + 0.06 * (level - 1)),
  mag: Math.round(gun.mag * (1 + 0.15 * (level - 1))),
})

/** The rules on the card by the door */
export const TELLS = [
  { id: 'reflection', rule: 'It has no reflection in the mirror.' },
  { id: 'shadow', rule: 'It casts no shadow.' },
  { id: 'eyes', rule: 'Its eyes catch the light like an animal\'s.' },
  { id: 'float', rule: 'Its feet don\'t quite touch the floor.' },
  { id: 'idHair', rule: 'Its hair isn\'t the colour on its ID.' },
  { id: 'idYear', rule: 'Its ID says it was born before 1900, or expires "never".' },
  { id: 'idHeight', rule: 'It\'s much taller than its ID says.' },
  { id: 'speech', rule: 'It doesn\'t talk quite right.' },
]

const FIRST = ['Ada', 'Ben', 'Cleo', 'Dev', 'Elsie', 'Finn', 'Gina', 'Hal', 'Ines', 'Jon', 'Kemi', 'Leo', 'Mina', 'Ned', 'Ola', 'Pia', 'Ravi', 'Sana', 'Theo', 'Uma', 'Vik', 'Wen', 'Yusuf', 'Zoe', 'Marta', 'Owen', 'Priya', 'Tom', 'Rosa', 'Kai']
const LAST = ['Okafor', 'Lindqvist', 'Moreau', 'Patel', 'Nakamura', 'Byrne', 'Silva', 'Kowalski', 'Haddad', 'Reyes', 'Fischer', 'Mensah', 'Doyle', 'Novak', 'Chen', 'Abara', 'Quinn', 'Ivers', 'Halloran', 'Teo']
export const HAIR = [
  { name: 'Black', color: 0x15110e }, { name: 'Brown', color: 0x5a3a20 }, { name: 'Blonde', color: 0xd8b56a },
  { name: 'Red', color: 0x9a3a1a }, { name: 'Grey', color: 0x9a9a9a }, { name: 'Blue', color: 0x2e5fa8 },
]
const LINES = [
  'Evening. Just popping in for a few bits.', 'Are you still open? Great.', 'I need milk. And probably crisps.',
  'Long day. Very long day.', 'Do you sell batteries?', 'Hi! Is the hot food on?', 'Just browsing, thanks.',
  'My kids want sweets. Again.', 'Cold out tonight, isn\'t it?', 'Quick shop before bed.',
]
const WRONG_LINES = [
  'I need... m i l k. Milk. That is a word I know.', 'Evening, evening, evening.', 'Is it still now? It is still now.',
  'Hello shopkeeper. I am a normal customer with normal skin.', 'Let me in. Let me in. I have money. It is warm money.',
  'What lovely shelves. What lovely, lovely shelves.', 'I would like to purchase one (1) bread for my human stomach.',
]

/** Builds a visitor: a human, or (with probability `odds`) something wearing one. */
export function makeVisitor (rng, odds, day) {
  const r = () => rng()
  const pick = a => a[Math.floor(r() * a.length)]
  const hair = pick(HAIR)
  const height = Math.round(150 + r() * 45)
  const year = 1950 + Math.floor(r() * 56)
  const human = r() >= odds
  const v = {
    human, tells: [],
    name: `${pick(FIRST)} ${pick(LAST)}`,
    hair: hair.color, idHair: hair.name,
    height, idHeight: height,
    born: `${1 + Math.floor(r() * 28)}/${1 + Math.floor(r() * 12)}/${year}`,
    expires: `${1 + Math.floor(r() * 28)}/${1 + Math.floor(r() * 12)}/${2027 + Math.floor(r() * 8)}`,
    line: pick(LINES),
    coat: [0x7a2e3a, 0x2f6b4f, 0x35508a, 0x8a6b2f, 0x5b3a7a, 0x2f6f7a, 0x6a6a6a, 0xa0522d][Math.floor(r() * 8)],
    trousers: [0x2e3f5c, 0x222222, 0x5a4a3a, 0x3a4a3a][Math.floor(r() * 4)],
    skin: [0xe0b394, 0xc69276, 0x8d5a3f, 0xf0caa8, 0x5e3b2a][Math.floor(r() * 5)],
    wants: [],
  }
  if (!human) {
    const count = day >= 6 && r() < 0.4 ? 1 : (r() < 0.6 ? 1 : 2) // later on, some only have one subtle tell
    const pool = TELLS.map(t => t.id)
    while (v.tells.length < count) { const t = pick(pool); if (!v.tells.includes(t)) v.tells.push(t) }
    for (const t of v.tells) {
      if (t === 'idHair') { let h = pick(HAIR); while (h.name === v.idHair) h = pick(HAIR); v.idHair = h.name }
      if (t === 'idYear') { if (r() < 0.5) v.born = `${1 + Math.floor(r() * 28)}/${1 + Math.floor(r() * 12)}/${1700 + Math.floor(r() * 180)}`; else v.expires = 'NEVER' }
      if (t === 'idHeight') v.idHeight = Math.round(v.height - 25 - r() * 20)
      if (t === 'speech') v.line = pick(WRONG_LINES)
    }
  }
  return v
}

/** Store hours: a day runs from 9:00 to 21:00 */
export const DAY_SECONDS = 420
export const OPEN_HOUR = 9
export const CLOSE_HOUR = 21
export const paranormalOdds = day => Math.min(0.45, 0.12 + (day - 1) * 0.03)
