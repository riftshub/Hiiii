// Night Owl Market: the building, shelves, fridges, tills, grill, stock room and the street outside.
import * as THREE from 'three'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { PRODUCTS, productById } from './data.js'

export const HALL = { minX: -12, maxX: 12, minZ: -11, maxZ: 8, h: 4 }
export const AISLES = [-9.75, -5.5, -1.5, 2.5, 6.5, 10.25]
export const FRONT_ROW = 3.0
export const BACK_ROW = -8.6
export const DOOR = { inner: { x: 0, z: 7.4 }, inspect: { x: 0, z: 9.3 }, outer: { x: 0, z: 11.0 }, console: { x: 2.1, z: 6.3 } }
export const TILLS = [
  { id: 0, x: -5.5, counterZ: 5.2, staff: { x: -5.5, z: 6.05 }, front: { x: -5.5, z: 4.35 } },
  { id: 1, x: -9.75, counterZ: 5.2, staff: { x: -9.75, z: 6.05 }, front: { x: -9.75, z: 4.35 } },
]
export const GRILL = { x: 8.5, z: 5.2, staff: { x: 8.5, z: 6.05 }, front: { x: 8.5, z: 4.35 } }
export const STOCKROOM = { pallet: { x: 9.6, z: -9.6 }, computer: { x: 6.2, z: -10.2 }, guns: { x: 11.3, z: -8.6 } }
export const QUEUE = k => ({ x: 0, z: 11.6 + k * 0.85 })

const tex = (draw, w = 256, h = 256, repeat = [1, 1]) => {
  const c = document.createElement('canvas')
  c.width = w; c.height = h
  draw(c.getContext('2d'), w, h)
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(...repeat)
  t.colorSpace = THREE.SRGBColorSpace
  t.anisotropy = 4
  return t
}
const speckle = (g, w, h, n = 600, a = 0.06) => { for (let i = 0; i < n; i++) { g.fillStyle = `rgba(0,0,0,${Math.random() * a})`; g.fillRect(Math.random() * w, Math.random() * h, 2, 2) } }

export function buildStore (scene, { quality = 'high' } = {}) {
  const high = quality === 'high'
  const statics = new Map()
  const colliders = []
  const root = new THREE.Group()
  scene.add(root)
  const tmp = new THREE.Matrix4()
  const std = (o) => new THREE.MeshStandardMaterial(o)
  const mats = {
    floor: std({ map: tex((g, w, h) => { for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) { g.fillStyle = (x + y) % 2 ? '#e9e4d6' : '#4e6b5c'; g.fillRect(x * 64, y * 64, 64, 64) } speckle(g, w, h, 1500) }, 256, 256, [12, 10]), roughness: 0.35 }),
    wall: std({ map: tex((g, w, h) => { g.fillStyle = '#ede5d3'; g.fillRect(0, 0, w, h); g.fillStyle = '#3f7a5e'; g.fillRect(0, h * 0.62, w, h * 0.06); g.fillStyle = '#c9c1ad'; g.fillRect(0, h * 0.68, w, h * 0.32); speckle(g, w, h, 300, 0.04) }, 256, 256, [1, 1]), roughness: 0.8 }),
    ceiling: std({ color: 0xd8d4c8, roughness: 0.95 }),
    gondola: std({ color: 0x8fc4ad, roughness: 0.5, metalness: 0.2 }),
    shelf: std({ color: 0xdfe6e1, roughness: 0.4, metalness: 0.3 }),
    counter: std({ color: 0x2f5a47, roughness: 0.5 }),
    counterTop: std({ color: 0xd9d2c0, roughness: 0.3 }),
    fridge: std({ color: 0xe6ebe8, roughness: 0.3, metalness: 0.3 }),
    glass: std({ color: 0xa8c8d8, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.22 }),
    dark: std({ color: 0x1c1f24, roughness: 0.6 }),
    metal: std({ color: 0x9aa2a6, roughness: 0.35, metalness: 0.8 }),
    wood: std({ color: 0x9a6b3e, roughness: 0.75 }),
    crate: std({ color: 0xb98a55, roughness: 0.85 }),
    asphalt: std({ map: tex((g, w, h) => { g.fillStyle = '#26282c'; g.fillRect(0, 0, w, h); speckle(g, w, h, 4000, 0.25); g.fillStyle = '#d9c26a'; g.fillRect(0, h / 2 - 3, w * 0.5, 6) }, 256, 256, [12, 2]), roughness: 0.9 }),
    pavement: std({ map: tex((g, w, h) => { g.fillStyle = '#6b6a66'; g.fillRect(0, 0, w, h); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 3; g.strokeRect(0, 0, w, h); speckle(g, w, h, 1500, 0.15) }, 128, 128, [40, 3]), roughness: 0.9 }),
    brick: std({ map: tex((g, w, h) => { g.fillStyle = '#3a2a26'; g.fillRect(0, 0, w, h); for (let y = 0; y < h; y += 16) for (let x = (y / 16) % 2 ? -16 : 0; x < w; x += 32) { g.fillStyle = `rgb(${110 + Math.random() * 30},${50 + Math.random() * 15},${40 + Math.random() * 10})`; g.fillRect(x + 1, y + 1, 30, 14) } }, 256, 256, [6, 2]), roughness: 0.9 }),
    tape: std({ color: 0xffd23f, roughness: 0.6 }),
    light: std({ color: 0xffffff, emissive: 0xf4fff8, emissiveIntensity: 1.6 }),
    mirror: std({ color: 0xbfd0d8, roughness: 0.02, metalness: 0.9, transparent: true, opacity: 0.35 }),
  }
  const add = (geom, mat, x, y, z, ry = 0) => {
    const g = geom.clone()
    tmp.compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), ry), new THREE.Vector3(1, 1, 1))
    g.applyMatrix4(tmp)
    if (!statics.has(mat)) statics.set(mat, [])
    statics.get(mat).push(g)
  }
  const box = (w, h, d, mat, x, y, z, { solid = true, ry = 0 } = {}) => {
    add(new THREE.BoxGeometry(w, h, d), mat, x, y + h / 2, z, ry)
    if (solid && y < 1.2) { const sw = Math.abs(Math.sin(ry)) > 0.7; colliders.push({ minX: x - (sw ? d : w) / 2, maxX: x + (sw ? d : w) / 2, minZ: z - (sw ? w : d) / 2, maxZ: z + (sw ? w : d) / 2 }) }
  }

  // ── shell ──
  const W = HALL.maxX - HALL.minX, D = HALL.maxZ - HALL.minZ
  const fl = new THREE.PlaneGeometry(W, D).rotateX(-Math.PI / 2)
  add(fl, mats.floor, 0, 0, (HALL.minZ + HALL.maxZ) / 2)
  add(new THREE.PlaneGeometry(W, D).rotateX(Math.PI / 2), mats.ceiling, 0, HALL.h, (HALL.minZ + HALL.maxZ) / 2)
  box(W, HALL.h, 0.25, mats.wall, 0, 0, HALL.minZ - 0.12)
  box(0.25, HALL.h, D, mats.wall, HALL.minX - 0.12, 0, (HALL.minZ + HALL.maxZ) / 2)
  box(0.25, HALL.h, D, mats.wall, HALL.maxX + 0.12, 0, (HALL.minZ + HALL.maxZ) / 2)
  // front: windows either side of the vestibule
  for (const s of [-1, 1]) {
    const x0 = s * 1.2, x1 = s * 12
    const cx = (x0 + x1) / 2, w = Math.abs(x1 - x0)
    box(w, 0.9, 0.25, mats.wall, cx, 0, HALL.maxZ + 0.12)
    box(w, 0.8, 0.25, mats.wall, cx, 3.2, HALL.maxZ + 0.12, { solid: false })
    add(new THREE.PlaneGeometry(w, 2.3), mats.glass, cx, 2.05, HALL.maxZ + 0.12)
    colliders.push({ minX: Math.min(x0, x1), maxX: Math.max(x0, x1), minZ: HALL.maxZ, maxZ: HALL.maxZ + 0.25 })
    for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x += 2.7) box(0.12, 2.3, 0.3, mats.dark, x, 0.9, HALL.maxZ + 0.12, { solid: false })
  }
  box(2.4, 1.6, 0.25, mats.wall, 0, 2.4, HALL.maxZ + 0.12, { solid: false })
  // vestibule: right wall solid, left wall a mirror with a "mirror room" behind it
  box(0.2, 2.6, 2.6, mats.wall, 1.3, 0, 9.3)
  box(2.6, 1.6, 2.8, mats.wall, 0, 2.6, 9.3, { solid: false })
  add(new THREE.PlaneGeometry(2.0, 2.2).rotateY(Math.PI / 2), mats.mirror, -1.19, 1.25, 9.3)
  box(0.1, 2.6, 2.6, mats.dark, -3.7, 0, 9.3, { solid: false })
  box(2.5, 0.05, 2.6, mats.floor, -2.45, -0.04, 9.3, { solid: false })
  colliders.push({ minX: -1.3, maxX: -1.1, minZ: 8, maxZ: 10.6 })
  // ceiling light panels
  const lights = []
  for (let x = -9; x <= 9; x += 4.5) for (let z = -8; z <= 6; z += 4.6) { add(new THREE.BoxGeometry(1.2, 0.04, 0.5), mats.light, x, HALL.h - 0.03, z); lights.push({ x, y: HALL.h - 0.2, z }) }

  // ── gondolas: two faces each ──
  const faces = [] // { id, x, z0, z1, side, product, stock, cap, mesh }
  const GX = [-7.5, -3.5, 0.5, 4.5, 8.5]
  for (const gx of GX) {
    box(1.0, 0.24, 8.0, mats.gondola, gx, 0, -2.5) // base (and the part you bump into)
    box(0.1, 1.9, 8.0, mats.gondola, gx, 0, -2.5, { solid: false }) // the spine between the two faces
    for (const z of [-6.45, 1.45]) box(1.0, 1.9, 0.1, mats.gondola, gx, 0, z, { solid: false }) // end panels
    for (const side of [-1, 1]) {
      for (let k = 0; k < 4; k++) add(new THREE.BoxGeometry(0.45, 0.03, 7.8), mats.shelf, gx + side * 0.3, 0.25 + k * 0.45, -2.5)
      faces.push({ id: `g${faces.length}`, display: 'shelf', x: gx + side * 0.52, z0: -6.3, z1: 1.3, side, gx, customer: { x: gx + side * 1.4, z: -2.5 } })
    }
    // end-cap sign
    add(new THREE.BoxGeometry(0.9, 0.35, 0.04), mats.counter, gx, 2.25, 1.55)
  }
  // ── back wall: fridges and freezers ──
  const coolers = []
  const coolerDefs = [['fridge', -10.2], ['fridge', -7.6], ['freezer', -5.0], ['freezer', -2.4]]
  for (const [kind, x] of coolerDefs) {
    box(2.4, 2.1, 0.9, mats.fridge, x, 0, -10.45)
    add(new THREE.PlaneGeometry(2.2, 1.7), mats.glass, x, 1.15, -9.98)
    for (let k = 0; k < 3; k++) add(new THREE.BoxGeometry(2.2, 0.02, 0.6), mats.shelf, x, 0.45 + k * 0.5, -10.4)
    add(new THREE.BoxGeometry(2.3, 0.18, 0.05), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: kind === 'fridge' ? 0x9fe0ff : 0xc8f0ff, emissiveIntensity: 1.2 }), x, 2.0, -9.97)
    coolers.push({ id: `c${coolers.length}`, display: kind, x, z: -10.0, customer: { x, z: -8.9 } })
  }
  // ── produce crates ──
  const crates = []
  for (const [x, z] of [[4.4, 4.2]]) {
    box(1.6, 0.7, 1.1, mats.crate, x, 0, z)
    add(new THREE.BoxGeometry(1.5, 0.05, 1.0), mats.wood, x, 0.66, z)
    crates.push({ id: 'k0', display: 'crate', x, z, customer: { x, z: z - 1.2 } })
  }
  // ── tills ──
  for (const t of TILLS) {
    box(2.4, 0.95, 0.75, mats.counter, t.x, 0, t.counterZ)
    add(new THREE.BoxGeometry(2.45, 0.05, 0.8), mats.counterTop, t.x, 0.95, t.counterZ)
    add(new THREE.BoxGeometry(0.45, 0.3, 0.35), mats.dark, t.x + 0.75, 1.1, t.counterZ + 0.1)
    add(new THREE.BoxGeometry(0.35, 0.22, 0.03), new THREE.MeshStandardMaterial({ color: 0x0a2a1a, emissive: 0x2aff8a, emissiveIntensity: 0.35 }), t.x + 0.75, 1.36, t.counterZ - 0.05)
    add(new THREE.BoxGeometry(0.5, 0.02, 0.3), new THREE.MeshStandardMaterial({ color: 0x220000, emissive: 0xff2222, emissiveIntensity: 0.5 }), t.x - 0.2, 0.97, t.counterZ) // scanner glass
  }
  // ── grill counter + hot dog warmer ──
  box(2.6, 0.95, 0.75, mats.metal, GRILL.x, 0, GRILL.z)
  add(new THREE.BoxGeometry(1.1, 0.04, 0.6), mats.dark, GRILL.x - 0.55, 0.97, GRILL.z)
  for (let k = 0; k < 6; k++) add(new THREE.CylinderGeometry(0.018, 0.018, 1.0, 6).rotateZ(Math.PI / 2), mats.metal, GRILL.x - 0.55, 1.0, GRILL.z - 0.25 + k * 0.1)
  box(1.0, 0.45, 0.6, mats.glass, GRILL.x + 0.7, 0.95, GRILL.z, { solid: false })
  add(new THREE.BoxGeometry(1.0, 0.03, 0.6), mats.metal, GRILL.x + 0.7, 1.4, GRILL.z)
  // ── door console ──
  box(1.3, 0.95, 0.6, mats.counter, 2.1, 0, 6.95)
  add(new THREE.BoxGeometry(0.6, 0.4, 0.05), mats.dark, 2.3, 1.15, 6.8, 0.4)
  // ── stock room (back right) ──
  box(0.2, 2.6, 3.0, mats.wall, 5.0, 0, -9.5)
  box(4.4, 2.6, 0.2, mats.wall, 9.8, 0, -7.5)
  box(1.3, 0.75, 0.7, mats.wood, STOCKROOM.computer.x, 0, STOCKROOM.computer.z)
  add(new THREE.BoxGeometry(0.55, 0.4, 0.05), mats.dark, STOCKROOM.computer.x, 1.0, STOCKROOM.computer.z + 0.1)
  add(new THREE.BoxGeometry(0.5, 0.33, 0.02), new THREE.MeshStandardMaterial({ color: 0x0a1a2a, emissive: 0x3a8aff, emissiveIntensity: 0.6 }), STOCKROOM.computer.x, 1.0, STOCKROOM.computer.z + 0.13)
  box(1.6, 0.15, 1.2, mats.wood, STOCKROOM.pallet.x, 0, STOCKROOM.pallet.z, { solid: false })
  box(0.6, 2.0, 1.4, mats.dark, STOCKROOM.guns.x, 0, STOCKROOM.guns.z)
  add(new THREE.BoxGeometry(0.03, 1.6, 1.2), new THREE.MeshStandardMaterial({ color: 0x5a1a1a, roughness: 0.8 }), STOCKROOM.guns.x - 0.31, 1.1, STOCKROOM.guns.z)
  // a mural on the back wall
  const mural = new THREE.Mesh(new THREE.PlaneGeometry(6, 2.2), new THREE.MeshStandardMaterial({ map: owlMural(), roughness: 0.9 }))
  mural.position.set(1.8, 2.5, HALL.minZ + 0.02)
  root.add(mural)

  // ── street outside ──
  add(new THREE.PlaneGeometry(80, 3.6).rotateX(-Math.PI / 2), mats.pavement, 0, 0.01, 12.4)
  add(new THREE.PlaneGeometry(80, 8).rotateX(-Math.PI / 2), mats.asphalt, 0, 0, 18.2)
  add(new THREE.PlaneGeometry(80, 3).rotateX(-Math.PI / 2), mats.pavement, 0, 0.01, 23.7)
  box(80, 7, 0.4, mats.brick, 0, 0, 25.4, { solid: false })
  box(80, 6, 0.3, mats.brick, 0, 0, HALL.maxZ + 0.3, { solid: false })
  // store façade above the windows is drawn by the brick strip; the sign
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(7, 1.3), new THREE.MeshBasicMaterial({ map: neonSign(), transparent: true }))
  sign.position.set(0, 4.7, HALL.maxZ + 0.5)
  root.add(sign)
  const streetLights = []
  for (const x of [-16, 0, 16]) {
    box(0.15, 5, 0.15, mats.dark, x, 0, 14.0, { solid: false })
    add(new THREE.BoxGeometry(1.0, 0.12, 0.3), mats.dark, x, 5, 14.4)
    add(new THREE.BoxGeometry(0.8, 0.04, 0.22), mats.light, x, 4.93, 14.5)
    streetLights.push({ x, y: 4.8, z: 14.5 })
  }
  // invisible street edges so nobody walks into the road
  colliders.push({ minX: -40, maxX: 40, minZ: 14, maxZ: 15 })
  colliders.push({ minX: -21, maxX: -20, minZ: 8, maxZ: 15 }, { minX: 20, maxX: 21, minZ: 8, maxZ: 15 })

  // ── merge ──
  for (const [mat, geoms] of statics) {
    const list = geoms.map(g => (g.index ? g.toNonIndexed() : g))
    for (const g of list) {
      if (!g.attributes.uv) g.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2))
      for (const n of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(n)) g.deleteAttribute(n)
    }
    const m = new THREE.Mesh(mergeGeometries(list), mat)
    m.receiveShadow = high
    m.castShadow = high && mat !== mats.ceiling && mat !== mats.floor && mat !== mats.glass
    root.add(m)
  }

  // ── product displays (instanced, one per display) ──
  const displays = [...faces, ...coolers, ...crates, { id: 'grill', display: 'grill', x: GRILL.x + 0.7, z: GRILL.z, customer: GRILL.front }]
  for (const d of displays) {
    d.product = null
    d.stock = 0
    d.mesh = null
    d.tape = null
  }
  return { root, colliders, faces, coolers, crates, displays, lights, streetLights, mats }
}

/** shape of one unit of a product */
export function unitGeometry (shape) {
  switch (shape) {
    case 'bag': return new THREE.BoxGeometry(0.16, 0.24, 0.07)
    case 'can': return new THREE.CylinderGeometry(0.035, 0.035, 0.12, 10)
    case 'small': return new THREE.BoxGeometry(0.1, 0.06, 0.08)
    case 'loaf': return new THREE.CapsuleGeometry(0.06, 0.16, 3, 8).rotateZ(Math.PI / 2)
    case 'tall': return new THREE.BoxGeometry(0.1, 0.25, 0.07)
    case 'round': return new THREE.SphereGeometry(0.045, 10, 8)
    case 'tub': return new THREE.CylinderGeometry(0.07, 0.06, 0.1, 12)
    case 'flat': return new THREE.BoxGeometry(0.28, 0.04, 0.28)
    case 'sausage': return new THREE.CapsuleGeometry(0.022, 0.14, 3, 8).rotateZ(Math.PI / 2)
    default: return new THREE.BoxGeometry(0.14, 0.14, 0.1)
  }
}

/** Where unit k of a display sits (fills front to back, bottom to top) */
export function slotPosition (d, k, cap) {
  if (d.display === 'shelf') {
    const perRow = Math.ceil(cap / 4)
    const row = Math.floor(k / perRow), col = k % perRow
    return { x: d.x - d.side * 0.12, y: 0.42 + row * 0.45, z: d.z0 + (col + 0.5) * (d.z1 - d.z0) / perRow }
  }
  if (d.display === 'fridge' || d.display === 'freezer') {
    const perRow = Math.ceil(cap / 3)
    const row = Math.floor(k / perRow), col = k % perRow
    return { x: d.x - 1.0 + (col + 0.5) * 2.0 / perRow, y: 0.5 + row * 0.5 + 0.08, z: d.z - 0.35 }
  }
  if (d.display === 'crate') {
    const col = k % 8, row = Math.floor(k / 8)
    return { x: d.x - 0.6 + col * 0.17, y: 0.74 + (row % 2) * 0.06, z: d.z - 0.35 + row * 0.12 }
  }
  // grill warmer
  return { x: d.x - 0.4 + (k % 6) * 0.16, y: 1.0, z: d.z - 0.15 + Math.floor(k / 6) * 0.14 }
}

export function makeDisplayMesh (d, cap) {
  const p = productById(d.product)
  // each unit of stock shows as a little block of products so shelves look full
  const layout = d.display === 'shelf' ? { across: 3, deep: 2, scale: 1.5, gap: 0.2 } : (d.display === 'fridge' || d.display === 'freezer') ? { across: 1, deep: 2, scale: 1.3, gap: 0.2 } : { across: 1, deep: 1, scale: 1.25, gap: 0 }
  const copies = layout.across * layout.deep
  const geo = unitGeometry(p.shape).scale(layout.scale, layout.scale, layout.scale)
  const mesh = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: p.color, roughness: 0.5 }), cap * copies)
  const m = new THREE.Matrix4()
  let i = 0
  for (let k = 0; k < cap; k++) {
    const s = slotPosition(d, k, cap)
    for (let a = 0; a < layout.across; a++) {
      for (let b = 0; b < layout.deep; b++) {
        const off = (a - (layout.across - 1) / 2) * layout.gap
        const back = b * 0.18
        if (d.display === 'shelf') m.makeTranslation(s.x - d.side * back, s.y, s.z + off)
        else m.makeTranslation(s.x + off, s.y, s.z - back)
        mesh.setMatrixAt(i++, m)
      }
    }
  }
  mesh.userData.copies = copies
  mesh.frustumCulled = false // its bounds are measured while empty, so never cull it
  mesh.count = 0
  mesh.castShadow = false
  return mesh
}

/** product label for a display (hanging tag) */
export function labelSprite (text, color = '#ffd23f') {
  const c = document.createElement('canvas')
  c.width = 256; c.height = 64
  const g = c.getContext('2d')
  g.fillStyle = color; g.fillRect(0, 0, 256, 64)
  g.fillStyle = '#1c1f24'; g.font = '700 30px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'
  g.fillText(text, 128, 34)
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c) }))
  s.scale.set(0.9, 0.225, 1)
  return s
}

function neonSign () {
  const c = document.createElement('canvas')
  c.width = 1024; c.height = 190
  const g = c.getContext('2d')
  g.font = '800 104px system-ui, sans-serif'
  g.textAlign = 'center'; g.textBaseline = 'middle'
  g.shadowColor = '#ff5fa2'; g.shadowBlur = 28
  g.fillStyle = '#ffd1e6'
  g.fillText('NIGHT OWL', 420, 100)
  g.shadowColor = '#7dffc4'
  g.fillStyle = '#d9fff0'
  g.font = '700 54px system-ui, sans-serif'
  g.fillText('MARKET', 830, 104)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

function owlMural () {
  const c = document.createElement('canvas')
  c.width = 768; c.height = 280
  const g = c.getContext('2d')
  g.fillStyle = '#2f5a47'; g.fillRect(0, 0, 768, 280)
  g.fillStyle = '#f2c94c'; g.beginPath(); g.arc(640, 70, 46, 0, 7); g.fill() // moon
  // a big friendly owl
  g.fillStyle = '#8a5a3a'; g.beginPath(); g.ellipse(160, 160, 90, 110, 0, 0, 7); g.fill()
  g.fillStyle = '#e9e4d6'
  for (const x of [125, 195]) { g.beginPath(); g.arc(x, 130, 32, 0, 7); g.fill() }
  g.fillStyle = '#1c1f24'
  for (const x of [125, 195]) { g.beginPath(); g.arc(x, 132, 15, 0, 7); g.fill() }
  g.fillStyle = '#f2c94c'; g.beginPath(); g.moveTo(150, 160); g.lineTo(170, 160); g.lineTo(160, 182); g.fill()
  g.fillStyle = '#e9e4d6'; g.font = '800 64px system-ui, sans-serif'; g.fillText('OPEN ALL NIGHT', 290, 170)
  g.font = '600 26px system-ui, sans-serif'; g.fillText('Friendly faces only, please.', 294, 214)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

export { PRODUCTS }
