// Night Owl Market: game loop, economy, co-op glue, rendering.
import * as THREE from 'three'
import { buildStore, makeDisplayMesh, labelSprite, HALL, DOOR, TILLS, GRILL, STOCKROOM, slotPosition } from './store.js'
import { Customers, customerVisual, drawIdCard } from './customers.js'
import { gunModel, rayCylinder, rayBoxes, tracer } from './guns.js'
import { PRODUCTS, TIERS, UPGRADES, GUNS, TELLS, productById, gunById, gunStats, upgradeCost, makeVisitor, DAY_SECONDS, paranormalOdds } from './data.js'
import { input, initInput, initTouchControls, consumePressed, consumeLook } from './input.js'
import { initGamepad, BTN } from '../../gamekit/gamepad.js'
import { net, on, connect, disconnect, sendAll, sendHost, sendTo } from '../../gamekit/net.js'
import { createAvatar } from '../../gamekit/avatar.js'
import { bindFullscreenButtons } from '../../gamekit/fullscreen.js'
import * as A from './audio.js'
import { coopServerUrl } from './config.js'

const $ = s => document.querySelector(s)
const store = {
  get (k, f) { try { const v = JSON.parse(localStorage.getItem(k) || 'null'); return v ? { ...f, ...v } : { ...f } } catch { return { ...f } } },
  set (k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} },
}
const settings = store.get('market.settings', { sensitivity: 1, volume: 0.8, quality: 'auto', invertY: false })
const saveSettings = () => store.set('market.settings', settings)
const touch = (navigator.maxTouchPoints > 0 && matchMedia('(pointer: coarse)').matches) || /Android|iPhone|iPad/i.test(navigator.userAgent)
const quality = settings.quality === 'auto' ? (touch ? 'low' : 'high') : settings.quality
const HIGH = quality === 'high'
document.body.classList.toggle('touch-ui', touch)
let myName = (() => { try { return localStorage.getItem('market.name') || '' } catch { return '' } })() || `Clerk ${Math.floor(100 + Math.random() * 900)}`
const coopUrl = coopServerUrl

// which product lives on which display
const ASSIGN = { g0: 'chips', g1: 'soda', g2: 'candy', g3: 'bread', g4: 'soup', g5: 'cereal', g6: 'headphones', g7: 'toys', g8: 'batteries', g9: null, c0: 'milk', c1: 'cheese', c2: 'icecream', c3: 'pizza', k0: 'apples', grill: 'hotdog' }
const BASE_CAP = { shelf: 24, fridge: 18, freezer: 15, crate: 32, grill: 12 }

// ═════════════ renderer ═════════════
const canvas = $('#view')
const renderer = new THREE.WebGLRenderer({ canvas, antialias: HIGH, powerPreference: 'high-performance' })
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, HIGH ? 1.5 : 1))
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 1.0
renderer.shadowMap.enabled = HIGH
const scene = new THREE.Scene()
scene.background = new THREE.Color(0x070a14)
scene.fog = new THREE.Fog(0x070a14, 25, 60)
const camera = new THREE.PerspectiveCamera(72, 1, 0.03, 120)
camera.rotation.order = 'YXZ'
scene.add(camera)
const resize = () => { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix() }
addEventListener('resize', resize)
resize()
scene.add(new THREE.HemisphereLight(0xeaf6ff, 0x2a3040, 1.1))
const W = buildStore(scene, { quality })
// a few real lights in the shop; the street gets orange sodium lamps
const shopLights = []
for (const [x, z] of (HIGH ? [[-7, -4], [0, -4], [7, -4], [-5, 3], [5, 3]] : [[-4, -3], [4, 2]])) {
  const l = new THREE.PointLight(0xf4fff8, HIGH ? 14 : 20, HIGH ? 16 : 22, 1.4)
  l.position.set(x, HALL.h - 0.4, z)
  scene.add(l)
  shopLights.push(l)
}
for (const s of W.streetLights.slice(0, HIGH ? 3 : 1)) { const l = new THREE.PointLight(0xffb060, 18, 14, 1.5); l.position.set(s.x, s.y, s.z); scene.add(l) }
const doorLight = new THREE.SpotLight(0xffffff, 18, 6, 0.7, 0.5, 1.2)
doorLight.position.set(0, 2.55, 9.3)
doorLight.target.position.set(0, 0, 9.3)
scene.add(doorLight, doorLight.target)

// ═════════════ state ═════════════
const freshSave = () => ({ day: 1, money: 120, rating: 3, tiers: 1, upgrades: [], guns: { pistol: 1 }, stock: {} })
let save = store.get('market.save', freshSave())
const S = {
  phase: 'title', day: 1, clock: 0, money: 0, rating: 3, tiers: 1, upgrades: new Set(), guns: {},
  boxes: [], grill: [], stats: null, nextSpawn: 0, nextBoxId: 1, inspect: null,
}
const G = { mode: 'title', paused: false, visuals: new Map(), visitors: new Map(), avatars: new Map(), registry: new Map(), tracers: [], panel: null, lastState: 0, lastWorld: 0, boxMeshes: new Map(), dynamite: [] }
const P = { x: 0, z: 2, yaw: Math.PI, pitch: 0, hp: 100, hurtAt: 0, ko: false, hold: null, gun: null, ammo: {}, reloadUntil: 0, nextShot: 0, moving: false, sprinting: false, bob: 0, stepDist: 0, shake: 0, yawLog: [] }
const myId = () => net.id ?? 'local'
const isHost = () => net.isHost
const now = () => performance.now()
let customers = null

// displays: product + stock + label
const capOf = d => Math.round(BASE_CAP[d.display] * (S.upgrades.has('bigShelves') ? 1.5 : 1))
for (const d of W.displays) {
  d.product = ASSIGN[d.id] ?? null
  d.stock = 0
  d.unitValue = 1
  if (!d.product) continue
  const p = productById(d.product)
  d.label = labelSprite(`${p.name}  $${p.price.toFixed(2)}`)
  const lp = d.display === 'shelf' ? { x: d.x + d.side * 0.02, y: 2.05, z: (d.z0 + d.z1) / 2 } : d.display === 'grill' ? { x: d.x, y: 1.75, z: d.z - 0.4 } : d.display === 'crate' ? { x: d.x, y: 1.2, z: d.z - 0.6 } : { x: d.x, y: 2.35, z: d.z + 0.1 }
  d.label.position.set(lp.x, lp.y, lp.z)
  scene.add(d.label)
  d.tape = new THREE.Mesh(new THREE.BoxGeometry(d.display === 'shelf' ? 0.04 : 2.2, 0.12, d.display === 'shelf' ? 7.6 : 0.04), new THREE.MeshStandardMaterial({ color: 0xffd23f, roughness: 0.6 }))
  d.tape.position.set(d.display === 'shelf' ? d.x + d.side * 0.05 : d.x, 1.1, d.display === 'shelf' ? (d.z0 + d.z1) / 2 : d.z + 0.15)
  d.tape.rotation.z = d.display === 'shelf' ? 0 : 0.15
  scene.add(d.tape)
}
function rebuildDisplayMeshes () {
  for (const d of W.displays) {
    if (!d.product) continue
    if (d.mesh) { scene.remove(d.mesh); d.mesh.geometry.dispose() }
    d.mesh = makeDisplayMesh(d, capOf(d))
    scene.add(d.mesh)
  }
}
rebuildDisplayMeshes()
const unlocked = d => d.product && productById(d.product).tier <= S.tiers

// ═════════════ host: the shop ═════════════
const hooks = {
  displays: W.displays,
  pay: (total, till, by) => { S.money += total; S.stats.sales += total; S.stats.served++; fx('kaching', { till, total: +total.toFixed(2) }) },
  fx: (k, d) => fx(k, d),
  rating: (delta, why) => { S.rating = Math.max(0, Math.min(5, S.rating + delta)); if (delta < -0.05 && why) fx('note', { text: `Rating down: ${why}.` }) },
  bounty: (amount, text) => { S.money += amount; S.stats.bounties += amount; fx('note', { text: `${text} +$${amount}` }) },
  unlocked: () => PRODUCTS.filter(p => p.tier <= S.tiers).map(p => p.id),
  takeStock: d => { if (d.stock <= 0) return false; d.stock--; return true },
  playersNear: () => [],
  hurtPlayer: (id, dmg) => { if (id === myId()) hurtMe(dmg); else sendTo(id, 'hurt', { dmg }) },
  doorStaffed: () => [...G.registry.values()].some(p => Math.hypot(p.x - DOOR.console.x, p.z - DOOR.console.z) < 2.2),
  autoDoor: () => S.upgrades.has('scanner'),
  cashier: () => S.upgrades.has('cashier'),
  monsterHp: () => 60 + S.day * 12,
}

function loadSave () {
  S.day = save.day; S.money = save.money; S.rating = save.rating; S.tiers = save.tiers
  S.upgrades = new Set(save.upgrades); S.guns = { ...save.guns }
  for (const d of W.displays) { const st = save.stock[d.id]; d.stock = st ? st[0] : 0; d.unitValue = st ? st[1] : 1 }
  rebuildDisplayMeshes()
}
function writeSave () {
  if (!isHost()) return
  save = { day: S.day, money: Math.round(S.money * 100) / 100, rating: S.rating, tiers: S.tiers, upgrades: [...S.upgrades], guns: S.guns, stock: Object.fromEntries(W.displays.filter(d => d.product).map(d => [d.id, [d.stock, d.unitValue]])) }
  store.set('market.save', save)
}

function openNight () {
  S.phase = 'open'
  S.clock = 0
  S.stats = { sales: 0, spent: 0, fines: 0, bounties: 0, served: 0, wrongIn: 0, killed: 0, ratingStart: S.rating }
  S.nextSpawn = now() + 3000
  customers = new Customers(hooks)
  G.visitors.clear()
  fx('night', { day: S.day })
}

function hostTick (dt, t) {
  if (S.phase === 'open' || S.phase === 'closing') {
    S.clock += dt / DAY_SECONDS
    if (S.phase === 'open' && S.clock >= 1) { S.phase = 'closing'; fx('closing', {}) }
    if (S.phase === 'open' && t > S.nextSpawn && customers.list.length < 12) {
      const interval = Math.max(3.2, 10 - S.rating * 1.1 - S.tiers * 0.45)
      S.nextSpawn = t + interval * 1000 * (0.7 + Math.random() * 0.6)
      const v = makeVisitor(Math.random, paranormalOdds(S.day), S.day)
      const c = customers.spawn(v)
      G.visitors.set(c.id, v)
      sendAll('spawn', { id: c.id, v })
    }
    const players = [...G.registry.values()].map(p => ({ id: p.id, x: p.x, z: p.z, down: p.ko }))
    customers.update(dt, t, players)
    if (S.phase === 'closing') {
      // the queue outside goes home; once the shop is empty (and nothing is loose), the night ends
      for (const c of customers.list) if (c.state === 'queue' || c.state === 'arrive' || c.state === 'inspect' || c.state === 'toInspect') { c.state = 'leave'; c.path = [{ x: 24 * (Math.random() < 0.5 ? -1 : 1), z: 12.8 }] }
      if (!customers.list.some(c => c.state !== 'leave') || customers.list.length === 0) endNight()
    }
    // the grill keeps cooking
    for (const s of S.grill) s.t += dt
    // deliveries
    for (const b of S.boxes) if (b.arriveAt && t >= b.arriveAt) { b.arriveAt = 0; fx('delivery', {}) }
    // dynamite
    for (const d of G.dynamite) {
      if (!d.host) continue
      if (t >= d.boomAt && !d.done) {
        d.done = true
        const pos = d.pos
        fx('boom', { x: pos.x, y: pos.y, z: pos.z })
        for (const c of customers.list) {
          const dist = Math.hypot(c.x - pos.x, c.z - pos.z)
          if (dist < d.radius) hitCustomer(c, d.dmg * (1 - dist / d.radius * 0.6), d.by, d.spin)
        }
        for (const p of G.registry.values()) { const dist = Math.hypot(p.x - pos.x, p.z - pos.z); if (dist < d.radius * 0.8) hooks.hurtPlayer(p.id, Math.round(30 * (1 - dist / d.radius))) }
      }
    }
  }
  if (net.online && t - G.lastWorld > 100) { G.lastWorld = t; sendAll('world', worldSnapshot()) }
}

function endNight () {
  S.phase = 'summary'
  const st = S.stats
  st.ratingEnd = S.rating
  writeSaveAfter()
  fx('summary', { st, day: S.day })
}
function writeSaveAfter () { S.day += 1; writeSave(); S.day -= 1 }

function hitCustomer (c, dmg, by, spin) {
  const r = customers.damage(c, dmg)
  if (!r) return
  if (r === 'hit') fx('hit', { x: c.x, z: c.z })
  if (r === 'killed' || r === 'unmasked') {
    const bounty = (r === 'unmasked' ? 45 : 30) + S.day * 5 + (spin ? 100 : 0)
    S.money += bounty
    S.stats.bounties += bounty
    S.stats.killed++
    fx('kill', { id: c.id, x: c.x, z: c.z, bounty, spin: !!spin, unmasked: r === 'unmasked', by })
  }
  if (r === 'human') {
    S.money -= 250
    S.stats.fines += 250
    S.rating = Math.max(0, S.rating - 0.6)
    fx('shotHuman', { x: c.x, z: c.z, by })
  }
}

/** a request from a player (the host runs these) */
function hostRequest (pid, d) {
  const tell = text => fx('note', { text, to: pid })
  switch (d.kind) {
    case 'decide': { const c = customers?.list.find(x => x.state === 'inspect'); if (c) { if (d.admit && !c.v.human) S.stats.wrongIn++; customers.decide(c, d.admit, pid) } break }
    case 'scan': { const c = customers?.list.find(x => x.state === 'paying' && x.till === d.till); if (c) customers.scan(c, pid); break }
    case 'order': {
      const p = productById(d.product)
      if (!p || p.tier > S.tiers) return
      if (S.money < p.cost) { tell('Not enough money for that.'); return }
      S.money -= p.cost
      S.stats && (S.stats.spent += p.cost)
      const onPallet = S.boxes.filter(b => !b.carrier && Math.hypot(b.x - STOCKROOM.pallet.x, b.z - STOCKROOM.pallet.z) < 1.2).length
      const k = onPallet
      S.boxes.push({ id: `b${S.nextBoxId++}`, product: p.id, units: p.box, x: STOCKROOM.pallet.x - 0.45 + (k % 3) * 0.45, y: 0.15 + Math.floor(k / 3) % 3 * 0.32, z: STOCKROOM.pallet.z - 0.25 + Math.floor(k / 9) * 0.5, carrier: null, arriveAt: now() + (S.upgrades.has('fastDelivery') ? 1200 : 6000) })
      fx('ordered', { to: pid, product: p.id })
      break
    }
    case 'pick': { const b = S.boxes.find(x => x.id === d.box && !x.carrier && !x.arriveAt); if (b) { b.carrier = pid; fx('pick', { box: b.id, by: pid }) } break }
    case 'drop': { const b = S.boxes.find(x => x.id === d.box && x.carrier === pid); if (b) { b.carrier = null; b.x = d.x; b.y = 0; b.z = d.z; fx('dropBox', { x: d.x, z: d.z }) } break }
    case 'stock': {
      const b = S.boxes.find(x => x.id === d.box && x.carrier === pid)
      const disp = W.displays.find(x => x.id === d.display)
      if (!b || !disp || disp.product !== b.product || !unlocked(disp)) return
      const n = Math.min(b.units, capOf(disp) - disp.stock)
      if (n <= 0) { tell('That shelf is full.'); return }
      disp.unitValue = (disp.unitValue * disp.stock + 1 * n) / (disp.stock + n)
      disp.stock += n
      b.units -= n
      fx('stocked', { display: disp.id, n })
      if (b.units <= 0) { S.boxes = S.boxes.filter(x => x !== b); fx('boxEmpty', { to: pid }) }
      break
    }
    case 'grillOn': {
      const b = S.boxes.find(x => x.id === d.box && x.carrier === pid && x.product === 'hotdog')
      const slots = S.upgrades.has('grill2') ? 8 : 4
      if (!b) return
      const n = Math.min(b.units, slots - S.grill.length)
      if (n <= 0) { tell('The grill is full.'); return }
      for (let k = 0; k < n; k++) S.grill.push({ t: 0 })
      b.units -= n
      if (b.units <= 0) { S.boxes = S.boxes.filter(x => x !== b); fx('boxEmpty', { to: pid }) }
      fx('sizzle', {})
      break
    }
    case 'grillOff': {
      if (!S.grill.length) return
      const warmer = W.displays.find(x => x.id === 'grill')
      const vals = S.grill.map(s => grillValue(s.t))
      const room = capOf(warmer) - warmer.stock
      const take = vals.slice(0, room)
      if (!take.length) { tell('The warmer is full.'); return }
      const avg = take.reduce((a, b) => a + b, 0) / take.length
      warmer.unitValue = (warmer.unitValue * warmer.stock + avg * take.length) / (warmer.stock + take.length)
      warmer.stock += take.length
      S.grill = S.grill.slice(take.length)
      fx('grilled', { avg: +avg.toFixed(2), to: pid })
      break
    }
    case 'shoot': {
      if (!customers) return
      const o = d.o
      for (const dir of d.dirs) {
        const wallT = rayBoxes(o, dir, W.colliders)
        let best = null
        for (const c of customers.list) {
          if (c.state === 'gone' || c.state === 'dying') continue
          const v = G.visitors.get(c.id)
          const h = (v?.height ?? 175) / 100 * (c.state === 'turned' ? 1.5 : 1.0)
          const t = rayCylinder(o, dir, c.x, c.z, c.state === 'turned' ? 0.5 : 0.36, h)
          if (t != null && t < wallT && (!best || t < best.t)) best = { c, t }
        }
        if (best) hitCustomer(best.c, d.dmg, pid, d.spin)
      }
      break
    }
    case 'throw': {
      const dyn = { ...d.dyn, host: true, by: pid, spin: d.spin }
      G.dynamite.push(dyn)
      sendAll('dynamite', { dyn: d.dyn })
      break
    }
    case 'buyTier': {
      const next = TIERS[S.tiers]
      if (!next || S.money < next.cost) return
      S.money -= next.cost
      S.tiers++
      fx('tier', { n: S.tiers, name: next.name })
      break
    }
    case 'buyUpgrade': {
      const u = UPGRADES.find(x => x.id === d.id)
      if (!u || S.upgrades.has(u.id) || S.money < u.cost || u.tier > S.tiers) return
      S.money -= u.cost
      S.upgrades.add(u.id)
      fx('upgrade', { name: u.name })
      if (u.id === 'bigShelves') { rebuildDisplayMeshes(); sendAll('rebuild', {}) }
      break
    }
    case 'buyGun': {
      const g = gunById(d.id)
      const lvl = S.guns[g.id] ?? 0
      const cost = lvl === 0 ? g.cost : upgradeCost(g, lvl)
      if (lvl >= 5 || S.money < cost) return
      S.money -= cost
      S.guns[g.id] = lvl + 1
      fx('gunBought', { id: g.id, level: lvl + 1, to: pid })
      break
    }
    case 'ko': S.money = Math.max(0, S.money - 50); break
    case 'nextDay': if (S.phase === 'summary') { S.day++; writeSave(); openNight() } break
  }
}

const grillValue = t => (t < 8 ? 0.6 + 0.9 * t / 8 : t < 10.5 ? 1.5 : Math.max(0, 1.5 * (1 - (t - 10.5) / 5.5)))

function worldSnapshot () {
  return {
    phase: S.phase, day: S.day, clock: +S.clock.toFixed(4), money: Math.round(S.money * 100) / 100, rating: +S.rating.toFixed(2), tiers: S.tiers,
    upg: [...S.upgrades], guns: S.guns, cust: customers ? customers.snapshot() : [],
    stock: W.displays.filter(d => d.product).map(d => [d.id, d.stock, +d.unitValue.toFixed(2)]),
    boxes: S.boxes.map(b => [b.id, b.product, b.units, +b.x.toFixed(2), +b.y.toFixed(2), +b.z.toFixed(2), b.carrier, b.arriveAt ? 1 : 0]),
    grill: S.grill.map(s => +s.t.toFixed(1)),
  }
}

// ═════════════ effects (everyone) ═════════════
function fx (kind, d = {}) {
  playFx(kind, d)
  if (net.online && isHost()) sendAll('fx', { kind, data: d })
}
const at = (x, z, y = 1.3) => ({ x, y, z })
function playFx (kind, d) {
  if (d.to && d.to !== myId()) return
  switch (kind) {
    case 'night': big(`Night ${d.day}`, 'Doors open at 20:00. Check every face.'); A.play('day_start', { vol: 0.6, music: true }); break
    case 'closing': toast('08:00. Closing time: no more customers. Finish up.'); A.play('day_start', { vol: 0.5, rate: 0.8, music: true }); break
    case 'summary': showSummary(d.st, d.day); break
    case 'doorbell': A.play('doorbell', { pos: at(0, 9.3, 2.4), vol: 0.8 }); break
    case 'admit': A.play('door_slide', { pos: at(0, 8), vol: 0.6 }); break
    case 'reject': A.play('buzzer', { pos: at(0, 9.3), vol: 0.6 }); if (d.by === myId() || d.by === 'scanner') toast(d.human ? 'You turned away a real customer.' : 'Good call. It wasn\'t a person.'); break
    case 'beep': A.play('beep', { pos: at(TILLS[d.till].x, TILLS[d.till].counterZ), vol: 0.7, rateJitter: 0 }); break
    case 'kaching': A.play('kaching', { pos: at(TILLS[d.till].x, TILLS[d.till].counterZ), vol: 0.8 }); popMoney(`+$${d.total.toFixed(2)}`); break
    case 'grumble': A.play('grumble', { pos: at(d.x, d.z), vol: 0.7 }); break
    case 'emptyShelf': if (Math.random() < 0.3) toast(`A customer wanted ${productById(d.product)?.name.toLowerCase() ?? 'something'} and the shelf was empty.`); break
    case 'turn': A.play('monster_turn', { pos: at(d.x, d.z), vol: 1.3, ref: 4 }); A.play('stinger', { vol: 0.6, music: true }); big('Something got in', 'Shoot it before it hurts anyone.'); G.flicker = now() + 1500; break
    case 'scream': A.play('scream', { pos: at(d.x, d.z, 1.6), vol: 0.7 }); break
    case 'swipe': A.play('swipe', { pos: at(d.x, d.z), vol: 1 }); break
    case 'smash': A.play('smash', { pos: at(d.x, d.z, 1), vol: 0.8 }); break
    case 'hit': A.play('impact', { pos: at(d.x, d.z), vol: 0.8 }); break
    case 'kill': A.play('splat', { pos: at(d.x, d.z), vol: 1 }); popMoney(`+$${d.bounty}`); if (d.spin && d.by === myId()) big('Spooky spin!', '+$100 for style'); else if (d.unmasked) toast('It was one of them. Its face slides off as it falls.'); break
    case 'shotHuman': A.play('scream', { pos: at(d.x, d.z, 1.6), vol: 1 }); A.play('buzzer', { vol: 0.8 }); toast(d.by === myId() ? 'That was a real customer. -$250 and the police aren\'t happy.' : 'Someone shot a real customer. -$250.'); break
    case 'boom': A.play('explosion', { pos: at(d.x, d.z), vol: 1.4, ref: 6 }); P.shake = Math.max(P.shake, 1 - Math.min(1, Math.hypot(d.x - P.x, d.z - P.z) / 14)); spawnBoom(d); break
    case 'delivery': A.play('truck', { pos: at(STOCKROOM.pallet.x, STOCKROOM.pallet.z), vol: 0.6 }); break
    case 'ordered': toast(`Ordered: ${productById(d.product).name}. The box will be on the pallet in the stock room.`); A.play('click', { vol: 0.5 }); break
    case 'pick': A.play('box', { pos: at(P.x, P.z), vol: 0.5 }); if (d.by === myId()) P.hold = { type: 'box', box: d.box }; break
    case 'dropBox': A.play('box', { pos: at(d.x, d.z, 0.3), vol: 0.6, rate: 0.8 }); break
    case 'stocked': { const disp = W.displays.find(x => x.id === d.display); A.play('stock', { pos: at(disp.customer.x, disp.customer.z), vol: 0.6 }); break }
    case 'boxEmpty': if (P.hold?.type === 'box') P.hold = null; toast('Box empty. It goes in the recycling.'); break
    case 'sizzle': A.play('sizzle', { pos: at(GRILL.x, GRILL.z), vol: 0.8 }); break
    case 'grilled': toast(d.avg >= 1.45 ? 'Perfect! Those sell for 1.5 times the price.' : d.avg <= 0.2 ? 'Burnt to a crisp. Nobody will pay for those.' : `Cooked: they'll sell at ${Math.round(d.avg * 100)}% of the price.`); A.play(d.avg >= 1.45 ? 'perfect' : d.avg <= 0.2 ? 'burnt' : 'click', { vol: 0.6 }); break
    case 'tier': big(`Tier ${d.n} unlocked`, `${d.name}: new shelves are open. Order stock for them on the computer.`); A.play('unlock', { vol: 0.7, music: true }); break
    case 'upgrade': toast(`Upgrade bought: ${d.name}.`); A.play('unlock', { vol: 0.5, music: true }); break
    case 'gunBought': toast(`${gunById(d.id).name}: level ${d.level}.`); A.play('reload', { vol: 0.8 }); renderGuns(); break
    case 'note': toast(d.text); break
  }
}

// ═════════════ networking ═════════════
on('state', (d, from) => {
  const p = G.registry.get(from) ?? { id: from }
  Object.assign(p, d, { id: from })
  G.registry.set(from, p)
  let av = G.avatars.get(from)
  if (!av) {
    const model = createAvatar(from, { outfit: 'clerk', name: playerName(from), shadows: HIGH })
    scene.add(model.group)
    av = { model, target: d, x: d.x, z: d.z, yaw: d.yaw, speed: 0, gun: null, gunId: null }
    G.avatars.set(from, av)
  }
  av.target = d
})
on('req', (d, from) => { if (isHost()) hostRequest(from, d) })
on('fx', d => { if (!isHost()) playFx(d.kind, d.data ?? {}) })
on('spawn', d => { if (!isHost()) G.visitors.set(d.id, d.v) })
on('visitors', d => { if (!isHost()) for (const [id, v] of d.list) G.visitors.set(id, v) })
on('hurt', d => hurtMe(d.dmg))
on('rebuild', () => rebuildDisplayMeshes())
on('dynamite', d => { if (!isHost()) G.dynamite.push({ ...d.dyn }) })
on('start', d => { if (!isHost()) startGame({ coop: true }) })
on('world', d => {
  if (isHost()) return
  const wasPhase = S.phase
  Object.assign(S, { phase: d.phase, day: d.day, clock: d.clock, money: d.money, rating: d.rating, tiers: d.tiers, guns: d.guns })
  const upg = new Set(d.upg)
  if (upg.has('bigShelves') !== S.upgrades.has('bigShelves')) { S.upgrades = upg; rebuildDisplayMeshes() } else S.upgrades = upg
  G.cust = d.cust
  for (const [id, stock, value] of d.stock) { const disp = W.displays.find(x => x.id === id); if (disp) { disp.stock = stock; disp.unitValue = value } }
  S.boxes = d.boxes.map(([id, product, units, x, y, z, carrier, arriving]) => ({ id, product, units, x, y, z, carrier, arriveAt: arriving ? 1 : 0 }))
  S.grill = d.grill.map(t => ({ t }))
  if (P.hold?.type === 'box' && !S.boxes.some(b => b.id === P.hold.box && b.carrier === myId())) P.hold = null
  if (wasPhase === 'summary' && S.phase === 'open') { G.panel = null; input.enabled = true; showScreen(null); setHud(true) }
})
on('peerJoin', d => {
  toast(`${d.name} clocked in.`)
  if (isHost() && G.mode !== 'title') {
    sendTo(d.id, 'visitors', { list: [...G.visitors] })
    sendTo(d.id, 'start', {})
  }
  refreshLobby()
})
on('peerLeave', d => {
  toast(`${playerName(d.id)} clocked out.`)
  G.registry.delete(d.id)
  const av = G.avatars.get(d.id)
  if (av) { av.model.dispose(); G.avatars.delete(d.id) }
  // drop any box they were holding
  for (const b of S.boxes) if (b.carrier === d.id) { b.carrier = null; b.y = 0 }
  refreshLobby()
})
on('hostChange', ({ isHost: me }) => {
  if (me && G.mode !== 'title') {
    // take over the shop from the last numbers we heard
    customers = new Customers(hooks)
    for (const row of G.cust ?? []) {
      const [id, x, z, yaw, state] = row
      const v = G.visitors.get(id)
      if (!v) continue
      const c = customers.spawn(v)
      Object.assign(c, { id, x, z, yaw, state: ['turned', 'leave'].includes(state) ? state : 'leave', path: state === 'leave' ? [DOOR.outer, { x: 24, z: 12.8 }] : [], hp: 80, maxHp: 80 })
    }
    if (!S.stats) S.stats = { sales: 0, spent: 0, fines: 0, bounties: 0, served: 0, wrongIn: 0, killed: 0, ratingStart: S.rating }
    toast('You are now running the shop.')
  }
  refreshLobby()
})
on('disconnected', () => { if (G.mode !== 'title') { toast('Lost the connection. Carrying on alone.'); for (const av of G.avatars.values()) av.model.dispose(); G.avatars.clear(); if (!customers) openNight() } })
on('roster', () => refreshLobby())
on('name', (d, from) => { const p = net.players.get(from); if (p) p.name = d.name; refreshLobby() })
const playerName = id => (id === myId() ? myName : net.players.get(id)?.name ?? 'Someone')
const request = (kind, data = {}) => { if (isHost()) hostRequest(myId(), { kind, ...data }); else sendHost('req', { kind, ...data }) }

// ═════════════ player ═════════════
function hurtMe (dmg) {
  if (P.ko) return
  P.hp = Math.max(0, P.hp - dmg)
  P.hurtAt = now()
  P.shake = Math.max(P.shake, 0.6)
  A.play('hurt', { vol: 0.9 })
  $('#hurt').style.opacity = '1'
  setTimeout(() => { $('#hurt').style.opacity = '0' }, 300)
  if (P.hp <= 0) {
    P.ko = true
    dropBox()
    fade(1, 400)
    toast('You were knocked out. You wake up in the stock room. (-$50)', 4000)
    request('ko')
    setTimeout(() => { P.x = 7.5; P.z = -9.2; P.yaw = 0; P.hp = 100; P.ko = false; fade(0, 900) }, 3200)
  }
}

function collide () {
  const R = 0.3
  for (let it = 0; it < 3; it++) {
    let pushed = false
    for (const c of W.colliders) {
      const cx = Math.max(c.minX, Math.min(P.x, c.maxX)), cz = Math.max(c.minZ, Math.min(P.z, c.maxZ))
      const dx = P.x - cx, dz = P.z - cz, d2 = dx * dx + dz * dz
      if (d2 >= R * R) continue
      if (d2 > 1e-8) { const d = Math.sqrt(d2); P.x += dx / d * (R - d); P.z += dz / d * (R - d) } else {
        const o = [[c.minX - R - P.x, 0], [c.maxX + R - P.x, 0], [0, c.minZ - R - P.z], [0, c.maxZ + R - P.z]].sort((a, b) => Math.abs(a[0] + a[1]) - Math.abs(b[0] + b[1]))[0]
        P.x += o[0]; P.z += o[1]
      }
      pushed = true
    }
    if (!pushed) break
  }
  // the vestibule is for customers: staff stay inside
  if (P.z > 7.7 && Math.abs(P.x) < 1.4) P.z = 7.7
}

function updatePlayer (dt, look, canAct) {
  const sens = 0.0022 * settings.sensitivity
  const oldYaw = P.yaw
  P.yaw -= look.x * sens
  P.pitch = Math.max(-1.35, Math.min(1.35, P.pitch - look.y * sens * (settings.invertY ? -1 : 1)))
  // remember how far we've spun (for the spin bonus)
  P.yawLog.push([now(), P.yaw - oldYaw])
  while (P.yawLog.length && now() - P.yawLog[0][0] > 1300) P.yawLog.shift()
  if (P.ko) return
  let mx = canAct ? input.move.x : 0, my = canAct ? input.move.y : 0
  const len = Math.hypot(mx, my)
  if (len > 1) { mx /= len; my /= len }
  const sprint = canAct && input.held.sprint && my > 0.3
  const speed = (sprint ? 5.0 : 3.2) * (P.hold?.type === 'box' ? 0.85 : 1)
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw), rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw)
  const ox = P.x, oz = P.z
  P.x += (fx * my + rx * mx) * speed * dt
  P.z += (fz * my + rz * mx) * speed * dt
  collide()
  const moved = Math.hypot(P.x - ox, P.z - oz)
  P.moving = len > 0.15 && moved / dt > 0.2
  P.sprinting = sprint && P.moving
  if (P.moving) {
    P.stepDist += moved
    P.bob += moved * 3
    if (P.stepDist > (P.sprinting ? 0.85 : 0.7)) { P.stepDist = 0; A.play('step_tile', { pos: at(P.x, P.z, 0.1), vol: P.sprinting ? 0.6 : 0.35 }) }
  }
  if (P.hp < 100 && now() - P.hurtAt > 5000) P.hp = Math.min(100, P.hp + 6 * dt)
}
const spinBonus = () => Math.abs(P.yawLog.reduce((s, [, d]) => s + d, 0)) > Math.PI * 1.9

// ═════════════ guns ═════════════
let viewGun = null
function equip (id) {
  if (P.hold?.type === 'box') dropBox()
  if (viewGun) { camera.remove(viewGun); viewGun = null }
  if (!id || P.gun === id) { P.gun = null; P.hold = null; return }
  P.gun = id
  P.hold = { type: 'gun', id }
  const lvl = S.guns[id] ?? 1
  if (P.ammo[id] == null) P.ammo[id] = gunStats(gunById(id), lvl).mag
  viewGun = gunModel(id)
  viewGun.position.set(Math.min(0.22, 0.17 * camera.aspect), -0.2, -0.42)
  camera.add(viewGun)
  A.play('reload', { vol: 0.4, rate: 1.3 })
}
function ownedGuns () { return GUNS.filter(g => S.guns[g.id]) }

function fire (t) {
  if (!P.gun) return
  const g = gunById(P.gun)
  const st = gunStats(g, S.guns[g.id] ?? 1)
  if (t < P.nextShot || t < P.reloadUntil) return
  if ((P.ammo[g.id] ?? 0) <= 0) { reload(); return }
  P.nextShot = t + 1000 / st.rate
  P.ammo[g.id]--
  const o = new THREE.Vector3(); camera.getWorldPosition(o)
  const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
  const spin = spinBonus()
  if (g.throw) {
    // throw the dynamite in an arc
    const dyn = { pos: { x: o.x + fwd.x * 0.5, y: o.y, z: o.z + fwd.z * 0.5 }, vel: { x: fwd.x * 9, y: fwd.y * 9 + 3.5, z: fwd.z * 9 }, boomAt: Date.now() + 1700, born: Date.now(), dmg: st.dmg, radius: g.radius }
    if (isHost()) { dyn.boomAt = now() + 1700; G.dynamite.push({ ...dyn, host: true, by: myId(), spin }); sendAll('dynamite', { dyn: { ...dyn, boomAt: 1700 } }) } else { sendHost('req', { kind: 'throw', dyn: { ...dyn, boomAt: 1700 }, spin }) }
    A.play('fuse', { vol: 0.8 })
  } else {
    const dirs = []
    for (let k = 0; k < st.pellets; k++) {
      const d = fwd.clone()
      d.x += (Math.random() - 0.5) * 2 * st.spread; d.y += (Math.random() - 0.5) * 2 * st.spread; d.z += (Math.random() - 0.5) * 2 * st.spread
      d.normalize()
      dirs.push({ x: d.x, y: d.y, z: d.z })
      const tWall = Math.min(40, rayBoxes(o, d, W.colliders))
      const start = new THREE.Vector3(); viewGun?.userData.flash.getWorldPosition(start)
      G.tracers.push(tracer(scene, start, o.clone().addScaledVector(d, tWall)))
    }
    request('shoot', { o: { x: o.x, y: o.y, z: o.z }, dirs, dmg: st.dmg, spin })
    A.play(g.sound, { vol: 0.9 })
    if (viewGun) { viewGun.userData.flash.material.opacity = 1; viewGun.position.z = -0.42 + 0.06; viewGun.rotation.x = 0.12 }
    P.shake = Math.max(P.shake, g.id === 'shotgun' || g.id === 'rifle' ? 0.35 : 0.12)
  }
  sendAll('shot', { gun: g.id })
}
function reload () {
  if (!P.gun) return
  const g = gunById(P.gun)
  const st = gunStats(g, S.guns[g.id] ?? 1)
  if (P.ammo[g.id] >= st.mag || now() < P.reloadUntil) return
  P.reloadUntil = now() + st.reload * 1000
  A.play('reload', { vol: 0.8 })
  setTimeout(() => { P.ammo[g.id] = st.mag }, st.reload * 1000)
}
on('shot', (d, from) => { const p = G.registry.get(from); if (p) A.play(gunById(d.gun).sound, { pos: at(p.x, p.z), vol: 0.9, ref: 4 }) })

const booms = []
function spawnBoom (d) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), new THREE.MeshBasicMaterial({ color: 0xffb040, transparent: true, opacity: 0.9 }))
  m.position.set(d.x, Math.max(0.5, d.y), d.z)
  scene.add(m)
  const l = new THREE.PointLight(0xffa040, 40, 12, 1.5)
  l.position.copy(m.position)
  scene.add(l)
  booms.push({ m, l, t: 0 })
}

// ═════════════ interaction ═════════════
const tmpV = new THREE.Vector3()
function findInteraction () {
  if (P.ko || G.mode !== 'playing') return null
  const eye = new THREE.Vector3(P.x, 1.6, P.z)
  const fwd = new THREE.Vector3(-Math.sin(P.yaw) * Math.cos(P.pitch), Math.sin(P.pitch), -Math.cos(P.yaw) * Math.cos(P.pitch))
  let best = null
  const consider = (x, y, z, reach, label, data, lim = 0.55) => {
    tmpV.set(x, y, z).sub(eye)
    const d = tmpV.length()
    if (d > reach) return
    const ang = tmpV.normalize().angleTo(fwd)
    if (ang > lim + (d < 1 ? 0.4 : 0)) return
    const score = d + ang * 2
    if (!best || score < best.score) best = { ...data, label, score }
  }
  const box = P.hold?.type === 'box' ? S.boxes.find(b => b.id === P.hold.box) : null
  // boxes to pick up
  if (!box) for (const b of S.boxes) if (!b.carrier && !b.arriveAt) consider(b.x, b.y + 0.15, b.z, 2.2, `Pick up: ${productById(b.product).name} (${b.units})`, { kind: 'pick', box: b.id })
  // shelves
  if (box) for (const d of W.displays) {
    if (!d.product || d.id === 'grill') continue
    const pos = d.display === 'shelf' ? { x: d.x, y: 1.0, z: Math.max(d.z0, Math.min(d.z1, P.z)) } : { x: d.x, y: 1.0, z: d.z }
    const ok = d.product === box.product
    consider(pos.x, pos.y, pos.z, 2.3, !unlocked(d) ? `Locked until tier ${productById(d.product).tier}` : ok ? `Stock ${productById(d.product).name} (${d.stock}/${capOf(d)})` : `This shelf takes ${productById(d.product).name}`, { kind: ok && unlocked(d) ? 'stock' : 'none', display: d.id }, 0.7)
  }
  // tills
  for (const t of TILLS) {
    if (Math.hypot(P.x - t.staff.x, P.z - t.staff.z) > 1.4) continue
    const c = customerAtTill(t.id)
    if (c) { const left = c.cart - c.scanned; consider(t.x - 0.2, 1.0, t.counterZ, 2.0, `Scan item (${left} left)`, { kind: 'scan', till: t.id }, 1.2) }
  }
  // grill
  if (Math.hypot(P.x - GRILL.staff.x, P.z - GRILL.staff.z) < 1.6) {
    if (box?.product === 'hotdog') consider(GRILL.x - 0.55, 1.0, GRILL.z, 2.0, 'Put hot dogs on the grill', { kind: 'grillOn' }, 1.2)
    else if (S.grill.length) consider(GRILL.x - 0.55, 1.0, GRILL.z, 2.0, 'Take the hot dogs off', { kind: 'grillOff' }, 1.2)
  }
  consider(STOCKROOM.computer.x, 1.0, STOCKROOM.computer.z, 2.0, 'Use the computer', { kind: 'computer' })
  consider(STOCKROOM.guns.x - 0.3, 1.1, STOCKROOM.guns.z, 2.0, 'Open the gun locker', { kind: 'locker' })
  return best
}
function customerAtTill (till) {
  const rows = isHost() ? (customers?.list ?? []).map(c => ({ state: c.state, till: c.till, scanned: c.scanned, cart: c.cart.length, items: c.cart.map(i => i.product), id: c.id })) : (G.cust ?? []).map(r => ({ id: r[0], state: r[4], till: r[6], scanned: r[7], cart: r[8], items: (r[10] || '').split(',').filter(Boolean) }))
  return rows.find(c => c.state === 'paying' && c.till === till) ?? null
}
function useInteraction (t) {
  if (!t) return
  switch (t.kind) {
    case 'pick': if (P.gun) equip(null); request('pick', { box: t.box }); break
    case 'stock': request('stock', { box: P.hold.box, display: t.display }); break
    case 'scan': request('scan', { till: t.till }); break
    case 'grillOn': request('grillOn', { box: P.hold.box }); break
    case 'grillOff': request('grillOff'); break
    case 'computer': openPanel('computer'); break
    case 'locker': openPanel('guns'); break
  }
}
function dropBox () {
  if (P.hold?.type !== 'box') return
  const x = P.x - Math.sin(P.yaw) * 0.8, z = P.z - Math.cos(P.yaw) * 0.8
  request('drop', { box: P.hold.box, x, z })
  P.hold = null
}

// ═════════════ the door ═════════════
function inspecting () {
  const rows = isHost() ? (customers?.list ?? []).map(c => ({ id: c.id, state: c.state })) : (G.cust ?? []).map(r => ({ id: r[0], state: r[4] }))
  return rows.find(c => c.state === 'inspect') ?? null
}
let doorShown = null
function updateDoorPanel () {
  const c = inspecting()
  const near = Math.hypot(P.x - DOOR.console.x, P.z - DOOR.console.z) < 2.0 && !P.ko && G.mode === 'playing'
  const show = !!(c && near && G.visitors.get(c.id))
  $('#door').classList.toggle('is-on', show)
  if (!show) { doorShown = null; return }
  if (doorShown !== c.id) {
    doorShown = c.id
    const v = G.visitors.get(c.id)
    drawIdCard($('#idcard'), v)
    $('#says').textContent = `"${v.line}"`
    const cam = $('#cam')
    const seen = S.upgrades.has('camera') && !v.human && hashStr(c.id) % 10 < 7
    cam.hidden = !S.upgrades.has('camera')
    cam.textContent = seen ? 'Camera: there is a faint outline around them.' : 'Camera: nothing unusual.'
  }
}
const hashStr = s => { let h = 0; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h) }
$('#admit').addEventListener('click', () => request('decide', { admit: true }))
$('#reject').addEventListener('click', () => request('decide', { admit: false }))

// ═════════════ visuals per frame ═════════════
const boxGeo = new THREE.BoxGeometry(0.5, 0.32, 0.4)
const boxMat = new THREE.MeshStandardMaterial({ color: 0xb98a55, roughness: 0.85 })
let heldBoxMesh = null
function boxMesh (product) {
  const g = new THREE.Group()
  const b = new THREE.Mesh(boxGeo, boxMat)
  b.castShadow = HIGH
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.51, 0.08, 0.41), new THREE.MeshStandardMaterial({ color: productById(product).color, roughness: 0.6 }))
  g.add(b, stripe)
  return g
}
function updateVisuals (dt, t) {
  // stock on display
  for (const d of W.displays) {
    if (!d.mesh) continue
    d.mesh.count = Math.min(d.stock, capOf(d)) * (d.mesh.userData.copies ?? 1)
    d.tape.visible = !unlocked(d)
    d.label.material.opacity = unlocked(d) ? 1 : 0.35
  }
  // boxes
  const seen = new Set()
  for (const b of S.boxes) {
    seen.add(b.id)
    let m = G.boxMeshes.get(b.id)
    if (!m) { m = boxMesh(b.product); scene.add(m); G.boxMeshes.set(b.id, m) }
    if (b.carrier === myId() || b.arriveAt) { m.visible = false; continue }
    m.visible = true
    if (b.carrier) {
      const av = G.avatars.get(b.carrier)
      if (av) m.position.set(av.x - Math.sin(av.yaw) * 0.45, 1.05, av.z - Math.cos(av.yaw) * 0.45)
      m.rotation.y = av?.yaw ?? 0
    } else { m.position.set(b.x, b.y + 0.16, b.z); m.rotation.y = 0 }
  }
  for (const [id, m] of G.boxMeshes) if (!seen.has(id)) { scene.remove(m); G.boxMeshes.delete(id) }
  // the box in our own hands
  const myBox = P.hold?.type === 'box' ? S.boxes.find(b => b.id === P.hold.box) : null
  if (myBox && !heldBoxMesh) { heldBoxMesh = boxMesh(myBox.product); heldBoxMesh.position.set(0, -0.42, -0.62); camera.add(heldBoxMesh) }
  if (!myBox && heldBoxMesh) { camera.remove(heldBoxMesh); heldBoxMesh = null }
  // customers
  const rows = isHost() ? (customers?.list ?? []).map(c => ({ id: c.id, x: c.x, z: c.z, yaw: c.yaw, state: c.state, speed: c.speed, dieT: c.dieT })) : (G.cust ?? []).map(r => ({ id: r[0], x: r[1], z: r[2], yaw: r[3], state: r[4], speed: r[5] }))
  const alive = new Set()
  for (const r of rows) {
    const v = G.visitors.get(r.id)
    if (!v) continue
    alive.add(r.id)
    let vis = G.visuals.get(r.id)
    if (!vis) { vis = customerVisual(scene, r.id, v, { shadows: HIGH }); vis.sx = r.x; vis.sz = r.z; G.visuals.set(r.id, vis) }
    if (!isHost()) { const k = Math.hypot(r.x - vis.sx, r.z - vis.sz) > 4 ? 1 : Math.min(1, dt * 10); vis.sx += (r.x - vis.sx) * k; vis.sz += (r.z - vis.sz) * k } else { vis.sx = r.x; vis.sz = r.z }
    if (r.state === 'dying') vis.dieT = (vis.dieT ?? 0) + dt
    vis.update(dt, { ...r, x: vis.sx, z: vis.sz, dieT: vis.dieT })
  }
  for (const [id, vis] of G.visuals) if (!alive.has(id)) { vis.dispose(); G.visuals.delete(id) }
  // grill sausages
  updateGrillVisual()
  // tracers, explosions, dynamite in flight
  G.tracers = G.tracers.filter(f => f(dt))
  for (const b of booms) { b.t += dt; b.m.scale.setScalar(0.5 + b.t * 9); b.m.material.opacity = Math.max(0, 0.9 - b.t * 2.5); b.l.intensity = Math.max(0, 40 - b.t * 120) }
  for (let k = booms.length - 1; k >= 0; k--) if (booms[k].t > 0.5) { scene.remove(booms[k].m, booms[k].l); booms.splice(k, 1) }
  updateDynamite(dt)
  // flicker when something turns
  const fl = G.flicker && t < G.flicker ? (Math.random() < 0.5 ? 0.15 : 1) : 1
  for (const l of shopLights) l.intensity = (HIGH ? 14 : 20) * fl
  // gun sway / recoil recovery
  if (viewGun) {
    viewGun.userData.flash.material.opacity = Math.max(0, viewGun.userData.flash.material.opacity - dt * 14)
    viewGun.position.z += (-0.42 - viewGun.position.z) * Math.min(1, dt * 12)
    viewGun.rotation.x += ((now() < P.reloadUntil ? -0.9 : 0) - viewGun.rotation.x) * Math.min(1, dt * 10)
    viewGun.position.x = Math.min(0.22, 0.17 * camera.aspect)
    viewGun.position.y = -0.2 + (P.moving ? Math.sin(P.bob * Math.PI) * 0.012 : 0)
  }
}

const grillMeshes = []
function updateGrillVisual () {
  while (grillMeshes.length < S.grill.length) {
    const m = new THREE.Mesh(new THREE.CapsuleGeometry(0.025, 0.16, 3, 8).rotateZ(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xd98a6a, roughness: 0.5 }))
    scene.add(m)
    grillMeshes.push(m)
  }
  grillMeshes.forEach((m, k) => {
    const s = S.grill[k]
    m.visible = !!s
    if (!s) return
    m.position.set(GRILL.x - 0.8 + (k % 4) * 0.17, 1.03, GRILL.z - 0.15 + Math.floor(k / 4) * 0.15)
    const v = grillValue(s.t)
    const burnt = s.t > 10.5
    m.material.color.setHex(s.t < 8 ? 0xd98a6a : !burnt ? 0x9a4a2a : v < 0.4 ? 0x1a1410 : 0x5a2a18)
  })
  // the cooking meter when you're at the grill
  const near = Math.hypot(P.x - GRILL.staff.x, P.z - GRILL.staff.z) < 2 && S.grill.length > 0 && G.mode === 'playing'
  const el = $('#grill')
  el.classList.toggle('is-on', near)
  if (near) {
    el.innerHTML = S.grill.map(s => { const v = grillValue(s.t); const pct = s.t < 10.5 ? Math.min(100, (s.t / 10.5) * 100) : 100; return `<div class="${s.t > 10.5 ? 'burnt' : v >= 1.5 ? 'perfect' : ''}"><i style="height:${pct}%"></i></div>` }).join('')
  }
}

function updateDynamite (dt) {
  for (const d of G.dynamite) {
    if (!d.mesh) {
      d.mesh = gunModel('dynamite')
      d.mesh.scale.setScalar(1.6)
      scene.add(d.mesh)
      d.p = { ...d.pos }; d.v = { ...d.vel }
      if (!d.host) d.boomLocal = now() + d.boomAt
    }
    if (d.done || (!d.host && now() > d.boomLocal)) { scene.remove(d.mesh); d.gone = true; continue }
    d.v.y -= 9.8 * dt
    d.p.x += d.v.x * dt; d.p.y += d.v.y * dt; d.p.z += d.v.z * dt
    if (d.p.y < 0.1) { d.p.y = 0.1; d.v.y *= -0.3; d.v.x *= 0.6; d.v.z *= 0.6 }
    d.pos = d.p
    d.mesh.position.set(d.p.x, d.p.y, d.p.z)
    d.mesh.rotation.x += dt * 8
  }
  G.dynamite = G.dynamite.filter(d => !d.gone)
}

function updateAvatars (dt) {
  for (const [id, av] of G.avatars) {
    const t = av.target
    const jump = Math.hypot(t.x - av.x, t.z - av.z)
    const k = jump > 4 ? 1 : Math.min(1, dt * 12)
    const ox = av.x, oz = av.z
    av.x += (t.x - av.x) * k; av.z += (t.z - av.z) * k
    let dy = t.yaw - av.yaw
    while (dy > Math.PI) dy -= Math.PI * 2
    while (dy < -Math.PI) dy += Math.PI * 2
    av.yaw += dy * Math.min(1, dt * 12)
    const v = jump > 4 ? 0 : Math.hypot(av.x - ox, av.z - oz) / Math.max(dt, 1e-3)
    av.speed += (v - av.speed) * Math.min(1, dt * 8)
    av.model.setName(playerName(id))
    av.model.update(dt, { x: av.x, z: av.z, yaw: av.yaw, pitch: t.pitch, speed: av.speed, down: !!t.ko, flashlight: false })
    // the gun in their hand
    if (av.gunId !== t.gun) {
      if (av.gun) av.gun.removeFromParent()
      av.gun = t.gun ? gunModel(t.gun) : null
      av.gunId = t.gun
      if (av.gun) { av.gun.position.set(0.25, 1.25, 0.35); av.gun.rotation.y = Math.PI; av.model.group.add(av.gun) }
    }
  }
}

function updateCamera (dt, t) {
  if (G.mode === 'title') {
    const s = t / 1000
    camera.position.set(Math.sin(s * 0.08) * 4, 1.8, 3.5 + Math.cos(s * 0.08) * 1.5)
    camera.rotation.set(-0.08, Math.PI + Math.sin(s * 0.08) * 0.4, 0)
    return
  }
  const bob = P.moving ? Math.sin(P.bob * Math.PI) * (P.sprinting ? 0.045 : 0.025) : 0
  const sh = P.shake * 0.05
  camera.position.set(P.x + (Math.random() - 0.5) * sh, (P.ko ? 0.4 : 1.6) + bob + (Math.random() - 0.5) * sh, P.z + (Math.random() - 0.5) * sh)
  camera.rotation.set(P.pitch, P.yaw, P.ko ? 1 : 0)
  P.shake = Math.max(0, P.shake - dt * 2)
}

// ═════════════ main loop ═════════════
let last = now()
function frame () {
  requestAnimationFrame(frame)
  const t = now()
  const dt = Math.min(0.05, (t - last) / 1000)
  last = t
  window.__frames = (window.__frames ?? 0) + 1
  if (G.mode === 'playing' && !G.paused) step(dt, t)
  if (G.mode === 'playing' && isHost() && !G.paused) hostTick(dt, t)
  updateVisuals(dt, t)
  updateAvatars(dt)
  updateCamera(dt, t)
  renderer.render(scene, camera)
}

function step (dt, t) {
  // safety net: if nothing should be blocking you (no menu, panel or end-of-night screen), you can always move
  if (!input.enabled && !G.panel && current !== 'summary' && current !== 'pause' && !document.querySelector('.screen.is-open')) { input.enabled = true; setHud(true) }
  const look = consumeLook()
  const panelOpen = !!G.panel
  const canAct = input.enabled && !panelOpen && !P.ko
  if (consumePressed('pause') && !panelOpen) pause()
  const doorOpen = $('#door').classList.contains('is-on')
  if (canAct) {
    if (doorOpen && consumePressed('gun1')) request('decide', { admit: true })
    if (doorOpen && consumePressed('gun2')) request('decide', { admit: false })
    for (let k = 1; k <= 5; k++) if (consumePressed(`gun${k}`)) { const g = GUNS[k - 1]; if (S.guns[g.id]) equip(g.id); else toast(`You don't own the ${g.name.toLowerCase()} yet. Buy it at the gun locker.`) }
    if (consumePressed('gun')) { const owned = ownedGuns(); const i = owned.findIndex(g => g.id === P.gun); equip(i + 1 < owned.length ? owned[i + 1].id : null) }
    if (consumePressed('holster')) equip(null)
    if (consumePressed('reload')) reload()
    if (consumePressed('drop')) dropBox()
  } else for (const k of ['gun1', 'gun2', 'gun3', 'gun4', 'gun5', 'gun', 'holster', 'reload', 'drop']) input.pressed.delete(k)
  updatePlayer(dt, canAct ? look : { x: 0, y: 0 }, canAct)
  // interact / fire
  const target = canAct ? findInteraction() : null
  setPrompt(target?.label ?? (inspecting() && Math.hypot(P.x - DOOR.console.x, P.z - DOOR.console.z) < 2 ? 'Check the person in the doorway' : ''))
  const clicked = consumePressed('click')
  if (canAct && (consumePressed('interact') || (clicked && !P.gun))) useInteraction(target)
  if (canAct && P.gun && (input.held.fire || clicked)) fire(t)
  input.pressed.delete('interact')
  updateDoorPanel()
  // send our state
  if (net.online && t - G.lastState > 66) { G.lastState = t; sendAll('state', { x: +P.x.toFixed(2), z: +P.z.toFixed(2), yaw: +P.yaw.toFixed(2), pitch: +P.pitch.toFixed(2), gun: P.gun, ko: P.ko }) }
  G.registry.set(myId(), { id: myId(), x: P.x, z: P.z, ko: P.ko })
  // audio
  const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
  A.S.listener(camera.position, fwd)
  const monsterLoose = isHost() ? customers?.list.some(c => c.state === 'turned') : (G.cust ?? []).some(r => r[4] === 'turned')
  A.updateBeds(dt, { inside: P.z < 8, danger: !!monsterLoose, busy: (isHost() ? customers?.list.length : (G.cust ?? []).length) ?? 0 })
  updateHud(monsterLoose)
}

// ═════════════ UI ═════════════
const screens = ['title', 'join', 'lobby', 'howto', 'settings', 'pause', 'computer', 'guns', 'summary']
let current = 'title'
const stack = []
function showScreen (name, { push = false } = {}) {
  if (push && current) stack.push(current)
  for (const s of screens) $(`#screen-${s}`)?.classList.toggle('is-open', s === name)
  current = name
}
const backScreen = () => showScreen(stack.pop() ?? 'title')
const setHud = on => { $('#hud').classList.toggle('is-on', on); $('#touch').classList.toggle('is-on', on && touch) }
const fade = (to, ms) => { const el = $('#fade'); el.style.transition = `opacity ${ms}ms`; el.style.opacity = String(to) }
const cache = new WeakMap()
const setText = (el, text, html = false) => { if (cache.get(el) === text) return; cache.set(el, text); if (html) el.innerHTML = text; else el.textContent = text }
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
let toastTimer
const toast = (text, ms = 3000) => { const el = $('#toast'); el.textContent = text; el.style.opacity = '1'; clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.style.opacity = '0' }, ms) }
let bigTimer
const big = (a, b) => { const el = $('#big'); el.innerHTML = `${esc(a)}<small>${esc(b)}</small>`; el.classList.add('is-on'); clearTimeout(bigTimer); bigTimer = setTimeout(() => el.classList.remove('is-on'), 3600) }
const setPrompt = l => setText($('#prompt'), l ? (touch ? esc(l) : `<kbd>E</kbd>${esc(l)}`) : '', true)
const money = n => `$${(Math.round(n * 100) / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
function popMoney (text) { const el = document.createElement('div'); el.className = 'popup'; el.textContent = text; el.style.left = '50%'; el.style.top = '44%'; $('#hud').appendChild(el); el.animate([{ opacity: 1, transform: 'translate(-50%, 0)' }, { opacity: 0, transform: 'translate(-50%, -40px)' }], { duration: 1100 }).onfinish = () => el.remove() }

function updateHud (monsterLoose) {
  setText($('#h-money'), money(S.money))
  const h = (20 + Math.floor(S.clock * 12)) % 24, m = Math.floor((S.clock * 12 % 1) * 60)
  setText($('#h-time'), `Night ${S.day}, ${String(h).padStart(2, '0')}:${String(m - m % 5).padStart(2, '0')}${S.phase === 'closing' ? ' (closing)' : ''}`)
  const full = Math.round(S.rating)
  setText($('#h-stars'), '★'.repeat(full) + '☆'.repeat(5 - full))
  let hint = ''
  const insp = inspecting()
  const empties = W.displays.filter(d => unlocked(d) && d.stock === 0).length
  if (monsterLoose) hint = 'Something is loose in the shop. Shoot it!<small>Draw a gun with 1 to 5.</small>'
  else if (insp && Math.hypot(P.x - DOOR.console.x, P.z - DOOR.console.z) > 2) hint = 'Someone is waiting at the door.<small>Go to the console by the entrance.</small>'
  else if (customerAtTill(0) && Math.hypot(P.x - TILLS[0].staff.x, P.z - TILLS[0].staff.z) > 1.5) hint = 'A customer is waiting at the till.<small>Stand behind it and scan their shopping.</small>'
  else if (empties > 2) hint = `${empties} shelves are empty.<small>Order stock on the computer in the back room.</small>`
  setText($('#hint'), hint, true)
  // what's in our hands
  let hands = ''
  if (P.gun) { const g = gunById(P.gun); const st = gunStats(g, S.guns[g.id] ?? 1); hands = `${esc(g.name)} <span style="color:var(--tag)">lv ${S.guns[g.id]}</span><small>${now() < P.reloadUntil ? 'Reloading…' : `${P.ammo[g.id] ?? st.mag} / ${st.mag}`}</small>` } else if (P.hold?.type === 'box') { const b = S.boxes.find(x => x.id === P.hold.box); if (b) hands = `Box: ${esc(productById(b.product).name)} (${b.units})<small>${touch ? 'Drop' : 'G'} to put it down</small>` }
  setText($('#hands'), hands, true)
  $('#health').style.display = P.hp < 100 ? 'block' : 'none'
  $('#health-bar').style.width = `${P.hp}%`
  // the receipt at the till
  const t0 = TILLS.find(t => Math.hypot(P.x - t.staff.x, P.z - t.staff.z) < 1.6)
  const c = t0 && customerAtTill(t0.id)
  const slip = $('#tillslip')
  slip.classList.toggle('is-on', !!c)
  if (c) {
    const total = c.items.reduce((s, id) => s + productById(id).price, 0)
    setText(slip, `<b>NIGHT OWL MARKET</b><br>${c.items.map((id, k) => `${k < c.scanned ? '✓' : '·'} ${esc(productById(id).name)} <span style="float:right">${money(productById(id).price)}</span>`).join('<br>')}<div class="t"><span>TOTAL</span><span>${money(total)}</span></div>`, true)
  }
  if (G.coop && net.online) setText($('#team'), [...net.players.values()].map(p => esc(p.name) + (p.id === myId() ? ' (you)' : '')).join('<br>'), true)
}

// computer + gun locker
function openPanel (name) {
  G.panel = name
  document.exitPointerLock?.()
  input.enabled = false
  if (name === 'computer') { renderComputer(); showScreen('computer') }
  if (name === 'guns') { renderGuns(); showScreen('guns') }
}
function closePanel () {
  G.panel = null
  input.enabled = true
  showScreen(S.phase === 'summary' ? 'summary' : null)
  if (S.phase !== 'summary' && !touch) void canvas.requestPointerLock?.()
}
let pcTab = 'stock'
function renderComputer () {
  setText($('#pc-money'), money(S.money))
  for (const b of document.querySelectorAll('#pc-tabs button')) b.setAttribute('aria-pressed', String(b.dataset.tab === pcTab))
  const list = $('#pc-list')
  if (pcTab === 'stock') {
    list.innerHTML = PRODUCTS.map(p => {
      const locked = p.tier > S.tiers
      return `<div class="line ${locked ? 'locked' : ''}"><div><b>${esc(p.name)}</b><small>${locked ? `Unlocks with tier ${p.tier}` : `Box of ${p.box} for ${money(p.cost)}. Sells at ${money(p.price)} each${p.id === 'hotdog' ? ' (cook them on the grill first)' : ''}.`}</small></div><button class="btn" data-order="${p.id}" ${locked || S.money < p.cost ? 'disabled' : ''}>Order</button></div>`
    }).join('')
  } else if (pcTab === 'tiers') {
    list.innerHTML = TIERS.map(t => {
      const owned = t.n <= S.tiers, next = t.n === S.tiers + 1
      const items = PRODUCTS.filter(p => p.tier === t.n).map(p => p.name).join(', ')
      return `<div class="line ${owned || next ? '' : 'locked'}"><div><b>Tier ${t.n}: ${esc(t.name)}</b><small>${esc(items)}</small></div>${owned ? '<span class="money">Open</span>' : `<button class="btn" data-tier="${t.n}" ${next && S.money >= t.cost ? '' : 'disabled'}>${money(t.cost)}</button>`}</div>`
    }).join('')
  } else {
    list.innerHTML = UPGRADES.map(u => {
      const owned = S.upgrades.has(u.id)
      return `<div class="line ${u.tier > S.tiers ? 'locked' : ''}"><div><b>${esc(u.name)}</b><small>${esc(u.blurb)}${u.tier > S.tiers ? ` Needs tier ${u.tier}.` : ''}</small></div>${owned ? '<span class="money">Owned</span>' : `<button class="btn" data-upgrade="${u.id}" ${u.tier <= S.tiers && S.money >= u.cost ? '' : 'disabled'}>${money(u.cost)}</button>`}</div>`
    }).join('')
  }
}
function renderGuns () {
  setText($('#gun-money'), money(S.money))
  $('#gun-list').innerHTML = GUNS.map(g => {
    const lvl = S.guns[g.id] ?? 0
    const cost = lvl === 0 ? g.cost : upgradeCost(g, lvl)
    const st = gunStats(g, Math.max(1, lvl))
    const desc = g.throw ? `Throw it. ${Math.round(st.dmg)} damage in a ${g.radius} m blast. Mind your friends.` : `${Math.round(st.dmg)}${g.pellets > 1 ? ` x ${g.pellets}` : ''} damage, ${st.mag} rounds, ${st.reload.toFixed(1)} s reload`
    return `<div class="line"><div><b>${esc(g.name)} ${lvl ? `<span class="money">lv ${lvl}</span>` : ''}</b><small>${esc(desc)}</small></div>${lvl >= 5 ? '<span class="money">Maxed</span>' : `<button class="btn" data-gun="${g.id}" ${S.money >= cost ? '' : 'disabled'}>${lvl ? 'Upgrade' : 'Buy'} ${money(cost)}</button>`}</div>`
  }).join('')
}
$('#pc-tabs').addEventListener('click', e => { if (e.target.dataset.tab) { pcTab = e.target.dataset.tab; renderComputer() } })
$('#pc-list').addEventListener('click', e => {
  const b = e.target.closest('button')
  if (!b) return
  if (b.dataset.order) request('order', { product: b.dataset.order })
  if (b.dataset.tier) request('buyTier')
  if (b.dataset.upgrade) request('buyUpgrade', { id: b.dataset.upgrade })
  setTimeout(renderComputer, 250)
})
$('#gun-list').addEventListener('click', e => { const b = e.target.closest('button'); if (b?.dataset.gun) { request('buyGun', { id: b.dataset.gun }); setTimeout(renderGuns, 250) } })

function showSummary (st, day) {
  setText($('#sum-title'), `End of night ${day}`)
  const rows = [
    ['Customers served', st.served], ['Takings', money(st.sales)], ['Stock bought', `-${money(st.spent)}`],
    ['Bounties', `+${money(st.bounties)}`], ['Fines', st.fines ? `-${money(st.fines)}` : money(0)],
    ['Things you let in by mistake', st.wrongIn], ['Things you put down', st.killed],
    ['Rating', `${'★'.repeat(Math.round(st.ratingEnd))}${'☆'.repeat(5 - Math.round(st.ratingEnd))}`],
  ]
  $('#sum-list').innerHTML = rows.map(([a, b]) => `<div class="line"><b>${esc(a)}</b><span class="money">${esc(b)}</span></div>`).join('')
  $('#next-day').disabled = !isHost()
  setText($('#next-day'), isHost() ? `Open night ${day + 1}` : 'Waiting for the owner…')
  document.exitPointerLock?.()
  G.panel = null
  input.enabled = false
  setHud(false)
  showScreen('summary')
  A.play('day_end', { vol: 0.6, music: true })
}

function pause () {
  if (G.mode !== 'playing' || current === 'pause') return
  G.paused = !net.online
  input.pressed.clear()
  setText($('#pause-note'), net.online ? 'The shop stays open while you\'re on break.' : 'The whole shop waits for you.')
  showScreen('pause')
}
function resume () { G.paused = false; showScreen(null); if (!touch) void canvas.requestPointerLock?.() }

function startGame ({ coop = false } = {}) {
  A.S.init(); A.S.setVolume(settings.volume); void A.startBeds()
  G.coop = coop
  if (isHost()) { loadSave(); openNight() }
  P.x = 2.1; P.z = 5.6; P.yaw = 0.2; P.hp = 100; P.hold = null
  equip(null)
  G.mode = 'playing'
  input.enabled = true
  stack.length = 0
  showScreen(null); setHud(true)
  fade(1, 0); setTimeout(() => fade(0, 1200), 80)
  if (!touch) void canvas.requestPointerLock?.()
}
function quitToTitle () {
  if (isHost() && S.phase !== 'title') writeSave()
  disconnect()
  G.mode = 'title'; S.phase = 'title'
  input.enabled = false
  document.exitPointerLock?.()
  for (const av of G.avatars.values()) av.model.dispose()
  G.avatars.clear()
  for (const v of G.visuals.values()) v.dispose()
  G.visuals.clear()
  customers = null
  S.boxes = []; S.grill = []
  setHud(false); stack.length = 0; showScreen('title'); updateProfile()
}
function updateProfile () { setText($('#profile'), `Night ${save.day}, ${money(save.money)} in the till`) }

function refreshLobby () {
  if (!net.online) return
  setText($('#lobby-code'), net.code || '- - - -')
  setText($('#lobby-roster'), [...net.players.values()].map(p => `<li>${esc(p.name)}${p.id === net.hostId ? '<small>owner</small>' : ''}${p.id === net.id ? '<small>you</small>' : ''}</li>`).join(''), true)
  $('#lobby-start').hidden = !isHost()
  setText($('#lobby-hint'), isHost() ? 'Share this code with up to three friends, then open up. Your saved shop is used.' : 'Waiting for the owner to open up.')
}
const setStatus = (sel, text, bad = false) => { const el = $(sel); el.textContent = text; el.classList.toggle('bad', bad) }
const setName = n => { myName = n.slice(0, 14); try { localStorage.setItem('market.name', myName) } catch {} }
async function openRoom () {
  showScreen('lobby', { push: true }); $('#host-name-field').hidden = false; $('#host-name').value = myName
  setStatus('#lobby-status', 'Opening… (the server can take up to a minute to wake up)')
  try { await connect({ url: coopUrl(), mode: 'create', name: myName }); setStatus('#lobby-status', ''); refreshLobby() } catch (err) { setStatus('#lobby-status', err.message, true) }
}
async function joinRoom () {
  const code = $('#join-code').value.trim().toUpperCase()
  if (code.length !== 4) { setStatus('#join-status', 'Codes are four letters.', true); return }
  setName($('#join-name').value.trim() || myName)
  setStatus('#join-status', 'Joining… (the server can take up to a minute to wake up)')
  try { await connect({ url: coopUrl(), mode: 'join', code, name: myName }); setStatus('#join-status', ''); showScreen('lobby', { push: true }); $('#host-name-field').hidden = true; refreshLobby() } catch (err) { setStatus('#join-status', err.message, true) }
}

document.addEventListener('click', e => {
  const b = e.target.closest('[data-go]')
  if (!b) return
  A.S.init()
  switch (b.dataset.go) {
    case 'play': disconnect(); startGame(); break
    case 'host': void openRoom(); break
    case 'join': showScreen('join', { push: true }); $('#join-name').value = myName; break
    case 'join-go': void joinRoom(); break
    case 'howto': showScreen('howto', { push: true }); break
    case 'settings': syncSettings(); showScreen('settings', { push: true }); break
    case 'back': backScreen(); break
    case 'leave': disconnect(); stack.length = 0; showScreen('title'); break
    case 'lobby-start': if (isHost()) { sendAll('start', {}); startGame({ coop: true }) } break
    case 'resume': resume(); break
    case 'quit': quitToTitle(); break
    case 'reset': if (confirm('Start a brand new shop? Your saved shop will be lost.')) { save = freshSave(); store.set('market.save', save); updateProfile() } break
    case 'close-panel': closePanel(); break
    case 'computer': openPanel('computer'); break
    case 'locker': openPanel('guns'); break
    case 'next-day': if (isHost()) { request('nextDay'); input.enabled = true; showScreen(null); setHud(true); if (!touch) void canvas.requestPointerLock?.() } break
  }
})
$('#host-name').addEventListener('change', e => { setName(e.target.value.trim() || myName); if (net.online) { sendAll('name', { name: myName }); const me = net.players.get(net.id); if (me) me.name = myName; refreshLobby() } })
$('#join-code').addEventListener('keydown', e => { if (e.key === 'Enter') void joinRoom() })
function syncSettings () {
  $('#set-sens').value = settings.sensitivity; $('#set-vol').value = settings.volume
  for (const b of document.querySelectorAll('#set-quality button')) b.setAttribute('aria-pressed', String(b.dataset.q === settings.quality))
  for (const b of document.querySelectorAll('#set-invert button')) b.setAttribute('aria-pressed', String(b.dataset.v === String(settings.invertY)))
}
$('#set-sens').addEventListener('input', e => { settings.sensitivity = +e.target.value; saveSettings() })
$('#set-vol').addEventListener('input', e => { settings.volume = +e.target.value; A.S.setVolume(settings.volume); saveSettings() })
$('#set-quality').addEventListener('click', e => { if (e.target.dataset.q) { settings.quality = e.target.dataset.q; saveSettings(); syncSettings(); setStatus('#settings-status', 'Graphics change when you next load the page.') } })
$('#set-invert').addEventListener('click', e => { if (e.target.dataset.v) { settings.invertY = e.target.dataset.v === 'true'; saveSettings(); syncSettings() } })

// rules lists
const rulesHtml = TELLS.map(t => `<li>${esc(t.rule)}</li>`).join('')
$('#rules').innerHTML = rulesHtml
$('#door-rules').innerHTML = rulesHtml

// ═════════════ boot ═════════════
bindFullscreenButtons()
initInput(canvas, { onPause: r => { if (r === 'unlock' && !G.panel && current !== 'summary') pause() } })
initGamepad(input, { sprintStick: true, held: { [BTN.RT]: 'fire', [BTN.A]: 'interact', [BTN.LB]: 'sprint' }, press: { [BTN.RT]: 'click', [BTN.A]: 'interact', [BTN.X]: 'reload', [BTN.Y]: 'gun', [BTN.B]: 'drop', [BTN.RB]: 'holster', [BTN.LEFT]: 'gun1', [BTN.RIGHT]: 'gun2' } })
if (touch) initTouchControls($('#touch'))
loadSave()
updateProfile()
$('#loading').style.display = 'none'
showScreen('title')
fade(0, 1200)
requestAnimationFrame(frame)
window.__mk = { S, P, G, W, hostTick, hooks, get customers () { return customers }, request, startGame, hostRequest, myId, openNight, endNight, findInteraction, useInteraction, equip, fire }
