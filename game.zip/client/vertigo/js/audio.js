// Vertigo Freight sound: plays the recorded files in ../audio/ (hosted with the site).
import { createSound } from '../../gamekit/sound.js'
import names from '../audio/index.js'

const S = createSound({ base: new URL('../audio/', import.meta.url).href, names })
S.prefetch()

export const audio = {
  get ctx () { return S.ctx },
  get started () { return !!S.ctx },
  volume: 0.8,
  loops: {},
}
export const sound = S

export function initAudio () { return S.init() }
export function setVolume (v) { audio.volume = v; S.setVolume(v) }
export function updateListener (pos, forward) { S.listener(pos, forward) }

// ───────────── beds ─────────────
export async function startTrainAmbience () {
  await S.init()
  if (audio.loops.train) return
  audio.loops.train = S.bed('amb_train', { vol: 0.8 })
  audio.loops.wind = S.bed('amb_wind', { vol: 0.15 })
  audio.loops.drone = S.bed('amb_drone', { vol: 0 })
  audio.loops.chase = S.bed('music_chase', { vol: 0, music: true })
}

export function stopAll () {
  for (const k of Object.keys(audio.loops)) { audio.loops[k]?.stop(0.5); delete audio.loops[k] }
}

let chaseLevel = 0
export function updateAmbience (dt, { speed = 1, fear = 0, outsideOpen = 0, chase = 0 } = {}) {
  const L = audio.loops
  if (!L.train) return
  L.train.setVol(0.45 + speed * 0.35, 0.4)
  L.train.setRate(0.75 + speed * 0.3, 0.6)
  L.wind.setVol(0.08 + speed * 0.08 + outsideOpen * 0.5, 0.4)
  L.drone.setVol(fear * 0.55, 0.6)
  chaseLevel += ((chase ? 1 : 0) - chaseLevel) * Math.min(1, dt * (chase ? 3 : 0.6))
  L.chase.setVol(chaseLevel * 0.85, 0.2)
}

// ───────────── one-shots ─────────────
export function footstep (pos, { loud = 0.5, surface = 'metal' } = {}) {
  S.play(`step_${surface}`, { pos: { ...pos, y: 0.1 }, vol: 0.25 + loud * 0.75, ref: 1.5 })
}
export const creatureStep = (pos, loud = 1) => S.play('creature_step', { pos, vol: 0.5 + loud * 0.6, ref: 2.5, max: 70 })
export const growl = (pos, intensity = 0.6) => S.play('growl', { pos, vol: 0.4 + intensity * 0.7, ref: 3, max: 80 })
export const roar = pos => S.play('roar', { pos, vol: 1.2, ref: 4, max: 120 })
export const drag = pos => S.play('drag', { pos, vol: 0.7, ref: 3 })
export const doorSlide = (pos, { slam = false } = {}) => S.play(slam ? 'door_slam' : 'door_slide', { pos, vol: slam ? 1 : 0.6 })
export const locked = pos => S.play('locked', { pos, vol: 0.8 })
export const pickup = () => S.play('pickup', { vol: 0.6 })
export const click = pos => S.play('click', { pos, vol: 0.5, ref: 1 })
export const lever = pos => S.play('lever', { pos, vol: 0.9 })
export const valve = pos => S.play('valve', { pos, vol: 0.8, rate: 0.7 })
export const knock = pos => S.play('knock', { pos, vol: 1, ref: 2 })
export const rattle = pos => S.play('rattle', { pos, vol: 0.8, ref: 1.5 })
export const paper = () => S.play('paper', { vol: 0.5 })
export const creak = pos => S.play('creak', { pos, vol: 0.5, ref: 3 })
export const powerUp = () => S.play('power_up', { vol: 0.9 })
export const powerDown = () => S.play('power_down', { vol: 0.9 })
export const radioStatic = () => S.play('radio_static', { vol: 0.7 })
export const heartbeat = (vol = 0.5) => S.play('heartbeat', { vol: vol * 1.2, rateJitter: 0 })
export const stinger = (vol = 0.6) => S.play('stinger', { vol: vol * 1.3, music: true })
export const scream = (vol = 1) => S.play('scream', { vol: vol * 1.3, rateJitter: 0.04 })
export const thunder = () => S.play('thunder', { vol: 0.8 })
export const gasp = () => S.play('gasp', { vol: 0.6 })
export const brakes = () => S.play('brakes', { vol: 1 })
export const whisper = pos => S.play('whisper', { pos, vol: 0.8, ref: 2 })
export const objectiveChime = () => S.play('objective', { vol: 0.35, music: true, rateJitter: 0 })
export const checkpointChime = () => S.play('checkpoint', { vol: 0.35, music: true, rateJitter: 0 })

/** Breathing while hiding: { setLevel(v), stop() } */
export function breathLoop () {
  const h = S.bed('breath_loop', { vol: 0 })
  return { setLevel: v => h.setVol(v * 0.6, 0.1), stop: () => h.stop(0.3) }
}
