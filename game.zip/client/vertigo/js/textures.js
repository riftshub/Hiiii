// Procedural textures drawn on canvases (no image files needed)
import * as THREE from 'three'

const cache = {}

const rand = (seed => () => {
  seed = (seed * 16807) % 2147483647
  return (seed - 1) / 2147483646
})(1337)

const canvas = (w, h) => {
  const c = document.createElement('canvas')
  c.width = w; c.height = h
  return [c, c.getContext('2d')]
}

const toTexture = (c, repeat = [1, 1], color = true) => {
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(repeat[0], repeat[1])
  t.anisotropy = 4
  if (color) t.colorSpace = THREE.SRGBColorSpace
  return t
}

/** Speckle + streak grime over whatever is drawn */
const grime = (g, w, h, amount = 0.25, streaks = true) => {
  for (let i = 0; i < w * h * 0.004 * amount * 10; i++) {
    const x = rand() * w, y = rand() * h, r = 1 + rand() * 6
    g.fillStyle = `rgba(20,14,8,${0.04 + rand() * 0.1 * amount})`
    g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill()
  }
  if (streaks) {
    for (let i = 0; i < 18 * amount; i++) {
      const x = rand() * w
      const grad = g.createLinearGradient(0, 0, 0, h)
      grad.addColorStop(0, 'rgba(25,18,10,0)')
      grad.addColorStop(0.5 + rand() * 0.4, `rgba(25,18,10,${0.08 + rand() * 0.1})`)
      grad.addColorStop(1, 'rgba(25,18,10,0)')
      g.fillStyle = grad
      g.fillRect(x, 0, 2 + rand() * 8, h)
    }
  }
}

export function woodPanel () {
  if (cache.wood) return cache.wood
  const [c, g] = canvas(512, 512)
  g.fillStyle = '#4a2c1a'
  g.fillRect(0, 0, 512, 512)
  const plank = 512 / 4
  for (let p = 0; p < 4; p++) {
    const x0 = p * plank
    const hue = 22 + rand() * 6
    g.fillStyle = `hsl(${hue}, 45%, ${17 + rand() * 6}%)`
    g.fillRect(x0, 0, plank, 512)
    // grain
    for (let i = 0; i < 70; i++) {
      g.strokeStyle = `rgba(${30 + rand() * 20},${16 + rand() * 10},6,${0.15 + rand() * 0.25})`
      g.lineWidth = 0.5 + rand() * 1.5
      g.beginPath()
      const x = x0 + rand() * plank
      g.moveTo(x, 0)
      for (let y = 0; y <= 512; y += 32) g.lineTo(x + Math.sin(y * 0.02 + i) * 3 + rand() * 2, y)
      g.stroke()
    }
    g.fillStyle = 'rgba(0,0,0,0.55)'
    g.fillRect(x0, 0, 2, 512)
  }
  // varnish highlight band
  const hl = g.createLinearGradient(0, 0, 0, 512)
  hl.addColorStop(0, 'rgba(255,200,140,0.06)'); hl.addColorStop(0.5, 'rgba(255,200,140,0)'); hl.addColorStop(1, 'rgba(0,0,0,0.12)')
  g.fillStyle = hl; g.fillRect(0, 0, 512, 512)
  grime(g, 512, 512, 0.3)
  cache.wood = c
  return c
}

export function floorPlate () {
  if (cache.floor) return cache.floor
  const [c, g] = canvas(256, 256)
  g.fillStyle = '#3b3d3e'
  g.fillRect(0, 0, 256, 256)
  // diamond tread pattern
  for (let y = 0; y < 256; y += 16) {
    for (let x = 0; x < 256; x += 16) {
      const ox = ((y / 16) % 2) * 8
      g.save()
      g.translate(x + ox + 4, y + 8)
      g.rotate(((y / 16) % 2 ? 1 : -1) * 0.7)
      g.fillStyle = 'rgba(160,165,168,0.22)'
      g.fillRect(-5, -1.5, 10, 3)
      g.fillStyle = 'rgba(0,0,0,0.35)'
      g.fillRect(-5, 1.5, 10, 1)
      g.restore()
    }
  }
  grime(g, 256, 256, 0.9, false)
  // rust patches
  for (let i = 0; i < 10; i++) {
    const x = rand() * 256, y = rand() * 256
    const r = g.createRadialGradient(x, y, 0, x, y, 10 + rand() * 30)
    r.addColorStop(0, 'rgba(90,45,20,0.35)'); r.addColorStop(1, 'rgba(90,45,20,0)')
    g.fillStyle = r; g.fillRect(0, 0, 256, 256)
  }
  cache.floor = c
  return c
}

export function carpet () {
  if (cache.carpet) return cache.carpet
  const [c, g] = canvas(256, 256)
  g.fillStyle = '#3a1416'
  g.fillRect(0, 0, 256, 256)
  // faded art-deco motif
  g.strokeStyle = 'rgba(176,141,87,0.22)'
  g.lineWidth = 2
  for (let y = 0; y < 256; y += 64) {
    for (let x = 0; x < 256; x += 64) {
      g.beginPath()
      g.moveTo(x + 32, y + 6); g.lineTo(x + 58, y + 32); g.lineTo(x + 32, y + 58); g.lineTo(x + 6, y + 32); g.closePath()
      g.stroke()
      g.beginPath(); g.arc(x + 32, y + 32, 6, 0, Math.PI * 2); g.stroke()
    }
  }
  for (let i = 0; i < 4000; i++) {
    g.fillStyle = `rgba(${rand() < 0.5 ? '0,0,0' : '120,60,50'},${rand() * 0.12})`
    g.fillRect(rand() * 256, rand() * 256, 1, 1)
  }
  grime(g, 256, 256, 0.8, false)
  cache.carpet = c
  return c
}

export function fabric () {
  if (cache.fabric) return cache.fabric
  const [c, g] = canvas(128, 128)
  g.fillStyle = '#4b1e22'
  g.fillRect(0, 0, 128, 128)
  for (let y = 0; y < 128; y += 2) {
    g.fillStyle = `rgba(0,0,0,${0.08 + (y % 4 ? 0.06 : 0)})`
    g.fillRect(0, y, 128, 1)
  }
  for (let i = 0; i < 1500; i++) {
    g.fillStyle = `rgba(${rand() < 0.5 ? '255,180,170' : '0,0,0'},${rand() * 0.07})`
    g.fillRect(rand() * 128, rand() * 128, 1, 2)
  }
  cache.fabric = c
  return c
}

export function paintedMetal (base = '#46524d') {
  const key = 'paint' + base
  if (cache[key]) return cache[key]
  const [c, g] = canvas(256, 256)
  g.fillStyle = base
  g.fillRect(0, 0, 256, 256)
  // panel seams + rivets
  g.strokeStyle = 'rgba(0,0,0,0.45)'
  g.lineWidth = 2
  g.strokeRect(1, 1, 254, 254)
  g.fillStyle = 'rgba(0,0,0,0.5)'
  for (let i = 8; i < 256; i += 24) {
    for (const [x, y] of [[i, 8], [i, 248], [8, i], [248, i]]) { g.beginPath(); g.arc(x, y, 2.2, 0, Math.PI * 2); g.fill() }
  }
  g.fillStyle = 'rgba(255,255,255,0.08)'
  for (let i = 8; i < 256; i += 24) {
    for (const [x, y] of [[i, 8], [i, 248], [8, i], [248, i]]) { g.beginPath(); g.arc(x - 0.6, y - 0.6, 1, 0, Math.PI * 2); g.fill() }
  }
  // chipped paint
  for (let i = 0; i < 40; i++) {
    g.fillStyle = `rgba(110,70,40,${0.2 + rand() * 0.3})`
    const x = rand() * 256, y = rand() * 256
    g.beginPath()
    g.moveTo(x, y)
    for (let k = 0; k < 6; k++) g.lineTo(x + (rand() - 0.5) * 12, y + (rand() - 0.5) * 12)
    g.fill()
  }
  grime(g, 256, 256, 0.6)
  cache[key] = c
  return c
}

export function crateWood () {
  if (cache.crate) return cache.crate
  const [c, g] = canvas(256, 256)
  g.fillStyle = '#6b5236'
  g.fillRect(0, 0, 256, 256)
  for (let p = 0; p < 6; p++) {
    g.fillStyle = `hsl(${30 + rand() * 6}, 32%, ${28 + rand() * 8}%)`
    g.fillRect(0, p * 42.6, 256, 41)
    for (let i = 0; i < 20; i++) {
      g.strokeStyle = `rgba(40,25,10,${0.15 + rand() * 0.2})`
      g.beginPath()
      const y = p * 42.6 + rand() * 41
      g.moveTo(0, y); g.bezierCurveTo(80, y + rand() * 4, 170, y - rand() * 4, 256, y)
      g.stroke()
    }
  }
  // frame + stencil
  g.fillStyle = '#4e3a24'
  g.fillRect(0, 0, 256, 18); g.fillRect(0, 238, 256, 18); g.fillRect(0, 0, 18, 256); g.fillRect(238, 0, 18, 256)
  g.save(); g.translate(128, 128); g.rotate(Math.atan2(220, 220))
  g.fillRect(-160, -9, 320, 18); g.restore()
  g.fillStyle = 'rgba(20,12,6,0.55)'
  g.font = 'bold 22px sans-serif'
  g.textAlign = 'center'
  g.fillText('ROUTE 0', 128, 60)
  g.font = 'bold 14px sans-serif'
  g.fillText('THIS WAY UP', 128, 210)
  grime(g, 256, 256, 0.5)
  cache.crate = c
  return c
}

export function ceiling () {
  if (cache.ceiling) return cache.ceiling
  const [c, g] = canvas(256, 256)
  g.fillStyle = '#b9ad94'
  g.fillRect(0, 0, 256, 256)
  for (let x = 0; x < 256; x += 32) {
    g.fillStyle = 'rgba(0,0,0,0.12)'
    g.fillRect(x, 0, 2, 256)
  }
  grime(g, 256, 256, 1.4)
  // water stains
  for (let i = 0; i < 6; i++) {
    const x = rand() * 256, y = rand() * 256, r = 10 + rand() * 40
    g.strokeStyle = 'rgba(90,60,30,0.25)'
    g.lineWidth = 2
    g.beginPath(); g.ellipse(x, y, r, r * 0.7, rand(), 0, Math.PI * 2); g.stroke()
    g.fillStyle = 'rgba(90,60,30,0.08)'; g.fill()
  }
  cache.ceiling = c
  return c
}

export function paper () {
  const [c, g] = canvas(256, 320)
  g.fillStyle = '#d9cfb7'
  g.fillRect(0, 0, 256, 320)
  g.strokeStyle = 'rgba(80,60,40,0.35)'
  for (let y = 40; y < 300; y += 18) { g.beginPath(); g.moveTo(20, y); g.lineTo(236, y); g.stroke() }
  g.fillStyle = 'rgba(40,30,20,0.7)'
  for (let y = 36; y < 290; y += 18) {
    let x = 24
    while (x < 220) { const w = 6 + rand() * 30; g.fillRect(x, y - 6, w, 2.5); x += w + 6 }
  }
  grime(g, 256, 320, 0.5, false)
  return c
}

const mat = (key, make) => cache['m_' + key] || (cache['m_' + key] = make())

export const materials = {
  wood: () => mat('wood', () => new THREE.MeshStandardMaterial({ map: toTexture(woodPanel(), [2, 1]), roughness: 0.55, metalness: 0.05 })),
  floor: () => mat('floor', () => new THREE.MeshStandardMaterial({ map: toTexture(floorPlate(), [2, 6]), bumpMap: toTexture(floorPlate(), [2, 6], false), bumpScale: 0.6, roughness: 0.7, metalness: 0.45 })),
  carpet: () => mat('carpet', () => new THREE.MeshStandardMaterial({ map: toTexture(carpet(), [1.5, 8]), roughness: 0.95 })),
  fabric: () => mat('fabric', () => new THREE.MeshStandardMaterial({ map: toTexture(fabric(), [2, 2]), roughness: 0.9 })),
  wall: () => mat('wall', () => new THREE.MeshStandardMaterial({ map: toTexture(paintedMetal('#3f4b47'), [4, 1]), roughness: 0.6, metalness: 0.3 })),
  wallCab: () => mat('wallCab', () => new THREE.MeshStandardMaterial({ map: toTexture(paintedMetal('#5b4a35'), [2, 1]), roughness: 0.55, metalness: 0.35 })),
  wallRed: () => mat('wallRed', () => new THREE.MeshStandardMaterial({ map: toTexture(paintedMetal('#4d2422'), [4, 1]), roughness: 0.6, metalness: 0.3 })),
  ceiling: () => mat('ceiling', () => new THREE.MeshStandardMaterial({ map: toTexture(ceiling(), [1, 6]), roughness: 0.85 })),
  crate: () => mat('crate', () => new THREE.MeshStandardMaterial({ map: toTexture(crateWood()), roughness: 0.8 })),
  brass: () => mat('brass', () => new THREE.MeshStandardMaterial({ color: 0xb08d57, roughness: 0.32, metalness: 0.85 })),
  steel: () => mat('steel', () => new THREE.MeshStandardMaterial({ color: 0x6e7476, roughness: 0.35, metalness: 0.8 })),
  darkSteel: () => mat('darkSteel', () => new THREE.MeshStandardMaterial({ color: 0x2a2d2f, roughness: 0.5, metalness: 0.7 })),
  rubber: () => mat('rubber', () => new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.95 })),
  glass: () => mat('glass', () => new THREE.MeshStandardMaterial({ color: 0x0c141c, roughness: 0.05, metalness: 0.2, transparent: true, opacity: 0.35 })),
  paper: () => mat('paper', () => new THREE.MeshStandardMaterial({ map: toTexture(paper()), roughness: 0.9, side: THREE.DoubleSide })),
  engine: () => mat('engine', () => new THREE.MeshStandardMaterial({ map: toTexture(paintedMetal('#2f3a33'), [3, 2]), roughness: 0.45, metalness: 0.6 })),
  locker: () => mat('locker', () => new THREE.MeshStandardMaterial({ map: toTexture(paintedMetal('#56605a'), [1, 2]), roughness: 0.5, metalness: 0.5 })),
}
