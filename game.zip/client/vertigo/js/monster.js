// The creature: a tall, gaunt figure (model + procedural animation) and its AI (run by the host only)
import * as THREE from 'three'
import { skinMat, torsoGeo, limbGeo, headGeo, handGeo, footGeo, furTex } from '../../gamekit/anatomy.js'
import { CARS, carIndexAt, laneX } from './world.js'
import {
  MONSTER_PATROL_SPEED, MONSTER_INVESTIGATE_SPEED, MONSTER_CHASE_SPEED, MONSTER_FINAL_CHASE_SPEED, MONSTER_CATCH_DISTANCE,
} from './config.js'

// ═════════════════════ MODEL ═════════════════════

export function createMonsterModel () {
  // pale, wet, veined skin stretched over bone
  const skin = skinMat(0x9a928c, { wet: true, veins: true, rough: 0.42, bump: 0.025 })
  const bone = new THREE.MeshStandardMaterial({ color: 0xcfc4ab, roughness: 0.42 })
  const mouth = new THREE.MeshStandardMaterial({ color: 0x3a0705, roughness: 0.35, emissive: 0x120201 })
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xd8d2c4 })
  const nail = new THREE.MeshStandardMaterial({ color: 0x1a1512, roughness: 0.3 })

  const add = (geo, mat, parent, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m }
  const pivot = (parent, x, y, z) => { const p = new THREE.Group(); p.position.set(x, y, z); parent.add(p); return p }
  const knob = (parent, r, y = 0) => { const k = add(new THREE.SphereGeometry(r, 14, 10), skin, parent, 0, y, 0); return k } // joint filler, the same width as the limb

  const root = new THREE.Group()
  root.name = 'creature'
  const hips = pivot(root, 0, 1.08, 0)
  // pelvis: bones showing at the hip
  const pelvis = add(new THREE.SphereGeometry(1, 18, 12), skin, hips, 0, 0.03, 0)
  pelvis.scale.set(0.125, 0.1, 0.085)
  for (const sx of [-1, 1]) add(new THREE.SphereGeometry(0.035, 10, 8), skin, hips, sx * 0.12, 0.04, 0.05)

  const spine = pivot(hips, 0, 0.05, 0)
  // emaciated torso: a deep ribcage and a sucked-in belly
  add(torsoGeo({ h: 0.74, hip: 0.12, waist: 0.085, chest: 0.155, shoulder: 0.185, neck: 0.04, depth: 0.62, segs: 24 }), skin, spine, 0, 0, 0)
  // ribs pressing through the skin, front and sides
  for (let i = 0; i < 6; i++) {
    const rib = new THREE.Mesh(new THREE.TorusGeometry(0.142 - Math.abs(i - 2.5) * 0.009, 0.016, 8, 22, Math.PI * 1.1), skin)
    rib.position.set(0, 0.36 + i * 0.058, -0.008)
    rib.rotation.set(Math.PI / 2 + 0.25, 0, Math.PI * 1.425)
    rib.scale.set(1, 0.68, 1)
    spine.add(rib)
  }
  // sternum and collarbones
  add(limbGeo(0.012, 0.01, 0.2, { bulge: 0 }), bone, spine, 0, 0.66, 0.085).rotation.x = 0.15
  for (const sx of [-1, 1]) { const c = add(limbGeo(0.012, 0.01, 0.16, { bulge: 0 }), skin, spine, sx * 0.02, 0.69, 0.07); c.rotation.z = sx * 1.35 }
  const chest = pivot(spine, 0, 0.74, 0)
  // spine ridge down the back
  for (let i = 0; i < 9; i++) {
    const v = add(new THREE.SphereGeometry(0.02, 10, 8), skin, spine, 0, 0.12 + i * 0.07, -0.075 - Math.sin(i / 8 * Math.PI) * 0.012)
    v.scale.set(1.3, 0.75, 0.7)
  }
  // shoulder blades
  for (const sx of [-1, 1]) { const b = add(new THREE.SphereGeometry(1, 12, 8), skin, chest, sx * 0.09, -0.16, -0.09); b.scale.set(0.07, 0.09, 0.025); b.rotation.z = sx * 0.3 }

  // what's left of a long coat: hanging open, torn into strips at the hem
  {
    const coatMat = new THREE.MeshStandardMaterial({ color: 0x1b1a1d, roughness: 0.95, side: THREE.DoubleSide, bumpMap: furTex(), bumpScale: 0.01 })
    const g = new THREE.CylinderGeometry(0.17, 0.27, 1.05, 30, 8, true, Math.PI * 0.22, Math.PI * 1.56)
    const p = g.attributes.position
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
      const a = Math.atan2(x, z)
      // ragged hem: strips of different lengths, and folds
      const hem = y < -0.35 ? (Math.abs(Math.sin(a * 9.3)) * 0.22 + Math.abs(Math.sin(a * 23.1)) * 0.08) * ((-y - 0.35) / 0.17) : 0
      const fold = 1 + Math.sin(a * 11 + y * 3) * 0.04
      p.setXYZ(i, x * fold, y + hem, z * fold * 0.82)
    }
    g.computeVertexNormals()
    const coat = add(g, coatMat, spine, 0, 0.26, -0.01)
    coat.castShadow = true
    // collar
    const collar = add(new THREE.TorusGeometry(0.1, 0.03, 6, 18, Math.PI * 1.4), coatMat, chest, 0, -0.04, -0.01)
    collar.rotation.set(Math.PI / 2 + 0.3, 0, Math.PI * 1.3)
  }
  const neck = pivot(chest, 0, 0.04, 0.03)
  add(limbGeo(0.04, 0.05, 0.26, { bulge: -0.15, at: 0.5 }), skin, neck, 0, 0.27, 0)
  // tendons in the neck
  for (const sx of [-1, 1]) { const t = add(limbGeo(0.009, 0.009, 0.26, { bulge: 0 }), skin, neck, sx * 0.025, 0.26, 0.025); t.rotation.z = sx * 0.1 }
  const head = pivot(neck, 0, 0.3, 0.04)
  // a long, hollow-cheeked skull with a heavy brow, almost no nose
  const skull = add(headGeo({ gaunt: 1.8, jaw: 0.75, skull: 1.3, nose: 0.15, brow: 2.2, chin: 0.6 }), skin, head, 0, 0.06, 0.02)
  skull.scale.set(0.12, 0.15, 0.145)
  // eyes: deep black sockets with pinpoints in them
  const eyes = []
  for (const sx of [-0.041, 0.041]) {
    const socket = add(new THREE.SphereGeometry(0.03, 14, 10), new THREE.MeshBasicMaterial({ color: 0x030101 }), head, sx, 0.084, 0.123)
    socket.scale.set(1, 0.75, 0.35)
    const eye = add(new THREE.SphereGeometry(0.008, 8, 6), eyeMat, head, sx, 0.084, 0.132)
    eyes.push(eye)
  }
  // nasal cavity: two slits
  for (const sx of [-0.008, 0.008]) add(new THREE.SphereGeometry(0.008, 8, 6), new THREE.MeshBasicMaterial({ color: 0x050202 }), head, sx, 0.035, 0.155).scale.set(0.6, 1.8, 0.4)
  // the mouth: a lipless slit across the face that tears wide open
  const throat = add(new THREE.SphereGeometry(1, 16, 10), mouth, head, 0, -0.016, 0.138)
  throat.scale.set(0.05, 0.016, 0.012)
  const jawPivot = pivot(head, 0, -0.012, 0.09)
  // chin on the hinge, just under the mouth
  const chin = add(new THREE.SphereGeometry(1, 16, 12), skin, jawPivot, 0, -0.04, 0.025)
  chin.scale.set(0.05, 0.035, 0.04)
  // teeth: long and uneven, upper row set in the face, lower row on the jaw
  for (let i = 0; i < 11; i++) {
    const t = i / 10 - 0.5
    const len = 0.014 + Math.abs(Math.sin(i * 2.7)) * 0.016
    const up = add(new THREE.ConeGeometry(0.0045, len, 5), bone, head, t * 0.085, -0.006 - len / 2, 0.15 - t * t * 0.08)
    up.rotation.x = Math.PI
    add(new THREE.ConeGeometry(0.004, len * 0.85, 5), bone, jawPivot, t * 0.08, -0.008 + len * 0.42, 0.058 - t * t * 0.08)
  }

  const makeArm = side => {
    const shoulder = pivot(chest, side * 0.165, -0.04, 0)
    knob(shoulder, 0.046)
    add(limbGeo(0.046, 0.03, 0.6, { bulge: 0.1, at: 0.25 }), skin, shoulder, 0, 0, 0)
    const elbow = pivot(shoulder, 0, -0.6, 0)
    knob(elbow, 0.031)
    add(limbGeo(0.032, 0.02, 0.68, { bulge: 0.14, at: 0.18 }), skin, elbow, 0, 0, 0)
    const wrist = pivot(elbow, 0, -0.68, 0)
    // long hands: fingers twice the length they should be, black nails filed to points
    const hg = handGeo({ fingerLen: 2.3, thick: 0.85, claws: 1.6, curl: 0.22 })
    if (side < 0) { hg.skin.scale(-1, 1, 1); hg.nails?.scale(-1, 1, 1) }
    const hand = pivot(wrist, 0, 0, 0)
    hand.rotation.y = side * -Math.PI / 2
    hand.scale.setScalar(1.25)
    add(hg.skin, skin, hand)
    if (hg.nails) add(hg.nails, nail, hand)
    hand.rotation.x = 0.2
    return { shoulder, elbow, wrist, fingers: [hand] }
  }
  const makeLeg = side => {
    const hip = pivot(hips, side * 0.11, -0.02, 0)
    add(limbGeo(0.07, 0.04, 0.53, { bulge: 0.08, at: 0.2 }), skin, hip, 0, 0, 0)
    const knee = pivot(hip, 0, -0.52, 0)
    knob(knee, 0.042)
    add(limbGeo(0.043, 0.024, 0.53, { bulge: 0.16, at: 0.22 }), skin, knee, 0, 0, 0)
    const ankle = pivot(knee, 0, -0.52, 0)
    // long bare feet with clawed toes
    add(footGeo({ len: 0.3, w: 0.045, h: 0.05 }), skin, ankle, 0, -0.02, 0)
    for (let t = 0; t < 4; t++) { const c = add(new THREE.ConeGeometry(0.008, 0.05, 5), nail, ankle, (t - 1.5) * 0.022, -0.035, 0.27); c.rotation.x = Math.PI / 2 + 0.3 }
    return { hip, knee, ankle }
  }
  const arms = [makeArm(-1), makeArm(1)]
  const legs = [makeLeg(-1), makeLeg(1)]

  let walkPhase = 0
  let twitch = 0
  let twitchTarget = new THREE.Euler()
  let lastStepSign = 0
  const model = {
    root, head, jawPivot, eyes, eyeMat, throat,
    /**
     * pose: { speed (m/s), state ('idle'|'walk'|'run'|'search'|'scream'|'lunge'), dt, alert (0-1) }
     * Returns true on a footstep frame.
     */
    animate ({ speed = 0, state = 'idle', dt = 0.016, alert = 0, jaw = 0 }) {
      const running = state === 'run' || speed > 3
      walkPhase += dt * (speed > 0.05 ? (running ? 9.5 : 5.4) * Math.min(1.4, speed / (running ? 3.6 : 1.6)) : 0)
      const s = Math.sin(walkPhase)
      const c = Math.cos(walkPhase)
      const moving = speed > 0.05
      const amp = moving ? (running ? 0.95 : 0.6) : 0
      // hunched lean: deeper when running
      const lean = running ? 0.62 : state === 'search' ? 0.5 : 0.35
      spine.rotation.x = lean + (moving ? Math.abs(s) * 0.06 : Math.sin(performance.now() / 900) * 0.03)
      chest.rotation.x = 0.25
      hips.position.y = 1.08 - (running ? 0.12 : 0.04) + (moving ? Math.abs(c) * 0.05 : 0)
      // legs
      legs.forEach((leg, i) => {
        const ph = i ? -s : s
        leg.hip.rotation.x = -ph * amp * 0.7 - (running ? 0.2 : 0.05)
        leg.knee.rotation.x = Math.max(0, (i ? c : -c)) * amp * 1.2 + 0.18
        leg.ankle.rotation.x = -0.15
      })
      // arms: long, dangling; reaching forward when chasing
      arms.forEach((arm, i) => {
        const ph = i ? s : -s
        const reach = running ? 1.25 : alert > 0.5 ? 0.6 : 0
        arm.shoulder.rotation.x = -reach + ph * amp * 0.6
        arm.shoulder.rotation.z = (i ? -1 : 1) * (0.12 + (running ? 0.15 : 0))
        arm.elbow.rotation.x = -0.25 - (running ? 0.35 : 0) + Math.sin(walkPhase * 0.5 + i) * 0.05
        for (const f of arm.fingers) f.rotation.x = 0.25 + Math.sin(performance.now() / 300 + i) * 0.1 + (state === 'search' ? 0.5 : 0)
      })
      // head: unnerving snaps
      twitch -= dt
      if (twitch <= 0) {
        twitch = 0.4 + Math.random() * (alert > 0.5 ? 0.6 : 2.2)
        twitchTarget = new THREE.Euler((Math.random() - 0.5) * 0.4 - 0.25, (Math.random() - 0.5) * (alert > 0.5 ? 0.4 : 1.1), (Math.random() - 0.5) * 0.9)
      }
      const k = Math.min(1, dt * 18)
      head.rotation.x += (twitchTarget.x - head.rotation.x) * k
      head.rotation.y += (twitchTarget.y - head.rotation.y) * k
      head.rotation.z += (twitchTarget.z - head.rotation.z) * k
      neck.rotation.x = -0.55
      jawPivot.rotation.x += ((state === 'scream' || state === 'lunge' ? 0.55 : jaw * 0.6) - jawPivot.rotation.x) * Math.min(1, dt * 14)
      throat.scale.y = 0.016 + jawPivot.rotation.x * 0.04
      // eyes: pale, or red when hunting
      const red = alert > 0.5
      eyeMat.color.setHex(red ? 0xff2a1a : 0xd8d2c4)
      for (const e of eyes) e.scale.setScalar(red ? 1.6 : 1)
      // footstep event when a foot plants
      const sign = Math.sign(s)
      const step = moving && sign !== lastStepSign && lastStepSign !== 0
      lastStepSign = sign
      return step
    },
  }
  return model
}

// ═════════════════════ AI (host only) ═════════════════════

/**
 * world: from buildWorld. hooks: {
 *   openDoor(index), isDoorOpen(index), onCatch(playerId), onSearchSpot(spotId, phase), onStateChange(state),
 *   isHidden(spotId) -> { playerId, holdingBreath, seenEntering } | null, litAt(z) -> 0..1, onRoar(), onSound(kind, x, z)
 * }
 */
export class MonsterBrain {
  constructor (world, hooks) {
    this.world = world
    this.hooks = hooks
    this.x = 0.85
    this.z = -110
    this.yaw = 0
    this.speed = 0
    this.state = 'dormant'
    this.anim = 'idle'
    this.alert = 0
    this.visible = false
    this.target = null
    this.timer = 0
    this.waitDoor = -1
    this.chaseId = null
    this.lastSeen = null
    this.sightTime = new Map()
    this.lostTimer = 0
    this.searchSpot = null
    this.final = false
    this.cooldown = 0
    this.lastSoundAt = 0
    this.recentlySearched = new Map()
  }

  snapshot () {
    return { x: +this.x.toFixed(2), z: +this.z.toFixed(2), yaw: +this.yaw.toFixed(2), speed: +this.speed.toFixed(2), anim: this.anim, alert: +this.alert.toFixed(2), visible: this.visible, state: this.state }
  }

  restore (s) {
    Object.assign(this, { x: s.x, z: s.z, yaw: s.yaw, speed: s.speed ?? 0, anim: s.anim, alert: s.alert, visible: s.visible, state: s.state === 'dormant' ? 'dormant' : s.state === 'away' ? 'away' : 'patrol', awayFor: 10 })
    this.target = null
    this.chaseId = null
  }

  /** walk away and disappear for a while */
  leave () {
    this.chaseId = null
    this.presence = 0
    this.fails = 0
    this.setState('leaving', { target: null })
  }

  placeAt (x, z, state = 'patrol') {
    this.presence = 0
    this.fails = 0
    this.x = x
    this.z = z
    this.visible = true
    this.setState(state)
  }

  setState (state, extra = {}) {
    this.state = state
    this.timer = 0
    Object.assign(this, extra)
    this.hooks.onStateChange?.(state)
  }

  /** A noise at (x,z) heard within `radius` metres */
  hear (x, z, radius) {
    if (!this.visible || this.state === 'dormant' || this.state === 'retreat' || this.state === 'leaving' || this.state === 'away' || this.state === 'scripted') return
    const d = Math.hypot(x - this.x, z - this.z)
    // walls muffle sound through closed doors
    const doorsBetween = this.closedDoorsBetween(this.z, z)
    const effective = radius / (1 + doorsBetween * 0.8)
    if (d > effective) return
    if (this.state === 'chase') return
    this.setState('investigate', { target: { x, z }, lookAround: 3 + Math.random() * 2 })
  }

  closedDoorsBetween (z0, z1) {
    let n = 0
    for (const d of this.world.doors) {
      if (d.z < Math.max(z0, z1) && d.z > Math.min(z0, z1) && !this.hooks.isDoorOpen(d.index)) n++
    }
    return n
  }

  /** Can the creature see this player right now? */
  canSee (p) {
    if (p.down || p.hidden || !p.alive) return false
    const dx = p.x - this.x, dz = p.z - this.z
    const d = Math.hypot(dx, dz)
    if (d > 32) return false
    if (this.closedDoorsBetween(this.z, p.z) > 0) return false
    // Car 7 compartments: only visible through the doorway
    if (p.z < -61.5 && p.z > -118.5 && p.x < 0.45 && Math.abs(this.z - p.z) > 1.2) return false
    if (p.z < -156 && p.z > -176 && p.x < 0.45 && Math.abs(this.z - p.z) > 1.2) return false
    // engine block hides the left side of the engine room
    if (p.z < -7.5 && p.z > -16.5 && p.x < 0.2 && this.x > 0.2 && Math.abs(dz) > 1.5) return false
    const lit = Math.max(this.hooks.litAt(p.z), p.flashlight ? 0.9 : 0)
    let range = 6 + lit * 12
    if (p.crouch) range *= 0.55
    if (p.crouch && p.inCover) range = Math.min(range, 2.2)
    if (this.final) range *= 1.25
    if (d > range) return false
    // field of view (wide when already hunting or very close)
    if (this.state !== 'chase' && d > 2.5) {
      const fx = Math.sin(this.yaw), fz = Math.cos(this.yaw)
      const dot = (dx * fx + dz * fz) / (d || 1)
      if (dot < Math.cos(Math.PI * 0.42)) return false
    }
    return true
  }

  moveToward (tx, tz, speed, dt) {
    // Wait for a door to open before passing through it
    if (this.waitDoor >= 0) {
      if (this.hooks.isDoorOpen(this.waitDoor)) this.waitDoor = -1
      else { this.speed = 0; return false }
    }
    const dz = tz - this.z
    const step = speed * dt
    let nz = this.z + Math.sign(dz) * Math.min(Math.abs(dz), step)
    // doors in the way?
    for (const d of this.world.doors) {
      const crossing = (this.z > d.z && nz <= d.z + 0.4) || (this.z < d.z && nz >= d.z - 0.4)
      if (crossing && Math.abs(this.z - d.z) < 1.2 && !this.hooks.isDoorOpen(d.index)) {
        if (this.hooks.isDoorLocked?.(d.index)) {
          this.speed = 0
          this.blockedTime = (this.blockedTime ?? 0) + dt
          if (this.blockedTime > 2.5 && this.state !== 'scripted') { this.blockedTime = 0; this.setState('patrol', { target: null }) }
          return this.state === 'scripted'
        }
        this.hooks.openDoor(d.index)
        this.waitDoor = d.index
        this.speed = 0
        return false
      }
    }
    // stay on the walkable lane, but step sideways toward targets off the lane (hiding spots)
    const nearTarget = Math.abs(tz - nz) < 1.6
    const wantX = nearTarget ? tx : laneX(nz)
    const nx = this.x + Math.sign(wantX - this.x) * Math.min(Math.abs(wantX - this.x), speed * dt * (nearTarget ? 1 : 1.4))
    const moved = Math.hypot(nx - this.x, nz - this.z)
    if (moved > 0.0005) this.yaw = Math.atan2(nx - this.x, nz - this.z)
    this.x = nx
    this.z = nz
    this.speed = moved / Math.max(dt, 1e-4)
    return Math.hypot(tx - this.x, tz - this.z) < 0.35
  }

  pickPatrolTarget (players) {
    const alive = players.filter(p => p.alive && !p.down)
    let z
    if (alive.length && Math.random() < (this.final ? 0.6 : 0.35)) {
      // drift toward the players (hunting), but not straight onto them
      const p = alive[Math.floor(Math.random() * alive.length)]
      z = p.z + (Math.random() < 0.5 ? -1 : 1) * (10 + Math.random() * 16)
    } else {
      const car = CARS[1 + Math.floor(Math.random() * (CARS.length - 1))]
      z = car.zr + 1 + Math.random() * (car.zf - car.zr - 2)
    }
    const rear = this.rearLimit ?? -134
    z = Math.max(rear, Math.min(-4.6, z)) // the cab is safe ground until the finale
    if (this.final) z = Math.max(rear, Math.min(2.5, z))
    return { x: laneX(z), z }
  }

  update (dt, players) {
    if (this.cooldown > 0) this.cooldown -= dt
    // gone for a while (it left): come back later, somewhere far from everyone
    if (this.state === 'away') {
      this.speed = 0
      this.awayFor -= dt
      if (this.awayFor <= 0) {
        const spot = this.farFrom(players)
        this.x = spot.x; this.z = spot.z
        this.visible = true
        this.presence = 0
        this.fails = 0
        this.sightTime.clear()
        this.setState('patrol', { target: null })
      }
      return
    }
    if (this.state === 'dormant' || !this.visible) { this.speed = 0; this.anim = 'idle'; return }
    // it doesn't camp: after hanging around you long enough without catching anyone, it leaves
    const near = players.some(p => p.alive && !p.down && Math.hypot(p.x - this.x, p.z - this.z) < 24)
    this.presence = Math.max(0, (this.presence ?? 0) + (near ? dt : -dt * 0.5))
    const limit = this.final ? 75 : 55
    const sceneLock = performance.now() - (this.lastHuntAt ?? -1e9) < 40000
    if (!sceneLock && (this.state === 'patrol' || this.state === 'investigate') && (this.presence > limit || (this.fails ?? 0) >= 2)) this.leave()
    this.timer += dt
    const chaseSpeed = this.final ? MONSTER_FINAL_CHASE_SPEED : MONSTER_CHASE_SPEED

    // perception (needs a moment of clear sight before it commits: fair warning)
    if (this.state !== 'retreat' && this.state !== 'leaving' && this.state !== 'scripted' && this.state !== 'searchSpot' && this.state !== 'hunt') {
      let best = null
      for (const p of players) {
        const seen = this.canSee(p)
        const t = seen ? (this.sightTime.get(p.id) ?? 0) + dt : 0
        this.sightTime.set(p.id, t)
        const need = this.state === 'chase' ? 0 : (this.final ? 0.18 : 0.38)
        if (seen && t >= need) {
          const d = Math.hypot(p.x - this.x, p.z - this.z)
          if (!best || d < best.d) best = { p, d }
        }
      }
      if (best) {
        if (this.state !== 'chase') {
          this.hooks.onRoar?.()
          this.setState('chase')
        }
        this.chaseId = best.p.id
        this.lastSeen = { x: best.p.x, z: best.p.z, t: 0 }
        this.lostTimer = 0
      }
    }

    switch (this.state) {
      case 'patrol': {
        this.alert = Math.max(0, this.alert - dt * 0.3)
        if (!this.target) { this.target = this.pickPatrolTarget(players); this.pause = 0 }
        if (this.pause > 0) {
          this.pause -= dt
          this.speed = 0
          if (this.pause <= 0) this.target = this.pickPatrolTarget(players)
        } else if (this.moveToward(this.target.x, this.target.z, MONSTER_PATROL_SPEED * (this.final ? 1.3 : 1), dt)) {
          this.pause = 1.5 + Math.random() * 3.5
          if (Math.random() < 0.5) this.hooks.onSound?.(Math.random() < 0.5 ? 'drag' : 'growl', this.x, this.z)
        }
        this.anim = this.speed > 0.1 ? 'walk' : 'idle'
        break
      }
      case 'investigate': {
        this.alert = Math.min(0.5, this.alert + dt)
        if (this.target && this.moveToward(this.target.x, this.target.z, MONSTER_INVESTIGATE_SPEED * (this.final ? 1.2 : 1), dt)) {
          this.target = null
          this.timer = 0
        }
        this.anim = this.speed > 0.1 ? 'walk' : 'search'
        if (!this.target) {
          this.speed = 0
          this.yaw += Math.sin(this.timer * 2.2) * dt * 1.4
          if (this.timer > this.lookAround) {
            const spot = this.nearbySpot(6)
            if (spot && Math.random() < 0.55) this.setState('searchSpot', { searchSpot: spot, target: { ...spot.exit }, phase: 'go' })
            else this.setState('patrol', { target: null })
          }
        }
        break
      }
      case 'chase': {
        this.alert = 1
        const p = players.find(q => q.id === this.chaseId)
        const visible = p && this.canSee(p)
        if (visible) {
          this.lastSeen = { x: p.x, z: p.z }
          this.lostTimer = 0
        } else {
          this.lostTimer += dt
          // Did they just duck into a hiding spot in front of it?
          if (p?.hidden && p.hiddenSeen) {
            const spot = this.world.hideSpots.find(s => s.id === p.hidden)
            if (spot) { this.setState('searchSpot', { searchSpot: spot, target: { ...spot.exit }, phase: 'go', certain: true }); break }
          }
        }
        const tgt = visible ? { x: p.x, z: p.z } : this.lastSeen
        const arrived = tgt ? this.moveToward(tgt.x, tgt.z, chaseSpeed, dt) : true
        this.anim = 'run'
        if (visible && Math.hypot(p.x - this.x, p.z - this.z) < MONSTER_CATCH_DISTANCE) {
          this.catchPlayer(p)
          break
        }
        if (!visible && (arrived || this.lostTimer > 4)) {
          this.fails = (this.fails ?? 0) + 1
          this.setState('investigate', { target: null, lookAround: 3.5 })
          this.chaseId = null
        }
        break
      }
      case 'searchSpot': {
        this.alert = this.certain ? 1 : 0.6
        const spot = this.searchSpot
        if (this.phase === 'go') {
          this.anim = this.certain ? 'run' : 'walk'
          if (this.moveToward(spot.exit.x, spot.exit.z, this.certain ? chaseSpeed : MONSTER_INVESTIGATE_SPEED, dt)) {
            this.phase = 'inspect'
            this.timer = 0
            this.yaw = Math.atan2(spot.inside.x - this.x, spot.inside.z - this.z)
            this.hooks.onSearchSpot?.(spot.id, 'start')
          }
        } else {
          this.speed = 0
          this.anim = 'search'
          if (this.timer > 2.6) {
            const inside = this.hooks.isHidden(spot.id)
            this.recentlySearched.set(spot.id, performance.now())
            this.hooks.onSearchSpot?.(spot.id, 'end')
            if (inside && (this.certain || !inside.holdingBreath)) {
              this.catchPlayer({ id: inside.playerId, x: spot.inside.x, z: spot.inside.z })
            } else {
              this.fails = (this.fails ?? 0) + 1
              this.setState('patrol', { target: null, certain: false })
              this.hooks.onSound?.('growl', this.x, this.z)
            }
          }
        }
        break
      }
      case 'hunt': {
        // scripted chase scene: it knows where you are and comes straight for you
        this.alert = 1
        const prey = players.filter(p => p.alive && !p.down && !p.hidden)
          .sort((a, b) => Math.hypot(a.x - this.x, a.z - this.z) - Math.hypot(b.x - this.x, b.z - this.z))[0]
        if (!prey) {
          const hid = players.find(p => p.hidden && p.hiddenSeen)
          const spot = hid && this.world.hideSpots.find(s => s.id === hid.hidden)
          if (spot) this.setState('searchSpot', { searchSpot: spot, target: { ...spot.exit }, phase: 'go', certain: true })
          else this.setState('investigate', { target: null, lookAround: 4 })
          break
        }
        this.chaseId = prey.id
        this.moveToward(prey.x, prey.z, this.huntSpeed ?? MONSTER_CHASE_SPEED, dt)
        this.anim = 'run'
        if (Math.hypot(prey.x - this.x, prey.z - this.z) < MONSTER_CATCH_DISTANCE) this.catchPlayer(prey)
        break
      }
      case 'leaving': {
        // walks off into the dark, then is simply gone
        this.alert = Math.max(0, this.alert - dt)
        this.anim = 'walk'
        if (!this.target) this.target = this.farFrom(players)
        const far = players.every(p => !p.alive || Math.hypot(p.x - this.x, p.z - this.z) > 20)
        if (this.moveToward(this.target.x, this.target.z, 3.0, dt) || this.timer > 12 || (far && this.timer > 3)) {
          this.visible = false
          this.speed = 0
          this.awayFor = this.final ? 18 + Math.random() * 14 : 35 + Math.random() * 35
          this.hooks.onSound?.('drag', this.x, this.z)
          this.setState('away')
        }
        break
      }
      case 'retreat': {
        this.alert = 0
        this.anim = 'walk'
        if (!this.target) this.target = this.farFrom(players)
        if (this.moveToward(this.target.x, this.target.z, 2.8, dt) || this.timer > 14) this.setState('patrol', { target: null })
        break
      }
      case 'scripted': {
        if (this.target) {
          const done = this.moveToward(this.target.x, this.target.z, this.scriptSpeed ?? 3.2, dt)
          this.anim = (this.scriptSpeed ?? 3.2) > 2.5 ? 'run' : 'walk'
          if (done) {
            this.target = this.next ?? null
            this.next = null
            if (!this.target) this.onScriptDone?.()
          }
        } else { this.speed = 0; this.anim = 'idle' }
        break
      }
    }
  }

  nearbySpot (radius) {
    const now = performance.now()
    let best = null
    for (const s of this.world.hideSpots) {
      const d = Math.hypot(s.exit.x - this.x, s.exit.z - this.z)
      if (d > radius) continue
      if (now - (this.recentlySearched.get(s.id) ?? 0) < 30000) continue
      if (!best || d < best.d) best = { s, d }
    }
    return best?.s ?? null
  }

  farFrom (players) {
    const alive = players.filter(p => p.alive)
    const avg = alive.length ? alive.reduce((a, p) => a + p.z, 0) / alive.length : 0
    const rear = this.rearLimit ?? -133
    const z = avg < (rear + 6) / 2 ? Math.min(-6, avg + 50) : Math.max(rear, avg - 50)
    return { x: laneX(z), z }
  }

  catchPlayer (p) {
    this.presence = 0
    this.fails = 0
    this.hooks.onCatch(p.id)
    this.chaseId = null
    this.sightTime.clear()
    this.setState('retreat', { target: null })
    this.cooldown = 6
  }

  /** Chase scene: run at the players regardless of sight */
  hunt (speed) {
    this.lastHuntAt = performance.now()
    this.visible = true
    this.huntSpeed = speed
    this.setState('hunt')
  }

  /** Scripted walk (for scares). path: [{x,z}, ...] */
  script (path, speed, onDone) {
    this.visible = true
    this.setState('scripted', { target: path[0], next: path[1] ?? null, scriptSpeed: speed })
    this.onScriptDone = onDone
  }
}
