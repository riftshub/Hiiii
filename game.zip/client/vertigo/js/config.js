// Vertigo Freight — shared settings

/**
 * Co-op relay. It lives on the same Render server as the Minecraft world (path /vertigo).
 * Change this if you move the server.
 */
export const COOP_SERVER = 'wss://gl-tahx.onrender.com/vertigo'

export const coopServerUrl = () => {
  const { hostname, protocol, host } = window.location
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    // Local testing: a server.js running on this machine
    const port = new URLSearchParams(location.search).get('relayPort') || '8080'
    return `${protocol === 'https:' ? 'wss' : 'ws'}://${hostname}:${port}/vertigo`
  }
  // Opened straight from the Render server: use that same server
  if (hostname.endsWith('.onrender.com')) return `wss://${host}/vertigo`
  return COOP_SERVER
}

export const MAX_PLAYERS = 4

// Player movement (metres / second)
export const WALK_SPEED = 2.3
export const SPRINT_SPEED = 4.3
export const CROUCH_SPEED = 1.1
export const PLAYER_RADIUS = 0.28
export const EYE_HEIGHT = 1.62
export const CROUCH_EYE_HEIGHT = 0.95

// Monster
export const MONSTER_PATROL_SPEED = 1.5
export const MONSTER_INVESTIGATE_SPEED = 2.6
export const MONSTER_CHASE_SPEED = 3.65
export const MONSTER_FINAL_CHASE_SPEED = 3.95
export const MONSTER_CATCH_DISTANCE = 0.95

// How long a downed teammate can still be revived
export const BLEED_OUT_SECONDS = 25
export const REVIVE_SECONDS = 3

// Final phase: time until the train arrives
export const FINAL_PHASE_SECONDS = 210

export const DEFAULT_SETTINGS = {
  sensitivity: 1,
  volume: 0.8,
  quality: 'auto', // 'auto' | 'high' | 'low'
  invertY: false,
}

export const isTouchDevice = () => (navigator.maxTouchPoints > 0 && matchMedia('(pointer: coarse)').matches) || /Android|iPhone|iPad/i.test(navigator.userAgent)
