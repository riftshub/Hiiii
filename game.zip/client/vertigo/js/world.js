// The train: carriages, furniture, colliders, doors, hiding spots, items, lamps and the night outside.
import * as THREE from 'three'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { materials as M } from './textures.js'

export const HALF_W = 1.45 // interior half width
export const CEIL = 2.2 // wall top; the arched ceiling peaks around 2.7

/**
 * Carriages from the front of the train (+Z, where it's heading) to the back.
 * Each car spans z from `zf` (front) down to `zr` (rear); a 1 m gangway joins neighbours.
 */
export const CARS = [
  { id: 'cab', name: 'Locomotive cab', zf: 4, zr: -4, wall: 'wallCab', floor: 'floor', surface: 'metal', lampColor: 0xff5a3c },
  { id: 'engine', name: 'Engine room', zf: -5, zr: -19, wall: 'wall', floor: 'floor', surface: 'metal', lampColor: 0xffd59a },
  { id: 'coach', name: 'Passenger car', zf: -20, zr: -40, wall: 'wood', floor: 'carpet', surface: 'wood', lampColor: 0xffc27a },
  { id: 'cargo', name: 'Cargo car', zf: -41, zr: -59, wall: 'wall', floor: 'floor', surface: 'metal', lampColor: 0xffe1b0 },
  { id: 'car7', name: 'Car 7', zf: -60, zr: -120, wall: 'wallRed', floor: 'carpet', surface: 'wood', lampColor: 0xc9ffd8 },
  { id: 'gen', name: 'Generator car', zf: -121, zr: -135, wall: 'wall', floor: 'floor', surface: 'metal', lampColor: 0xffd59a },
  // Cars that were not on the train when it left the station (behind the generator car)
  { id: 'dining', name: 'Dining car', zf: -136, zr: -154, wall: 'wood', floor: 'carpet', surface: 'carpet', lampColor: 0xffb870 },
  { id: 'sleeper', name: 'Sleeping car', zf: -155, zr: -177, wall: 'wallRed', floor: 'carpet', surface: 'carpet', lampColor: 0xffd2a0 },
  { id: 'mail', name: 'Mail car', zf: -178, zr: -194, wall: 'wall', floor: 'floor', surface: 'wood', lampColor: 0xe8f0ff },
  { id: 'obs', name: 'Observation car', zf: -195, zr: -207, wall: 'wood', floor: 'carpet', surface: 'carpet', lampColor: 0xffc890 },
]
export const TRAIN_FRONT = 3.6
export const TRAIN_REAR = -206.5

export const carAt = z => CARS.find(c => z <= c.zf + 0.5 && z >= c.zr - 0.5) ?? null
export const carIndexAt = z => CARS.findIndex(c => z <= c.zf + 0.5 && z >= c.zr - 0.5)

/** The x the creature walks along at a given z (aisle / walkway / corridor) */
export const laneX = z => {
  if (z < -7 && z > -17) return 0.85 // engine room walkway beside the engine
  if (z < -61.5 && z > -118.5) return 1.0 // Car 7 side corridor
  if (z < -156.5 && z > -175.5) return 1.0 // sleeping car corridor
  if (z < -179 && z > -193) return 0.35 // mail car: between the sorting table and the sacks
  return 0
}

export const HOME_LEVEL = 2.2

export function buildWorld (scene, { quality = 'high' } = {}) {
  const high = quality === 'high'
  const statics = new Map() // material -> geometries (merged at the end to cut draw calls)
  const colliders = []
  const covers = []
  const doors = []
  const hideSpots = []
  const interactables = []
  const items = []
  const lampsByCar = new Map()
  const dynamic = new THREE.Group()
  dynamic.name = 'dynamic'
  scene.add(dynamic)

  const tmpM = new THREE.Matrix4()
  const add = (geom, mat, x, y, z, { rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1 } = {}) => {
    const g = geom.clone()
    tmpM.compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)), new THREE.Vector3(sx, sy, sz))
    g.applyMatrix4(tmpM)
    if (!statics.has(mat)) statics.set(mat, [])
    statics.get(mat).push(g)
    return g
  }
  const box = (w, h, d, mat, x, y, z, opts) => add(new THREE.BoxGeometry(w, h, d), mat, x, y + h / 2, z, opts)
  const cyl = (rt, rb, h, mat, x, y, z, opts = {}, seg = 16) => add(new THREE.CylinderGeometry(rt, rb, h, seg), mat, x, y, z, opts)
  const collide = (minX, maxX, minZ, maxZ, extra = {}) => { const c = { minX, maxX, minZ, maxZ, ...extra }; colliders.push(c); return c }
  const boxC = (w, h, d, mat, x, y, z, opts) => { box(w, h, d, mat, x, y, z, opts); return collide(x - w / 2, x + w / 2, z - d / 2, z + d / 2) }

  // ───────── carriage shells ─────────
  const arch = (() => {
    const s = new THREE.Shape()
    s.moveTo(-HALF_W - 0.05, CEIL)
    s.quadraticCurveTo(0, CEIL + 0.95, HALF_W + 0.05, CEIL)
    s.lineTo(HALF_W + 0.05, CEIL + 0.06)
    s.quadraticCurveTo(0, CEIL + 1.02, -HALF_W - 0.05, CEIL + 0.06)
    s.closePath()
    return s
  })()
  // solid half-moon that closes the space above an end wall, up to the ceiling
  const archFill = (() => {
    const s = new THREE.Shape()
    s.moveTo(-HALF_W - 0.05, CEIL - 0.01)
    s.quadraticCurveTo(0, CEIL + 1.0, HALF_W + 0.05, CEIL - 0.01)
    s.closePath()
    return s
  })()

  /** Openings in a side wall: windows (glass, sill..head) or a full-height door gap */
  const openingsFor = (car, side) => {
    const len = car.zf - car.zr
    const win = (z0, z1) => ({ z0, z1, sill: 0.95, head: 1.75, glass: true })
    const list = []
    if (car.id === 'coach') for (let z = car.zf - 1.6; z > car.zr + 1.2; z -= 1.5) list.push(win(z - 1.05, z))
    else if (car.id === 'car7') { if (side > 0) for (let z = car.zf - 2.4; z > car.zr + 2; z -= 3) list.push(win(z - 1.4, z)) }
    else if (car.id === 'cab') list.push(win(car.zf - 2.2, car.zf - 0.6), win(car.zf - 4.6, car.zf - 3.2))
    else if (car.id === 'engine' || car.id === 'gen') for (let z = car.zf - 2; z > car.zr + 1.5; z -= len / 3) list.push(win(z - 0.7, z))
    else if (car.id === 'cargo' && side < 0) list.push({ z0: -50.6, z1: -48.2, sill: 0, head: 2.05, glass: false })
    else if (car.id === 'dining') for (let z = car.zf - 1.4; z > car.zr + 5.5; z -= 3) list.push(win(z - 1.6, z))
    else if (car.id === 'sleeper') { if (side > 0) for (let z = car.zf - 2.2; z > car.zr + 2; z -= 3.4) list.push(win(z - 1.4, z)) }
    else if (car.id === 'mail') for (let z = car.zf - 2.5; z > car.zr + 2; z -= 4) list.push({ z0: z - 0.6, z1: z, sill: 1.6, head: 1.95, glass: true })
    else if (car.id === 'obs') for (let z = car.zf - 1; z > car.zr + 1.4; z -= 2.6) list.push({ z0: z - 2.2, z1: z, sill: 0.6, head: 2.1, glass: true })
    return list.sort((a, b) => b.z1 - a.z1)
  }

  const sideWall = (car, side) => {
    const x = side * (HALF_W + 0.04)
    const mat = M[car.wall]()
    let cursor = car.zf
    for (const o of openingsFor(car, side)) {
      if (cursor - o.z1 > 0.01) box(0.08, CEIL, cursor - o.z1, mat, x, 0, (cursor + o.z1) / 2)
      const zm = (o.z0 + o.z1) / 2, zl = o.z1 - o.z0
      if (o.sill > 0) box(0.08, o.sill, zl, mat, x, 0, zm)
      box(0.08, CEIL - o.head, zl, mat, x, o.head, zm)
      if (o.glass) {
        box(0.1, 0.05, zl, M.brass(), x - side * 0.01, o.sill - 0.02, zm)
        add(new THREE.PlaneGeometry(zl, o.head - o.sill), M.glass(), x + side * 0.02, (o.sill + o.head) / 2, zm, { ry: side > 0 ? -Math.PI / 2 : Math.PI / 2 })
      } else {
        // door runner + frame
        box(0.12, 0.08, zl + 0.3, M.darkSteel(), x, o.head, zm)
        for (const ze of [o.z0, o.z1]) box(0.12, o.head, 0.08, M.darkSteel(), x, 0, ze)
      }
      cursor = o.z0
    }
    if (cursor - car.zr > 0.01) box(0.08, CEIL, cursor - car.zr, mat, x, 0, (cursor + car.zr) / 2)
    collide(side > 0 ? HALF_W : -HALF_W - 0.3, side > 0 ? HALF_W + 0.3 : -HALF_W, car.zr - 0.5, car.zf + 0.5)
  }

  const endWall = (car, z, withDoor, faceSign) => {
    const mat = M[car.wall]()
    if (!withDoor && car.id === 'obs') {
      // the last car ends in a wide window looking back down the line
      box(HALF_W * 2 + 0.1, 0.8, 0.08, mat, 0, 0, z)
      box(HALF_W * 2 + 0.1, CEIL - 2.0, 0.08, mat, 0, 2.0, z)
      for (const sx of [-1, 1]) box(0.25, 1.2, 0.08, mat, sx * (HALF_W - 0.1), 0.8, z)
      collide(-HALF_W, HALF_W, z - 0.1, z + 0.1)
      add(new THREE.ShapeGeometry(archFill, 14), mat, 0, 0, z)
      add(new THREE.ShapeGeometry(archFill, 14), mat, 0, 0, z, { ry: Math.PI })
      return
    }
    if (!withDoor) {
      box(HALF_W * 2 + 0.1, CEIL, 0.08, mat, 0, 0, z)
      collide(-HALF_W, HALF_W, z - 0.1, z + 0.1)
      add(new THREE.ShapeGeometry(archFill, 14), mat, 0, 0, z)
      add(new THREE.ShapeGeometry(archFill, 14), mat, 0, 0, z, { ry: Math.PI })
      return
    }
    const side = HALF_W - 0.45
    box(side, CEIL, 0.08, mat, -0.45 - side / 2, 0, z)
    box(side, CEIL, 0.08, mat, 0.45 + side / 2, 0, z)
    box(0.9, CEIL - 2.05, 0.08, mat, 0, 2.05, z)
    // brass door frame
    box(0.06, 2.05, 0.12, M.brass(), -0.47, 0, z)
    box(0.06, 2.05, 0.12, M.brass(), 0.47, 0, z)
    box(1.0, 0.06, 0.12, M.brass(), 0, 2.03, z)
    collide(-HALF_W, -0.45, z - 0.1, z + 0.1)
    collide(0.45, HALF_W, z - 0.1, z + 0.1)
    // arch fill above the end wall (both faces)
    add(new THREE.ShapeGeometry(archFill, 14), mat, 0, 0, z)
    add(new THREE.ShapeGeometry(archFill, 14), mat, 0, 0, z, { ry: Math.PI })
  }

  for (const [i, car] of CARS.entries()) {
    const len = car.zf - car.zr
    const mid = (car.zf + car.zr) / 2
    // floor
    add(new THREE.PlaneGeometry(HALF_W * 2, len), M[car.floor](), 0, 0, mid, { rx: -Math.PI / 2 })
    // arched ceiling
    const ceil = new THREE.ExtrudeGeometry(arch, { depth: len, bevelEnabled: false, curveSegments: 14 })
    add(ceil, M.ceiling(), 0, 0, car.zr)
    sideWall(car, -1)
    sideWall(car, 1)
    if (car.id !== 'cab') endWall(car, car.zf, true, -1)
    if (i < CARS.length - 1) endWall(car, car.zr, true, 1)
    else endWall(car, car.zr, false, 1)
    // skirting + emergency floor strips (dim red: always on, they help in the dark)
    for (const sx of [-1, 1]) {
      box(0.04, 0.12, len, M.darkSteel(), sx * (HALF_W - 0.02), 0, mid)
    }
    // gangway to the next car
    if (i < CARS.length - 1) {
      const next = CARS[i + 1]
      const gz = (car.zr + next.zf) / 2
      const gl = car.zr - next.zf
      add(new THREE.PlaneGeometry(1.1, gl + 0.2), M.floor(), 0, 0.005, gz, { rx: -Math.PI / 2 })
      for (const sx of [-1, 1]) {
        for (let k = 0; k < 5; k++) box(0.06, 2.1, 0.12, M.rubber(), sx * 0.58, 0, next.zf + 0.1 + k * (gl - 0.2) / 4)
        box(0.04, 2.1, gl, M.rubber(), sx * 0.62, 0, gz)
        collide(sx > 0 ? 0.55 : -0.9, sx > 0 ? 0.9 : -0.55, next.zf - 0.1, car.zr + 0.1)
      }
      box(1.3, 0.05, gl, M.rubber(), 0, 2.1, gz)
    }
  }

  // ───────── doors (sliding, between cars) ─────────
  for (let i = 1; i < CARS.length; i++) {
    const car = CARS[i]
    const z = car.zf
    const leaf = new THREE.Group()
    const panel = new THREE.Mesh(new THREE.BoxGeometry(0.9, 2.02, 0.05), M.wallCab())
    panel.position.y = 1.01
    panel.castShadow = true
    panel.receiveShadow = true
    const pane = new THREE.Mesh(new THREE.PlaneGeometry(0.36, 0.5), M.glass())
    pane.position.set(0, 1.55, 0.03)
    const pane2 = pane.clone()
    pane2.position.z = -0.03
    pane2.rotation.y = Math.PI
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.22, 0.06), M.brass())
    handle.position.set(0.36, 1.05, 0)
    leaf.add(panel, pane, pane2, handle)
    leaf.position.set(0, 0, z)
    dynamic.add(leaf)
    const locked = car.id === 'car7' || car.id === 'dining'
    if (locked) {
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.07), new THREE.MeshStandardMaterial({ color: 0x7a1d18, roughness: 0.5, metalness: 0.4, emissive: 0x2a0503 }))
      plate.position.set(0.3, 1.05, 0)
      leaf.add(plate)
    }
    const collider = collide(-0.45, 0.45, z - 0.06, z + 0.06, { doorIndex: doors.length })
    doors.push({ index: doors.length, z, leaf, open: 0, target: 0, locked, lastOpened: 0, collider, label: car.name, carId: car.id })
  }

  // ───────── lamps ─────────
  let fly = null // generator flywheel (built with the generator car)
  const lampGeom = new THREE.CylinderGeometry(0.16, 0.2, 0.08, 18)
  const addLamp = (car, x, y, z) => {
    if (!lampsByCar.has(car.id)) lampsByCar.set(car.id, [])
    lampsByCar.get(car.id).push({ x, y, z })
    box(0.44, 0.03, 0.44, M.brass(), x, y + 0.04, z)
  }
  for (const car of CARS) {
    if (car.id === 'cab') { addLamp(car, 0, 2.55, 0.5); continue }
    const step = car.id === 'car7' ? 4 : 3.4
    for (let z = car.zf - 1.7; z > car.zr + 0.8; z -= step) addLamp(car, car.id === 'engine' ? 0.85 : car.id === 'car7' || car.id === 'sleeper' ? 1.0 : car.id === 'mail' ? 0.3 : 0, car.id === 'car7' ? 2.55 : 2.6, z)
  }
  const lampGroups = new Map()
  for (const [carId, list] of lampsByCar) {
    const car = CARS.find(c => c.id === carId)
    const m = new THREE.MeshStandardMaterial({ color: 0x222222, emissive: car.lampColor, emissiveIntensity: 0, roughness: 0.4 })
    const geoms = list.map(l => lampGeom.clone().translate(l.x, l.y, l.z))
    const mesh = new THREE.Mesh(mergeGeometries(geoms), m)
    dynamic.add(mesh)
    // soft halo sprites (one material per car so each car can flicker on its own)
    const haloMat = glowSpriteMaterial(car.lampColor).clone()
    haloMat.opacity = 0
    const halos = []
    for (const l of list) {
      const s = new THREE.Sprite(haloMat)
      s.position.set(l.x, l.y - 0.12, l.z)
      s.scale.setScalar(0.9)
      dynamic.add(s)
      halos.push(s)
    }
    lampGroups.set(carId, { car, lamps: list, material: m, haloMat, halos, level: 0, target: 0, flicker: 0 })
  }

  // Emergency floor strips per car (dim red, separate so they can glow)
  const stripMat = new THREE.MeshBasicMaterial({ color: 0x5a0e0a })
  const stripGeoms = []
  for (const car of CARS) {
    for (const sx of [-1, 1]) stripGeoms.push(new THREE.BoxGeometry(0.03, 0.012, car.zf - car.zr - 0.4).translate(sx * (HALF_W - 0.08), 0.006, (car.zf + car.zr) / 2))
  }
  dynamic.add(new THREE.Mesh(mergeGeometries(stripGeoms), stripMat))

  // ───────── helpers for furniture ─────────
  const seat = (x, z, facing = 1) => {
    // facing +1: passengers face the front (+z)
    const f = facing
    box(0.86, 0.42, 0.5, M.wood(), x, 0, z)
    box(0.84, 0.1, 0.52, M.fabric(), x, 0.42, z + 0.01 * f)
    box(0.84, 0.72, 0.12, M.fabric(), x, 0.5, z - 0.26 * f, { rx: -0.12 * f })
    box(0.88, 0.08, 0.14, M.wood(), x, 1.2, z - 0.31 * f)
    for (const sx of [-0.45, 0.45]) box(0.05, 0.25, 0.46, M.wood(), x + sx, 0.42, z)
  }

  const locker = (x, z, doorFacing, id, label = 'Hide in the locker') => {
    // doorFacing: direction the door faces ('+x' | '-x' | '+z' | '-z')
    const w = 0.62, d = 0.52, h = 1.95
    const alongZ = doorFacing === '+x' || doorFacing === '-x'
    const bw = alongZ ? d : w, bd = alongZ ? w : d
    box(bw, h, bd, M.locker(), x, 0, z)
    collide(x - bw / 2, x + bw / 2, z - bd / 2, z + bd / 2)
    // door with vent slits (dynamic so it can rattle)
    const door = new THREE.Group()
    const panel = new THREE.Mesh(new THREE.BoxGeometry(alongZ ? 0.03 : w - 0.04, h - 0.06, alongZ ? w - 0.04 : 0.03), M.locker())
    panel.position.y = h / 2
    door.add(panel)
    const slitMat = M.rubber()
    for (let k = 0; k < 4; k++) {
      const slit = new THREE.Mesh(new THREE.BoxGeometry(alongZ ? 0.035 : 0.34, 0.025, alongZ ? 0.34 : 0.035), slitMat)
      slit.position.y = 1.45 + k * 0.06
      door.add(slit)
    }
    const off = { '+x': [bw / 2 + 0.005, 0], '-x': [-bw / 2 - 0.005, 0], '+z': [0, bd / 2 + 0.005], '-z': [0, -bd / 2 - 0.005] }[doorFacing]
    door.position.set(x + off[0], 0, z + off[1])
    dynamic.add(door)
    const dir = { '+x': [1, 0], '-x': [-1, 0], '+z': [0, 1], '-z': [0, -1] }[doorFacing]
    const yaw = Math.atan2(-dir[0], -dir[1])
    hideSpots.push({ id, type: 'locker', inside: { x, z }, exit: { x: x + dir[0] * 0.75, z: z + dir[1] * 0.75 }, yaw, door, label })
  }

  const note = (id, x, y, z, ry = 0, flat = true) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(0.21, 0.28), M.paper())
    m.position.set(x, y, z)
    if (flat) { m.rotation.x = -Math.PI / 2; m.rotation.z = ry } else m.rotation.y = ry
    dynamic.add(m)
    items.push({ id, kind: 'note', noteId: id, x, y, z, mesh: m, reusable: true })
  }

  const itemMesh = kind => {
    const g = new THREE.Group()
    if (kind === 'fuse') {
      const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.14, 12), new THREE.MeshStandardMaterial({ color: 0xffd9a0, emissive: 0xff8a2a, emissiveIntensity: 0.6, transparent: true, opacity: 0.85, roughness: 0.1 }))
      glass.rotation.z = Math.PI / 2
      const capA = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.04, 12), M.brass())
      capA.rotation.z = Math.PI / 2; capA.position.x = 0.08
      const capB = capA.clone(); capB.position.x = -0.08
      g.add(glass, capA, capB)
    } else if (kind === 'battery') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.12, 12), new THREE.MeshStandardMaterial({ color: 0x1f3b2e, roughness: 0.4, metalness: 0.3 }))
      body.rotation.z = Math.PI / 2
      const tip = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.02, 8), M.steel())
      tip.rotation.z = Math.PI / 2; tip.position.x = 0.07
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.036, 0.03, 12), M.brass())
      band.rotation.z = Math.PI / 2; band.position.x = 0.03
      g.add(body, tip, band)
    } else if (kind === 'pills') {
      const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.09, 12), new THREE.MeshStandardMaterial({ color: 0x8a4a12, roughness: 0.15, transparent: true, opacity: 0.85 }))
      bottle.position.y = 0.045
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.025, 12), new THREE.MeshStandardMaterial({ color: 0xe8e1d3, roughness: 0.6 }))
      cap.position.y = 0.1
      const label = new THREE.Mesh(new THREE.CylinderGeometry(0.0305, 0.0305, 0.045, 12, 1, true), new THREE.MeshStandardMaterial({ color: 0xe8e1d3, roughness: 0.8 }))
      label.position.y = 0.045
      g.add(bottle, cap, label)
    } else if (kind === 'key') {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.03, 0.008, 8, 18), M.brass())
      const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.012, 0.012), M.brass())
      shaft.position.x = 0.07
      const bit = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.03, 0.012), M.brass())
      bit.position.set(0.105, -0.015, 0)
      const tag = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.07, 0.004), new THREE.MeshStandardMaterial({ color: 0x7a1d18, roughness: 0.7 }))
      tag.position.set(-0.05, -0.04, 0)
      g.add(ring, shaft, bit, tag)
    }
    else if (kind === 'wrench') {
      const handle = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.025, 0.04), M.steel())
      const head = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.015, 6, 12, Math.PI * 1.5), M.steel())
      head.position.x = 0.18; head.rotation.x = Math.PI / 2
      const grip = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.045), new THREE.MeshStandardMaterial({ color: 0xa31d16, roughness: 0.6 }))
      grip.position.x = -0.1
      g.add(handle, head, grip)
    } else if (kind === 'tube') {
      const glassT = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.1, 12), new THREE.MeshStandardMaterial({ color: 0xcfe6ff, transparent: true, opacity: 0.5, roughness: 0.05, emissive: 0x335577, emissiveIntensity: 0.4 }))
      glassT.position.y = 0.07
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.025, 10, 8), glassT.material)
      top.position.y = 0.12
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.03, 12), M.rubber())
      base.position.y = 0.015
      g.add(glassT, top, base)
    } else if (kind === 'coil') {
      const coil = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 8, 24), new THREE.MeshStandardMaterial({ color: 0xb87333, roughness: 0.35, metalness: 0.85 }))
      coil.rotation.x = Math.PI / 2
      const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.3, 6), M.steel())
      rod.rotation.z = Math.PI / 2
      g.add(coil, rod)
    } else if (kind === 'cell') {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.1), new THREE.MeshStandardMaterial({ color: 0x2a2f2c, roughness: 0.5, metalness: 0.3 }))
      body.position.y = 0.06
      for (const sx of [-0.04, 0.04]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.03, 8), sx < 0 ? M.brass() : new THREE.MeshStandardMaterial({ color: 0xa31d16 }))
        post.position.set(sx, 0.13, 0)
        g.add(post)
      }
      g.add(body)
    }
    g.traverse(o => { if (o.isMesh) o.castShadow = true })
    return g
  }

  const item = (id, kind, x, y, z, ry = 0) => {
    const mesh = itemMesh(kind)
    mesh.position.set(x, y, z)
    mesh.rotation.y = ry
    dynamic.add(mesh)
    const glint = new THREE.Sprite(glowSpriteMaterial(kind === 'fuse' ? 0xff9a4a : ['wrench', 'tube', 'coil', 'cell'].includes(kind) ? 0x9fd0ff : 0xfff1d0, 0.55))
    glint.scale.setScalar(0.22)
    glint.position.set(x, y + 0.05, z)
    dynamic.add(glint)
    items.push({ id, kind, x, y, z, mesh, glint })
  }

  const interact = (id, x, y, z, label, extra = {}) => interactables.push({ id, x, y, z, label, ...extra })

  // ═════════ CAB ═════════
  {
    const z0 = 4
    // windshield wall
    box(HALF_W * 2 + 0.1, 1.05, 0.1, M.wallCab(), 0, 0, z0)
    box(HALF_W * 2 + 0.1, 0.35, 0.1, M.wallCab(), 0, 1.85, z0)
    add(new THREE.PlaneGeometry(2.9, 0.8), M.glass(), 0, 1.45, z0 + 0.01, { ry: Math.PI })
    box(0.08, 0.8, 0.12, M.darkSteel(), 0, 1.05, z0)
    add(new THREE.ShapeGeometry(archFill, 14), M.wallCab(), 0, 0, z0)
    add(new THREE.ShapeGeometry(archFill, 14), M.wallCab(), 0, 0, z0, { ry: Math.PI })
    collide(-HALF_W, HALF_W, z0 - 0.1, z0 + 0.3)
    // control desk
    boxC(HALF_W * 2, 0.95, 0.85, M.darkSteel(), 0, 0, 3.5)
    box(HALF_W * 2, 0.06, 0.95, M.wood(), 0, 0.95, 3.48, { rx: 0.15 })
    // gauges
    for (let k = 0; k < 4; k++) {
      cyl(0.075, 0.075, 0.03, M.brass(), -0.6 + k * 0.38, 1.02, 3.62, { rx: Math.PI / 2 - 0.5 })
    }
    // throttle + brake stands (handles are dynamic)
    cyl(0.04, 0.05, 0.25, M.steel(), 0.15, 1.0, 3.35)
    cyl(0.05, 0.06, 0.3, M.darkSteel(), 0.72, 1.0, 3.3)
    // driver seat
    box(0.55, 0.5, 0.55, M.rubber(), 0.4, 0, 2.3)
    box(0.55, 0.65, 0.12, M.rubber(), 0.4, 0.5, 2.02, { rx: 0.15 })
    collide(0.12, 0.68, 2.0, 2.58)
    // second seat
    box(0.5, 0.5, 0.5, M.rubber(), -0.75, 0, 2.4)
    collide(-1.0, -0.5, 2.15, 2.65)
    // radio
    box(0.42, 0.24, 0.3, M.darkSteel(), -0.9, 0.98, 3.45)
    // cabinet at back
    boxC(0.6, 1.9, 0.5, M.wallCab(), -1.1, 0, -3.65)
    interact('radio', -0.9, 1.15, 3.4, 'Use the radio')
    interact('pressure', -0.2, 1.12, 3.55, 'Reset the brake pressure')
    interact('brake', 0.72, 1.25, 3.3, 'Pull the emergency brake', { final: true })
    interact('driverSeat', 0.4, 0.9, 2.35, 'Sit down and let the train arrive', { final: true })
    note('n1', -0.25, 1.0, 3.25, 0.3)
    item('battery-cab', 'battery', 0.5, 1.0, 3.2, 0.6)
  }

  // ═════════ ENGINE ROOM ═════════
  {
    // the engine block
    const ez0 = -7.5, ez1 = -16.5
    boxC(1.6, 1.75, ez0 - ez1, M.engine(), -0.62, 0, (ez0 + ez1) / 2)
    for (let k = 0; k < 6; k++) {
      const z = ez0 - 0.8 - k * 1.45
      cyl(0.16, 0.18, 0.35, M.darkSteel(), -0.62, 1.92, z)
      cyl(0.04, 0.04, 0.6, M.steel(), -0.25, 1.4, z, { rz: Math.PI / 2 })
    }
    cyl(0.12, 0.12, ez0 - ez1, M.steel(), 0.25, 1.55, (ez0 + ez1) / 2, { rx: Math.PI / 2 })
    cyl(0.14, 0.14, 1.0, M.darkSteel(), -1.0, 1.75, -12, {})
    cyl(0.18, 0.18, 0.5, M.darkSteel(), -1.0, 2.3, -12)
    // walkway railing
    for (let z = ez0; z >= ez1; z -= 1.5) cyl(0.025, 0.025, 1.0, M.brass(), 0.3, 0.5, z)
    cyl(0.025, 0.025, ez0 - ez1, M.brass(), 0.3, 1.0, (ez0 + ez1) / 2, { rx: Math.PI / 2 })
    // pipes along the ceiling
    for (const px of [-1.2, 1.25]) cyl(0.05, 0.05, 14, M.darkSteel(), px, 2.1, -12, { rx: Math.PI / 2 })
    // breaker box
    box(0.12, 0.7, 0.55, M.darkSteel(), 1.38, 1.05, -6.2)
    interact('breaker', 1.32, 1.4, -6.2, 'Check the breaker box')
    note('n2', 1.32, 1.25, -6.62, -Math.PI / 2, false)
    // toolbox with fuse 1
    boxC(0.5, 0.28, 0.32, new THREE.MeshStandardMaterial({ color: 0x7a1d18, roughness: 0.5, metalness: 0.5 }), 1.1, 0, -17.6)
    item('fuse1', 'fuse', 1.05, 0.33, -17.6, 0.4)
    // shelf with battery
    box(0.3, 0.04, 1.2, M.darkSteel(), 1.3, 1.15, -11)
    item('battery-engine', 'battery', 1.28, 1.2, -11.2, 1.2)
    locker(-1.1, -18.55, '+z', 'locker-engine')
  }

  // ═════════ PASSENGER CAR ═════════
  {
    const car = CARS[2]
    let row = 0
    for (let z = car.zf - 1.4; z > car.zr + 2.2; z -= 1.5) {
      row++
      for (const sx of [-1, 1]) {
        const x = sx * 0.95
        seat(x, z, 1)
        collide(x - 0.45, x + 0.45, z - 0.33, z + 0.27)
      }
    }
    // luggage racks
    for (const sx of [-1, 1]) {
      for (const k of [0, 1, 2]) cyl(0.018, 0.018, car.zf - car.zr - 1, M.brass(), sx * (1.05 + k * 0.12), 1.92, (car.zf + car.zr) / 2, { rx: Math.PI / 2 })
      box(0.4, 0.02, car.zf - car.zr - 1, M.wood(), sx * 1.17, 1.88, (car.zf + car.zr) / 2)
    }
    // closet in the rear-left corner (hiding spot)
    const cz0 = car.zr + 1.55, cz1 = car.zr
    box(0.06, CEIL, cz0 - 0.62 - cz1, M.wood(), -0.5, 0, (cz0 - 0.62 + cz1) / 2)
    box(0.06, CEIL - 2.0, 0.6, M.wood(), -0.5, 2.0, cz0 - 0.36)
    box(0.95, CEIL, 0.06, M.wood(), -0.975, 0, cz0)
    collide(-0.56, -0.44, cz1, cz0 - 0.6)
    collide(-HALF_W, -0.44, cz0 - 0.06, cz0 + 0.06)
    const door = new THREE.Group()
    const dp = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.0, 0.6), M.wood())
    dp.position.y = 1.0
    door.add(dp)
    door.position.set(-0.5, 0, cz0 - 0.3 - 0.06)
    dynamic.add(door)
    hideSpots.push({ id: 'closet-coach', type: 'closet', inside: { x: -1.0, z: (cz0 + cz1) / 2 }, exit: { x: -0.05, z: (cz0 + cz1) / 2 + 0.2 }, yaw: -Math.PI / 2, door, label: 'Hide in the closet' })
    collide(-0.56, -0.44, cz0 - 0.62, cz0 - 0.06, { hideDoor: 'closet-coach' })
    item('fuse2', 'fuse', -1.12, 1.92, car.zf - 1.4 - 1.5 * 5, 0.2)
    item('pills-coach', 'pills', -0.85, 0.53, car.zf - 1.4 - 1.5 * 2)
    item('battery-coach', 'battery', 0.9, 0.53, car.zf - 1.4 - 1.5 * 9, 2)
    note('n3', 0.95, 0.53, car.zf - 1.4 - 1.5 * 8, 2.6)
    note('n4', -0.95, 0.53, car.zf - 1.4 - 1.5 * 11, -0.4)
  }

  // ═════════ CARGO CAR ═════════
  {
    const car = CARS[3]
    const crate = (x, z, w, d, h, y = 0, coverable = true) => {
      box(w, h, d, M.crate(), x, y, z, { ry: 0 })
      if (y === 0) {
        const c = collide(x - w / 2, x + w / 2, z - d / 2, z + d / 2)
        if (coverable && h >= 0.8) covers.push(c)
      }
    }
    // zig-zag of stacks, leaving a winding path through the middle
    crate(-0.9, -43.2, 1.1, 1.1, 1.1)
    crate(-0.9, -43.2, 0.8, 0.8, 0.7, 1.1)
    crate(1.0, -45.6, 0.9, 1.2, 0.9)
    crate(1.0, -45.4, 0.7, 0.7, 0.6, 0.9)
    crate(-1.0, -52.6, 0.9, 1.6, 1.4)
    crate(0.95, -51.0, 1.0, 1.0, 1.0)
    crate(0.4, -54.2, 0.7, 0.7, 0.7)
    crate(-0.85, -55.6, 1.1, 1.0, 1.2)
    crate(1.05, -49.0, 0.8, 0.8, 0.5)
    // the strange crate: chained shut
    box(1.0, 1.0, 1.4, new THREE.MeshStandardMaterial({ color: 0x3a2a1a, roughness: 0.9 }), -0.95, 0, -46.6)
    covers.push(collide(-1.45, -0.45, -47.3, -45.9))
    for (const dz of [-0.4, 0.4]) cyl(0.03, 0.03, 1.05, M.steel(), -0.95, 0.75, -46.6 + dz, { rz: Math.PI / 2 })
    // open side door on the left (wind, the night rushing past) behind a safety bar
    const dz0 = -48.2, dz1 = -50.6
    for (const y of [0.55, 1.05]) cyl(0.03, 0.03, dz0 - dz1, M.brass(), -1.38, y, (dz0 + dz1) / 2, { rx: Math.PI / 2 })
    // conductor's cage with the key hook
    box(0.04, 1.7, 1.4, M.steel(), 0.55, 0, -56.6)
    collide(0.5, 0.6, -57.3, -55.9)
    box(0.5, 0.04, 0.3, M.wood(), 1.2, 0.95, -56.4)
    item('key', 'key', 1.3, 1.45, -56.2, Math.PI / 2)
    item('battery-cargo', 'battery', -0.9, 1.12, -43.1)
    item('pills-cargo', 'pills', 1.0, 0.92, -51.0)
    note('n5', 1.0, 0.92, -45.6, 1.2)
    locker(-1.18, -58.3, '+z', 'locker-cargo')
  }

  // ═════════ CAR 7 (longer inside than outside) ═════════
  {
    const car = CARS[4]
    const cz0 = car.zf - 1.6, cz1 = car.zr + 1.6
    const compLen = 3
    const partitionX = 0.45
    const count = Math.floor((cz0 - cz1) / compLen)
    const enterable = new Map([[2, 'hide'], [5, 'hide'], [9, 'office'], [13, 'hide'], [16, 'hide']])
    for (let k = 0; k < count; k++) {
      const zA = cz0 - k * compLen
      const zB = zA - compLen
      const zm = (zA + zB) / 2
      // dividing wall between compartments
      box(partitionX + HALF_W, CEIL, 0.06, M.wood(), (-HALF_W + partitionX) / 2, 0, zB)
      collide(-HALF_W, partitionX, zB - 0.05, zB + 0.05)
      // corridor wall with a door per compartment
      const doorZ0 = zm + 0.4, doorZ1 = zm - 0.4
      box(0.06, CEIL, zA - doorZ0, M.wood(), partitionX, 0, (zA + doorZ0) / 2)
      box(0.06, CEIL, doorZ1 - zB, M.wood(), partitionX, 0, (doorZ1 + zB) / 2)
      box(0.06, CEIL - 2.0, 0.8, M.wood(), partitionX, 2.0, zm)
      collide(partitionX - 0.05, partitionX + 0.05, doorZ0, zA)
      collide(partitionX - 0.05, partitionX + 0.05, zB, doorZ1)
      // compartment door (closed unless enterable)
      const kind = enterable.get(k)
      const door = new THREE.Group()
      const dp = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.0, 0.8), M.wood())
      dp.position.y = 1.0
      const num = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.08), new THREE.MeshBasicMaterial({ color: 0xb08d57 }))
      num.position.set(0.025, 1.7, 0); num.rotation.y = Math.PI / 2
      door.add(dp, num)
      door.position.set(partitionX, 0, zm)
      dynamic.add(door)
      if (!kind) collide(partitionX - 0.05, partitionX + 0.05, doorZ1, doorZ0)
      // bunks
      box(0.75, 0.45, compLen - 0.4, M.fabric(), -1.05, 0, zm)
      collide(-HALF_W, -0.66, zB + 0.2, zA - 0.2)
      box(0.75, 0.06, compLen - 0.4, M.wood(), -1.05, 1.35, zm)
      // little window table lamp glow handled by lamps; compartment interiors get a small table
      box(0.3, 0.04, 0.4, M.wood(), -0.5, 0.7, zA - 0.35)
      if (kind === 'office') door.position.z = zm + 0.78 // slid open: walk in
      if (kind === 'hide') {
        hideSpots.push({ id: `comp-${k}`, type: 'compartment', inside: { x: -0.2, z: zm }, exit: { x: 1.0, z: zm }, yaw: -Math.PI / 2, door, label: 'Hide in the compartment', compartment: { zA, zB } })
        collide(partitionX - 0.05, partitionX + 0.05, doorZ1, doorZ0, { hideDoor: `comp-${k}` })
      }
      if (kind === 'office') {
        item('fuse3', 'fuse', -0.5, 0.77, zA - 0.35, 0.8)
        note('n7', -0.95, 0.47, zm + 0.5, 1.2)
      }
      if (k === 7) item('pills-car7', 'pills', 1.25, 0.0, zm)
      if (k === 12) item('battery-car7', 'battery', 1.2, 0.0, zm - 0.5, 0.4)
    }
    // corridor handrail under the windows
    cyl(0.02, 0.02, cz0 - cz1, M.brass(), HALF_W - 0.06, 1.0, (cz0 + cz1) / 2, { rx: Math.PI / 2 })
    note('n6', 1.05, 0.005, car.zf - 2.2, 0.6)
    // the compartments make the left side a solid wall to the corridor, so mark the corridor as the lane
  }

  // ═════════ GENERATOR CAR ═════════
  {
    const car = CARS[5]
    // generator housing + flywheel
    boxC(1.4, 1.5, 4.5, M.engine(), -0.65, 0, -128.5)
    fly = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.18, 32), M.darkSteel())
    fly.rotation.z = Math.PI / 2
    fly.position.set(-0.65, 1.2, -125.6)
    fly.castShadow = true
    dynamic.add(fly)
    collide(-1.4, 0.1, -126.3, -125.4)
    cyl(0.1, 0.1, 6, M.steel(), -0.65, 1.95, -128.5, { rx: Math.PI / 2 })
    for (let k = 0; k < 4; k++) cyl(0.035, 0.035, 2.2, M.darkSteel(), -1.3 + k * 0.08, 1.1, -131.5)
    // fuse panel + main lever on the right wall
    box(0.1, 0.9, 1.1, M.darkSteel(), 1.4, 0.9, -127)
    interact('fusePanel', 1.33, 1.35, -127, 'Install fuses')
    box(0.12, 0.5, 0.35, M.darkSteel(), 1.38, 0.95, -128.6)
    interact('mainLever', 1.3, 1.25, -128.6, 'Pull the main power lever')
    note('n8', 1.37, 1.55, -129.4, -Math.PI / 2, false)
    item('battery-gen', 'battery', -1.15, 1.52, -124, 0.4)
    locker(1.15, -134.45, '+z', 'locker-gen')
    // valve wrench hooks... and a door that should open onto empty track
    note('n9', -1.36, 1.5, car.zr + 0.9, Math.PI / 2, false)
  }

  // ═════════ shared builders for the new cars ═════════
  const compartments = (car, { cz0, cz1, compLen, enterable = new Map(), onEach }) => {
    const partitionX = 0.45
    const count = Math.floor((cz0 - cz1) / compLen)
    for (let k = 0; k < count; k++) {
      const zA = cz0 - k * compLen
      const zB = zA - compLen
      const zm = (zA + zB) / 2
      box(partitionX + HALF_W, CEIL, 0.06, M.wood(), (-HALF_W + partitionX) / 2, 0, zB)
      collide(-HALF_W, partitionX, zB - 0.05, zB + 0.05)
      const doorZ0 = zm + 0.4, doorZ1 = zm - 0.4
      box(0.06, CEIL, zA - doorZ0, M.wood(), partitionX, 0, (zA + doorZ0) / 2)
      box(0.06, CEIL, doorZ1 - zB, M.wood(), partitionX, 0, (doorZ1 + zB) / 2)
      box(0.06, CEIL - 2.0, 0.8, M.wood(), partitionX, 2.0, zm)
      collide(partitionX - 0.05, partitionX + 0.05, doorZ0, zA)
      collide(partitionX - 0.05, partitionX + 0.05, zB, doorZ1)
      const kind = enterable.get(k)
      const door = new THREE.Group()
      const dp = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.0, 0.8), M.wood())
      dp.position.y = 1.0
      door.add(dp)
      door.position.set(partitionX, 0, zm)
      dynamic.add(door)
      if (!kind) collide(partitionX - 0.05, partitionX + 0.05, doorZ1, doorZ0)
      if (kind === 'open') door.position.z = zm + 0.78
      if (kind === 'hide') {
        hideSpots.push({ id: `${car.id}-comp-${k}`, type: 'compartment', inside: { x: -0.2, z: zm }, exit: { x: 1.0, z: zm }, yaw: -Math.PI / 2, door, label: 'Hide in the compartment', compartment: { zA, zB } })
        collide(partitionX - 0.05, partitionX + 0.05, doorZ1, doorZ0, { hideDoor: `${car.id}-comp-${k}` })
      }
      onEach?.(k, zA, zB, zm, kind)
    }
    cyl(0.02, 0.02, cz0 - cz1, M.brass(), HALF_W - 0.06, 1.0, (cz0 + cz1) / 2, { rx: Math.PI / 2 })
  }
  const valve = (id, x, y, z, facing) => {
    // a red hand-wheel on a pipe stub: close it with the wrench
    const g = new THREE.Group()
    const wheel = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.02, 8, 20), new THREE.MeshStandardMaterial({ color: 0xa31d16, roughness: 0.4, metalness: 0.4 }))
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.08, 10), M.steel())
    hub.rotation.x = Math.PI / 2
    for (let k = 0; k < 3; k++) {
      const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.015, 0.015), M.steel())
      spoke.rotation.z = k * Math.PI / 3
      g.add(spoke)
    }
    g.add(wheel, hub)
    g.position.set(x, y, z)
    g.rotation.y = facing
    dynamic.add(g)
    cyl(0.045, 0.045, 0.3, M.darkSteel(), x - Math.sin(facing) * 0.15, y, z - Math.cos(facing) * 0.15, { rx: Math.PI / 2, ry: facing })
    cyl(0.04, 0.04, 2.2, M.darkSteel(), x - Math.sin(facing) * 0.28, 1.1, z - Math.cos(facing) * 0.28)
    interact(id, x, y, z, 'Close the valve', { valve: true, wheel: g })
  }

  // ═════════ DINING CAR ═════════
  {
    const car = CARS.find(c => c.id === 'dining')
    const tableMat = new THREE.MeshStandardMaterial({ color: 0xe9e1cf, roughness: 0.9 })
    for (let k = 0; k < 4; k++) {
      const z = car.zf - 2.6 - k * 3
      for (const sx of [-1, 1]) {
        const x = sx * 0.95
        box(0.95, 0.05, 0.8, tableMat, x, 0.74, z)
        cyl(0.04, 0.06, 0.74, M.brass(), x, 0.37, z)
        for (const dz of [-0.75, 0.75]) {
          box(0.9, 0.44, 0.45, M.fabric(), x, 0, z + dz)
          box(0.9, 0.7, 0.1, M.fabric(), x, 0.44, z + dz + Math.sign(dz) * 0.2)
        }
        collide(x - 0.47, x + 0.47, z - 1.0, z + 1.0)
        // table lamp
        cyl(0.05, 0.08, 0.2, M.brass(), x + sx * 0.25, 0.86, z)
      }
    }
    // kitchen at the rear: counter on the left, pantry on the right
    const kz0 = car.zr + 5, kz1 = car.zr
    boxC(0.65, 0.92, kz0 - kz1 - 0.6, M.steel(), -1.1, 0, (kz0 + kz1) / 2 - 0.3)
    box(0.7, 0.05, kz0 - kz1 - 0.6, M.darkSteel(), -1.1, 0.92, (kz0 + kz1) / 2 - 0.3)
    for (let k = 0; k < 3; k++) cyl(0.11, 0.11, 0.03, M.rubber(), -1.1, 0.96, kz0 - 1 - k * 0.8)
    box(0.65, 0.8, 0.6, M.steel(), -1.1, 1.4, kz1 + 1.1) // overhead cabinet
    // icebox (holds a radio cell)
    boxC(0.6, 1.5, 0.6, new THREE.MeshStandardMaterial({ color: 0xd8d2c0, roughness: 0.5, metalness: 0.2 }), 1.12, 0, kz1 + 2.6)
    item('cell', 'cell', 0.75, 1.0, kz1 + 3.4, 0.3)
    box(0.35, 0.03, 0.5, M.wood(), 1.25, 0.95, kz1 + 3.4)
    locker(1.15, kz1 + 0.45, '+z', 'pantry-dining', 'Hide in the pantry')
    item('pills-dining', 'pills', -0.95, 0.79, car.zf - 2.6 - 3)
    item('battery-dining', 'battery', 0.95, 0.79, car.zf - 2.6 - 6, 1.1)
    note('n10', -0.95, 0.79, car.zf - 2.6 - 9, 0.5)
  }

  // ═════════ SLEEPING CAR ═════════
  {
    const car = CARS.find(c => c.id === 'sleeper')
    compartments(car, {
      cz0: car.zf - 1.0, cz1: car.zr + 1.0, compLen: 3.3,
      enterable: new Map([[1, 'hide'], [3, 'open'], [5, 'hide']]),
      onEach: (k, zA, zB, zm, kind) => {
        // berth + folded blanket + washbasin
        box(0.75, 0.5, 2.7, M.fabric(), -1.05, 0, zm)
        collide(-HALF_W, -0.66, zB + 0.2, zA - 0.2)
        box(0.7, 0.08, 0.5, new THREE.MeshStandardMaterial({ color: 0xe9e1cf, roughness: 0.95 }), -1.05, 0.5, zA - 0.5)
        box(0.3, 0.04, 0.4, M.wood(), -0.5, 0.75, zA - 0.35)
        if (kind === 'open') {
          item('tube', 'tube', -0.5, 0.79, zA - 0.35, 0.4)
          note('n11', -1.0, 0.56, zm, 0.2)
        }
        if (k === 4) item('battery-sleeper', 'battery', -0.5, 0.79, zA - 0.35)
      },
    })
    valve('valve-sleeper', 1.37, 1.0, car.zr + 2.2, -Math.PI / 2)
    note('n12', 1.05, 0.005, car.zf - 1.4, 0.3)
  }

  // ═════════ MAIL CAR ═════════
  {
    const car = CARS.find(c => c.id === 'mail')
    // pigeonhole wall on the left
    box(0.4, 2.1, car.zf - car.zr - 2, M.wood(), -1.22, 0, (car.zf + car.zr) / 2)
    collide(-HALF_W, -1.0, car.zr + 1, car.zf - 1)
    const holeMat = new THREE.MeshStandardMaterial({ color: 0x1a120c, roughness: 1 })
    for (let row = 0; row < 7; row++) for (let col = 0; col < 24; col++) {
      if ((row * 7 + col * 3) % 5 === 0) continue
      add(new THREE.PlaneGeometry(0.5, 0.22), holeMat, -1.015, 0.25 + row * 0.27, car.zf - 1.5 - col * 0.55, { ry: Math.PI / 2 })
    }
    // sorting table down the middle-left, mail sacks
    boxC(0.7, 0.85, 9, M.wood(), -0.4, 0, (car.zf + car.zr) / 2 + 0.5)
    const sack = new THREE.MeshStandardMaterial({ color: 0x8a7a5a, roughness: 1 })
    for (let k = 0; k < 6; k++) add(new THREE.SphereGeometry(0.32, 10, 8), sack, 1.0 + (k % 2) * 0.15, 0.28, car.zf - 2 - k * 2.3, { sy: 0.8 })
    for (let k = 0; k < 6; k++) collide(0.7, 1.4, car.zf - 2.3 - k * 2.3, car.zf - 1.7 - k * 2.3)
    item('wrench', 'wrench', -0.35, 0.9, car.zf - 5.2, 0.6)
    note('n13', -0.45, 0.86, car.zf - 8.0, 2.2)
    item('pills-mail', 'pills', -0.5, 0.86, car.zf - 11)
    locker(1.15, car.zr + 0.45, '+z', 'locker-mail')
  }

  // ═════════ OBSERVATION CAR (the last car) ═════════
  {
    const car = CARS.find(c => c.id === 'obs')
    const chair = (x, z, ry) => {
      box(0.6, 0.42, 0.6, M.fabric(), x, 0, z, { ry })
      box(0.6, 0.6, 0.12, M.fabric(), x - Math.sin(ry) * 0.27, 0.42, z - Math.cos(ry) * 0.27, { ry })
      collide(x - 0.33, x + 0.33, z - 0.33, z + 0.33)
    }
    chair(-0.95, car.zf - 2.5, Math.PI / 2); chair(-0.95, car.zf - 5.2, Math.PI / 2)
    chair(0.95, car.zf - 3.8, -Math.PI / 2); chair(0.95, car.zf - 6.6, -Math.PI / 2)
    boxC(0.5, 0.5, 0.5, M.wood(), -0.95, 0, car.zf - 3.85)
    // big rear window + the coupling release
    add(new THREE.PlaneGeometry(2.6, 1.2), M.glass(), 0, 1.4, car.zr + 0.02)
    box(0.3, 1.0, 0.3, M.darkSteel(), 0.9, 0, car.zr + 0.5)
    interact('coupling', 0.9, 1.15, car.zr + 0.5, 'Pull the coupling release')
    item('coil', 'coil', -0.95, 0.53, car.zf - 3.85, 0.3)
    note('n14', 0.6, 0.005, car.zr + 1.5, 1.1)
    locker(-1.15, car.zr + 0.45, '+z', 'locker-obs')
  }

  // ═════════ valves for the brake line (chapter 2) ═════════
  valve('valve-engine', 1.37, 1.0, -14.5, -Math.PI / 2)
  valve('valve-coach', 1.37, 1.0, -39.0, -Math.PI / 2)
  valve('valve-cargo', 1.37, 1.0, -53.6, -Math.PI / 2)
  note('n15', -0.9, 0.53, -26.4, 1.4)
  note('n16', 1.2, 0.005, -103.0, 0.4)

  // dynamic handles in the cab
  const brakeHandle = new THREE.Group()
  const bh = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.45, 10), M.steel())
  bh.position.y = 0.22
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.06, 14, 10), new THREE.MeshStandardMaterial({ color: 0xa31d16, roughness: 0.35 }))
  knob.position.y = 0.46
  brakeHandle.add(bh, knob)
  brakeHandle.position.set(0.72, 1.15, 3.3)
  brakeHandle.rotation.x = -0.5
  dynamic.add(brakeHandle)

  const fuseSlots = []
  for (let k = 0; k < 3; k++) {
    const slot = itemMesh('fuse')
    slot.position.set(1.33, 1.1 + k * 0.25, -127)
    slot.rotation.y = Math.PI / 2
    slot.visible = false
    dynamic.add(slot)
    fuseSlots.push(slot)
  }
  const mainLever = new THREE.Group()
  const ml = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.4, 0.05), M.steel())
  ml.position.y = 0.2
  const mk = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.07, 0.07), new THREE.MeshStandardMaterial({ color: 0xa31d16, roughness: 0.4 }))
  mk.position.y = 0.4
  mainLever.add(ml, mk)
  mainLever.position.set(1.3, 1.0, -128.6)
  mainLever.rotation.z = 0.6
  dynamic.add(mainLever)

  // ───────── merge static geometry ─────────
  const staticGroup = new THREE.Group()
  staticGroup.name = 'static'
  for (const [mat, geoms] of statics) {
    const nonIndexed = geoms.map(g => (g.index ? g.toNonIndexed() : g))
    for (const g of nonIndexed) { if (!g.attributes.uv) g.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2)); if (!g.attributes.normal) g.computeVertexNormals() }
    // keep only position/normal/uv so all geometries match
    for (const g of nonIndexed) for (const name of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(name)) g.deleteAttribute(name)
    const merged = mergeGeometries(nonIndexed)
    const mesh = new THREE.Mesh(merged, mat)
    mesh.receiveShadow = high
    mesh.castShadow = high && mat !== M.ceiling() && mat !== M.floor() && mat !== M.carpet()
    staticGroup.add(mesh)
  }
  scene.add(staticGroup)

  // ───────── outside: the night landscape ─────────
  const outside = buildOutside(scene, high)

  // spawn + checkpoints
  const spawns = {
    start: [{ x: 0.4, z: 2.3, yaw: Math.PI, seated: true }, { x: -0.75, z: 2.4, yaw: Math.PI, seated: true }, { x: 0.0, z: 0.6, yaw: Math.PI }, { x: -0.6, z: -0.6, yaw: Math.PI }],
    powerOut: [{ x: 0.85, z: -8.5, yaw: 0 }, { x: 0.85, z: -7.4, yaw: 0 }, { x: 0.0, z: -5.6, yaw: 0 }, { x: 1.0, z: -6.8, yaw: 0 }],
    fusesIn: [{ x: 0.3, z: -126.5, yaw: Math.PI }, { x: 0.6, z: -125.5, yaw: Math.PI }, { x: 0.2, z: -124.2, yaw: Math.PI }, { x: 0.7, z: -123.4, yaw: Math.PI }],
    chase1: [{ x: 0.3, z: -126.5, yaw: Math.PI }, { x: 0.6, z: -125.5, yaw: Math.PI }, { x: 0.2, z: -124.2, yaw: Math.PI }, { x: 0.7, z: -123.4, yaw: Math.PI }],
    brakeLine: [{ x: 1.0, z: -158.5, yaw: 0 }, { x: 1.0, z: -157.6, yaw: 0 }, { x: 1.0, z: -160, yaw: 0 }, { x: 1.0, z: -161, yaw: 0 }],
    radio: [{ x: 0.0, z: 1.2, yaw: 0 }, { x: -0.6, z: 0.4, yaw: 0 }, { x: 0.5, z: 0.2, yaw: 0 }, { x: 0, z: -0.8, yaw: 0 }],
    chase2: [{ x: 0, z: -204.2, yaw: Math.PI }, { x: 0.5, z: -203.5, yaw: Math.PI }, { x: -0.4, z: -203.2, yaw: Math.PI }, { x: 0, z: -202.5, yaw: Math.PI }],
    finalPhase: [{ x: 0.3, z: -125.8, yaw: Math.PI }, { x: 0.6, z: -125, yaw: Math.PI }, { x: 0.2, z: -124, yaw: Math.PI }, { x: 0.7, z: -123.2, yaw: Math.PI }],
  }

  return {
    colliders, covers, doors, hideSpots, interactables, items, lampGroups, outside, spawns,
    brakeHandle, fuseSlots, mainLever, flywheel: fly, cargoDoor: { z0: -48.2, z1: -50.6 },
  }
}

// ───────── glow sprites ─────────
const glowCache = new Map()
export function glowSpriteMaterial (color, opacity = 0.5) {
  const key = `${color}-${opacity}`
  if (glowCache.has(key)) return glowCache.get(key)
  const c = document.createElement('canvas')
  c.width = c.height = 64
  const g = c.getContext('2d')
  const r = g.createRadialGradient(32, 32, 0, 32, 32, 32)
  r.addColorStop(0, 'rgba(255,255,255,1)')
  r.addColorStop(0.25, 'rgba(255,255,255,0.45)')
  r.addColorStop(1, 'rgba(255,255,255,0)')
  g.fillStyle = r
  g.fillRect(0, 0, 64, 64)
  const tex = new THREE.CanvasTexture(c)
  const m = new THREE.SpriteMaterial({ map: tex, color, transparent: true, opacity, depthWrite: false, blending: THREE.AdditiveBlending })
  glowCache.set(key, m)
  return m
}

// ───────── the landscape outside ─────────
function buildOutside (scene, high) {
  const group = new THREE.Group()
  group.name = 'outside'
  scene.add(group)
  const LOOP = 420 // metres of scenery that loops past
  const silhouette = new THREE.MeshBasicMaterial({ color: 0x0b1018, fog: true })
  const groundMat = new THREE.MeshBasicMaterial({ color: 0x10151a })
  // ground strips (embankment) either side + gravel bed
  const gc = document.createElement('canvas')
  gc.width = 64; gc.height = 256
  const gg = gc.getContext('2d')
  gg.fillStyle = '#121619'; gg.fillRect(0, 0, 64, 256)
  for (let i = 0; i < 900; i++) { gg.fillStyle = `rgba(${90 + Math.random() * 60},${90 + Math.random() * 60},${100 + Math.random() * 60},${Math.random() * 0.25})`; gg.fillRect(Math.random() * 64, Math.random() * 256, 1 + Math.random() * 2, 1 + Math.random() * 2) }
  const gtex = new THREE.CanvasTexture(gc)
  gtex.wrapS = gtex.wrapT = THREE.RepeatWrapping
  gtex.repeat.set(30, 60)
  gtex.colorSpace = THREE.SRGBColorSpace
  const groundTexMat = new THREE.MeshBasicMaterial({ map: gtex, color: 0x9aa4b0 })
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 800, 8, 27), groundTexMat)
  ground.rotation.x = -Math.PI / 2
  ground.position.set(0, -1.25, -60)
  group.add(ground)

  // neighbouring track (rails static, sleepers scroll)
  const railMat = new THREE.MeshBasicMaterial({ color: 0x3a4148 })
  for (const rx of [-4.6, -3.4]) {
    for (let z = -330; z < 210; z += 30) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.12, 30.05), railMat)
      rail.position.set(rx, -1.12, z + 15)
      group.add(rail)
    }
  }
  const sleeperCount = Math.floor(LOOP / 0.7)
  const sleepers = new THREE.InstancedMesh(new THREE.BoxGeometry(2.4, 0.1, 0.22), new THREE.MeshBasicMaterial({ color: 0x1d1813 }), sleeperCount)
  group.add(sleepers)

  // trees
  const treeCount = high ? 340 : 160
  const coneGeo = new THREE.ConeGeometry(1, 1, 7)
  const trees = new THREE.InstancedMesh(coneGeo, silhouette, treeCount)
  const treeData = []
  for (let i = 0; i < treeCount; i++) {
    const side = Math.random() < 0.5 ? -1 : 1
    const x = side * (9 + Math.pow(Math.random(), 0.6) * 70)
    const h = 7 + Math.random() * 12
    treeData.push({ x, z: Math.random() * LOOP, h, w: h * (0.22 + Math.random() * 0.1) })
  }
  group.add(trees)

  // telegraph poles + wires
  const poleCount = Math.ceil(LOOP / 32)
  const poles = new THREE.InstancedMesh(new THREE.BoxGeometry(0.22, 7, 0.22), silhouette, poleCount)
  const arms = new THREE.InstancedMesh(new THREE.BoxGeometry(1.6, 0.14, 0.14), silhouette, poleCount)
  group.add(poles, arms)
  // wires and rails are built from short pieces: very long thin boxes depth-test badly on some GPUs
  const longPieces = (w, h, positions) => {
    const parts = []
    for (const [x, y] of positions) for (let z = -330; z < 210; z += 30) parts.push(new THREE.BoxGeometry(w, h, 30.05).translate(x, y, z + 15))
    return mergeGeometries(parts)
  }
  group.add(new THREE.Mesh(longPieces(0.02, 0.02, [[5.0, 4.7], [6.0, 4.7], [5.0, 5.2], [6.0, 5.2]]), new THREE.MeshBasicMaterial({ color: 0x0a0d12 })))

  // distant hills (static)
  const hillGeo = new THREE.ConeGeometry(1, 1, 5)
  const hills = new THREE.InstancedMesh(hillGeo, new THREE.MeshBasicMaterial({ color: 0x0d131c, fog: false }), 40)
  const dummy = new THREE.Object3D()
  for (let i = 0; i < 40; i++) {
    const side = i % 2 ? 1 : -1
    dummy.position.set(side * (160 + Math.random() * 80), -2, -340 + i * 18 + Math.random() * 10)
    dummy.scale.set(40 + Math.random() * 60, 25 + Math.random() * 40, 40 + Math.random() * 40)
    dummy.rotation.y = Math.random() * 3
    dummy.updateMatrix()
    hills.setMatrixAt(i, dummy.matrix)
  }
  group.add(hills)

  // moon
  const moonC = document.createElement('canvas')
  moonC.width = moonC.height = 128
  const mg = moonC.getContext('2d')
  const mr = mg.createRadialGradient(64, 64, 10, 64, 64, 64)
  mr.addColorStop(0, 'rgba(230,236,240,1)'); mr.addColorStop(0.32, 'rgba(210,220,230,0.95)'); mr.addColorStop(0.36, 'rgba(160,180,200,0.25)'); mr.addColorStop(1, 'rgba(120,140,170,0)')
  mg.fillStyle = mr; mg.fillRect(0, 0, 128, 128)
  const moon = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(moonC), fog: false, depthWrite: false, transparent: true }))
  moon.position.set(-140, 90, 220)
  moon.scale.setScalar(60)
  group.add(moon)

  let offset = 0
  const flashMats = [silhouette, groundTexMat, railMat]
  const baseColors = flashMats.map(m => m.color.clone())
  const update = (dt, speed) => {
    offset = (offset + speed * dt) % LOOP
    gtex.offset.y = (gtex.offset.y - speed * dt / (800 / 60)) % 1
    const wrap = z => {
      let v = (z - offset) % LOOP
      if (v < 0) v += LOOP
      return 120 - v // range [120-LOOP, 120]
    }
    for (let i = 0; i < sleeperCount; i++) {
      dummy.position.set(-4.0, -1.2, wrap(i * 0.7))
      dummy.scale.set(1, 1, 1); dummy.rotation.set(0, 0, 0)
      dummy.updateMatrix()
      sleepers.setMatrixAt(i, dummy.matrix)
    }
    sleepers.instanceMatrix.needsUpdate = true
    for (let i = 0; i < treeCount; i++) {
      const t = treeData[i]
      dummy.position.set(t.x, -1.25 + t.h / 2, wrap(t.z))
      dummy.scale.set(t.w, t.h, t.w)
      dummy.rotation.set(0, i, 0)
      dummy.updateMatrix()
      trees.setMatrixAt(i, dummy.matrix)
    }
    trees.instanceMatrix.needsUpdate = true
    for (let i = 0; i < poleCount; i++) {
      const z = wrap(i * 32)
      dummy.position.set(5.5, 2.2, z); dummy.scale.set(1, 1, 1); dummy.rotation.set(0, 0, 0)
      dummy.updateMatrix(); poles.setMatrixAt(i, dummy.matrix)
      dummy.position.set(5.5, 5.0, z)
      dummy.updateMatrix(); arms.setMatrixAt(i, dummy.matrix)
    }
    poles.instanceMatrix.needsUpdate = true
    arms.instanceMatrix.needsUpdate = true
  }
  const flash = level => {
    flashMats.forEach((m, i) => m.color.copy(baseColors[i]).lerp(new THREE.Color(0x9fb2c8), level))
  }
  update(0, 0)
  return { group, update, flash }
}
