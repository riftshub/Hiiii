// DOM side: screens, HUD, prompts, notes, toasts.
import { NOTES } from './story.js'

const $ = sel => document.querySelector(sel)
const screens = ['title', 'join', 'lobby', 'howto', 'settings', 'pause', 'down', 'ending']
let current = null
const stack = []

export const ui = {
  touch: false,
  get screen () { return current },
}

export function showScreen (name, { push = false } = {}) {
  if (push && current) stack.push(current)
  for (const s of screens) $(`#screen-${s}`)?.classList.toggle('is-open', s === name)
  current = name
  const first = name && $(`#screen-${name}`)?.querySelector('input, button')
  if (first && !ui.touch) setTimeout(() => first.focus({ preventScroll: true }), 30)
}

export function backScreen () {
  const prev = stack.pop()
  showScreen(prev ?? 'title')
  return prev ?? 'title'
}

export function clearStack () { stack.length = 0 }

export function setHud (on) {
  $('#hud').classList.toggle('is-on', on)
  $('#touch').classList.toggle('is-on', on && ui.touch)
  document.body.classList.toggle('touch-ui', ui.touch)
}

export function setLoading (text) {
  const el = $('#loading')
  el.textContent = text || ''
  el.style.display = text ? 'block' : 'none'
}

export function fade (to, ms = 1200) {
  const el = $('#fade')
  el.style.transition = `opacity ${ms}ms`
  el.style.opacity = String(to)
}

let flashTimer
export function redFlash (strength = 1) {
  const el = $('#flash')
  el.style.transition = 'none'
  el.style.opacity = String(strength)
  clearTimeout(flashTimer)
  flashTimer = setTimeout(() => { el.style.transition = 'opacity 1.4s'; el.style.opacity = '0' }, 120)
}

// ───── HUD pieces ─────
const textCache = new WeakMap()
const setText = (el, text, html = false) => {
  if (textCache.get(el) === text) return
  textCache.set(el, text)
  if (html) el.innerHTML = text
  else el.textContent = text
}

export function setObjective (obj, extra = '') {
  const el = $('#objective')
  if (!obj) { setText(el, ''); return }
  setText(el, `<small>${escapeHtml(obj.step)}</small>${escapeHtml(obj.text)}${extra ? `<br><span style="color:var(--smoke)">${escapeHtml(extra)}</span>` : ''}`, true)
}

export function setPrompt (label) {
  const el = $('#prompt')
  if (!label) { setText(el, ''); return }
  setText(el, ui.touch ? `${escapeHtml(label)}` : `<kbd>E</kbd>${escapeHtml(label)}`, true)
}

let toastTimer
export function toast (text, ms = 3200, html = false) {
  const el = $('#toast')
  if (html) el.innerHTML = text
  else el.textContent = text
  el.style.opacity = '1'
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { el.style.opacity = '0' }, ms)
}

export function setInventory ({ fuses, key, batteries, pills, coop, extra = [] }) {
  const parts = []
  if (fuses != null) parts.push(`<span class="${fuses ? '' : 'off'}">Fuses <b>${fuses}/3</b></span>`)
  if (key != null) parts.push(`<span class="${key ? '' : 'off'}">Key <b>${key ? 'yes' : 'no'}</b></span>`)
  for (const [label, value] of extra) parts.push(`<span>${escapeHtml(label)} <b>${escapeHtml(value)}</b></span>`)
  parts.push(`<span class="${batteries ? '' : 'off'}">Batteries <b>${batteries}</b></span>`)
  parts.push(`<span class="${pills ? '' : 'off'}">Pills <b>${pills}</b></span>`)
  setText($('#inv'), parts.join(''), true)
  void coop
}

/** Big chapter title card that fades in and out */
let chapterTimer
export function chapterCard (kicker, title) {
  const el = $('#chapter')
  if (!el) return
  el.innerHTML = `<small>${escapeHtml(kicker)}</small>${escapeHtml(title)}`
  el.classList.add('is-on')
  clearTimeout(chapterTimer)
  chapterTimer = setTimeout(() => el.classList.remove('is-on'), 4200)
}

export function setBattery (pct, on) {
  $('#battery-bar').style.width = `${Math.max(0, Math.min(100, pct))}%`
  $('#battery-cell').classList.toggle('low', pct < 20)
  $('#battery-cell').style.opacity = on ? '1' : '0.6'
}

/** Spirit level: the bubble drifts off-centre as you get dizzy */
export function setLevel (offset, state) {
  $('#bubble').style.transform = `translateX(${offset * 62}px)`
  const level = $('#level')
  level.classList.toggle('warn', state === 'warn')
  level.classList.toggle('spell', state === 'spell')
  const label = state === 'spell' ? (ui.touch ? 'Dizzy: hold Steady near a wall' : 'Dizzy: hold Q near a wall') : state === 'warn' ? 'Your head is spinning…' : 'Balance'
  setText($('#level-label'), label)
}

export function setBreath (visible, amount, urgent) {
  const el = $('#breath')
  el.style.display = visible ? 'block' : 'none'
  $('#breath-bar').style.width = `${amount * 100}%`
  setText(el.firstChild, urgent ? (ui.touch ? 'It\'s right outside. Hold breath!' : 'It\'s right outside. Hold Space!') : (ui.touch ? 'Hidden. Hold breath when it comes close' : 'Hidden. Hold Space to hold your breath, E to get out'))
  el.style.color = urgent ? '#ffb4a8' : ''
}

export function setSlits (mode) {
  const el = $('#slits')
  el.style.display = mode ? 'block' : 'none'
  el.classList.toggle('full', mode === 'dark')
}

export function setTimer (seconds) {
  const el = $('#timer')
  if (seconds == null) { el.style.display = 'none'; return }
  el.style.display = 'block'
  const s = Math.max(0, Math.ceil(seconds))
  setText(el, `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`)
}

export function setTeam (list) {
  setText($('#team'), list.map(p => `<span class="${p.down ? 'down' : ''}">${escapeHtml(p.name)}${p.down ? (p.dead ? ', gone' : `, down ${Math.ceil(p.downLeft)}s`) : ''}</span>`).join(''), true)
}

// ───── notes ─────
export function openNote (id) {
  const n = NOTES[id]
  if (!n) return false
  $('#note-title').textContent = n.title
  $('#note-body').innerHTML = n.body.map(line => `<p>${escapeHtml(line)}</p>`).join('')
  $('#note').classList.add('is-open')
  return true
}
export const closeNote = () => $('#note').classList.remove('is-open')
export const noteOpen = () => $('#note').classList.contains('is-open')

// ───── lobby ─────
export function setLobby ({ code, roster, isHost, status }) {
  if (code !== undefined) setText($('#lobby-code'), code || '- - - -')
  if (roster) setText($('#lobby-roster'), roster.map(p => `<li>${escapeHtml(p.name)}${p.host ? ' <span class="host">host</span>' : ''}${p.me ? ' <span class="host">you</span>' : ''}</li>`).join(''), true)
  if (isHost !== undefined) {
    $('#lobby-start').parentElement.style.display = isHost ? '' : 'none'
    setText($('#lobby-hint'), isHost ? 'Share this code with up to three friends, then start.' : 'Waiting for the host to start the run.')
  }
  if (status !== undefined) {
    setText($('#lobby-status'), status)
  }
}

export function setStatus (sel, text, bad = false) {
  const el = $(sel)
  el.textContent = text
  el.classList.toggle('bad', bad)
}

function escapeHtml (s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
}
export { escapeHtml }
