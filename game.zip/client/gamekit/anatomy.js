// Anatomy kit shared by the site's games: sculpted heads, shaped torsos and limbs, hands with fingers,
// hair, and procedural surface detail (skin pores, cloth weave, fur, veins, porcelain cracks).
// Everything is built from code (no model files), so it loads instantly and costs few draw calls:
// each part is one merged geometry per material.
import * as THREE from 'three'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'

// ═════════════ surface textures (made once, shared) ═════════════
const texCache = new Map()
function canvasTex (key, size, draw, repeat = 1) {
  if (texCache.has(key)) return texCache.get(key)
  const c = document.createElement('canvas')
  c.width = c.height = size
  const g = c.getContext('2d')
  draw(g, size)
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(repeat, repeat)
  t.anisotropy = 4
  texCache.set(key, t)
  return t
}
let seed = 1234
const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647 }

/** fine pores and blotches: used as a bump + roughness map for skin */
export const skinTex = () => canvasTex('skin', 256, (g, s) => {
  g.fillStyle = '#808080'; g.fillRect(0, 0, s, s)
  for (let i = 0; i < 2600; i++) { const v = 100 + rnd() * 60 | 0; g.fillStyle = `rgba(${v},${v},${v},.5)`; g.fillRect(rnd() * s, rnd() * s, 1 + rnd() * 1.5, 1 + rnd() * 1.5) }
  for (let i = 0; i < 40; i++) { const r = 6 + rnd() * 18; const gr = g.createRadialGradient(0, 0, 0, 0, 0, r); gr.addColorStop(0, 'rgba(110,110,110,.25)'); gr.addColorStop(1, 'rgba(128,128,128,0)'); g.save(); g.translate(rnd() * s, rnd() * s); g.fillStyle = gr; g.fillRect(-r, -r, r * 2, r * 2); g.restore() }
}, 3)
/** woven cloth */
export const clothTex = () => canvasTex('cloth', 128, (g, s) => {
  g.fillStyle = '#808080'; g.fillRect(0, 0, s, s)
  for (let y = 0; y < s; y += 2) { g.fillStyle = y % 4 ? 'rgba(150,150,150,.6)' : 'rgba(100,100,100,.6)'; g.fillRect(0, y, s, 1) }
  for (let x = 0; x < s; x += 2) { g.fillStyle = x % 4 ? 'rgba(140,140,140,.35)' : 'rgba(110,110,110,.35)'; g.fillRect(x, 0, 1, s) }
  for (let i = 0; i < 300; i++) { g.fillStyle = `rgba(${90 + rnd() * 80 | 0},${90 + rnd() * 80 | 0},${90 + rnd() * 80 | 0},.25)`; g.fillRect(rnd() * s, rnd() * s, 1, 3) }
}, 6)
/** fur / felt: short directional streaks */
export const furTex = () => canvasTex('fur', 256, (g, s) => {
  g.fillStyle = '#7a7a7a'; g.fillRect(0, 0, s, s)
  g.lineCap = 'round'
  for (let i = 0; i < 5000; i++) {
    const x = rnd() * s, y = rnd() * s, l = 3 + rnd() * 7, a = Math.PI / 2 + (rnd() - 0.5) * 0.8
    const v = 70 + rnd() * 120 | 0
    g.strokeStyle = `rgba(${v},${v},${v},.55)`; g.lineWidth = 0.6 + rnd()
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke()
  }
}, 2)
/** hair: long fibres along v */
export const hairTex = () => canvasTex('hair', 128, (g, s) => {
  g.fillStyle = '#8a8a8a'; g.fillRect(0, 0, s, s)
  for (let i = 0; i < 900; i++) { const x = rnd() * s, v = 60 + rnd() * 140 | 0; g.fillStyle = `rgba(${v},${v},${v},.5)`; g.fillRect(x, 0, 0.6 + rnd(), s) }
}, 2)
/** branching dark veins on pale or dark skin (colour map, multiplies) */
export const veinTex = () => canvasTex('veins', 512, (g, s) => {
  g.fillStyle = '#ffffff'; g.fillRect(0, 0, s, s)
  for (let i = 0; i < 3000; i++) { const v = 215 + rnd() * 40 | 0; g.fillStyle = `rgb(${v},${v - 6},${v - 8})`; g.fillRect(rnd() * s, rnd() * s, 2, 2) }
  const branch = (x, y, a, w, n) => {
    if (n <= 0 || w < 0.3) return
    const l = 10 + rnd() * 26
    const nx = x + Math.cos(a) * l, ny = y + Math.sin(a) * l
    g.strokeStyle = `rgba(70,40,60,${0.25 + w * 0.08})`; g.lineWidth = w
    g.beginPath(); g.moveTo(x, y); g.lineTo(nx, ny); g.stroke()
    branch(nx, ny, a + (rnd() - 0.5) * 0.9, w * 0.86, n - 1)
    if (rnd() < 0.35) branch(nx, ny, a + (rnd() < 0.5 ? 1 : -1) * (0.5 + rnd() * 0.7), w * 0.6, n - 2)
  }
  for (let i = 0; i < 26; i++) branch(rnd() * s, rnd() * s, rnd() * Math.PI * 2, 2.4, 9)
}, 1)
/** hairline cracks for porcelain and plastic */
export const crackTex = () => canvasTex('cracks', 512, (g, s) => {
  g.fillStyle = '#ffffff'; g.fillRect(0, 0, s, s)
  for (let i = 0; i < 9; i++) {
    let x = rnd() * s, y = rnd() * s, a = rnd() * Math.PI * 2
    g.strokeStyle = 'rgba(60,50,50,.55)'; g.lineWidth = 0.9
    g.beginPath(); g.moveTo(x, y)
    for (let k = 0; k < 14; k++) { a += (rnd() - 0.5) * 1.1; x += Math.cos(a) * 9; y += Math.sin(a) * 9; g.lineTo(x, y) }
    g.stroke()
  }
}, 1)

// ═════════════ materials ═════════════
/** skin: pores in the bump map, slightly glossy */
export function skinMat (color, { rough = 0.55, wet = false, veins = false, bump = 0.012 } = {}) {
  const opts = { color, roughness: rough, bumpMap: skinTex(), bumpScale: bump, roughnessMap: null }
  if (veins) opts.map = veinTex()
  if (wet) return new THREE.MeshPhysicalMaterial({ ...opts, clearcoat: 0.55, clearcoatRoughness: 0.35, sheen: 0.3, sheenColor: new THREE.Color(0x553333) })
  return new THREE.MeshStandardMaterial(opts)
}
export const clothMat = (color, rough = 0.9) => new THREE.MeshStandardMaterial({ color, roughness: rough, bumpMap: clothTex(), bumpScale: 0.006 })
export const furMat = (color, rough = 1) => new THREE.MeshStandardMaterial({ color, roughness: rough, bumpMap: furTex(), bumpScale: 0.02, map: furTex() })
export const hairMat = color => new THREE.MeshStandardMaterial({ color, roughness: 0.62, bumpMap: hairTex(), bumpScale: 0.01, map: hairTex() })
export const porcelainMat = (color = 0xf3eee6) => new THREE.MeshPhysicalMaterial({ color, roughness: 0.18, clearcoat: 0.8, clearcoatRoughness: 0.1, map: crackTex() })
export const plasticMat = color => new THREE.MeshPhysicalMaterial({ color, roughness: 0.32, clearcoat: 0.4, clearcoatRoughness: 0.3, bumpMap: skinTex(), bumpScale: 0.002 })

// ═════════════ shapes ═════════════
const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t) }

/**
 * A limb segment hanging down from the origin (y = 0 → y = -len): radius r0 at the top, r1 at the bottom,
 * with a muscle bulge (bulge × radius at `at` along its length) and rounded ends.
 */
export function limbGeo (r0, r1, len, { bulge = 0.12, at = 0.3, segs = 14, rings = 10, flat = 1 } = {}) {
  const pts = []
  const cap = 4
  // bottom cap → shaft → top cap (lathe wants y ascending)
  for (let i = 0; i <= cap; i++) { const a = (i / cap) * Math.PI / 2; pts.push(new THREE.Vector2(Math.sin(a) * r1, -len - Math.cos(a) * r1 * 0.6)) }
  for (let i = 1; i < rings; i++) {
    const t = 1 - i / rings // 1 at the bottom … 0 at the top
    const r = r0 + (r1 - r0) * t
    const b = 1 + bulge * Math.exp(-Math.pow((t - at) / 0.22, 2))
    pts.push(new THREE.Vector2(r * b, -len * t))
  }
  for (let i = 0; i <= cap; i++) { const a = (1 - i / cap) * Math.PI / 2; pts.push(new THREE.Vector2(Math.max(0.0001, Math.sin(a) * r0), Math.cos(a) * r0 * 0.6)) }
  const g = new THREE.LatheGeometry(pts, segs)
  if (flat !== 1) g.scale(1, 1, flat)
  return g
}

/** torso from the hips (y = 0) up to the shoulders (y = h). Widths are half-widths. */
export function torsoGeo ({ h = 0.55, hip = 0.15, waist = 0.13, chest = 0.17, shoulder = 0.19, neck = 0.06, depth = 0.7, belly = 0, bust = 0, segs = 20 } = {}) {
  const prof = [
    [0, hip * 0.6], [0.02, hip * 0.95], [0.08, hip], [0.22, waist + belly * 0.5], [0.35, waist + belly], [0.52, chest * 0.95],
    [0.68, chest], [0.82, chest * 1.02], [0.9, shoulder], [0.96, shoulder * 0.8], [0.99, neck * 1.6], [1.0, neck],
  ]
  const pts = prof.map(([t, r]) => new THREE.Vector2(r, t * h))
  const g = new THREE.LatheGeometry(pts, segs)
  // flatten front-to-back, push the chest forward a little and round the shoulder blades
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    const t = y / h
    let nz = z * depth
    if (z > 0) nz += Math.exp(-Math.pow((t - 0.72) / 0.12, 2)) * (0.012 + bust * 0.05) * (1 - Math.abs(x) / (chest * 1.2))
    if (z > 0 && belly) nz += Math.exp(-Math.pow((t - 0.32) / 0.15, 2)) * belly * 0.8
    if (z < 0) nz -= Math.exp(-Math.pow((t - 0.78) / 0.1, 2)) * 0.01
    p.setZ(i, nz)
  }
  g.computeVertexNormals()
  return g
}

/**
 * Head sculpted from a sphere (about 0.24 m tall at scale 1, face toward +z, centre at the origin).
 * opts: jaw (width of the jaw), gaunt (hollow cheeks), brow, nose, chin, skull (long skull), age
 */
export function headGeo ({ jaw = 1, gaunt = 0, brow = 1, nose = 1, chin = 1, skull = 1, segs = 32 } = {}) {
  const g = new THREE.SphereGeometry(1, segs, Math.round(segs * 0.8))
  const p = g.attributes.position
  const v = new THREE.Vector3()
  const bump = (x, y, z, cx, cy, cz, w) => Math.exp(-((x - cx) ** 2 + (y - cy) ** 2 + (z - cz) ** 2) / w)
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i)
    let { x, y, z } = v
    // overall: taller than wide (the lower face a little shorter), back of the skull fuller
    y *= y > 0 ? 1.16 : 1.04
    if (z < 0) { z *= 1.08 * skull; y += (skull - 1) * 0.2 * Math.max(0, y) }
    // jaw narrows toward the chin
    const low = smooth(-0.1, -1.1, y)
    x *= 1 - low * (0.26 / jaw) + (jaw - 1) * 0.12 * low
    if (z > 0) z *= 1 - low * 0.12
    // chin pushes forward a touch
    if (z > 0.2) z += bump(x, y, z, 0, -0.95, 0.75, 0.05) * 0.12 * chin
    // temples narrow
    x *= 1 - smooth(0.2, 0.9, y) * 0.08
    // eye sockets and the brow ridge over them
    for (const sx of [-0.36, 0.36]) {
      const d = bump(x, y, z, sx * 0.95, 0.16, 0.86, 0.02)
      x -= 0; z -= d * (0.085 + gaunt * 0.05)
      z += bump(x, y, z, sx, 0.36, 0.86, 0.03) * 0.035 * brow
      // cheekbones, hollow cheeks under them
      z += bump(x, y, z, sx * 1.45, -0.1, 0.7, 0.03) * 0.03
      const hollow = bump(x, y, z, sx * 1.4, -0.42, 0.62, 0.05)
      x -= Math.sign(sx) * hollow * gaunt * 0.07; z -= hollow * gaunt * 0.06
    }
    // nose: bridge between the eyes down to the tip
    if (z > 0.6 && Math.abs(x) < 0.25) {
      const along = smooth(0.25, -0.22, y) * (1 - smooth(-0.22, -0.32, y))
      z += along * Math.exp(-(x * x) / 0.006) * 0.17 * nose
      z += bump(x, y, z, 0, -0.24, 0.98, 0.006) * 0.06 * nose // tip
      for (const sx of [-0.09, 0.09]) z += bump(x, y, z, sx, -0.28, 0.93, 0.004) * 0.03 * nose // nostrils
    }
    // mouth: a soft groove, lips either side of it
    z -= bump(x, y, z, 0, -0.5, 0.92, 0.003) * 0.025
    z += bump(x, y, z, 0, -0.45, 0.92, 0.01) * 0.02
    z += bump(x, y, z, 0, -0.56, 0.9, 0.012) * 0.02
    p.setXYZ(i, x, y, z)
  }
  g.computeVertexNormals()
  return g
}

/** an ear (flattened, cupped), for the right side; mirror x for the left */
export function earGeo () {
  const g = new THREE.SphereGeometry(1, 12, 10)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    p.setXYZ(i, x * 0.25 + (y > 0 ? 0.08 : 0) * (1 - Math.abs(z)), y * 1.15, z * 0.65 - Math.max(0, x) * 0.2)
  }
  g.computeVertexNormals()
  return g
}

/**
 * A hand hanging down from the wrist (y = 0) with palm facing -x for the right hand (mirror for left).
 * size ~0.18 m at scale 1. claws adds pointed nails. Returns { skin, nails } geometries.
 */
export function handGeo ({ fingerLen = 1, thick = 1, claws = 0, curl = 0.18, segs = 8 } = {}) {
  const skin = []
  const nails = []
  const palm = new THREE.SphereGeometry(1, 14, 10)
  palm.scale(0.05 * thick, 0.056, 0.024 * thick)
  palm.translate(0, -0.052, 0)
  skin.push(palm)
  // four fingers across the width of the palm (x), each in three joints curling toward the palm side (+z)
  const fingers = [[-0.033, 0.82], [-0.011, 1], [0.011, 0.95], [0.033, 0.78]]
  for (const [fx, l] of fingers) {
    let y = -0.1 + Math.abs(fx) * 0.3, z = 0.002, ang = 0.05
    const lens = [0.045, 0.03, 0.024].map(v => v * l * fingerLen)
    for (let k = 0; k < 3; k++) {
      const r = (0.0115 - k * 0.0013) * thick
      const seg = new THREE.CapsuleGeometry(r, lens[k], 3, segs)
      seg.translate(0, -lens[k] / 2, 0)
      seg.rotateX(-ang)
      seg.translate(fx, y, z)
      skin.push(seg)
      y -= Math.cos(ang) * lens[k]
      z += Math.sin(ang) * lens[k]
      ang += curl
    }
    if (claws > 0) {
      const c = new THREE.ConeGeometry(0.006 * thick, 0.03 * claws, 6)
      c.rotateX(Math.PI - ang)
      c.translate(fx, y - 0.01 * claws, z + 0.004)
      nails.push(c)
    }
  }
  // thumb: off the side of the palm, angled toward the palm
  const th = new THREE.CapsuleGeometry(0.011 * thick, 0.04 * fingerLen, 3, segs)
  th.rotateZ(0.55); th.rotateX(-0.5)
  th.translate(0.045, -0.04, 0.012)
  skin.push(th)
  return { skin: mergeGeometries(skin), nails: nails.length ? mergeGeometries(nails) : null }
}

/** a simple shoe / foot from the ankle, toes toward +z */
export function footGeo ({ len = 0.25, w = 0.05, h = 0.07 } = {}) {
  const g = new THREE.SphereGeometry(1, 16, 10)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    const toe = (z + 1) / 2
    x *= w * (0.75 + toe * 0.35)
    y = Math.max(y, -0.55) * h
    z = z * len / 2 + len * 0.28
    p.setXYZ(i, x, y, z)
  }
  g.computeVertexNormals()
  return g
}

/** hair cap over a head of radius ~1 (scaled with the head); style: short | long | bob | bun | bald */
export function hairGeo (style = 'short') {
  const parts = []
  const cap = new THREE.SphereGeometry(1.07, 28, 18, 0, Math.PI * 2, 0, Math.PI * (style === 'short' ? 0.56 : 0.6))
  const p = cap.attributes.position
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    y *= 1.2
    // clumps of hair
    const n = Math.sin(x * 23) * Math.sin(z * 19) * 0.018 + Math.sin(y * 31 + x * 7) * 0.01
    x *= 1 + n; z *= 1 + n
    // hairline: high on the forehead, sweeping down past the temples to the ears and the nape
    const front = Math.max(0, z / 1.07)
    const side = Math.abs(x) / 1.07
    const minY = 0.74 * Math.pow(front, 0.8) * (1 - side * 0.6) - (1 - front) * 0.08
    if (y < minY) { y = minY; z *= 0.94; x *= 0.97 }
    p.setXYZ(i, x, y + 0.03, z)
  }
  cap.computeVertexNormals()
  parts.push(cap)
  if (style === 'long' || style === 'bob') {
    const len = style === 'long' ? 1.5 : 0.75
    const back = new THREE.CylinderGeometry(1.02, style === 'long' ? 0.86 : 0.96, len, 24, 4, true, Math.PI * 0.3, Math.PI * 1.4)
    back.translate(0, -len / 2 + 0.25, -0.05)
    const bp = back.attributes.position
    for (let i = 0; i < bp.count; i++) { const x = bp.getX(i), z = bp.getZ(i), y = bp.getY(i); const n = 1 + Math.sin(Math.atan2(x, z) * 18 + y * 4) * 0.025; bp.setXYZ(i, x * n * 1.05, y, z * n * 1.05) }
    back.computeVertexNormals()
    parts.push(back)
  }
  if (style === 'bun') { const b = new THREE.SphereGeometry(0.42, 14, 10); b.translate(0, 0.75, -0.75); parts.push(b) }
  if (style === 'ponytail') { const t = limbGeo(0.22, 0.12, 1.3, { bulge: 0.2, at: 0.6 }); t.rotateX(-0.35); t.translate(0, 0.55, -0.95); parts.push(t) }
  return mergeGeometries(parts.map(g => g.index ? g.toNonIndexed() : g))
}

/**
 * A complete face on a head: skin (head + ears + eyelids), eyes (whites + irises), brows and lips.
 * Returns { group, skinMesh, eyeMat, irisMat, setLook(dx, dy), blink(t) }. Scale the group to size the head.
 */
export function buildHead ({ skin, eyeColor = 0x4a3a2a, browColor = 0x2a1d12, lipColor = 0xb0675e, headOpts = {}, eyeSize = 1.15, ears = true, noFace = false } = {}) {
  const group = new THREE.Group()
  const skinParts = [headGeo(headOpts)]
  if (ears) for (const s of [-1, 1]) { const e = earGeo(); if (s < 0) e.scale(-1, 1, 1); e.scale(0.18, 0.22, 0.2); e.translate(s * 0.83, 0.02, -0.08); skinParts.push(e) }
  const eyes = []
  const lids = []
  if (!noFace) {
    for (const s of [-1, 1]) {
      // upper lid: a half shell over the eyeball
      const lid = new THREE.SphereGeometry(0.142 * eyeSize, 14, 8, 0, Math.PI * 2, 0, Math.PI * 0.42)
      lid.rotateX(0.55)
      lid.translate(s * 0.34, 0.165, 0.775)
      lids.push(lid)
    }
    skinParts.push(...lids)
  }
  const skinMesh = new THREE.Mesh(mergeGeometries(skinParts.map(g => g.index ? g.toNonIndexed() : g)), skin)
  skinMesh.castShadow = true
  group.add(skinMesh)
  const eyeMat = new THREE.MeshPhysicalMaterial({ color: 0xf2eee6, roughness: 0.15, clearcoat: 1, clearcoatRoughness: 0.05, emissive: 0x000000 })
  const irisMat = new THREE.MeshStandardMaterial({ color: eyeColor, roughness: 0.3, emissive: 0x000000 })
  let irisGroup = null
  if (!noFace) {
    const whites = []
    const iris = []
    for (const s of [-1, 1]) {
      const w = new THREE.SphereGeometry(0.135 * eyeSize, 16, 12)
      w.translate(s * 0.34, 0.16, 0.77)
      whites.push(w)
      const ir = new THREE.CircleGeometry(0.07 * eyeSize, 18)
      ir.translate(0, 0, 0.136 * eyeSize + 0.008)
      const pu = new THREE.CircleGeometry(0.03 * eyeSize, 12)
      pu.translate(0, 0, 0.136 * eyeSize + 0.013)
      // pupil is darker: bake as a vertex colour later; keep it simple, separate merged geometry
      ir.translate(s * 0.34, 0.16, 0.77)
      pu.translate(s * 0.34, 0.16, 0.77)
      iris.push(ir)
      eyes.push(pu)
    }
    group.add(new THREE.Mesh(mergeGeometries(whites), eyeMat))
    irisGroup = new THREE.Group()
    irisGroup.add(new THREE.Mesh(mergeGeometries(iris), irisMat))
    irisGroup.add(new THREE.Mesh(mergeGeometries(eyes), new THREE.MeshBasicMaterial({ color: 0x050505 })))
    group.add(irisGroup)
    // brows
    const brows = []
    for (const s of [-1, 1]) {
      const b = new THREE.CapsuleGeometry(0.03, 0.2, 3, 6)
      b.rotateZ(Math.PI / 2 + s * 0.12)
      b.translate(s * 0.35, 0.36, 0.905)
      brows.push(b)
    }
    group.add(new THREE.Mesh(mergeGeometries(brows), new THREE.MeshStandardMaterial({ color: browColor, roughness: 0.9 })))
    // lips
    const lips = []
    const up = new THREE.CapsuleGeometry(0.035, 0.2, 3, 8); up.rotateZ(Math.PI / 2); up.scale(1, 0.75, 0.45); up.translate(0, -0.475, 0.88); lips.push(up)
    const lo = new THREE.CapsuleGeometry(0.04, 0.17, 3, 8); lo.rotateZ(Math.PI / 2); lo.scale(1, 0.85, 0.5); lo.translate(0, -0.555, 0.865); lips.push(lo)
    group.add(new THREE.Mesh(mergeGeometries(lips), new THREE.MeshStandardMaterial({ color: lipColor, roughness: 0.45 })))
  }
  let blinkT = 0, nextBlink = 2
  return {
    group, skinMesh, eyeMat, irisMat,
    /** look direction in radians (small) */
    setLook (dx, dy) { if (irisGroup) { irisGroup.rotation.y = dx * 0.4; irisGroup.rotation.x = -dy * 0.3 } },
    /** blink now and then (squash the eyes) */
    update (dt) {
      if (!irisGroup) return
      nextBlink -= dt
      if (nextBlink <= 0) { blinkT = 0.14; nextBlink = 2 + Math.random() * 4 }
      blinkT = Math.max(0, blinkT - dt)
      const k = blinkT > 0 ? 0.15 : 1
      irisGroup.scale.y += (k - irisGroup.scale.y) * 0.6
    },
  }
}

/** merge a list of [geometry, matrix?] into one mesh */
export function mergedMesh (geos, mat) {
  const m = new THREE.Mesh(mergeGeometries(geos.map(g => (g.index ? g.toNonIndexed() : g))), mat)
  m.castShadow = true
  return m
}
