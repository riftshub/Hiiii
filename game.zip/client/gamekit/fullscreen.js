// Fullscreen toggle shared by the site's games.
// Any element with data-fullscreen becomes a toggle; its text follows the state.
//
// - Esc normally throws the browser out of fullscreen. Where the browser allows it (Chrome, Edge),
//   we "lock" Esc while fullscreen so a quick tap pauses the game instead; holding Esc still exits.
// - If you turned fullscreen on and something kicks you out (a pause, an alert, switching apps),
//   the next menu button you press (Play, Resume…) puts it back.
// - iPhone doesn't let web pages go fullscreen at all. There the button explains how to add the game
//   to the Home Screen, which opens it full screen (see manifest.webmanifest in each game folder).

const el = document.documentElement
const PREF = 'site.fullscreen'
export const canFullscreen = () => !!(el.requestFullscreen || el.webkitRequestFullscreen)
export const isFullscreen = () => !!(document.fullscreenElement || document.webkitFullscreenElement)
const isIOS = () => /iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1 && !canFullscreen())
const isStandalone = () => matchMedia('(display-mode: fullscreen), (display-mode: standalone)').matches || navigator.standalone === true

const getPref = () => { try { return localStorage.getItem(PREF) === '1' } catch { return false } }
const setPref = on => { try { localStorage.setItem(PREF, on ? '1' : '0') } catch {} }

async function enter () {
  try {
    await (el.requestFullscreen || el.webkitRequestFullscreen).call(el, { navigationUI: 'hide' })
    // keep Esc for the game (pause) instead of leaving fullscreen; holding Esc still exits
    try { await navigator.keyboard?.lock?.(['Escape']) } catch {}
  } catch { /* the browser said no */ }
}
async function leave () {
  try { navigator.keyboard?.unlock?.() } catch {}
  try { await (document.exitFullscreen || document.webkitExitFullscreen).call(document) } catch {}
}

export async function toggleFullscreen () {
  if (isFullscreen()) { setPref(false); await leave() } else { setPref(true); await enter() }
}

// On phones the title menus can run past the bottom of the screen (the browser bars eat space),
// so the title-screen button sits in the top corner where it's always in reach.
const pinStyle = document.createElement('style')
pinStyle.textContent = `@media (pointer: coarse) {
  #screen-title [data-fullscreen] { position: fixed !important; top: max(12px, env(safe-area-inset-top)); right: max(12px, env(safe-area-inset-right)); z-index: 30;
    margin: 0 !important; padding: 9px 14px !important; background: rgba(0,0,0,.55) !important; border: 1px solid rgba(255,255,255,.4) !important; border-radius: 4px;
    color: #fff !important; font: 600 15px/1 system-ui, sans-serif !important; text-decoration: none !important; }
  #screen-title [data-fullscreen]::after { display: none !important; }
}`
document.head.appendChild(pinStyle)

export function bindFullscreenButtons (root = document) {
  const buttons = [...root.querySelectorAll('[data-fullscreen]')]
  const iosTip = !canFullscreen() && isIOS() && !isStandalone()
  const sync = () => {
    for (const b of buttons) {
      b.hidden = !canFullscreen() && !iosTip
      b.textContent = isFullscreen() ? (b.dataset.exitLabel || 'Exit fullscreen') : (b.dataset.label || 'Fullscreen')
      b.setAttribute('aria-pressed', String(isFullscreen()))
    }
  }
  for (const b of buttons) {
    b.addEventListener('click', e => {
      e.stopPropagation()
      if (iosTip) showIosTip()
      else void toggleFullscreen()
    })
  }
  document.addEventListener('fullscreenchange', () => { if (!isFullscreen()) try { navigator.keyboard?.unlock?.() } catch {} sync() })
  document.addEventListener('webkitfullscreenchange', sync)
  // you asked for fullscreen and got thrown out: any menu button (a real tap or click) brings it back
  document.addEventListener('click', e => {
    if (!e.isTrusted || !getPref() || isFullscreen() || !canFullscreen()) return
    if (e.target.closest?.('[data-fullscreen]')) return
    if (e.target.closest?.('[data-go], .tbtn, button')) void enter()
  }, true)
  // Android's back gesture (a swipe in from the screen edge) drops out of fullscreen mid-game,
  // and the in-game touch buttons don't fire clicks: the next tap anywhere puts it back
  document.addEventListener('touchend', e => {
    if (!e.isTrusted || !getPref() || isFullscreen() || !canFullscreen()) return
    if (e.target.closest?.('[data-fullscreen]')) return
    void enter()
  }, { capture: true, passive: true })
  sync()
}

function showIosTip () {
  let tip = document.getElementById('ios-fullscreen-tip')
  if (!tip) {
    tip = document.createElement('div')
    tip.id = 'ios-fullscreen-tip'
    tip.setAttribute('role', 'dialog')
    tip.setAttribute('aria-label', 'Full screen on iPhone')
    tip.style.cssText = 'position:fixed;inset:0;z-index:100;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(0,0,0,.7);font:16px/1.45 system-ui,sans-serif;color:#222'
    tip.innerHTML = `<div style="max-width:340px;background:#f6f3ea;padding:20px 20px 16px;box-shadow:0 20px 50px rgba(0,0,0,.5)">
      <b style="font-size:19px;display:block;margin-bottom:8px">Full screen on iPhone</b>
      <p style="margin:0 0 10px">iPhones don't let websites go full screen, but you can add the game to your Home Screen and it opens full screen from there:</p>
      <ol style="margin:0 0 14px;padding-left:20px"><li>Tap the <b>Share</b> button (the square with an arrow).</li><li>Tap <b>Add to Home Screen</b>.</li><li>Open the game from its new icon.</li></ol>
      <button type="button" style="font:700 16px system-ui,sans-serif;padding:9px 18px;border:0;background:#222;color:#fff;cursor:pointer">Got it</button></div>`
    tip.addEventListener('click', e => { if (e.target === tip || e.target.tagName === 'BUTTON') tip.remove() })
  }
  document.body.appendChild(tip)
  tip.querySelector('button').focus()
}
