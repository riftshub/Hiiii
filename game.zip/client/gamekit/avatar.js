// Player and NPC character models: a sculpted person (face, hands, hair, clothes with texture) with
// walk / run / crouch / downed poses, a flashlight beam and a floating name tag. Shared by the site's games.
import * as THREE from 'three'
import { buildHead, limbGeo, torsoGeo, handGeo, footGeo, hairGeo, skinMat, clothMat, hairMat } from './anatomy.js'

const glowTex = (() => {
  let tex = null
  return () => {
    if (tex) return tex
    const c = document.createElement('canvas')
    c.width = c.height = 64
    const g = c.getContext('2d')
    const r = g.createRadialGradient(32, 32, 0, 32, 32, 32)
    r.addColorStop(0, 'rgba(255,255,255,1)'); r.addColorStop(0.3, 'rgba(255,255,255,.5)'); r.addColorStop(1, 'rgba(255,255,255,0)')
    g.fillStyle = r; g.fillRect(0, 0, 64, 64)
    tex = new THREE.CanvasTexture(c)
    return tex
  }
})()

const OUTFITS = {
  // Vertigo Freight: railway conductor
  conductor: { coat: 0x1e2b40, trim: 0xb08d57, trousers: 0x161b24, shoes: 0x0d0d0f, hat: 'cap', hatColor: 0x14181f, coatTail: true, pack: false },
  // Creeps: explorers in hoodies
  explorer: { coat: 0x7a2e3a, trim: 0xe7e2d6, trousers: 0x2e3f5c, shoes: 0xe9e4da, hat: 'hood', hatColor: null, coatTail: false, pack: true },
  // Night Owl Market: shop staff in aprons, and ordinary shoppers
  clerk: { coat: 0x2f6b4f, trim: 0xf2c94c, trousers: 0x23262e, shoes: 0x111111, hat: 'cap', hatColor: 0x1d4a36, coatTail: false, pack: false, apron: 0x3a8a62 },
  shopper: { coat: 0x35508a, trim: 0xe7e2d6, trousers: 0x2e3f5c, shoes: 0x333333, hat: null, hatColor: null, coatTail: false, pack: false },
  // Little Lantern: a girl in a raincoat
  girl: { coat: 0xe8c23a, trim: 0x2b2b30, trousers: 0x2e3f5c, shoes: 0xb03030, hat: null, hatColor: null, coatTail: true, pack: false, small: true, child: true },
}
const SKIN = [0xe0b394, 0xc69276, 0x8d5a3f, 0xf0caa8, 0x5e3b2a, 0xb07a58]
const COATS = [0x7a2e3a, 0x2f6b4f, 0x35508a, 0x8a6b2f, 0x5b3a7a, 0x2f6f7a]
const EYES = [0x4a3a2a, 0x2f4f6f, 0x3d5a3a, 0x5a4630, 0x1f1a16]
const HAIR = [0x1c140e, 0x3b2616, 0x6b4a2b, 0xb8925a, 0x0e0e10]

export const hashId = s => { let h = 0; for (const ch of String(s)) h = Math.trunc(h * 31 + ch.charCodeAt(0)); return Math.abs(h) }

function nameSprite (text) {
  const c = document.createElement('canvas')
  c.width = 256; c.height = 64
  const g = c.getContext('2d')
  g.font = '600 30px system-ui, sans-serif'
  g.textAlign = 'center'
  const w = Math.min(240, g.measureText(text).width + 24)
  g.fillStyle = 'rgba(6,9,13,.55)'
  g.beginPath(); g.roundRect?.(128 - w / 2, 10, w, 44, 10); g.fill()
  g.fillStyle = 'rgba(240,234,220,.95)'
  g.fillText(text, 128, 43)
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, fog: false }))
  s.scale.set(0.95, 0.24, 1)
  s.renderOrder = 5
  return s
}

// shapes are built once and shared by every character (a shop full of shoppers stays cheap)
const geoCache = new Map()
const memo = (key, make) => { if (!geoCache.has(key)) geoCache.set(key, make()); return geoCache.get(key) }

/**
 * id: picks skin tone / colours / hair. opts: { name, outfit, shadows, look: { coat, trousers, skin, hair, hairStyle, eyes, build } }
 * Returns { group, head, materials, setEyeGlow, setMonster(t), update(dt, state), setName(n), dispose() }
 * state: { x, z, yaw, pitch, speed, crouch, down, hidden, flashlight, y }
 */
export function createAvatar (id, opts = {}) {
  const h = hashId(id)
  const o = { ...OUTFITS[opts.outfit ?? 'conductor'] }
  if (opts.outfit === 'explorer') o.coat = COATS[h % COATS.length]
  const look = opts.look ?? {}
  if (look.coat != null) o.coat = look.coat
  if (look.trousers != null) o.trousers = look.trousers
  const female = o.child || ((h >> 5) % 2 === 1)
  const hairStyle = look.hairStyle ?? (o.child ? 'ponytail' : female ? ['long', 'bob', 'bun', 'ponytail'][(h >> 7) % 4] : ['short', 'short', 'bald'][(h >> 7) % 3])
  const build = look.build ?? (0.92 + ((h >> 9) % 5) * 0.04) // slimmer … broader
  const mat = (color, rough = 0.8, metal = 0) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal })
  const M = {
    coat: clothMat(o.coat, 0.88), trim: mat(o.trim, 0.4, opts.outfit === 'conductor' ? 0.7 : 0),
    trousers: clothMat(o.trousers, 0.92), shoes: mat(o.shoes, 0.45), skin: skinMat(look.skin ?? SKIN[h % SKIN.length], { rough: 0.6 }),
    hair: hairMat(look.hair ?? HAIR[(h >> 3) % HAIR.length]),
    hat: o.hatColor != null ? clothMat(o.hatColor, 0.7) : null, dark: mat(0x1a1a1a, 0.5, 0.4), lens: new THREE.MeshBasicMaterial({ color: 0xfff1c8 }),
  }
  const cast = opts.shadows !== false
  const add = (geo, m, parent, x = 0, y = 0, z = 0) => {
    const me = new THREE.Mesh(geo, m)
    me.position.set(x, y, z)
    me.castShadow = cast
    parent.add(me)
    return me
  }
  const joint = (parent, x, y, z) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); return g }
  const b = build
  const kid = o.child ? 1 : 0

  const group = new THREE.Group()
  const body = joint(group, 0, 0, 0) // everything that tilts when downed
  const hips = joint(body, 0, 0.93, 0)
  // pelvis (trousers)
  add(memo(`pelvis${b}`, () => { const g = new THREE.SphereGeometry(1, 18, 12); g.scale(0.16 * b, 0.12, 0.115); return g }), M.trousers, hips, 0, 0.0, 0)
  const spine = joint(hips, 0, 0.08, 0)
  // torso: shaped (chest, waist, shoulders), in the coat's cloth
  add(memo(`torso${b}${female}`, () => torsoGeo({ h: 0.5, hip: 0.15 * b, waist: (female ? 0.125 : 0.135) * b, chest: 0.168 * b, shoulder: (female ? 0.17 : 0.19) * b, neck: 0.056, depth: 0.66, bust: female && !kid ? 0.5 : 0 })), M.coat, spine, 0, -0.03, 0)
  if (o.coatTail) {
    const tail = add(memo('coattail', () => { const g = new THREE.CylinderGeometry(0.17, 0.23, 0.42, 18, 1, true); g.scale(1, 1, 0.72); return g }), M.coat, spine, 0, -0.18, 0)
    tail.material = M.coat.clone(); tail.material.side = THREE.DoubleSide
    for (let i = 0; i < 4; i++) add(memo('button', () => new THREE.SphereGeometry(0.012, 8, 6)), M.trim, spine, 0, 0.4 - i * 0.1, 0.117)
    add(memo('belt', () => { const g = new THREE.TorusGeometry(0.152, 0.018, 6, 24); g.rotateX(Math.PI / 2); g.scale(1, 1, 0.7); return g }), M.dark, spine, 0, 0.04, 0)
  } else {
    // hoodie pocket + drawstrings
    add(memo('pocket', () => { const g = new THREE.SphereGeometry(1, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2); g.scale(0.11, 0.05, 0.02); g.rotateX(-Math.PI / 2); return g }), M.coat, spine, 0, 0.12, 0.1)
    for (const sx of [-0.035, 0.035]) add(memo('string', () => new THREE.CylinderGeometry(0.004, 0.004, 0.14, 5)), M.trim, spine, sx, 0.4, 0.105)
  }
  if (o.pack) {
    const pack = add(memo('pack', () => { const g = new THREE.SphereGeometry(1, 14, 10); g.scale(0.15, 0.19, 0.07); return g }), mat(0x2b2b30, 0.8), spine, 0, 0.28, -0.15)
    pack.rotation.x = 0.05
    for (const sx of [-0.09, 0.09]) add(memo('strap', () => new THREE.BoxGeometry(0.035, 0.42, 0.02)), mat(0x1c1c20), spine, sx, 0.3, 0.115)
  }
  if (o.apron) {
    const apron = add(memo('apron', () => { const g = new THREE.CylinderGeometry(0.17, 0.2, 0.55, 16, 1, true, -0.9, 1.8); g.scale(1, 1, 0.66); return g }), (() => { const m = clothMat(o.apron, 0.9); m.side = THREE.DoubleSide; return m })(), spine, 0, 0.12, 0.012)
    apron.castShadow = false
    add(memo('badge', () => new THREE.BoxGeometry(0.075, 0.045, 0.006)), mat(0xf2ead6, 0.6), spine, 0.06, 0.33, 0.12)
  }
  const neck = joint(spine, 0, 0.445, 0)
  add(memo('neck', () => limbGeo(0.056, 0.064, 0.09, { bulge: 0 })), M.skin, neck, 0, 0.075, 0)
  const head = joint(neck, 0, 0.085, 0)
  const headScale = 0.108 * (kid ? 1.12 : 1)
  const face = buildHead({
    skin: M.skin, eyeColor: look.eyes ?? EYES[(h >> 4) % EYES.length], browColor: look.hair ?? HAIR[(h >> 3) % HAIR.length],
    lipColor: female ? 0xb5615c : 0xa36a60, headOpts: { jaw: female ? 0.9 : 1.1, brow: female ? 0.7 : 1.1, nose: kid ? 0.7 : 1, chin: female ? 0.9 : 1.1 },
  })
  face.group.scale.setScalar(headScale)
  face.group.position.set(0, 0.085, 0.012)
  head.add(face.group)
  if (hairStyle !== 'bald') {
    const hair = add(memo(`hair-${hairStyle}`, () => hairGeo(hairStyle)), M.hair, head, 0, 0.085, 0.012)
    hair.scale.setScalar(headScale)
  }
  // the hidden monster parts (Night Owl Market's things that aren't people)
  const maw = new THREE.Group()
  {
    const gums = new THREE.Mesh(memo('maw', () => { const g = new THREE.SphereGeometry(1, 16, 12, 0, Math.PI * 2, Math.PI * 0.35, Math.PI * 0.5); g.scale(0.45, 0.7, 0.3); return g }), new THREE.MeshStandardMaterial({ color: 0x2a0306, roughness: 0.5, side: THREE.DoubleSide }))
    maw.add(gums)
    const teeth = new THREE.Mesh(memo('teeth', () => {
      const parts = []
      for (let k = 0; k < 16; k++) { const a = (k / 16) * Math.PI * 2; const c = new THREE.ConeGeometry(0.035, 0.22, 5); c.rotateZ(a + Math.PI / 2); c.translate(Math.cos(a) * 0.4, Math.sin(a) * 0.55, 0.12); parts.push(c) }
      const g = parts[0].clone(); return parts.length ? mergeAll(parts) : g
    }), new THREE.MeshStandardMaterial({ color: 0xe8e0c8, roughness: 0.35 }))
    maw.add(teeth)
    maw.position.set(0, -0.55, 0.86)
    maw.scale.setScalar(0.001)
    maw.visible = false
    face.group.add(maw)
  }
  // arms with hands
  const nailMat = new THREE.MeshStandardMaterial({ color: 0x2a2420, roughness: 0.35 })
  const arms = [-1, 1].map(side => {
    const shoulder = joint(spine, side * 0.19 * b, 0.43, 0)
    add(memo(`upperarm${b}`, () => limbGeo(0.05 * b, 0.042 * b, 0.28, { bulge: 0.16, at: 0.35 })), M.coat, shoulder, 0, -0.01, 0)
    const elbow = joint(shoulder, 0, -0.29, 0)
    add(memo(`forearm${b}`, () => limbGeo(0.044 * b, 0.034, 0.25, { bulge: 0.14, at: 0.22 })), M.coat, elbow, 0, 0, 0)
    add(memo('cuff', () => limbGeo(0.037, 0.037, 0.02, { bulge: 0 })), M.coat, elbow, 0, -0.24, 0)
    const wrist = joint(elbow, 0, -0.255, 0)
    const hg = memo(`hand${side}`, () => { const g = handGeo({ claws: 1 }); if (side < 0) { g.skin.scale(-1, 1, 1); g.nails?.scale(-1, 1, 1) } return g })
    const hand = add(hg.skin, M.skin, wrist, 0, 0, 0)
    hand.rotation.y = side * -Math.PI / 2 // palms face the body
    const claws = hg.nails ? add(hg.nails, nailMat, wrist, 0, 0, 0) : null
    if (claws) { claws.rotation.y = hand.rotation.y; claws.scale.setScalar(0.001); claws.visible = false }
    return { shoulder, elbow, wrist, claws }
  })
  // flashlight in the right hand
  const torch = joint(arms[1].elbow, 0, -0.3, 0.02)
  torch.rotation.x = Math.PI / 2 // torch points along the forearm
  add(memo('torch', () => { const g = new THREE.CylinderGeometry(0.022, 0.028, 0.17, 12); g.rotateX(Math.PI / 2); return g }), M.dark, torch, 0, 0, 0.04)
  const lens = add(memo('lens', () => new THREE.CircleGeometry(0.026, 12)), M.lens, torch, 0, 0, 0.126)
  lens.castShadow = false
  const lamp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex(), color: 0xfff0c8, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.9 }))
  lamp.scale.setScalar(0.32)
  lamp.position.set(0, 0, 0.14)
  torch.add(lamp)
  const beamMat = new THREE.MeshBasicMaterial({ color: 0xffe6b0, transparent: true, opacity: 0.06, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide })
  const beam = new THREE.Mesh(memo('beam', () => new THREE.ConeGeometry(0.75, 5, 22, 1, true).translate(0, -2.5, 0).rotateX(-Math.PI / 2)), beamMat)
  beam.position.z = 0.14
  torch.add(beam)
  const torchGrip = new THREE.Group() // the torch is only drawn when it's on, so empty hands look like hands
  torch.visible = false
  void torchGrip
  // legs
  const legs = [-1, 1].map(side => {
    const hip = joint(hips, side * 0.088 * b, -0.02, 0)
    add(memo(`thigh${b}`, () => limbGeo(0.078 * b, 0.054, 0.43, { bulge: 0.1, at: 0.25 })), M.trousers, hip, 0, 0, 0)
    const knee = joint(hip, 0, -0.43, 0)
    add(memo(`shin${b}`, () => limbGeo(0.056, 0.04, 0.42, { bulge: 0.16, at: 0.28 })), M.trousers, knee, 0, 0, 0)
    const ankle = joint(knee, 0, -0.44, 0)
    add(memo('shoe', () => footGeo({ len: 0.26, w: 0.05, h: 0.065 })), M.shoes, ankle, 0, -0.02, 0)
    return { hip, knee, ankle }
  })
  // headwear
  if (o.hat === 'cap') {
    add(memo('capcrown', () => { const g = new THREE.SphereGeometry(0.12, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2); g.scale(1, 0.75, 1.05); return g }), M.hat, head, 0, 0.125, 0)
    const visor = add(memo('visor', () => { const g = new THREE.CylinderGeometry(0.11, 0.11, 0.01, 18, 1, false, -Math.PI / 2, Math.PI); g.scale(1, 1, 0.85); return g }), M.dark, head, 0, 0.13, 0.03)
    visor.rotation.x = 0.12
    add(memo('capbadge', () => new THREE.BoxGeometry(0.045, 0.028, 0.008)), M.trim, head, 0, 0.17, 0.12)
  } else if (o.hat === 'hood') {
    const hood = add(memo('hood', () => new THREE.SphereGeometry(0.15, 18, 12, Math.PI * 0.18, Math.PI * 1.64, 0, Math.PI * 0.62)), M.coat, head, 0, 0.07, -0.015)
    hood.material = M.coat.clone(); hood.material.side = THREE.DoubleSide
    hood.rotation.y = Math.PI
  }
  let label = nameSprite(opts.name ?? '')
  label.position.y = 2.05
  group.add(label)

  let phase = 0
  let crouchT = 0
  let downT = 0
  let monster = 0
  let lastName = opts.name ?? ''
  let breath = Math.random() * 6

  if (o.small) group.scale.setScalar(0.8)
  const api = {
    group,
    head,
    materials: { ...M, eye: face.irisMat, sclera: face.eyeMat },
    /** glowing eyes (for things pretending to be people) */
    setEyeGlow (on, color = 0xffe08a) {
      face.irisMat.emissive.setHex(on ? color : 0x000000); face.irisMat.emissiveIntensity = on ? 3 : 0
      face.eyeMat.emissive.setHex(on ? color : 0x000000); face.eyeMat.emissiveIntensity = on ? 0.6 : 0
    },
    /** 0 = a person … 1 = what's underneath: the jaw splits open, claws push out */
    setMonster (t) {
      monster = t
      maw.visible = t > 0.02
      maw.scale.setScalar(Math.max(0.001, t))
      for (const a of arms) if (a.claws) { a.claws.visible = t > 0.02; a.claws.scale.setScalar(Math.max(0.001, t * 1.6)) }
    },
    setName (n) {
      if (n === lastName) return
      lastName = n
      group.remove(label)
      label.material.map.dispose()
      label = nameSprite(n)
      label.position.y = 2.05
      group.add(label)
    },
    /** Smoothly pose the model. speed in m/s. */
    update (dt, st) {
      group.visible = !st.hidden && !st.gone
      group.position.set(st.x, st.y ?? 0, st.z)
      group.rotation.y = st.yaw + Math.PI // our yaw 0 looks along -z, the model faces +z
      const speed = st.down ? 0 : Math.min(6, st.speed ?? 0)
      crouchT += ((st.crouch ? 1 : 0) - crouchT) * Math.min(1, dt * 8)
      downT += ((st.down ? 1 : 0) - downT) * Math.min(1, dt * 4)
      const running = speed > 3.2
      phase += dt * (speed > 0.15 ? (running ? 11 : 7.5) * Math.min(1.3, speed / (running ? 4.3 : 2.3)) : 0)
      breath += dt
      const s = Math.sin(phase), c = Math.cos(phase)
      const amp = speed > 0.15 ? Math.min(1, speed / 2.3) * (running ? 0.85 : 0.55) : 0
      // legs: hip swing, knee bends on the forward swing, foot rolls heel to toe
      legs.forEach((l, i) => {
        const ph = i ? -s : s
        const pc = i ? -c : c
        l.hip.rotation.x = -ph * amp * 0.75 - crouchT * 1.25
        l.knee.rotation.x = Math.max(0, -pc) * amp * 1.25 + crouchT * 2.1 + 0.03
        l.ankle.rotation.x = (ph > 0 ? -ph * 0.35 : -ph * 0.15) * amp - crouchT * 0.8
      })
      hips.position.y = 0.93 - crouchT * 0.38 + (speed > 0.15 ? Math.abs(c) * 0.035 * amp : Math.sin(breath * 0.8) * 0.003)
      hips.rotation.y = s * amp * 0.12 // pelvis turns with each stride
      spine.rotation.y = -s * amp * 0.18 // shoulders counter-rotate
      spine.rotation.x = crouchT * 0.45 + (running ? 0.18 : 0.04) + monster * 0.35
      spine.scale.set(1, 1 + Math.sin(breath * 1.6) * 0.006, 1 + Math.sin(breath * 1.6) * 0.01) // breathing
      // arms swing opposite; the torch arm points where the player looks
      arms.forEach((a, i) => {
        const ph = i ? s : -s
        if (i === 1 && st.flashlight) {
          a.shoulder.rotation.x = -1.25 - (st.pitch ?? 0) * 0.9
          a.elbow.rotation.x = -0.25
        } else if (monster > 0.5) {
          a.shoulder.rotation.x = -1.3 + ph * 0.3
          a.elbow.rotation.x = -0.4
        } else {
          a.shoulder.rotation.x = ph * amp * 0.8 - crouchT * 0.4
          a.elbow.rotation.x = -0.2 - amp * 0.45 - crouchT * 0.3
        }
        a.shoulder.rotation.z = (i ? -1 : 1) * (0.07 + Math.sin(breath * 1.6) * 0.01)
        a.wrist.rotation.x = -0.1 - amp * 0.15
      })
      head.rotation.x = -(st.pitch ?? 0) * 0.6
      head.rotation.y = -spine.rotation.y * 0.8 // keep looking ahead while walking
      face.update(dt)
      // downed: lying on the side, one arm reaching
      body.rotation.z = downT * 1.45
      body.position.y = downT * 0.18
      body.position.x = -downT * 0.75
      if (downT > 0.5) { arms[0].shoulder.rotation.x = -2.6 + Math.sin(performance.now() / 500) * 0.15 }
      const lit = !!st.flashlight && !st.down
      torch.visible = lit
      lamp.visible = lit
      beam.visible = lit
      label.position.y = 2.05 - crouchT * 0.4 - downT * 1.3
    },
    dispose () {
      // shapes are shared between characters: only drop this one's materials
      group.traverse(m => { if (m.isMesh && m.material && !Object.values(M).includes(m.material)) m.material.dispose?.() })
      group.removeFromParent()
    },
  }
  return api
}

function mergeAll (geos) {
  // small local merge for the teeth (avoids importing the addon twice)
  let n = 0
  for (const g of geos) n += (g.index ? g.index.count : g.attributes.position.count)
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3)
  let o = 0
  for (const g0 of geos) {
    const g = g0.index ? g0.toNonIndexed() : g0
    pos.set(g.attributes.position.array, o * 3)
    nor.set(g.attributes.normal.array, o * 3)
    o += g.attributes.position.count
  }
  const out = new THREE.BufferGeometry()
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3))
  return out
}
