// Controller support shared by the site's games (Xbox / PlayStation / Switch Pro and most USB pads).
// In play: left stick moves, right stick looks, buttons map to each game's actions.
// In menus: D-pad or left stick moves between buttons, A presses, B goes back, Start pauses / resumes.
//
// Uses the browser's "standard" layout:
//   0 A / Cross   1 B / Circle   2 X / Square   3 Y / Triangle   4 LB   5 RB   6 LT   7 RT
//   8 Back / Share   9 Start / Options   10 left stick click   11 right stick click   12-15 D-pad up, down, left, right

const MENUS = '.screen.is-open, #note.is-open'

export const BTN = { A: 0, B: 1, X: 2, Y: 3, LB: 4, RB: 5, LT: 6, RT: 7, BACK: 8, START: 9, LS: 10, RS: 11, UP: 12, DOWN: 13, LEFT: 14, RIGHT: 15 }

const DEAD = 0.18
const shape = v => { const a = Math.abs(v); if (a < DEAD) return 0; const t = (a - DEAD) / (1 - DEAD); return Math.sign(v) * t * t }

/**
 * input: the game's input object ({ move, look, held, pressed, enabled })
 * opts.held:  { [button]: 'heldName' }   held while the button is down
 * opts.press: { [button]: 'action' }     one press per push
 * opts.sprintStick: push the left stick all the way (or click it) to sprint
 * opts.lookSpeed: how fast the right stick turns (default 1100)
 */
export function initGamepad (input, opts = {}) {
  if (!('getGamepads' in navigator)) return
  const held = opts.held ?? {}
  const press = opts.press ?? {}
  const lookSpeed = opts.lookSpeed ?? 1100
  let prev = []
  let usedSticks = false
  let sprintLatch = false
  let navRepeatAt = 0
  let lastDir = null
  let announced = false
  let last = performance.now()

  addEventListener('gamepadconnected', e => { toastPad(`Controller connected: ${shortName(e.gamepad.id)}`); announced = true })
  addEventListener('gamepaddisconnected', () => toastPad('Controller disconnected'))

  const menuOpen = () => !input.enabled || !!document.querySelector(MENUS)

  function tick () {
    requestAnimationFrame(tick)
    const now = performance.now()
    const dt = Math.min(0.05, (now - last) / 1000)
    last = now
    const pads = [...(navigator.getGamepads?.() ?? [])].filter(Boolean)
    const pad = pads.find(p => p.connected && (p.mapping === 'standard' || p.buttons.length >= 16)) ?? pads[0]
    if (!pad) { prev = []; return }
    if (!announced) { announced = true; toastPad(`Controller connected: ${shortName(pad.id)}`) }
    const down = pad.buttons.map(b => b.pressed || b.value > 0.5)
    const was = i => !!prev[i]
    const pressed = i => down[i] && !was(i)
    const released = i => !down[i] && was(i)
    const [lx = 0, ly = 0, rx = 0, ry = 0] = pad.axes

    document.body.classList.toggle('pad-ui', true)

    if (menuOpen()) {
      // let go of anything the game thinks is held
      if (usedSticks) { input.move.x = 0; input.move.y = 0; usedSticks = false }
      for (const name of Object.values(held)) if (input.held[name]) input.held[name] = false
      navigateMenus(down, pressed, lx, ly, now)
      prev = down
      return
    }

    // ── in play ──
    const mx = shape(lx), my = -shape(ly)
    if (mx || my) { input.move.x = mx; input.move.y = my; usedSticks = true } else if (usedSticks) { input.move.x = 0; input.move.y = 0; usedSticks = false }
    if (opts.sprintStick) {
      if (pressed(BTN.LS)) sprintLatch = true
      if (!mx && !my) sprintLatch = false
      const full = Math.hypot(lx, ly) > 0.95 && -ly > 0.6
      if (sprintLatch || full) input.held.sprint = true
      else if (usedSticks || was(BTN.LS)) input.held.sprint = false
    }
    const lxv = shape(rx), lyv = shape(ry)
    input.look.x += lxv * lookSpeed * dt
    input.look.y += lyv * lookSpeed * 0.75 * dt
    for (const [b, name] of Object.entries(held)) {
      if (pressed(+b)) input.held[name] = true
      if (released(+b)) input.held[name] = false
    }
    for (const [b, action] of Object.entries(press)) {
      if (!pressed(+b)) continue
      for (const a of [].concat(action)) input.pressed.add(a)
    }
    if (pressed(BTN.START)) input.pressed.add('pause')
    prev = down
  }

  requestAnimationFrame(tick)

  function navigateMenus (down, pressed, lx, ly, now) {
    const items = focusables()
    if (!items.length) return
    const active = items.includes(document.activeElement) ? document.activeElement : null
    let dir = null
    if (down[BTN.UP] || ly < -0.6) dir = 'up'
    else if (down[BTN.DOWN] || ly > 0.6) dir = 'down'
    else if (down[BTN.LEFT] || lx < -0.6) dir = 'left'
    else if (down[BTN.RIGHT] || lx > 0.6) dir = 'right'
    if (dir && (dir !== lastDir || now > navRepeatAt)) {
      navRepeatAt = now + (dir === lastDir ? 140 : 380)
      let next = active ? nearest(active, items, dir) : items[0]
      // nothing directly above / below: go to the next or previous item in the list (wrapping)
      if (!next && active && (dir === 'up' || dir === 'down')) next = items[(items.indexOf(active) + (dir === 'down' ? 1 : -1) + items.length) % items.length]
      if (next) next.focus({ preventScroll: false })
      // sliders: left/right changes the value
      if (active?.type === 'range' && (dir === 'left' || dir === 'right') && !next) {
        if (dir === 'left') active.stepDown(); else active.stepUp()
        active.dispatchEvent(new Event('input', { bubbles: true }))
      }
    }
    lastDir = dir
    if (pressed(BTN.A)) {
      if (!active) items[0].focus()
      else if (active.tagName === 'INPUT' && active.type !== 'range') active.focus()
      else active.click()
    }
    if (pressed(BTN.B) || (pressed(BTN.START) && document.querySelector('[data-go=resume]:not([hidden])')?.offsetParent)) {
      const back = ['[data-go=resume]', '[data-go=back]', '[data-go=close-panel]', '[data-go=close-note]', '[data-go=leave]']
        .map(s => [...document.querySelectorAll(s)].find(visible)).find(Boolean)
      back?.click()
    }
  }
}

const visible = el => {
  if (!el || el.disabled || el.hidden) return false
  if (el.closest('#touch, #hud, [hidden]')) return false
  const r = el.getBoundingClientRect()
  if (r.width < 2 || r.height < 2) return false
  const cs = getComputedStyle(el)
  return cs.visibility !== 'hidden' && cs.display !== 'none' && el.offsetParent !== null
}
function focusables () {
  // prefer whatever is on top: an open screen, else a visible panel like the door check
  const root = [...document.querySelectorAll(MENUS)].pop() ?? document
  return [...root.querySelectorAll('button, a[href], input, select, [tabindex="0"]')].filter(visible)
}
function nearest (from, items, dir) {
  const a = from.getBoundingClientRect()
  const ax = a.left + a.width / 2, ay = a.top + a.height / 2
  let best = null, bestScore = Infinity
  for (const el of items) {
    if (el === from) continue
    const r = el.getBoundingClientRect()
    const x = r.left + r.width / 2, y = r.top + r.height / 2
    const dx = x - ax, dy = y - ay
    const along = dir === 'up' ? -dy : dir === 'down' ? dy : dir === 'left' ? -dx : dx
    // sideways distance between the two boxes' edges (0 when they line up), so left-aligned lists work
    const across = dir === 'up' || dir === 'down'
      ? Math.max(0, Math.max(a.left, r.left) - Math.min(a.right, r.right))
      : Math.max(0, Math.max(a.top, r.top) - Math.min(a.bottom, r.bottom))
    if (along <= 4) continue
    const score = along + across * 2.2
    if (score < bestScore) { bestScore = score; best = el }
  }
  return best
}

const shortName = id => (/xbox|xinput/i.test(id) ? 'Xbox' : /dualsense|dualshock|playstation|054c/i.test(id) ? 'PlayStation' : /pro controller|057e/i.test(id) ? 'Switch Pro' : 'gamepad')

let toastEl = null, toastTimer = 0
function toastPad (text) {
  if (!toastEl) {
    toastEl = document.createElement('div')
    toastEl.setAttribute('role', 'status')
    toastEl.style.cssText = 'position:fixed;left:50%;bottom:max(18px,env(safe-area-inset-bottom));transform:translateX(-50%);z-index:60;padding:8px 14px;background:rgba(10,10,14,.85);color:#fff;font:600 14px system-ui,sans-serif;border-radius:4px;pointer-events:none;transition:opacity .3s;opacity:0'
    document.body.appendChild(toastEl)
  }
  toastEl.textContent = text
  toastEl.style.opacity = '1'
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastEl.style.opacity = '0' }, 2600)
}

// make the focused menu item easy to see when using a pad
const style = document.createElement('style')
style.textContent = 'body.pad-ui :focus { outline: 3px solid #ffd23f !important; outline-offset: 3px; }'
document.head.appendChild(style)
