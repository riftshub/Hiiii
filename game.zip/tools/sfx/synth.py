"""Small offline synthesizer used to render the games' sound files (numpy + scipy).

Everything here is deterministic for a given seed so re-running gives the same files.
"""
import numpy as np
from scipy import signal

SR = 44100
rng = np.random.default_rng(7)


def seed(n):
    global rng
    rng = np.random.default_rng(n)


def t_axis(dur):
    return np.arange(int(dur * SR)) / SR


def noise(dur, color='white'):
    n = rng.standard_normal(int(dur * SR))
    if color == 'pink':
        b = [0.049922035, -0.095993537, 0.050612699, -0.004408786]
        a = [1, -2.494956002, 2.017265875, -0.522189400]
        n = signal.lfilter(b, a, n) * 4
    elif color == 'brown':
        n = np.cumsum(n)
        n = signal.lfilter([1, -1], [1, -0.995], n)  # remove drift
        n /= (np.abs(n).max() + 1e-9)
    return n


def bp(x, lo, hi, order=2):
    lo = max(lo, 5)
    hi = min(hi, SR / 2 - 100)
    sos = signal.butter(order, [lo, hi], btype='band', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def lp(x, f, order=2):
    sos = signal.butter(order, min(f, SR / 2 - 100), btype='low', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def hp(x, f, order=2):
    sos = signal.butter(order, max(f, 5), btype='high', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def peak(x, f, q=8, gain=1.0):
    """Resonant band (formant) added to the signal"""
    b, a = signal.iirpeak(min(f, SR / 2 - 200), q, fs=SR)
    return signal.lfilter(b, a, x) * gain


def sweep_filter(x, f_start, f_end, q=4, kind='bp', steps=64):
    """Time-varying filter done in blocks with overlap (cheap and good enough)"""
    n = len(x)
    out = np.zeros(n)
    block = max(256, n // steps)
    win = np.hanning(block * 2)
    pos = 0
    i = 0
    while pos < n:
        seg = x[max(0, pos - block // 2): pos + block + block // 2]
        frac = min(1, pos / max(1, n))
        f = f_start * (f_end / f_start) ** frac if f_start > 0 and f_end > 0 else f_start + (f_end - f_start) * frac
        if kind == 'bp':
            y = bp(seg, f / (1 + 1 / q), f * (1 + 1 / q))
        elif kind == 'lp':
            y = lp(seg, f)
        else:
            y = hp(seg, f)
        w = np.hanning(len(y))
        s0 = max(0, pos - block // 2)
        out[s0:s0 + len(y)] += y * w
        pos += block
        i += 1
    return out * 0.66


def env_adsr(n, a=0.01, d=0.1, s=0.7, r=0.2, dur=None):
    a_n, d_n, r_n = int(a * SR), int(d * SR), int(r * SR)
    s_n = max(0, n - a_n - d_n - r_n)
    e = np.concatenate([
        np.linspace(0, 1, max(1, a_n)),
        np.linspace(1, s, max(1, d_n)),
        np.full(s_n, s),
        np.linspace(s, 0, max(1, r_n)),
    ])
    return np.pad(e, (0, max(0, n - len(e))))[:n]


def env_exp(n, decay=0.2, attack=0.002):
    t = np.arange(n) / SR
    e = np.exp(-t / decay)
    a_n = int(attack * SR)
    if a_n > 1:
        e[:a_n] *= np.linspace(0, 1, a_n)
    return e


def osc(freq, dur, kind='sine', phase=0.0):
    """freq: number or array (per-sample)"""
    n = int(dur * SR)
    f = np.full(n, float(freq)) if np.isscalar(freq) else np.asarray(freq)[:n]
    ph = 2 * np.pi * np.cumsum(f) / SR + phase
    if kind == 'sine':
        return np.sin(ph)
    if kind == 'saw':
        return 2 * ((ph / (2 * np.pi)) % 1) - 1
    if kind == 'square':
        return np.sign(np.sin(ph))
    if kind == 'tri':
        return 2 * np.abs(2 * ((ph / (2 * np.pi)) % 1) - 1) - 1
    if kind == 'pulse':
        # glottal-ish pulse train (for voices)
        p = (ph / (2 * np.pi)) % 1
        return np.where(p < 0.4, np.sin(np.pi * p / 0.4) ** 2, 0) * 2 - 0.5
    raise ValueError(kind)


def glide(points, dur):
    """points: [(time_fraction, value), ...] -> per-sample curve (log interpolation)"""
    n = int(dur * SR)
    xs = np.array([p[0] for p in points]) * n
    ys = np.log(np.array([p[1] for p in points], dtype=float))
    return np.exp(np.interp(np.arange(n), xs, ys))


def lin(points, dur):
    n = int(dur * SR)
    xs = np.array([p[0] for p in points]) * n
    ys = np.array([p[1] for p in points], dtype=float)
    return np.interp(np.arange(n), xs, ys)


def distort(x, drive=3.0):
    return np.tanh(x * drive) / np.tanh(drive)


def bitcrush(x, bits=6, down=4):
    y = np.round(x * 2 ** bits) / 2 ** bits
    y = np.repeat(y[::down], down)[:len(x)]
    return np.pad(y, (0, len(x) - len(y)))


def ring(x, f):
    return x * np.sin(2 * np.pi * f * np.arange(len(x)) / SR)


def reverb(x, decay=1.2, mix=0.3, predelay=0.012, bright=6000, stereo=False):
    n = int(decay * SR * 1.5)
    ir_l = rng.standard_normal(n) * np.exp(-np.arange(n) / (decay * SR / 6.9))
    ir_l = lp(ir_l, bright)
    ir_l[:int(predelay * SR)] = 0
    ir_l /= np.sqrt(np.sum(ir_l ** 2)) + 1e-9
    wet_l = np.pad(signal.fftconvolve(x, ir_l), (0, 1))[:len(x) + n]
    dry = np.pad(x, (0, n))
    if not stereo:
        return dry * (1 - mix) + wet_l * mix
    ir_r = rng.standard_normal(n) * np.exp(-np.arange(n) / (decay * SR / 6.9))
    ir_r = lp(ir_r, bright)
    ir_r[:int(predelay * SR)] = 0
    ir_r /= np.sqrt(np.sum(ir_r ** 2)) + 1e-9
    wet_r = np.pad(signal.fftconvolve(x, ir_r), (0, 1))[:len(x) + n]
    return np.stack([dry * (1 - mix) + wet_l * mix, dry * (1 - mix) + wet_r * mix], axis=1)


def place(dst, src, at):
    """mix src into dst at time `at` seconds (mono)"""
    i = int(at * SR)
    if i >= len(dst):
        return dst
    m = min(len(src), len(dst) - i)
    dst[i:i + m] += src[:m]
    return dst


def silence(dur):
    return np.zeros(int(dur * SR))


def fade(x, fin=0.005, fout=0.02):
    x = x.copy()
    a, b = int(fin * SR), int(fout * SR)
    if a > 1:
        x[:a] *= np.linspace(0, 1, a)[:, None] if x.ndim == 2 else np.linspace(0, 1, a)
    if b > 1:
        x[-b:] *= np.linspace(1, 0, b)[:, None] if x.ndim == 2 else np.linspace(1, 0, b)
    return x


def make_loop(x, xfade=1.0):
    """Seamless loop: crossfade the tail into the head"""
    n = int(xfade * SR)
    if x.ndim == 1:
        head, body, tail = x[:n], x[n:-n] if n else x, x[-n:]
        ramp = np.linspace(0, 1, n)
        joined = tail * (1 - ramp) + head * ramp
        return np.concatenate([joined, x[n:-n]])
    ramp = np.linspace(0, 1, n)[:, None]
    joined = x[-n:] * (1 - ramp) + x[:n] * ramp
    return np.concatenate([joined, x[n:-n]])


def normalize(x, peak_db=-1.0):
    p = np.abs(x).max() + 1e-9
    return x / p * 10 ** (peak_db / 20)


# ───────────── voice helpers ─────────────

VOWELS = {  # F1, F2, F3 (Hz)
    'a': (800, 1200, 2500), 'e': (500, 1900, 2600), 'i': (320, 2400, 3000),
    'o': (500, 900, 2400), 'u': (330, 800, 2300), 'aa': (700, 1100, 2400), 'ow': (600, 900, 2300),
}


def formant_voice(pitch, vowels, dur, breath=0.15, q=(9, 12, 14), gains=(1.0, 0.6, 0.3)):
    """pitch: number or curve. vowels: list of vowel keys spread across the duration."""
    src = osc(pitch, dur, 'pulse') + noise(dur) * breath
    n = len(src)
    out = np.zeros(n)
    segs = len(vowels)
    seg_n = n // segs
    for k, v in enumerate(vowels):
        nxt = vowels[min(k + 1, segs - 1)]
        s0 = k * seg_n
        s1 = n if k == segs - 1 else (k + 1) * seg_n
        piece = src[max(0, s0 - 512): s1 + 512]
        y = np.zeros(len(piece))
        for fi in range(3):
            f = (VOWELS[v][fi] + VOWELS[nxt][fi]) / 2
            y += peak(piece, f, q[fi], gains[fi])
        w = np.hanning(len(y))
        out[max(0, s0 - 512): max(0, s0 - 512) + len(y)] += (y * w)[:n - max(0, s0 - 512)]
    return out
